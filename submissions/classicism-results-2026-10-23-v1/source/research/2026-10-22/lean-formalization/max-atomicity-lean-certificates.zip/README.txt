COMPLETE LEAN VERIFICATION CERTIFICATES

Verified theorem:
Classicism.Meta.Research.MaxAtomicityInconsistency.maximalism_atomicity_inconsistent
  : not (AxiomSet.maximalist union P.AtomicityT.schema).Consistent

This is C + pure Max(C) + unboxed Atomicity_t. The theorem has no mathematical
input premises. Its complete axiom report contains only propext,
Classical.choice, and Quot.sound: no sorryAx or custom mathematical axiom.

This package contains all48 checked MaxAtomicity modules and their current
local Classicism dependency closure, matching compiled .olean proof artifacts,
source files, immutable compiler manifests, compiler logs/axiom reports,
ordinary proof guide, and source audit. MANIFEST.json binds included sources
and proof artifacts by SHA-256. The compiler manifest also records the exact
external compiler and dependency binary hashes used for the successful check.

The pinned Lean4.33.1 and Mathlib installation are external prerequisites and
are not bundled. The existing project installation supplies them. Standalone
import requires those pinned dependencies and an appropriate LEAN_PATH.
The evidence index contains the serial reproduction command; no download was
needed for the verification in this workspace.
