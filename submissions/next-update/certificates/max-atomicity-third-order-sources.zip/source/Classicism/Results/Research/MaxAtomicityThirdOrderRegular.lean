import Classicism.Results.Research.MaxAtomicityThirdOrderDomains
import Classicism.Results.Research.MaxAtomicityJechShelahIndexCoding

/-!
# Regular opens as third-order characteristic codes

The representation is built directly from sets of natural-number tree indices.
No set-theoretic universe or collapse is used. The regularity clause is the
finite density clause in the third-order rewrite. All representation and
order-reflection obligations are proved below.

Direct source: original formalization, misc, 25 October 2026; upstream
Max--Atomicity rewrite, section 2 (unpaginated; upstream-comparison.md).
Verification evidence is recorded in the accompanying third-order status and compiler manifests.
-/

namespace Classicism.Meta.Research.MaxAtomicityThirdOrderRegular

set_option backward.isDefEq.respectTransparency false

open MaxAtomicityThirdOrderDomains MaxAtomicityRegularCompletion
open MaxAtomicityJechShelahTrees MaxAtomicityJechShelahEnumeration
open MaxAtomicityJechShelahCylinders MaxAtomicityJechShelahIndexedGenerators
open MaxAtomicityJechShelahIndexCoding MaxAtomicityJechShelahRigidityCriterion

noncomputable section

/-- Inclusion of extensions, using identity to top throughout. -/
def SubsetCode {D : Type*} [Top D] {A : Type*} (X Y : A → D) : Prop :=
  ∀ x, X x = ⊤ → Y x = ⊤

/-- The displayed finite regular-open condition. `C` is later replaced by the
explicit finite arithmetic condition formula, not an object-language constant. -/
def RegularCode {D : Type*} [CompleteBooleanAlgebra D]
    (N : D → D) (C : (D → D) → Prop) (U : (D → D) → D) : Prop :=
  ClassCode N U ∧
  (∀ X, U X = ⊤ → C X) ∧
  (∀ X Y, C X → C Y → SubsetCode X Y → U Y = ⊤ → U X = ⊤) ∧
  (∀ X, C X →
    (∀ Y, C Y → SubsetCode Y X →
      ∃ Z, C Z ∧ SubsetCode Z Y ∧ U Z = ⊤) → U X = ⊤)

section LowerSets

variable {α : Type*} [Preorder α]

private def pseudoLower (S : Set α) : LowerSet α where
  carrier := {p | ∀ q, q ≤ p → q ∉ S}
  lower' := by
    intro a b hab hb q hqa
    exact hb q (hqa.trans hab)

private theorem mem_compl (S : LowerSet α) (p : α) :
    p ∈ Sᶜ ↔ ∀ q, q ≤ p → q ∉ S := by
  have heq : pseudoLower (S : Set α) = Sᶜ := by
    apply eq_of_forall_le_iff
    intro T
    rw [le_compl_iff_disjoint_right]
    constructor
    · intro h
      apply disjoint_iff_inf_le.mpr
      intro q hq
      exact (h hq.1) q le_rfl hq.2
    · intro h p hp q hqp hq
      exact (disjoint_iff_inf_le.mp h) ⟨T.lower hqp hp, hq⟩
  change p ∈ Sᶜ ↔ p ∈ pseudoLower (S : Set α)
  rw [heq]

/-- Regularity is exactly density of membership below the tested point. -/
theorem mem_double_compl (S : LowerSet α) (p : α) :
    p ∈ Sᶜᶜ ↔ ∀ q, q ≤ p → ∃ r, r ≤ q ∧ r ∈ S := by
  classical
  rw [mem_compl]
  constructor
  · intro hd q hqp
    by_contra hn
    apply hd q hqp
    apply (mem_compl S q).2
    intro r hr hs
    exact hn ⟨r, hr, hs⟩
  · intro hd q hqp hq
    obtain ⟨r, hr, hs⟩ := hd q hqp
    exact (mem_compl S q).1 hq r hr hs

end LowerSets

variable {D : Type} [CompleteBooleanAlgebra D] [Nontrivial D]
variable {N : D → D} {z : D} {s : D → D} (h : NatFrame N z s)

/-- The arithmetic predicate after its numerical transport has been proved. -/
def TreeCode (X : D → D) : Prop :=
  RealCode N X ∧ IndexCondition (h.realSet X)

def encodeTree (T : Condition) : D → D := h.encodeReal (nodeIndices T)

theorem treeCode_encodeTree (T : Condition) : TreeCode h (encodeTree h T) := by
  exact ⟨h.encodeReal_code _, by
    simpa only [encodeTree, h.realSet_encodeReal] using nodeIndices_indexCondition T⟩

theorem treeCode_iff (X : D → D) :
    TreeCode h X ↔ ∃ T : Condition, encodeTree h T = X := by
  constructor
  · rintro ⟨hX, hi⟩
    obtain ⟨T, ht⟩ := (indexCondition_iff (h.realSet X)).1 hi
    refine ⟨T, ?_⟩
    unfold encodeTree
    rw [ht, h.encodeReal_realSet hX]
  · rintro ⟨T, rfl⟩
    exact treeCode_encodeTree h T

theorem nodeIndices_le_iff (T S : Condition) :
    nodeIndices T ⊆ nodeIndices S ↔ T ≤ S := by
  constructor
  · intro hi t ht
    obtain ⟨u, hu, heq⟩ := hi ⟨t, ht, rfl⟩
    have hut : u = t := index_injective _ _ (S.submaster hu) (T.submaster ht) heq
    exact hut ▸ hu
  · intro hTS j hj
    obtain ⟨t, ht, rfl⟩ := hj
    exact ⟨t, hTS ht, rfl⟩

theorem nodeIndices_injective : Function.Injective nodeIndices := by
  intro T S heq
  exact le_antisymm ((nodeIndices_le_iff T S).1 heq.le)
    ((nodeIndices_le_iff S T).1 heq.ge)

theorem encodeTree_injective : Function.Injective (encodeTree h) := by
  intro T S heq
  exact nodeIndices_injective (h.encodeReal_injective heq)

theorem subsetCode_iff {X Y : D → D} (hX : RealCode N X) (hY : RealCode N Y) :
    SubsetCode X Y ↔ h.realSet X ⊆ h.realSet Y := by
  constructor
  · intro hh n hn
    exact hh _ hn
  · intro hh x hx
    have hxN : N x = ⊤ := (hX x).elim And.left (fun hbot =>
      (bot_ne_top (hbot.symm.trans hx)).elim)
    obtain ⟨n, rfl⟩ := (h.mem_iff_range x).1 hxN
    exact hh hx

theorem encodeTree_subset (T S : Condition) :
    SubsetCode (encodeTree h T) (encodeTree h S) ↔ T ≤ S := by
  unfold encodeTree
  rw [subsetCode_iff h (h.encodeReal_code _) (h.encodeReal_code _)]
  simpa only [encodeTree, h.realSet_encodeReal] using nodeIndices_le_iff T S

/-- The actual canonical third-order code of a regular lower set. -/
def encodeOpen (b : B) : (D → D) → D :=
  h.encodeClass {A | ∃ T : Condition, nodeIndices T = A ∧ T ∈ (b : LowerSet Condition)}

theorem encodeOpen_code (b : B) : ClassCode N (encodeOpen h b) :=
  h.encodeClass_code _

theorem encodeOpen_mem (b : B) (X : D → D) :
    encodeOpen h b X = ⊤ ↔
      ∃ T : Condition, encodeTree h T = X ∧ T ∈ (b : LowerSet Condition) := by
  rw [encodeOpen, h.encodeClass_mem]
  constructor
  · rintro ⟨hX, T, ht, hb⟩
    refine ⟨T, ?_, hb⟩
    unfold encodeTree
    rw [ht, h.encodeReal_realSet hX]
  · rintro ⟨T, rfl, hb⟩
    exact ⟨h.encodeReal_code _, T, (h.realSet_encodeReal _).symm, hb⟩

@[simp] theorem encodeOpen_tree (b : B) (T : Condition) :
    encodeOpen h b (encodeTree h T) = ⊤ ↔ T ∈ (b : LowerSet Condition) := by
  rw [encodeOpen_mem]
  constructor
  · rintro ⟨S, heq, hb⟩
    exact encodeTree_injective h heq ▸ hb
  · intro hb
    exact ⟨T, rfl, hb⟩

theorem encodeOpen_regular (b : B) : RegularCode N (TreeCode h) (encodeOpen h b) := by
  refine ⟨encodeOpen_code h b, ?_, ?_, ?_⟩
  · intro X hx
    obtain ⟨T, rfl, _⟩ := (encodeOpen_mem h b X).1 hx
    exact treeCode_encodeTree h T
  · intro X Y hX hY hXY hYb
    obtain ⟨T, rfl⟩ := (treeCode_iff h X).1 hX
    obtain ⟨S, rfl⟩ := (treeCode_iff h Y).1 hY
    exact (encodeOpen_tree h b T).2
      ((b : LowerSet Condition).lower ((encodeTree_subset h T S).1 hXY)
        ((encodeOpen_tree h b S).1 hYb))
  · intro X hX hdense
    obtain ⟨T, rfl⟩ := (treeCode_iff h X).1 hX
    apply (encodeOpen_tree h b T).2
    have hreg : (b : LowerSet Condition)ᶜᶜ ≤ (b : LowerSet Condition) :=
      le_of_eq b.property.eq
    apply hreg
    apply (mem_double_compl _ T).2
    intro S hST
    obtain ⟨Z, hZ, hZS, hbZ⟩ := hdense (encodeTree h S)
      (treeCode_encodeTree h S) ((encodeTree_subset h S T).2 hST)
    obtain ⟨Q, rfl⟩ := (treeCode_iff h Z).1 hZ
    exact ⟨Q, (encodeTree_subset h Q S).1 hZS, (encodeOpen_tree h b Q).1 hbZ⟩

/-- A regular class defines a lower set without making any choices. -/
def decodeLower (U : (D → D) → D) (hU : RegularCode N (TreeCode h) U) :
    LowerSet Condition where
  carrier := {T | U (encodeTree h T) = ⊤}
  lower' := by
    intro S T hTS hS
    exact hU.2.2.1 _ _ (treeCode_encodeTree h T) (treeCode_encodeTree h S)
      ((encodeTree_subset h T S).2 hTS) hS

theorem decodeLower_regular (U : (D → D) → D)
    (hU : RegularCode N (TreeCode h) U) : Heyting.IsRegular (decodeLower h U hU) := by
  apply le_antisymm
  · intro T hT
    apply hU.2.2.2 _ (treeCode_encodeTree h T)
    intro Y hY hYT
    obtain ⟨S, rfl⟩ := (treeCode_iff h Y).1 hY
    obtain ⟨Q, hQS, hQU⟩ := (mem_double_compl _ T).1 hT S
      ((encodeTree_subset h S T).1 hYT)
    exact ⟨encodeTree h Q, treeCode_encodeTree h Q,
      (encodeTree_subset h Q S).2 hQS, hQU⟩
  · exact le_compl_compl

def decodeOpen (U : (D → D) → D) (hU : RegularCode N (TreeCode h) U) : B :=
  ⟨decodeLower h U hU, decodeLower_regular h U hU⟩

private theorem classCode_ext {U V : (D → D) → D}
    (hU : ClassCode N U) (hV : ClassCode N V)
    (he : ∀ X, U X = ⊤ ↔ V X = ⊤) : U = V := by
  funext X
  rcases classCode_values hU X with ht | hb
  · exact ht.trans ((he X).1 ht).symm
  · rcases classCode_values hV X with ht | hb'
    · exact (bot_ne_top (hb.symm.trans ((he X).2 ht))).elim
    · exact hb.trans hb'.symm

theorem encode_decode (U : (D → D) → D) (hU : RegularCode N (TreeCode h) U) :
    encodeOpen h (decodeOpen h U hU) = U := by
  apply classCode_ext (encodeOpen_code h _) hU.1
  intro X
  rw [encodeOpen_mem]
  constructor
  · rintro ⟨T, rfl, hT⟩
    exact hT
  · intro hx
    obtain ⟨T, rfl⟩ := (treeCode_iff h X).1 (hU.2.1 X hx)
    exact ⟨T, rfl, hx⟩

theorem encodeOpen_injective : Function.Injective (encodeOpen h) := by
  intro b c heq
  apply Heyting.Regular.coe_injective
  apply LowerSet.ext
  apply Set.ext
  intro T
  constructor
  · intro hT
    have ht := (encodeOpen_tree h b T).2 hT
    rw [heq] at ht
    exact (encodeOpen_tree h c T).1 ht
  · intro hT
    have ht := (encodeOpen_tree h c T).2 hT
    rw [← heq] at ht
    exact (encodeOpen_tree h b T).1 ht

theorem regularCode_iff (U : (D → D) → D) :
    RegularCode N (TreeCode h) U ↔ ∃ b : B, encodeOpen h b = U := by
  constructor
  · intro hU
    exact ⟨decodeOpen h U hU, encode_decode h U hU⟩
  · rintro ⟨b, rfl⟩
    exact encodeOpen_regular h b

theorem encodeOpen_subset (b c : B) :
    SubsetCode (encodeOpen h b) (encodeOpen h c) ↔ b ≤ c := by
  constructor
  · intro hh T hT
    exact (encodeOpen_tree h c T).1 (hh _ ((encodeOpen_tree h b T).2 hT))
  · intro hbc X hX
    obtain ⟨T, rfl, hT⟩ := (encodeOpen_mem h b X).1 hX
    exact (encodeOpen_tree h c T).2 (hbc hT)

end

end Classicism.Meta.Research.MaxAtomicityThirdOrderRegular
