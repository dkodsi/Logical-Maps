import Classicism.Results.Records.Lattice
import Classicism.Tools.Check
import Classicism.Tools.TypeSystem
import Classicism.Tools.Translate
import Classicism.Results.Research.MaxAtomicityReduction

/-!
# Direct obstruction to a pure splitter under unboxed Atomicity

This is the small, direct replacement for the bounded-splitter detour. It
leaves the already certified sources unchanged. Source: the original
Max--Atomicity argument, simplified in the map rewrite of 24 October 2026,
Lemma 1, by Claude Opus 5.5 prompted by Cian Dorr:
https://github.com/zwlgzwlg/Logical-Maps/blob/ca7afd1d06cae46c4d8249f13d69e95f11d8dea3/logical-maps/topics/classicism/writeups/maximalist-distinctness-incompatible-with-atomicity-t.md

Atomicity is used once, at the splitter sentence itself, and remains unboxed.
Everything passed to necessitation is a theorem of C. No bounded splitter,
guard identity, or choice of a bound occurs in this proof.

Verification evidence is recorded in the accompanying third-order status and
compiler manifests. The commands below perform the gate, type and derivation audits.
-/

namespace Classicism.Research.MaxAtomicityDirectObstruction

open Classicism.P Classicism.Paper

def Split (F : Prop → Prop) : Prop :=
  ∀ p : Prop, p ≠ False →
    ((p ∧ F p) ≠ False ∧ (p ∧ ¬ F p) ≠ False)

/-- The closed implication to which necessitation will be applied. -/
theorem split_at_true (F : Prop → Prop) (w : Prop) :
    (w → Split F) → w →
      ((w ∧ F w) ≠ False ∧ (w ∧ ¬ F w) ≠ False) :=
  fun hs hw => hs hw w (dia_intro w hw)

/-- Containment kills the complementary Boolean part. -/
theorem negative_part_zero (p q : Prop) (h : p ≤ q) : (p ∧ ¬ q) = False :=
  modalized_fregean _ _ (modal_K _ _
    (nec% (fun (hpq : p → q) =>
      (show (p ∧ ¬ q) ↔ False from
        ⟨fun hp => hp.2 (hpq hp.1), fun hf => hf.elim⟩)))
    ((le_iff_prop p q).1 h))

/-- Take an atom below the splitting sentence and contradict its two parts. -/
theorem atomicity_split_zero (at_ : AtomicityT) (F : Prop → Prop) :
    Split F = False :=
  (at_ (Split F)).elim (eq_false_of_le_neg (Split F))
    (fun h => h.elim fun w hw => by
      have hnw : w ≠ False :=
        fun e => not_le_neg_of_atom hw.1 (le_neg_of_eq_false w e)
      have hparts : □ (w →
          ((w ∧ F w) ≠ False ∧ (w ∧ ¬ F w) ≠ False)) :=
        modal_K _ _ (nec% (split_at_true F w)) ((le_iff_prop _ _).1 hw.2)
      have hpossible : ◇ ((w ∧ F w) ≠ False ∧ (w ∧ ¬ F w) ≠ False) :=
        dia_mono _ _ hparts hnw
      have hpos : (w ∧ F w) ≠ False :=
        ne_of_dia_ne _ _ (dia_mono _ _
          (nec% (fun (h : (w ∧ F w) ≠ False ∧ (w ∧ ¬ F w) ≠ False) => h.1))
          hpossible)
      have hneg : (w ∧ ¬ F w) ≠ False :=
        ne_of_dia_ne _ _ (dia_mono _ _
          (nec% (fun (h : (w ∧ F w) ≠ False ∧ (w ∧ ¬ F w) ≠ False) => h.2))
          hpossible)
      have impossible : False :=
        (em ((w ∧ F w) = w)).elim
          (fun heq =>
            have hle : w ≤ F w :=
              Eq.mp (congrArg (fun p : Prop => p ≤ F w) heq)
                (and_le_right_prop w (F w))
            hneg (negative_part_zero w (F w) hle))
          (fun hne => hpos (eq_false_of_le_neg _
            ((hw.1 (Rel.and w (F w))).1 ⟨and_le_left_prop w (F w), hne⟩)))
      exact impossible.elim)

end Classicism.Research.MaxAtomicityDirectObstruction

#classicism_check Classicism.Research.MaxAtomicityDirectObstruction.split_at_true
  Classicism.Research.MaxAtomicityDirectObstruction.negative_part_zero
  Classicism.Research.MaxAtomicityDirectObstruction.atomicity_split_zero
#classicism_types Classicism.Research.MaxAtomicityDirectObstruction.split_at_true
  Classicism.Research.MaxAtomicityDirectObstruction.negative_part_zero
  Classicism.Research.MaxAtomicityDirectObstruction.atomicity_split_zero
#classicism_derive Classicism.Research.MaxAtomicityDirectObstruction.atomicity_split_zero

namespace Classicism.Meta.Research.MaxAtomicityDirectObstruction

open AxiomSet

abbrev SplitterTy : RTy := Ty.t ⇒ RTy.t

/-- The same finite sentence as in the original certificate. -/
def splitParts {Γ : Ctx} (p : Formula Signature.pure Γ)
    (F : Term Signature.pure Γ SplitterTy) : Formula Signature.pure Γ :=
  Term.conj
    (Term.neg (Term.eq' (Term.conj p (.app F p)) Term.bot))
    (Term.neg (Term.eq' (Term.conj p (Term.neg (.app F p))) Term.bot))

def split {Γ : Ctx} (F : Term Signature.pure Γ SplitterTy) :
    Formula Signature.pure Γ :=
  Term.forall' (σ := Ty.t)
    (Term.imp (Term.neg (Term.eq' Term.v0 Term.bot))
      (splitParts Term.v0 F.weaken))

theorem split_closedTypes (F : Term Signature.pure [] SplitterTy)
    (hF : F.closedTypes = true) : (split F).closedTypes = true := by
  simp [split, splitParts, Term.closedTypes, Term.weaken,
    Term.closedTypes_rename, hF]

/-- One discharge and one instantiation; no guard bridge or bound is needed. -/
theorem split_zero_under_atomicity (F : Term Signature.pure [] SplitterTy) :
    Theorem (C.axioms ∪ P.AtomicityT.schema) (Term.eq' (split F) Term.bot) := by
  have hdirect : Theorem (C.axioms ∪ P.AtomicityT.schema)
      (Term.imp P.AtomicityT.quoted
        (Term.forall' (σ := SplitterTy)
          (Term.eq' (split Term.v0) Term.bot))) := by
    first
    | exact Theorem.ofCMinus
        Classicism.Research.MaxAtomicityDirectObstruction.atomicity_split_zero.derivable
    | exact Theorem.ofC
        Classicism.Research.MaxAtomicityDirectObstruction.atomicity_split_zero.derivable
  exact Derivable.allEβ (Theorem.mp hdirect (Theorem.ax rfl)) F

theorem inconsistent_of_split_not_zero_theorem
    (F : Term Signature.pure [] SplitterTy) (hF : F.closedTypes = true)
    (hnot : ¬ C.Theorem (Term.eq' (split F) Term.bot)) :
    ¬ Consistent (maximalist ∪ P.AtomicityT.schema) :=
  MaxAtomicityReduction.atomicityT_inconsistent_of_separator (split F)
    (split_closedTypes F hF) hnot (split_zero_under_atomicity F)

end Classicism.Meta.Research.MaxAtomicityDirectObstruction

#print axioms Classicism.Research.MaxAtomicityDirectObstruction.atomicity_split_zero.derivable
#print axioms Classicism.Meta.Research.MaxAtomicityDirectObstruction.split_zero_under_atomicity
#print axioms Classicism.Meta.Research.MaxAtomicityDirectObstruction.inconsistent_of_split_not_zero_theorem
