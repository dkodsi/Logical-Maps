import Classicism.Semantics.BooleanValued
import Classicism.Syntax.SentenceSchemas

/-!
# Finite identity formulas

A small syntax compiler for the third-order Max--Atomicity argument. Atomic
formulas are literal identities between actual pure C terms; all binders are
ordinary typed C binders. The external satisfaction relation is proved to agree
with Boolean evaluation, including arbitrary full-domain quantification.

Direct source: original formalization, misc, 25 October 2026, following section
2 of the upstream third-order rewrite identified in upstream-comparison.md.
Verification evidence is recorded in the accompanying third-order status and compiler manifests.
-/

namespace Classicism.Meta.Research.MaxAtomicityIdentityFormula

open BooleanValued

abbrev PT (Γ : Ctx) (σ : Ty) := Term Signature.pure Γ σ
abbrev Num : Ty := Ty.t
abbrev Real : RTy := Num ⇒ RTy.t
abbrev Class : RTy := (Real : Ty) ⇒ RTy.t
abbrev Binary : RTy := Num ⇒ Num ⇒ RTy.t

/-- A finite identity formula, not an infinitary formula or a semantic oracle. -/
inductive IdFormula : Ctx → Type
  | bot {Γ} : IdFormula Γ
  | top {Γ} : IdFormula Γ
  | eq {Γ σ} (a b : PT Γ σ) : IdFormula Γ
  | neg {Γ} (p : IdFormula Γ) : IdFormula Γ
  | conj {Γ} (p q : IdFormula Γ) : IdFormula Γ
  | disj {Γ} (p q : IdFormula Γ) : IdFormula Γ
  | imp {Γ} (p q : IdFormula Γ) : IdFormula Γ
  | iff {Γ} (p q : IdFormula Γ) : IdFormula Γ
  | all {Γ} (σ : Ty) (p : IdFormula (σ :: Γ)) : IdFormula Γ
  | ex {Γ} (σ : Ty) (p : IdFormula (σ :: Γ)) : IdFormula Γ

namespace IdFormula

def term {Γ} : IdFormula Γ → Formula Signature.pure Γ
  | .bot => Term.bot
  | .top => Term.top
  | .eq a b => Term.eq' a b
  | .neg p => Term.neg p.term
  | .conj p q => Term.conj p.term q.term
  | .disj p q => Term.disj p.term q.term
  | .imp p q => Term.imp p.term q.term
  | .iff p q => Term.iff p.term q.term
  | .all _ p => Term.forall' p.term
  | .ex _ p => Term.exists' p.term

noncomputable def holds {B : Type} [CompleteBooleanAlgebra B]
    (I : Interpretation Signature.pure B) {Γ} :
    IdFormula Γ → IEnv (Dom I.E B) Γ → Prop
  | .bot, _ => False
  | .top, _ => True
  | .eq a b, env => eval I a env = eval I b env
  | .neg p, env => ¬ p.holds I env
  | .conj p q, env => p.holds I env ∧ q.holds I env
  | .disj p q, env => p.holds I env ∨ q.holds I env
  | .imp p q, env => p.holds I env → q.holds I env
  | .iff p q, env => p.holds I env ↔ q.holds I env
  | .all _ p, env => ∀ x, p.holds I (.cons x env)
  | .ex _ p, env => ∃ x, p.holds I (.cons x env)

end IdFormula

noncomputable section

variable {B : Type} [CompleteBooleanAlgebra B]

def truth (P : Prop) : B := by
  classical
  exact if P then ⊤ else ⊥

@[simp] theorem truth_false : (truth False : B) = ⊥ := by simp [truth]
@[simp] theorem truth_true : (truth True : B) = ⊤ := by simp [truth]
@[simp] theorem truth_not (P : Prop) : (truth P : B)ᶜ = truth (¬ P) := by
  classical
  by_cases h : P <;> simp [truth, h]
@[simp] theorem truth_and (P Q : Prop) :
    (truth P : B) ⊓ truth Q = truth (P ∧ Q) := by
  classical
  by_cases hp : P <;> by_cases hq : Q <;> simp [truth, hp, hq]
@[simp] theorem truth_or (P Q : Prop) :
    (truth P : B) ⊔ truth Q = truth (P ∨ Q) := by
  classical
  by_cases hp : P <;> by_cases hq : Q <;> simp [truth, hp, hq]
@[simp] theorem truth_imp (P Q : Prop) :
    (truth P : B)ᶜ ⊔ truth Q = truth (P → Q) := by
  classical
  by_cases hp : P <;> by_cases hq : Q <;> simp [truth, hp, hq]
@[simp] theorem truth_iff (P Q : Prop) :
    ((truth P : B)ᶜ ⊔ truth Q) ⊓ ((truth Q : B)ᶜ ⊔ truth P) = truth (P ↔ Q) := by
  classical
  by_cases hp : P <;> by_cases hq : Q <;> simp [truth, hp, hq]
@[simp] theorem truth_all {D : Type*} (P : D → Prop) :
    (⨅ x, (truth (P x) : B)) = truth (∀ x, P x) := by
  classical
  by_cases h : ∀ x, P x
  · have ht : (⨅ x, (truth (P x) : B)) = ⊤ :=
      top_unique (le_iInf (fun x => by simp [truth, h x]))
    simpa [truth, h] using ht
  · obtain ⟨x, hx⟩ := not_forall.mp h
    have hz : (⨅ y, (truth (P y) : B)) = ⊥ :=
      bot_unique ((iInf_le _ x).trans (by simp [truth, hx]))
    simpa [truth, h] using hz
@[simp] theorem truth_ex {D : Type*} (P : D → Prop) :
    (⨆ x, (truth (P x) : B)) = truth (∃ x, P x) := by
  classical
  by_cases h : ∃ x, P x
  · obtain ⟨x, hx⟩ := h
    have ht : (⨆ y, (truth (P y) : B)) = ⊤ :=
      top_unique ((show (⊤ : B) ≤ truth (P x) by simp [truth, hx]).trans
        (le_iSup (fun y => (truth (P y) : B)) x))
    simpa [truth, show ∃ x, P x from ⟨x, hx⟩] using ht
  · have hz : (⨆ x, (truth (P x) : B)) = ⊥ :=
      bot_unique (iSup_le (fun x => by simp [truth, not_exists.mp h x]))
    simpa [truth, h] using hz
@[simp] theorem truth_eq_top [Nontrivial B] (P : Prop) :
    (truth P : B) = ⊤ ↔ P := by
  classical
  by_cases h : P <;> simp [truth, h]
@[simp] theorem truth_eq_bot [Nontrivial B] (P : Prop) :
    (truth P : B) = ⊥ ↔ ¬ P := by
  classical
  by_cases h : P <;> simp [truth, h]

/-- The actual compiler-correctness proof: there is no adequacy assumption. -/
theorem eval_term (I : Interpretation Signature.pure B) {Γ} (p : IdFormula Γ) :
    ∀ env, eval I p.term env = truth (p.holds I env) := by
  induction p with
  | bot => intro env; simpa only [IdFormula.term, IdFormula.holds, truth_false] using eval_bot I env
  | top => intro env; simpa only [IdFormula.term, IdFormula.holds, truth_true] using eval_top I env
  | eq a b => intro env; rfl
  | neg p ih => intro env; exact (congrArg (fun b : B => bᶜ) (ih env)).trans (truth_not _)
  | conj p q ihp ihq =>
    intro env
    change eval I p.term env ⊓ eval I q.term env = _
    rw [ihp, ihq, truth_and]; rfl
  | disj p q ihp ihq =>
    intro env
    change eval I p.term env ⊔ eval I q.term env = _
    rw [ihp, ihq, truth_or]; rfl
  | imp p q ihp ihq =>
    intro env
    change (eval I p.term env)ᶜ ⊔ eval I q.term env = _
    rw [ihp, ihq, truth_imp]; rfl
  | iff p q ihp ihq =>
    intro env
    change ((eval I p.term env)ᶜ ⊔ eval I q.term env) ⊓
      ((eval I q.term env)ᶜ ⊔ eval I p.term env) = _
    rw [ihp, ihq, truth_iff]; rfl
  | all σ p ih =>
    intro env
    change (⨅ x, eval I p.term (.cons x env)) = _
    simp only [ih, truth_all]; rfl
  | ex σ p ih =>
    intro env
    change (⨆ x, eval I p.term (.cons x env)) = _
    simp only [ih, truth_ex]; rfl

/-- Boolean existential pooling at a unique crisp witness. -/
theorem guardedSup_unique (P : B → Prop) (q : B)
    (hq : P q) (hu : ∀ r, P r → r = q) :
    (⨆ r, truth (P r) ⊓ r) = q := by
  classical
  apply le_antisymm
  · apply iSup_le
    intro r
    by_cases hr : P r
    · simp [truth, hr, hu r hr]
    · simp [truth, hr]
  · exact (show q ≤ truth (P q) ⊓ q by simp [truth, hq]).trans
      (le_iSup (fun r => truth (P r) ⊓ r) q)

end

end Classicism.Meta.Research.MaxAtomicityIdentityFormula
