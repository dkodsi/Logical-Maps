import Classicism.Results.Research.MaxAtomicityThirdOrderSyntax
import Classicism.Results.Research.MaxAtomicityThirdOrderArithmetic
import Classicism.Results.Research.MaxAtomicityThirdOrderSelection

/-!
# Adequacy of the actual finite third-order selector

This bridge discharges every coding premise. The literal reading of the finite
C formula yields a full Peano frame, uniquely determined arithmetic, exactly
the tree conditions, exactly the regular opens, and a genuine isomorphism.
Rigidity then makes the selected cylinder independent of all quantified codes.
Conversely explicit characteristic functions supply every quantified witness.

Direct source: original formalization, misc, 25 October 2026, implementing the
upstream third-order rewrite, sections 2--3 (upstream-comparison.md).
Verification evidence is recorded in the accompanying third-order status and compiler manifests.
-/

namespace Classicism.Meta.Research.MaxAtomicityThirdOrderBridge

set_option backward.isDefEq.respectTransparency false

open MaxAtomicityIdentityFormula MaxAtomicityThirdOrderDomains
open MaxAtomicityThirdOrderArithmetic MaxAtomicityThirdOrderRegular
open MaxAtomicityThirdOrderSelection MaxAtomicityThirdOrderSyntax
open MaxAtomicityJechShelahCylinders MaxAtomicityJechShelahIndexedGenerators

noncomputable section

/-- Interpret the numeric and relational variables as actual full functions. -/
def data (A M E : B → B → B) (P Q O : B → B) (R : B → B → B) : Data B :=
  ⟨A, M, E, P, Q, O, fun x y => R x y = ⊤⟩

theorem frame_iff (N : B → B) (z : B) (s : B → B) :
    Ordinary.frame N z s ↔ NatFrame N z s := by
  constructor
  · rintro ⟨hz, hs, hinj, hind⟩
    refine ⟨hz, fun x hx => (hs x hx).1, fun x hx => (hs x hx).2,
      fun x y hx hy => hinj x hx y hy, ?_⟩
    intro P hzero hsucc x hx
    let X : B → B := fun y => truth (P y)
    have hX : ∀ y, X y = ⊤ ↔ P y := fun y => truth_eq_top (P y)
    have htop : X x = ⊤ := hind X ⟨(hX z).2 hzero, by
      intro y hy hp
      exact (hX (s y)).2 (hsucc y hy ((hX y).1 hp))⟩ x hx
    exact (hX x).1 htop
  · intro h
    exact ⟨h.zero_mem, fun x hx => ⟨h.succ_mem x hx, h.succ_ne_zero x hx⟩,
      fun x hx y hy => h.succ_injective x y hx hy,
      fun X hX => h.induction_on (fun x => X x = ⊤) hX.1 hX.2⟩

variable {N : B → B} {z : B} {s : B → B} {h : NatFrame N z s}
variable {A M E : B → B → B} {P Q O : B → B} {R : B → B → B}

theorem arithmetic_iff (h : NatFrame N z s) :
    Ordinary.arithmetic N z s A M E P Q O R ↔ Arithmetic h (data A M E P Q O R) := by
  constructor
  · rintro ⟨h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12,
      h13, h14, h15, h16, h17, h18, h19⟩
    exact ⟨h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12,
      h13, h14, h15, h16, h17, h18, h19⟩
  · intro ha
    exact ⟨ha.add_mem, ha.mul_mem, ha.pow_mem, ha.p_mem, ha.n_mem, ha.o_mem,
      ha.add_zero, ha.add_succ, ha.mul_zero, ha.mul_succ, ha.pow_zero,
      ha.pow_succ, ha.p_zero, ha.n_zero, ha.o_zero, ha.p_succ, ha.n_succ,
      ha.o_succ, ha.ancestor_recursion⟩

section Transport

variable (ha : Arithmetic h (data A M E P Q O R))

include ha

theorem condition_iff (X : B → B) :
    Ordinary.condition N z s A M E P Q O R X ↔ TreeCode h X :=
  ha.conditionCode_iff X

theorem regular_iff (U : (B → B) → B) :
    Ordinary.regular N z s A M E P Q O R U ↔ RegularCode N (TreeCode h) U := by
  simp only [Ordinary.regular, condition_iff ha, RegularCode,
    Ordinary.classCode, Ordinary.real, ClassCode, RealCode,
    Ordinary.subset, SubsetCode]

theorem isomorphism_iff (f : B → (B → B) → B) :
    Ordinary.isomorphism N z s A M E P Q O R f ↔ Presentation h f := by
  simp only [Ordinary.isomorphism, regular_iff ha, inf_eq_left, Presentation,
    Ordinary.classSubset, SubsetCode]

theorem inCylinder_iff (n : ℕ) (X : B → B) :
    Ordinary.inCylinder N R (h.numeral n) X ↔ InCylinder h n X := by
  constructor
  · intro hh j hj
    exact (or_congr (ha.ancestor_numeral j n) (ha.ancestor_numeral n j)).1
      (hh (h.numeral j) (h.numeral_mem j) hj)
  · intro hh y hy hY
    obtain ⟨j, rfl⟩ := (h.mem_iff_range y).1 hy
    exact (or_congr (ha.ancestor_numeral j n) (ha.ancestor_numeral n j)).2 (hh j hY)

theorem cylinder_iff (U : (B → B) → B) (n : ℕ) :
    Ordinary.cylinder N z s A M E P Q O R U (h.numeral n) ↔ CylinderCode h U n := by
  simp only [Ordinary.cylinder, regular_iff ha, condition_iff ha,
    inCylinder_iff ha, CylinderCode]

theorem splits_iff (b : B) (n : ℕ) :
    Ordinary.splits N z s A M E P Q O R (encodeOpen h b) (h.numeral n) ↔ Splits b n := by
  have he : Ordinary.splits N z s A M E P Q O R (encodeOpen h b) (h.numeral n) ↔
      SplitsCode h (encodeOpen h b) n := by
    simp only [Ordinary.splits, condition_iff ha, inCylinder_iff ha, SplitsCode]
  exact he.trans (splitsCode_iff h b n)

theorem lt_numeral (m n : ℕ) :
    Ordinary.lt N s A (h.numeral m) (h.numeral n) ↔ m < n := ha.lt_numeral m n

theorem least_iff (b : B) (n : ℕ) :
    Ordinary.least N z s A M E P Q O R (encodeOpen h b) (h.numeral n) ↔ Least b n := by
  unfold Ordinary.least Least
  rw [splits_iff ha, h.forall_number_iff]
  simp only [lt_numeral ha, splits_iff ha]

end Transport

/-- The characteristic ancestor relation supplies exactly the required
Boolean-valued variable, including at points outside the number frame. -/
theorem canonical_data (h : NatFrame N z s) :
    data h.canonicalData.add h.canonicalData.mul h.canonicalData.pow
      h.canonicalData.p h.canonicalData.n h.canonicalData.o h.canonicalRelation =
        h.canonicalData := by
  have he : (fun x y => h.canonicalRelation x y = ⊤) = h.canonicalData.ancestor := by
    funext x y
    exact propext (h.canonicalRelation_top_iff x y)
  unfold data
  rw [he]

theorem canonical_arithmetic (h : NatFrame N z s) :
    Ordinary.arithmetic N z s h.canonicalData.add h.canonicalData.mul h.canonicalData.pow
      h.canonicalData.p h.canonicalData.n h.canonicalData.o h.canonicalRelation := by
  apply (arithmetic_iff h).2
  rw [canonical_data h]
  exact MaxAtomicityThirdOrderArithmetic.canonical_arithmetic h

/-- All quantified presentations in the finite formula select the same
standard least cylinder. No external selection function has been quoted. -/
theorem select_iff (p q : B) :
    Ordinary.select p q ↔ ∃ n : ℕ, Least p n ∧ q = indexedGenerator n := by
  constructor
  · rintro ⟨N, z, s, A, M, E, P, Q, O, R, f, i,
      hframe, harith, hiso, hi, hcyl, hleast⟩
    let h : NatFrame N z s := (frame_iff N z s).1 hframe
    have ha : Arithmetic h (data A M E P Q O R) := (arithmetic_iff h).1 harith
    have hf := presentation_unique h f ((isomorphism_iff ha f).1 hiso)
    rw [hf] at hcyl hleast
    obtain ⟨n, rfl⟩ := (h.mem_iff_range i).1 hi
    refine ⟨n, (least_iff ha p n).1 hleast, ?_⟩
    exact encodeOpen_injective h ((cylinderCode_iff h _ n).1 ((cylinder_iff ha _ n).1 hcyl))
  · rintro ⟨n, hn, rfl⟩
    let N := embeddingN numberEmbedding
    let z := embeddingZero numberEmbedding
    let s := embeddingSucc numberEmbedding
    let h : NatFrame N z s := embeddingFrame numberEmbedding
    let a := h.canonicalData
    let R := h.canonicalRelation
    have ha : Arithmetic h (data a.add a.mul a.pow a.p a.n a.o R) := by
      rw [canonical_data h]
      exact MaxAtomicityThirdOrderArithmetic.canonical_arithmetic h
    refine ⟨N, z, s, a.add, a.mul, a.pow, a.p, a.n, a.o, R,
      encodeOpen h, h.numeral n, (frame_iff N z s).2 h,
      canonical_arithmetic h, (isomorphism_iff ha _).2 (canonical_presentation h),
      h.numeral_mem n, ?_, (least_iff ha p n).2 hn⟩
    apply (cylinder_iff ha _ n).2
    exact (cylinderCode_iff h _ n).2 rfl

/-- Existence and uniqueness come from ordinary least natural-number search. -/
theorem select_exists_unique {p : B} (hp : p ≠ ⊥) :
    ∃ q : B, Ordinary.select p q ∧
      (∀ r, Ordinary.select p r → r = q) ∧ p ⊓ q ≠ ⊥ ∧ p ⊓ qᶜ ≠ ⊥ := by
  obtain ⟨n, hn⟩ := exists_least hp
  refine ⟨indexedGenerator n, (select_iff p _).2 ⟨n, hn, rfl⟩, ?_, hn.1⟩
  intro r hr
  obtain ⟨m, hm, rfl⟩ := (select_iff p r).1 hr
  rw [least_unique hm hn]

#print axioms frame_iff
#print axioms arithmetic_iff
#print axioms select_iff
#print axioms select_exists_unique

end

end Classicism.Meta.Research.MaxAtomicityThirdOrderBridge
