import Classicism.Results.Research.MaxAtomicityThirdOrderRegular
import Classicism.Results.Research.MaxAtomicityJechShelahLocalFusion
import Mathlib.Order.Monotone.Basic

/-!
# Rigidity and the first splitting cylinder

Only the cylinder-splitting property is used. This proof does not invoke the
complete-generation theorem. Coded presentations are decoded to actual order
automorphisms, so the already certified rigidity theorem proves uniqueness.
Direct source: original formalization, misc, 25 October 2026, following the
upstream third-order rewrite, sections 2--3 (upstream-comparison.md).
Verification evidence is recorded in the accompanying third-order status and compiler manifests.
-/

namespace Classicism.Meta.Research.MaxAtomicityThirdOrderSelection

set_option backward.isDefEq.respectTransparency false

open MaxAtomicityThirdOrderDomains MaxAtomicityThirdOrderRegular
open MaxAtomicityRegularCompletion MaxAtomicityRigidTransport
open MaxAtomicityJechShelahTrees MaxAtomicityJechShelahCylinders
open MaxAtomicityJechShelahIndexedGenerators MaxAtomicityJechShelahIndexCoding
open MaxAtomicityJechShelahRigidityCriterion

noncomputable section

/-- The finite presentation condition, read externally. -/
def Presentation {D : Type} [CompleteBooleanAlgebra D] [Nontrivial D]
    {N : D → D} {z : D} {s : D → D} (h : NatFrame N z s)
    (f : B → (D → D) → D) : Prop :=
  (∀ b, RegularCode N (TreeCode h) (f b)) ∧
  (∀ U, RegularCode N (TreeCode h) U → ∃ b, f b = U) ∧
  (∀ b c, b ≤ c ↔ SubsetCode (f b) (f c))

variable {D : Type} [CompleteBooleanAlgebra D] [Nontrivial D]
variable {N : D → D} {z : D} {s : D → D} (h : NatFrame N z s)

theorem canonical_presentation : Presentation h (encodeOpen h) := by
  exact ⟨encodeOpen_regular h, fun U hU => (regularCode_iff h U).1 hU,
    fun b c => (encodeOpen_subset h b c).symm⟩

def decodeMap (f : B → (D → D) → D) (hf : Presentation h f) (b : B) : B :=
  decodeOpen h (f b) (hf.1 b)

theorem encode_decodeMap (f : B → (D → D) → D) (hf : Presentation h f) (b : B) :
    encodeOpen h (decodeMap h f hf b) = f b := encode_decode h _ _

theorem decodeMap_le (f : B → (D → D) → D) (hf : Presentation h f) (b c : B) :
    decodeMap h f hf b ≤ decodeMap h f hf c ↔ b ≤ c := by
  rw [← encodeOpen_subset h, encode_decodeMap, encode_decodeMap]
  exact (hf.2.2 b c).symm

def decodedIso (f : B → (D → D) → D) (hf : Presentation h f) : B ≃o B where
  toEquiv := Equiv.ofBijective (decodeMap h f hf) ⟨by
    intro b c heq
    exact le_antisymm ((decodeMap_le h f hf b c).1 heq.le)
      ((decodeMap_le h f hf c b).1 heq.ge), by
    intro b
    obtain ⟨c, hc⟩ := hf.2.1 (encodeOpen h b) (encodeOpen_regular h b)
    refine ⟨c, encodeOpen_injective h ?_⟩
    rw [encode_decodeMap, hc]⟩
  map_rel_iff' := by
    intro b c
    exact decodeMap_le h f hf b c

/-- Every admissible presentation is the canonical characteristic encoding. -/
theorem presentation_unique (f : B → (D → D) → D) (hf : Presentation h f) :
    f = encodeOpen h := by
  funext b
  have he : decodeMap h f hf b = b :=
    congrArg (fun e : B ≃o B => e b)
      (MaxAtomicityJechShelahLocalFusion.actual_rigid (decodedIso h f hf))
  rw [← encode_decodeMap h f hf b, he]

def InCylinder (n : ℕ) (X : D → D) : Prop :=
  ∀ j ∈ h.realSet X, Ancestor j n ∨ Ancestor n j

def CylinderCode (U : (D → D) → D) (n : ℕ) : Prop :=
  RegularCode N (TreeCode h) U ∧
  ∀ X, TreeCode h X → (U X = ⊤ ↔ InCylinder h n X)

def SplitsCode (U : (D → D) → D) (n : ℕ) : Prop :=
  (∃ X, TreeCode h X ∧ U X = ⊤ ∧ InCylinder h n X) ∧
  (∃ X, TreeCode h X ∧ U X = ⊤ ∧ ¬ InCylinder h n X)

/-- The two nonzero Boolean parts required of a cylinder. -/
def Splits (b : B) (n : ℕ) : Prop :=
  b ⊓ indexedGenerator n ≠ ⊥ ∧ b ⊓ (indexedGenerator n)ᶜ ≠ ⊥

def Least (b : B) (n : ℕ) : Prop := Splits b n ∧ ∀ m, m < n → ¬ Splits b m

theorem inCylinder_tree (n : ℕ) (T : Condition) :
    InCylinder h n (encodeTree h T) ↔ T ∈ (indexedGenerator n : LowerSet Condition) := by
  unfold InCylinder encodeTree
  rw [h.realSet_encodeReal]
  exact (mem_indexedGenerator_iff T n).symm

theorem cylinderCode_iff (U : (D → D) → D) (n : ℕ) :
    CylinderCode h U n ↔ U = encodeOpen h (indexedGenerator n) := by
  constructor
  · rintro ⟨hU, hc⟩
    obtain ⟨b, rfl⟩ := (regularCode_iff h U).1 hU
    apply congrArg (encodeOpen h)
    apply Heyting.Regular.coe_injective
    apply LowerSet.ext
    apply Set.ext
    intro T
    exact (encodeOpen_tree h b T).symm.trans
      ((hc _ (treeCode_encodeTree h T)).trans (inCylinder_tree h n T))
  · rintro rfl
    refine ⟨encodeOpen_regular h _, ?_⟩
    intro X hX
    obtain ⟨T, rfl⟩ := (treeCode_iff h X).1 hX
    rw [encodeOpen_tree, inCylinder_tree]

private theorem meet_nonzero (b c : B) :
    b ⊓ c ≠ ⊥ ↔ ∃ T : Condition, T ∈ (b : LowerSet Condition) ∧
      T ∈ (c : LowerSet Condition) := by
  constructor
  · intro hn
    obtain ⟨T, hT⟩ := condition_dense hn
    exact ⟨T, (condition_le_iff_mem T b).1 (hT.trans inf_le_left),
      (condition_le_iff_mem T c).1 (hT.trans inf_le_right)⟩
  · rintro ⟨T, hb, hc⟩ hz
    apply condition_ne_bot T
    apply le_bot_iff.mp
    rw [← hz]
    exact le_inf ((condition_le_iff_mem T b).2 hb) ((condition_le_iff_mem T c).2 hc)

private theorem meet_compl_nonzero (b c : B) :
    b ⊓ cᶜ ≠ ⊥ ↔ ∃ T : Condition, T ∈ (b : LowerSet Condition) ∧
      T ∉ (c : LowerSet Condition) := by
  classical
  have he : b ⊓ cᶜ = ⊥ ↔ b ≤ c := by
    constructor
    · intro hz
      calc
        b = b ⊓ (c ⊔ cᶜ) := by simp
        _ = (b ⊓ c) ⊔ (b ⊓ cᶜ) := inf_sup_left _ _ _
        _ ≤ c := by rw [hz, sup_bot_eq]; exact inf_le_right
    · intro hbc
      exact le_bot_iff.mp ((inf_le_inf_right _ hbc).trans_eq inf_compl_eq_bot)
  rw [ne_eq, he]
  change (¬ ∀ T, T ∈ (b : LowerSet Condition) → T ∈ (c : LowerSet Condition)) ↔ _
  simp only [not_forall, exists_prop]

theorem splitsCode_iff (b : B) (n : ℕ) :
    SplitsCode h (encodeOpen h b) n ↔ Splits b n := by
  have he (P : (D → D) → Prop) :
      (∃ X, TreeCode h X ∧ encodeOpen h b X = ⊤ ∧ P X) ↔
        ∃ T, T ∈ (b : LowerSet Condition) ∧ P (encodeTree h T) := by
    constructor
    · rintro ⟨X, hX, hb, hp⟩
      obtain ⟨T, rfl⟩ := (treeCode_iff h X).1 hX
      exact ⟨T, (encodeOpen_tree h b T).1 hb, hp⟩
    · rintro ⟨T, hb, hp⟩
      exact ⟨encodeTree h T, treeCode_encodeTree h T, (encodeOpen_tree h b T).2 hb, hp⟩
  unfold SplitsCode Splits
  rw [he, he, meet_nonzero, meet_compl_nonzero]
  simp only [inCylinder_tree]

/-- Two incompatible immediate successor restrictions exhibit a cylinder
which splits any nonzero regular open. No generation theorem is needed. -/
theorem exists_splitting_cylinder {b : B} (hb : b ≠ ⊥) : ∃ n, Splits b n := by
  obtain ⟨T, hTb⟩ := condition_dense hb
  obtain ⟨v, hv, hlong⟩ := T.exists_long_node 2
  obtain ⟨t, ht, hvt, f, hf, hchildren⟩ := T.bushy v hv 1
  have htwo : 2 ≤ growthP (index t) ^ 1 := by
    rw [pow_one]
    have hlen := length_le_index t
    have hgrowth := index_le_growthP (index t)
    have hstrict := hvt.2
    omega
  let i : Fin (growthP (index t) ^ 1) := ⟨0, by omega⟩
  let j : Fin (growthP (index t) ^ 1) := ⟨1, by omega⟩
  let a := t ++ [f i]
  let c := t ++ [f j]
  have ha : a ∈ T.tree := hchildren i
  have hc : c ∈ T.tree := hchildren j
  have hne : a ≠ c := by
    intro hh
    have hij : f i = f j := by simpa [a, c] using hh
    have hval := congrArg Fin.val (hf hij)
    exact Nat.zero_ne_one hval
  have hdisj : cylinder a ⊓ cylinder c = ⊥ := cylinders_disjoint (by simp [a, c]) hne
  have hccompl : cylinder c ≤ (cylinder a)ᶜ := by
    calc
      cylinder c = cylinder c ⊓ (cylinder a ⊔ (cylinder a)ᶜ) := by simp
      _ = (cylinder c ⊓ cylinder a) ⊔ (cylinder c ⊓ (cylinder a)ᶜ) := inf_sup_left _ _ _
      _ ≤ (cylinder a)ᶜ := by
        rw [inf_comm (cylinder c) (cylinder a), hdisj, bot_sup_eq]
        exact inf_le_right
  refine ⟨index a, ?_, ?_⟩
  · rw [indexedGenerator_index a (T.submaster ha)]
    intro hz
    apply condition_ne_bot (T.restrict a ha)
    apply le_bot_iff.mp
    rw [← hz]
    exact le_inf ((condition_mono (T.restrict_le a ha)).trans hTb)
      (restrict_le_cylinder T a ha)
  · rw [indexedGenerator_index a (T.submaster ha)]
    intro hz
    apply condition_ne_bot (T.restrict c hc)
    apply le_bot_iff.mp
    rw [← hz]
    exact le_inf ((condition_mono (T.restrict_le c hc)).trans hTb)
      ((restrict_le_cylinder T c hc).trans hccompl)

theorem exists_least {b : B} (hb : b ≠ ⊥) : ∃ n, Least b n := by
  classical
  let hex := exists_splitting_cylinder hb
  exact ⟨Nat.find hex, Nat.find_spec hex, fun m hm => Nat.find_min hex hm⟩

theorem least_unique {b : B} {n m : ℕ} (hn : Least b n) (hm : Least b m) : n = m := by
  rcases lt_trichotomy n m with hlt | heq | hgt
  · exact (hm.2 n hlt hn.1).elim
  · exact heq
  · exact (hn.2 m hgt hm.1).elim

private def nextNonzero (b : {b : B // b ≠ ⊥}) : {b : B // b ≠ ⊥} :=
  ⟨Classical.choose (forcing_completion_atomless b.2),
    (Classical.choose_spec (forcing_completion_atomless b.2)).1⟩
private theorem nextNonzero_lt (b : {b : B // b ≠ ⊥}) : (nextNonzero b).1 < b.1 := by
  have hh := Classical.choose_spec (forcing_completion_atomless b.2)
  exact lt_of_le_of_ne hh.2.1 hh.2.2
private def nonzeroChain : ℕ → {b : B // b ≠ ⊥}
  | 0 => ⟨⊤, top_ne_bot⟩
  | n + 1 => nextNonzero (nonzeroChain n)
private theorem chain_strictAnti : StrictAnti (fun n => (nonzeroChain n).1) :=
  strictAnti_nat_of_succ_lt (fun n => nextNonzero_lt (nonzeroChain n))

/-- An explicit injection supplies the canonical number frame. -/
def numberEmbedding : ℕ ↪ B := ⟨fun n => (nonzeroChain n).1, chain_strictAnti.injective⟩

#print axioms presentation_unique
#print axioms exists_splitting_cylinder
#print axioms exists_least
#print axioms numberEmbedding

end

end Classicism.Meta.Research.MaxAtomicityThirdOrderSelection
