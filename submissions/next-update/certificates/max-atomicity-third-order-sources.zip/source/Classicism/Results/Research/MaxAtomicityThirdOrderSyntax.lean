import Classicism.Results.Research.MaxAtomicityIdentityFormula
import Classicism.Results.Research.MaxAtomicityEvalTools

/-!
# The actual finite third-order selector

Every displayed predicate is an abbreviation for a finite identity formula.
The compiler produces actual pure C terms. The companion Ordinary predicates
are the literal classical readings; each correctness lemma is proved from the
identity-formula truth lemma. Arithmetic and regular-open adequacy are supplied
in the separate bridge, rather than assumed by this syntax module.

Direct source: original formalization, misc, 25 October 2026, following the
upstream Max--Atomicity third-order rewrite (upstream-comparison.md, section 1).
Verification evidence is recorded in the accompanying third-order status and compiler manifests.
-/

namespace Classicism.Meta.Research.MaxAtomicityThirdOrderSyntax

open BooleanValued MaxAtomicityIdentityFormula MaxAtomicityEvalTools

namespace Ordinary

variable {D : Type} [CompleteBooleanAlgebra D]

def frame (N : (D → D)) (z : D) (s : (D → D)) : Prop :=
  (((N z) = ⊤) ∧
    ((∀ x : D, (((N x) = ⊤) →
    (((N (s x)) = ⊤) ∧
    (¬ ((s x) = z))))) ∧
    ((∀ x : D, (((N x) = ⊤) →
    (∀ y : D, (((N y) = ⊤) →
    (((s x) = (s y)) →
    (x = y)))))) ∧
    (∀ X : (D → D), ((((X z) = ⊤) ∧
    (∀ x : D, (((N x) = ⊤) →
    (((X x) = ⊤) →
    ((X (s x)) = ⊤))))) →
    (∀ x : D, (((N x) = ⊤) →
    ((X x) = ⊤))))))))

def real (N : (D → D)) (X : (D → D)) : Prop :=
  (∀ x : D, ((((N x) = ⊤) ∧
    ((X x) = ⊤)) ∨
    ((X x) = ⊥)))

def classCode (N : (D → D)) (U : ((D → D) → D)) : Prop :=
  (∀ X : (D → D), (((real N X) ∧
    ((U X) = ⊤)) ∨
    ((U X) = ⊥)))

def le (N : (D → D)) (A : (D → D → D)) (x : D) (y : D) : Prop :=
  (∃ k : D, (((N k) = ⊤) ∧
    (((A x) k) = y)))

def lt (N : (D → D)) (s : (D → D)) (A : (D → D → D)) (x : D) (y : D) : Prop :=
  (le N A (s x) y)

def child (N : (D → D)) (s : (D → D)) (A : (D → D → D)) (Q : (D → D)) (O : (D → D)) (k : D) (j : D) : Prop :=
  ((le N A (O k) j) ∧
    (lt N s A j ((A (O k)) (Q k))))

def arithmetic (N : (D → D)) (z : D) (s : (D → D)) (A : (D → D → D)) (M : (D → D → D)) (E : (D → D → D)) (P : (D → D)) (Q : (D → D)) (O : (D → D)) (R : (D → D → D)) : Prop :=
  ((∀ x : D, (∀ y : D, (((N x) = ⊤) →
    (((N y) = ⊤) →
    ((N ((A x) y)) = ⊤))))) ∧
    ((∀ x : D, (∀ y : D, (((N x) = ⊤) →
    (((N y) = ⊤) →
    ((N ((M x) y)) = ⊤))))) ∧
    ((∀ x : D, (∀ y : D, (((N x) = ⊤) →
    (((N y) = ⊤) →
    ((N ((E x) y)) = ⊤))))) ∧
    ((∀ x : D, (((N x) = ⊤) →
    ((N (P x)) = ⊤))) ∧
    ((∀ x : D, (((N x) = ⊤) →
    ((N (Q x)) = ⊤))) ∧
    ((∀ x : D, (((N x) = ⊤) →
    ((N (O x)) = ⊤))) ∧
    ((∀ x : D, (((N x) = ⊤) →
    (((A x) z) = x))) ∧
    ((∀ x : D, (∀ y : D, (((N x) = ⊤) →
    (((N y) = ⊤) →
    (((A x) (s y)) = (s ((A x) y))))))) ∧
    ((∀ x : D, (((N x) = ⊤) →
    (((M x) z) = z))) ∧
    ((∀ x : D, (∀ y : D, (((N x) = ⊤) →
    (((N y) = ⊤) →
    (((M x) (s y)) = ((A ((M x) y)) x)))))) ∧
    ((∀ x : D, (((N x) = ⊤) →
    (((E x) z) = (s z)))) ∧
    ((∀ x : D, (∀ y : D, (((N x) = ⊤) →
    (((N y) = ⊤) →
    (((E x) (s y)) = ((M ((E x) y)) x)))))) ∧
    (((P z) = (s z)) ∧
    (((Q z) = (s z)) ∧
    (((O z) = (s z)) ∧
    ((∀ x : D, (((N x) = ⊤) →
    ((P (s x)) = ((M (P x)) (Q x))))) ∧
    ((∀ x : D, (((N x) = ⊤) →
    ((Q (s x)) = ((E (s (s z))) (P (s x)))))) ∧
    ((∀ x : D, (((N x) = ⊤) →
    ((O (s x)) = ((A (O x)) (Q x))))) ∧
    (∀ i : D, (∀ j : D, (((N i) = ⊤) →
    (((N j) = ⊤) →
    ((((R i) j) = ⊤) ↔
    ((i = j) ∨
    (∃ k : D, (((N k) = ⊤) ∧
    ((child N s A Q O k j) ∧
    (((R i) k) = ⊤))))))))))))))))))))))))))))

def manyChildren (N : (D → D)) (s : (D → D)) (A : (D → D → D)) (Q : (D → D)) (O : (D → D)) (X : (D → D)) (w : D) (r : D) : Prop :=
  (∃ f : (D → D), ((∀ i : D, (((N i) = ⊤) →
    ((lt N s A i r) →
    (((N (f i)) = ⊤) ∧
    (((X (f i)) = ⊤) ∧
    (child N s A Q O w (f i))))))) ∧
    (∀ i : D, (∀ j : D, (((N i) = ⊤) →
    (((N j) = ⊤) →
    ((lt N s A i r) →
    ((lt N s A j r) →
    (((f i) = (f j)) →
    (i = j))))))))))

def condition (N : (D → D)) (z : D) (s : (D → D)) (A : (D → D → D)) (M : (D → D → D)) (E : (D → D → D)) (P : (D → D)) (Q : (D → D)) (O : (D → D)) (R : (D → D → D)) (X : (D → D)) : Prop :=
  ((real N X) ∧
    (((X z) = ⊤) ∧
    ((∀ j : D, (((N j) = ⊤) →
    (((X j) = ⊤) →
    (∀ i : D, (((N i) = ⊤) →
    ((((R i) j) = ⊤) →
    ((X i) = ⊤))))))) ∧
    (∀ i : D, (((N i) = ⊤) →
    (((X i) = ⊤) →
    (∀ m : D, (((N m) = ⊤) →
    (∃ w : D, (((N w) = ⊤) ∧
    (((X w) = ⊤) ∧
    ((¬ (i = w)) ∧
    ((((R i) w) = ⊤) ∧
    (manyChildren N s A Q O X w ((E (P w)) m)))))))))))))))

def subset (X : (D → D)) (Y : (D → D)) : Prop :=
  (∀ x : D, (((X x) = ⊤) →
    ((Y x) = ⊤)))

def classSubset (U : ((D → D) → D)) (V : ((D → D) → D)) : Prop :=
  (∀ X : (D → D), (((U X) = ⊤) →
    ((V X) = ⊤)))

def regular (N : (D → D)) (z : D) (s : (D → D)) (A : (D → D → D)) (M : (D → D → D)) (E : (D → D → D)) (P : (D → D)) (Q : (D → D)) (O : (D → D)) (R : (D → D → D)) (U : ((D → D) → D)) : Prop :=
  ((classCode N U) ∧
    ((∀ X : (D → D), (((U X) = ⊤) →
    (condition N z s A M E P Q O R X))) ∧
    ((∀ X : (D → D), (∀ Y : (D → D), ((condition N z s A M E P Q O R X) →
    ((condition N z s A M E P Q O R Y) →
    ((subset X Y) →
    (((U Y) = ⊤) →
    ((U X) = ⊤))))))) ∧
    (∀ X : (D → D), ((condition N z s A M E P Q O R X) →
    ((∀ Y : (D → D), ((condition N z s A M E P Q O R Y) →
    ((subset Y X) →
    (∃ V : (D → D), ((condition N z s A M E P Q O R V) ∧
    ((subset V Y) ∧
    ((U V) = ⊤))))))) →
    ((U X) = ⊤)))))))

def isomorphism (N : (D → D)) (z : D) (s : (D → D)) (A : (D → D → D)) (M : (D → D → D)) (E : (D → D → D)) (P : (D → D)) (Q : (D → D)) (O : (D → D)) (R : (D → D → D)) (f : (D → (D → D) → D)) : Prop :=
  ((∀ p : D, (regular N z s A M E P Q O R (f p))) ∧
    ((∀ U : ((D → D) → D), ((regular N z s A M E P Q O R U) →
    (∃ p : D, ((f p) = U)))) ∧
    (∀ p : D, (∀ q : D, (((p ⊓ q) = p) ↔
    (classSubset (f p) (f q)))))))

def inCylinder (N : (D → D)) (R : (D → D → D)) (i : D) (X : (D → D)) : Prop :=
  (∀ j : D, (((N j) = ⊤) →
    (((X j) = ⊤) →
    ((((R j) i) = ⊤) ∨
    (((R i) j) = ⊤)))))

def cylinder (N : (D → D)) (z : D) (s : (D → D)) (A : (D → D → D)) (M : (D → D → D)) (E : (D → D → D)) (P : (D → D)) (Q : (D → D)) (O : (D → D)) (R : (D → D → D)) (U : ((D → D) → D)) (i : D) : Prop :=
  ((regular N z s A M E P Q O R U) ∧
    (∀ X : (D → D), ((condition N z s A M E P Q O R X) →
    (((U X) = ⊤) ↔
    (inCylinder N R i X)))))

def splits (N : (D → D)) (z : D) (s : (D → D)) (A : (D → D → D)) (M : (D → D → D)) (E : (D → D → D)) (P : (D → D)) (Q : (D → D)) (O : (D → D)) (R : (D → D → D)) (U : ((D → D) → D)) (i : D) : Prop :=
  ((∃ X : (D → D), ((condition N z s A M E P Q O R X) ∧
    (((U X) = ⊤) ∧
    (inCylinder N R i X)))) ∧
    (∃ X : (D → D), ((condition N z s A M E P Q O R X) ∧
    (((U X) = ⊤) ∧
    (¬ (inCylinder N R i X))))))

def least (N : (D → D)) (z : D) (s : (D → D)) (A : (D → D → D)) (M : (D → D → D)) (E : (D → D → D)) (P : (D → D)) (Q : (D → D)) (O : (D → D)) (R : (D → D → D)) (U : ((D → D) → D)) (i : D) : Prop :=
  ((splits N z s A M E P Q O R U i) ∧
    (∀ j : D, (((N j) = ⊤) →
    ((lt N s A j i) →
    (¬ (splits N z s A M E P Q O R U j))))))

def select (p : D) (q : D) : Prop :=
  (∃ N : (D → D), (∃ z : D, (∃ s : (D → D), (∃ A : (D → D → D), (∃ M : (D → D → D), (∃ E : (D → D → D), (∃ P : (D → D), (∃ Q : (D → D), (∃ O : (D → D), (∃ R : (D → D → D), (∃ f : (D → (D → D) → D), (∃ i : D, ((frame N z s) ∧
    ((arithmetic N z s A M E P Q O R) ∧
    ((isomorphism N z s A M E P Q O R f) ∧
    (((N i) = ⊤) ∧
    ((cylinder N z s A M E P Q O R (f q) i) ∧
    (least N z s A M E P Q O R (f p) i))))))))))))))))))

end Ordinary

def frame {Γ : Ctx} (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real) : IdFormula Γ :=
  (.conj (.eq (.app N z) Term.top)
    (.conj (.all Num (.imp (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.conj (.eq (.app N.weaken (.app s.weaken (Term.var .zero))) Term.top)
    (.neg (.eq (.app s.weaken (Term.var .zero)) z.weaken)))))
    (.conj (.all Num (.imp (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.all Num (.imp (.eq (.app N.weaken.weaken (Term.var .zero)) Term.top)
    (.imp (.eq (.app s.weaken.weaken (Term.var (.succ .zero))) (.app s.weaken.weaken (Term.var .zero)))
    (.eq (Term.var (.succ .zero)) (Term.var .zero)))))))
    (.all Real (.imp (.conj (.eq (.app (Term.var .zero) z.weaken) Term.top)
    (.all Num (.imp (.eq (.app N.weaken.weaken (Term.var .zero)) Term.top)
    (.imp (.eq (.app (Term.var (.succ .zero)) (Term.var .zero)) Term.top)
    (.eq (.app (Term.var (.succ .zero)) (.app s.weaken.weaken (Term.var .zero))) Term.top)))))
    (.all Num (.imp (.eq (.app N.weaken.weaken (Term.var .zero)) Term.top)
    (.eq (.app (Term.var (.succ .zero)) (Term.var .zero)) Term.top))))))))

def real {Γ : Ctx} (N : PT Γ Real) (X : PT Γ Real) : IdFormula Γ :=
  (.all Num (.disj (.conj (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.eq (.app X.weaken (Term.var .zero)) Term.top))
    (.eq (.app X.weaken (Term.var .zero)) Term.bot)))

def classCode {Γ : Ctx} (N : PT Γ Real) (U : PT Γ Class) : IdFormula Γ :=
  (.all Real (.disj (.conj (real N.weaken (Term.var .zero))
    (.eq (.app U.weaken (Term.var .zero)) Term.top))
    (.eq (.app U.weaken (Term.var .zero)) Term.bot)))

def le {Γ : Ctx} (N : PT Γ Real) (A : PT Γ Binary) (x : PT Γ Num) (y : PT Γ Num) : IdFormula Γ :=
  (.ex Num (.conj (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.eq (.app (.app A.weaken x.weaken) (Term.var .zero)) y.weaken)))

def lt {Γ : Ctx} (N : PT Γ Real) (s : PT Γ Real) (A : PT Γ Binary) (x : PT Γ Num) (y : PT Γ Num) : IdFormula Γ :=
  (le N A (.app s x) y)

def child {Γ : Ctx} (N : PT Γ Real) (s : PT Γ Real) (A : PT Γ Binary) (Q : PT Γ Real) (O : PT Γ Real) (k : PT Γ Num) (j : PT Γ Num) : IdFormula Γ :=
  (.conj (le N A (.app O k) j)
    (lt N s A j (.app (.app A (.app O k)) (.app Q k))))

def arithmetic {Γ : Ctx} (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real) (A : PT Γ Binary) (M : PT Γ Binary) (E : PT Γ Binary) (P : PT Γ Real) (Q : PT Γ Real) (O : PT Γ Real) (R : PT Γ Binary) : IdFormula Γ :=
  (.conj (.all Num (.all Num (.imp (.eq (.app N.weaken.weaken (Term.var (.succ .zero))) Term.top)
    (.imp (.eq (.app N.weaken.weaken (Term.var .zero)) Term.top)
    (.eq (.app N.weaken.weaken (.app (.app A.weaken.weaken (Term.var (.succ .zero))) (Term.var .zero))) Term.top)))))
    (.conj (.all Num (.all Num (.imp (.eq (.app N.weaken.weaken (Term.var (.succ .zero))) Term.top)
    (.imp (.eq (.app N.weaken.weaken (Term.var .zero)) Term.top)
    (.eq (.app N.weaken.weaken (.app (.app M.weaken.weaken (Term.var (.succ .zero))) (Term.var .zero))) Term.top)))))
    (.conj (.all Num (.all Num (.imp (.eq (.app N.weaken.weaken (Term.var (.succ .zero))) Term.top)
    (.imp (.eq (.app N.weaken.weaken (Term.var .zero)) Term.top)
    (.eq (.app N.weaken.weaken (.app (.app E.weaken.weaken (Term.var (.succ .zero))) (Term.var .zero))) Term.top)))))
    (.conj (.all Num (.imp (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.eq (.app N.weaken (.app P.weaken (Term.var .zero))) Term.top)))
    (.conj (.all Num (.imp (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.eq (.app N.weaken (.app Q.weaken (Term.var .zero))) Term.top)))
    (.conj (.all Num (.imp (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.eq (.app N.weaken (.app O.weaken (Term.var .zero))) Term.top)))
    (.conj (.all Num (.imp (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.eq (.app (.app A.weaken (Term.var .zero)) z.weaken) (Term.var .zero))))
    (.conj (.all Num (.all Num (.imp (.eq (.app N.weaken.weaken (Term.var (.succ .zero))) Term.top)
    (.imp (.eq (.app N.weaken.weaken (Term.var .zero)) Term.top)
    (.eq (.app (.app A.weaken.weaken (Term.var (.succ .zero))) (.app s.weaken.weaken (Term.var .zero))) (.app s.weaken.weaken (.app (.app A.weaken.weaken (Term.var (.succ .zero))) (Term.var .zero))))))))
    (.conj (.all Num (.imp (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.eq (.app (.app M.weaken (Term.var .zero)) z.weaken) z.weaken)))
    (.conj (.all Num (.all Num (.imp (.eq (.app N.weaken.weaken (Term.var (.succ .zero))) Term.top)
    (.imp (.eq (.app N.weaken.weaken (Term.var .zero)) Term.top)
    (.eq (.app (.app M.weaken.weaken (Term.var (.succ .zero))) (.app s.weaken.weaken (Term.var .zero))) (.app (.app A.weaken.weaken (.app (.app M.weaken.weaken (Term.var (.succ .zero))) (Term.var .zero))) (Term.var (.succ .zero))))))))
    (.conj (.all Num (.imp (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.eq (.app (.app E.weaken (Term.var .zero)) z.weaken) (.app s.weaken z.weaken))))
    (.conj (.all Num (.all Num (.imp (.eq (.app N.weaken.weaken (Term.var (.succ .zero))) Term.top)
    (.imp (.eq (.app N.weaken.weaken (Term.var .zero)) Term.top)
    (.eq (.app (.app E.weaken.weaken (Term.var (.succ .zero))) (.app s.weaken.weaken (Term.var .zero))) (.app (.app M.weaken.weaken (.app (.app E.weaken.weaken (Term.var (.succ .zero))) (Term.var .zero))) (Term.var (.succ .zero))))))))
    (.conj (.eq (.app P z) (.app s z))
    (.conj (.eq (.app Q z) (.app s z))
    (.conj (.eq (.app O z) (.app s z))
    (.conj (.all Num (.imp (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.eq (.app P.weaken (.app s.weaken (Term.var .zero))) (.app (.app M.weaken (.app P.weaken (Term.var .zero))) (.app Q.weaken (Term.var .zero))))))
    (.conj (.all Num (.imp (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.eq (.app Q.weaken (.app s.weaken (Term.var .zero))) (.app (.app E.weaken (.app s.weaken (.app s.weaken z.weaken))) (.app P.weaken (.app s.weaken (Term.var .zero)))))))
    (.conj (.all Num (.imp (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.eq (.app O.weaken (.app s.weaken (Term.var .zero))) (.app (.app A.weaken (.app O.weaken (Term.var .zero))) (.app Q.weaken (Term.var .zero))))))
    (.all Num (.all Num (.imp (.eq (.app N.weaken.weaken (Term.var (.succ .zero))) Term.top)
    (.imp (.eq (.app N.weaken.weaken (Term.var .zero)) Term.top)
    (.iff (.eq (.app (.app R.weaken.weaken (Term.var (.succ .zero))) (Term.var .zero)) Term.top)
    (.disj (.eq (Term.var (.succ .zero)) (Term.var .zero))
    (.ex Num (.conj (.eq (.app N.weaken.weaken.weaken (Term.var .zero)) Term.top)
    (.conj (child N.weaken.weaken.weaken s.weaken.weaken.weaken A.weaken.weaken.weaken Q.weaken.weaken.weaken O.weaken.weaken.weaken (Term.var .zero) (Term.var (.succ .zero)))
    (.eq (.app (.app R.weaken.weaken.weaken (Term.var (.succ (.succ .zero)))) (Term.var .zero)) Term.top))))))))))))))))))))))))))))

def manyChildren {Γ : Ctx} (N : PT Γ Real) (s : PT Γ Real) (A : PT Γ Binary) (Q : PT Γ Real) (O : PT Γ Real) (X : PT Γ Real) (w : PT Γ Num) (r : PT Γ Num) : IdFormula Γ :=
  (.ex Real (.conj (.all Num (.imp (.eq (.app N.weaken.weaken (Term.var .zero)) Term.top)
    (.imp (lt N.weaken.weaken s.weaken.weaken A.weaken.weaken (Term.var .zero) r.weaken.weaken)
    (.conj (.eq (.app N.weaken.weaken (.app (Term.var (.succ .zero)) (Term.var .zero))) Term.top)
    (.conj (.eq (.app X.weaken.weaken (.app (Term.var (.succ .zero)) (Term.var .zero))) Term.top)
    (child N.weaken.weaken s.weaken.weaken A.weaken.weaken Q.weaken.weaken O.weaken.weaken w.weaken.weaken (.app (Term.var (.succ .zero)) (Term.var .zero))))))))
    (.all Num (.all Num (.imp (.eq (.app N.weaken.weaken.weaken (Term.var (.succ .zero))) Term.top)
    (.imp (.eq (.app N.weaken.weaken.weaken (Term.var .zero)) Term.top)
    (.imp (lt N.weaken.weaken.weaken s.weaken.weaken.weaken A.weaken.weaken.weaken (Term.var (.succ .zero)) r.weaken.weaken.weaken)
    (.imp (lt N.weaken.weaken.weaken s.weaken.weaken.weaken A.weaken.weaken.weaken (Term.var .zero) r.weaken.weaken.weaken)
    (.imp (.eq (.app (Term.var (.succ (.succ .zero))) (Term.var (.succ .zero))) (.app (Term.var (.succ (.succ .zero))) (Term.var .zero)))
    (.eq (Term.var (.succ .zero)) (Term.var .zero)))))))))))

def condition {Γ : Ctx} (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real) (A : PT Γ Binary) (M : PT Γ Binary) (E : PT Γ Binary) (P : PT Γ Real) (Q : PT Γ Real) (O : PT Γ Real) (R : PT Γ Binary) (X : PT Γ Real) : IdFormula Γ :=
  (.conj (real N X)
    (.conj (.eq (.app X z) Term.top)
    (.conj (.all Num (.imp (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.imp (.eq (.app X.weaken (Term.var .zero)) Term.top)
    (.all Num (.imp (.eq (.app N.weaken.weaken (Term.var .zero)) Term.top)
    (.imp (.eq (.app (.app R.weaken.weaken (Term.var .zero)) (Term.var (.succ .zero))) Term.top)
    (.eq (.app X.weaken.weaken (Term.var .zero)) Term.top)))))))
    (.all Num (.imp (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.imp (.eq (.app X.weaken (Term.var .zero)) Term.top)
    (.all Num (.imp (.eq (.app N.weaken.weaken (Term.var .zero)) Term.top)
    (.ex Num (.conj (.eq (.app N.weaken.weaken.weaken (Term.var .zero)) Term.top)
    (.conj (.eq (.app X.weaken.weaken.weaken (Term.var .zero)) Term.top)
    (.conj (.neg (.eq (Term.var (.succ (.succ .zero))) (Term.var .zero)))
    (.conj (.eq (.app (.app R.weaken.weaken.weaken (Term.var (.succ (.succ .zero)))) (Term.var .zero)) Term.top)
    (manyChildren N.weaken.weaken.weaken s.weaken.weaken.weaken A.weaken.weaken.weaken Q.weaken.weaken.weaken O.weaken.weaken.weaken X.weaken.weaken.weaken (Term.var .zero) (.app (.app E.weaken.weaken.weaken (.app P.weaken.weaken.weaken (Term.var .zero))) (Term.var (.succ .zero)))))))))))))))))

def subset {Γ : Ctx} (X : PT Γ Real) (Y : PT Γ Real) : IdFormula Γ :=
  (.all Num (.imp (.eq (.app X.weaken (Term.var .zero)) Term.top)
    (.eq (.app Y.weaken (Term.var .zero)) Term.top)))

def classSubset {Γ : Ctx} (U : PT Γ Class) (V : PT Γ Class) : IdFormula Γ :=
  (.all Real (.imp (.eq (.app U.weaken (Term.var .zero)) Term.top)
    (.eq (.app V.weaken (Term.var .zero)) Term.top)))

def regular {Γ : Ctx} (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real) (A : PT Γ Binary) (M : PT Γ Binary) (E : PT Γ Binary) (P : PT Γ Real) (Q : PT Γ Real) (O : PT Γ Real) (R : PT Γ Binary) (U : PT Γ Class) : IdFormula Γ :=
  (.conj (classCode N U)
    (.conj (.all Real (.imp (.eq (.app U.weaken (Term.var .zero)) Term.top)
    (condition N.weaken z.weaken s.weaken A.weaken M.weaken E.weaken P.weaken Q.weaken O.weaken R.weaken (Term.var .zero))))
    (.conj (.all Real (.all Real (.imp (condition N.weaken.weaken z.weaken.weaken s.weaken.weaken A.weaken.weaken M.weaken.weaken E.weaken.weaken P.weaken.weaken Q.weaken.weaken O.weaken.weaken R.weaken.weaken (Term.var (.succ .zero)))
    (.imp (condition N.weaken.weaken z.weaken.weaken s.weaken.weaken A.weaken.weaken M.weaken.weaken E.weaken.weaken P.weaken.weaken Q.weaken.weaken O.weaken.weaken R.weaken.weaken (Term.var .zero))
    (.imp (subset (Term.var (.succ .zero)) (Term.var .zero))
    (.imp (.eq (.app U.weaken.weaken (Term.var .zero)) Term.top)
    (.eq (.app U.weaken.weaken (Term.var (.succ .zero))) Term.top)))))))
    (.all Real (.imp (condition N.weaken z.weaken s.weaken A.weaken M.weaken E.weaken P.weaken Q.weaken O.weaken R.weaken (Term.var .zero))
    (.imp (.all Real (.imp (condition N.weaken.weaken z.weaken.weaken s.weaken.weaken A.weaken.weaken M.weaken.weaken E.weaken.weaken P.weaken.weaken Q.weaken.weaken O.weaken.weaken R.weaken.weaken (Term.var .zero))
    (.imp (subset (Term.var .zero) (Term.var (.succ .zero)))
    (.ex Real (.conj (condition N.weaken.weaken.weaken z.weaken.weaken.weaken s.weaken.weaken.weaken A.weaken.weaken.weaken M.weaken.weaken.weaken E.weaken.weaken.weaken P.weaken.weaken.weaken Q.weaken.weaken.weaken O.weaken.weaken.weaken R.weaken.weaken.weaken (Term.var .zero))
    (.conj (subset (Term.var .zero) (Term.var (.succ .zero)))
    (.eq (.app U.weaken.weaken.weaken (Term.var .zero)) Term.top)))))))
    (.eq (.app U.weaken (Term.var .zero)) Term.top)))))))

def isomorphism {Γ : Ctx} (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real) (A : PT Γ Binary) (M : PT Γ Binary) (E : PT Γ Binary) (P : PT Γ Real) (Q : PT Γ Real) (O : PT Γ Real) (R : PT Γ Binary) (f : PT Γ (Num ⇒ Class)) : IdFormula Γ :=
  (.conj (.all Num (regular N.weaken z.weaken s.weaken A.weaken M.weaken E.weaken P.weaken Q.weaken O.weaken R.weaken (.app f.weaken (Term.var .zero))))
    (.conj (.all Class (.imp (regular N.weaken z.weaken s.weaken A.weaken M.weaken E.weaken P.weaken Q.weaken O.weaken R.weaken (Term.var .zero))
    (.ex Num (.eq (.app f.weaken.weaken (Term.var .zero)) (Term.var (.succ .zero))))))
    (.all Num (.all Num (.iff (.eq (Term.conj (Term.var (.succ .zero)) (Term.var .zero)) (Term.var (.succ .zero)))
    (classSubset (.app f.weaken.weaken (Term.var (.succ .zero))) (.app f.weaken.weaken (Term.var .zero))))))))

def inCylinder {Γ : Ctx} (N : PT Γ Real) (R : PT Γ Binary) (i : PT Γ Num) (X : PT Γ Real) : IdFormula Γ :=
  (.all Num (.imp (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.imp (.eq (.app X.weaken (Term.var .zero)) Term.top)
    (.disj (.eq (.app (.app R.weaken (Term.var .zero)) i.weaken) Term.top)
    (.eq (.app (.app R.weaken i.weaken) (Term.var .zero)) Term.top)))))

def cylinder {Γ : Ctx} (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real) (A : PT Γ Binary) (M : PT Γ Binary) (E : PT Γ Binary) (P : PT Γ Real) (Q : PT Γ Real) (O : PT Γ Real) (R : PT Γ Binary) (U : PT Γ Class) (i : PT Γ Num) : IdFormula Γ :=
  (.conj (regular N z s A M E P Q O R U)
    (.all Real (.imp (condition N.weaken z.weaken s.weaken A.weaken M.weaken E.weaken P.weaken Q.weaken O.weaken R.weaken (Term.var .zero))
    (.iff (.eq (.app U.weaken (Term.var .zero)) Term.top)
    (inCylinder N.weaken R.weaken i.weaken (Term.var .zero))))))

def splits {Γ : Ctx} (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real) (A : PT Γ Binary) (M : PT Γ Binary) (E : PT Γ Binary) (P : PT Γ Real) (Q : PT Γ Real) (O : PT Γ Real) (R : PT Γ Binary) (U : PT Γ Class) (i : PT Γ Num) : IdFormula Γ :=
  (.conj (.ex Real (.conj (condition N.weaken z.weaken s.weaken A.weaken M.weaken E.weaken P.weaken Q.weaken O.weaken R.weaken (Term.var .zero))
    (.conj (.eq (.app U.weaken (Term.var .zero)) Term.top)
    (inCylinder N.weaken R.weaken i.weaken (Term.var .zero)))))
    (.ex Real (.conj (condition N.weaken z.weaken s.weaken A.weaken M.weaken E.weaken P.weaken Q.weaken O.weaken R.weaken (Term.var .zero))
    (.conj (.eq (.app U.weaken (Term.var .zero)) Term.top)
    (.neg (inCylinder N.weaken R.weaken i.weaken (Term.var .zero)))))))

def least {Γ : Ctx} (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real) (A : PT Γ Binary) (M : PT Γ Binary) (E : PT Γ Binary) (P : PT Γ Real) (Q : PT Γ Real) (O : PT Γ Real) (R : PT Γ Binary) (U : PT Γ Class) (i : PT Γ Num) : IdFormula Γ :=
  (.conj (splits N z s A M E P Q O R U i)
    (.all Num (.imp (.eq (.app N.weaken (Term.var .zero)) Term.top)
    (.imp (lt N.weaken s.weaken A.weaken (Term.var .zero) i.weaken)
    (.neg (splits N.weaken z.weaken s.weaken A.weaken M.weaken E.weaken P.weaken Q.weaken O.weaken R.weaken U.weaken (Term.var .zero)))))))

def select {Γ : Ctx} (p : PT Γ Num) (q : PT Γ Num) : IdFormula Γ :=
  (.ex Real (.ex Num (.ex Real (.ex Binary (.ex Binary (.ex Binary (.ex Real (.ex Real (.ex Real (.ex Binary (.ex (Num ⇒ Class) (.ex Num (.conj (frame (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero)))))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero))))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero)))))))))))
    (.conj (arithmetic (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero)))))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero))))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero)))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero)))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ .zero))))))) (Term.var (.succ (.succ (.succ (.succ (.succ .zero)))))) (Term.var (.succ (.succ (.succ (.succ .zero))))) (Term.var (.succ (.succ (.succ .zero)))) (Term.var (.succ (.succ .zero))))
    (.conj (isomorphism (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero)))))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero))))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero)))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero)))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ .zero))))))) (Term.var (.succ (.succ (.succ (.succ (.succ .zero)))))) (Term.var (.succ (.succ (.succ (.succ .zero))))) (Term.var (.succ (.succ (.succ .zero)))) (Term.var (.succ (.succ .zero))) (Term.var (.succ .zero)))
    (.conj (.eq (.app (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero)))))))))))) (Term.var .zero)) Term.top)
    (.conj (cylinder (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero)))))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero))))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero)))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero)))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ .zero))))))) (Term.var (.succ (.succ (.succ (.succ (.succ .zero)))))) (Term.var (.succ (.succ (.succ (.succ .zero))))) (Term.var (.succ (.succ (.succ .zero)))) (Term.var (.succ (.succ .zero))) (.app (Term.var (.succ .zero)) q.weaken.weaken.weaken.weaken.weaken.weaken.weaken.weaken.weaken.weaken.weaken.weaken) (Term.var .zero))
    (least (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero)))))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero))))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero)))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero))))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ (.succ .zero)))))))) (Term.var (.succ (.succ (.succ (.succ (.succ (.succ .zero))))))) (Term.var (.succ (.succ (.succ (.succ (.succ .zero)))))) (Term.var (.succ (.succ (.succ (.succ .zero))))) (Term.var (.succ (.succ (.succ .zero)))) (Term.var (.succ (.succ .zero))) (.app (Term.var (.succ .zero)) p.weaken.weaken.weaken.weaken.weaken.weaken.weaken.weaken.weaken.weaken.weaken.weaken) (Term.var .zero)))))))))))))))))))

noncomputable section

variable {D : Type} [CompleteBooleanAlgebra D]
variable (I : Interpretation Signature.pure D) {Γ : Ctx}

theorem holds_frame (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real)
    (env : IEnv (Dom I.E D) Γ) :
    (frame N z s).holds I env ↔
      Ordinary.frame (eval I N env) (eval I z env) (eval I s env) := by
  simp only [frame, Ordinary.frame, IdFormula.holds,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_real (N : PT Γ Real) (X : PT Γ Real)
    (env : IEnv (Dom I.E D) Γ) :
    (real N X).holds I env ↔
      Ordinary.real (eval I N env) (eval I X env) := by
  simp only [real, Ordinary.real, IdFormula.holds,
    holds_frame,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_classCode (N : PT Γ Real) (U : PT Γ Class)
    (env : IEnv (Dom I.E D) Γ) :
    (classCode N U).holds I env ↔
      Ordinary.classCode (eval I N env) (eval I U env) := by
  simp only [classCode, Ordinary.classCode, IdFormula.holds,
    holds_frame, holds_real,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_le (N : PT Γ Real) (A : PT Γ Binary) (x : PT Γ Num) (y : PT Γ Num)
    (env : IEnv (Dom I.E D) Γ) :
    (le N A x y).holds I env ↔
      Ordinary.le (eval I N env) (eval I A env) (eval I x env) (eval I y env) := by
  simp only [le, Ordinary.le, IdFormula.holds,
    holds_frame, holds_real, holds_classCode,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_lt (N : PT Γ Real) (s : PT Γ Real) (A : PT Γ Binary) (x : PT Γ Num) (y : PT Γ Num)
    (env : IEnv (Dom I.E D) Γ) :
    (lt N s A x y).holds I env ↔
      Ordinary.lt (eval I N env) (eval I s env) (eval I A env) (eval I x env) (eval I y env) := by
  simp only [lt, Ordinary.lt, IdFormula.holds,
    holds_frame, holds_real, holds_classCode, holds_le,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_child (N : PT Γ Real) (s : PT Γ Real) (A : PT Γ Binary) (Q : PT Γ Real) (O : PT Γ Real) (k : PT Γ Num) (j : PT Γ Num)
    (env : IEnv (Dom I.E D) Γ) :
    (child N s A Q O k j).holds I env ↔
      Ordinary.child (eval I N env) (eval I s env) (eval I A env) (eval I Q env) (eval I O env) (eval I k env) (eval I j env) := by
  simp only [child, Ordinary.child, IdFormula.holds,
    holds_frame, holds_real, holds_classCode, holds_le, holds_lt,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_arithmetic (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real) (A : PT Γ Binary) (M : PT Γ Binary) (E : PT Γ Binary) (P : PT Γ Real) (Q : PT Γ Real) (O : PT Γ Real) (R : PT Γ Binary)
    (env : IEnv (Dom I.E D) Γ) :
    (arithmetic N z s A M E P Q O R).holds I env ↔
      Ordinary.arithmetic (eval I N env) (eval I z env) (eval I s env) (eval I A env) (eval I M env) (eval I E env) (eval I P env) (eval I Q env) (eval I O env) (eval I R env) := by
  simp only [arithmetic, Ordinary.arithmetic, IdFormula.holds,
    holds_frame, holds_real, holds_classCode, holds_le, holds_lt, holds_child,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_manyChildren (N : PT Γ Real) (s : PT Γ Real) (A : PT Γ Binary) (Q : PT Γ Real) (O : PT Γ Real) (X : PT Γ Real) (w : PT Γ Num) (r : PT Γ Num)
    (env : IEnv (Dom I.E D) Γ) :
    (manyChildren N s A Q O X w r).holds I env ↔
      Ordinary.manyChildren (eval I N env) (eval I s env) (eval I A env) (eval I Q env) (eval I O env) (eval I X env) (eval I w env) (eval I r env) := by
  simp only [manyChildren, Ordinary.manyChildren, IdFormula.holds,
    holds_frame, holds_real, holds_classCode, holds_le, holds_lt, holds_child, holds_arithmetic,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_condition (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real) (A : PT Γ Binary) (M : PT Γ Binary) (E : PT Γ Binary) (P : PT Γ Real) (Q : PT Γ Real) (O : PT Γ Real) (R : PT Γ Binary) (X : PT Γ Real)
    (env : IEnv (Dom I.E D) Γ) :
    (condition N z s A M E P Q O R X).holds I env ↔
      Ordinary.condition (eval I N env) (eval I z env) (eval I s env) (eval I A env) (eval I M env) (eval I E env) (eval I P env) (eval I Q env) (eval I O env) (eval I R env) (eval I X env) := by
  simp only [condition, Ordinary.condition, IdFormula.holds,
    holds_frame, holds_real, holds_classCode, holds_le, holds_lt, holds_child, holds_arithmetic, holds_manyChildren,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_subset (X : PT Γ Real) (Y : PT Γ Real)
    (env : IEnv (Dom I.E D) Γ) :
    (subset X Y).holds I env ↔
      Ordinary.subset (eval I X env) (eval I Y env) := by
  simp only [subset, Ordinary.subset, IdFormula.holds,
    holds_frame, holds_real, holds_classCode, holds_le, holds_lt, holds_child, holds_arithmetic, holds_manyChildren, holds_condition,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_classSubset (U : PT Γ Class) (V : PT Γ Class)
    (env : IEnv (Dom I.E D) Γ) :
    (classSubset U V).holds I env ↔
      Ordinary.classSubset (eval I U env) (eval I V env) := by
  simp only [classSubset, Ordinary.classSubset, IdFormula.holds,
    holds_frame, holds_real, holds_classCode, holds_le, holds_lt, holds_child, holds_arithmetic, holds_manyChildren, holds_condition, holds_subset,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_regular (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real) (A : PT Γ Binary) (M : PT Γ Binary) (E : PT Γ Binary) (P : PT Γ Real) (Q : PT Γ Real) (O : PT Γ Real) (R : PT Γ Binary) (U : PT Γ Class)
    (env : IEnv (Dom I.E D) Γ) :
    (regular N z s A M E P Q O R U).holds I env ↔
      Ordinary.regular (eval I N env) (eval I z env) (eval I s env) (eval I A env) (eval I M env) (eval I E env) (eval I P env) (eval I Q env) (eval I O env) (eval I R env) (eval I U env) := by
  simp only [regular, Ordinary.regular, IdFormula.holds,
    holds_frame, holds_real, holds_classCode, holds_le, holds_lt, holds_child, holds_arithmetic, holds_manyChildren, holds_condition, holds_subset, holds_classSubset,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_isomorphism (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real) (A : PT Γ Binary) (M : PT Γ Binary) (E : PT Γ Binary) (P : PT Γ Real) (Q : PT Γ Real) (O : PT Γ Real) (R : PT Γ Binary) (f : PT Γ (Num ⇒ Class))
    (env : IEnv (Dom I.E D) Γ) :
    (isomorphism N z s A M E P Q O R f).holds I env ↔
      Ordinary.isomorphism (eval I N env) (eval I z env) (eval I s env) (eval I A env) (eval I M env) (eval I E env) (eval I P env) (eval I Q env) (eval I O env) (eval I R env) (eval I f env) := by
  simp only [isomorphism, Ordinary.isomorphism, IdFormula.holds,
    holds_frame, holds_real, holds_classCode, holds_le, holds_lt, holds_child, holds_arithmetic, holds_manyChildren, holds_condition, holds_subset, holds_classSubset, holds_regular,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_inCylinder (N : PT Γ Real) (R : PT Γ Binary) (i : PT Γ Num) (X : PT Γ Real)
    (env : IEnv (Dom I.E D) Γ) :
    (inCylinder N R i X).holds I env ↔
      Ordinary.inCylinder (eval I N env) (eval I R env) (eval I i env) (eval I X env) := by
  simp only [inCylinder, Ordinary.inCylinder, IdFormula.holds,
    holds_frame, holds_real, holds_classCode, holds_le, holds_lt, holds_child, holds_arithmetic, holds_manyChildren, holds_condition, holds_subset, holds_classSubset, holds_regular, holds_isomorphism,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_cylinder (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real) (A : PT Γ Binary) (M : PT Γ Binary) (E : PT Γ Binary) (P : PT Γ Real) (Q : PT Γ Real) (O : PT Γ Real) (R : PT Γ Binary) (U : PT Γ Class) (i : PT Γ Num)
    (env : IEnv (Dom I.E D) Γ) :
    (cylinder N z s A M E P Q O R U i).holds I env ↔
      Ordinary.cylinder (eval I N env) (eval I z env) (eval I s env) (eval I A env) (eval I M env) (eval I E env) (eval I P env) (eval I Q env) (eval I O env) (eval I R env) (eval I U env) (eval I i env) := by
  simp only [cylinder, Ordinary.cylinder, IdFormula.holds,
    holds_frame, holds_real, holds_classCode, holds_le, holds_lt, holds_child, holds_arithmetic, holds_manyChildren, holds_condition, holds_subset, holds_classSubset, holds_regular, holds_isomorphism, holds_inCylinder,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_splits (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real) (A : PT Γ Binary) (M : PT Γ Binary) (E : PT Γ Binary) (P : PT Γ Real) (Q : PT Γ Real) (O : PT Γ Real) (R : PT Γ Binary) (U : PT Γ Class) (i : PT Γ Num)
    (env : IEnv (Dom I.E D) Γ) :
    (splits N z s A M E P Q O R U i).holds I env ↔
      Ordinary.splits (eval I N env) (eval I z env) (eval I s env) (eval I A env) (eval I M env) (eval I E env) (eval I P env) (eval I Q env) (eval I O env) (eval I R env) (eval I U env) (eval I i env) := by
  simp only [splits, Ordinary.splits, IdFormula.holds,
    holds_frame, holds_real, holds_classCode, holds_le, holds_lt, holds_child, holds_arithmetic, holds_manyChildren, holds_condition, holds_subset, holds_classSubset, holds_regular, holds_isomorphism, holds_inCylinder, holds_cylinder,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_least (N : PT Γ Real) (z : PT Γ Num) (s : PT Γ Real) (A : PT Γ Binary) (M : PT Γ Binary) (E : PT Γ Binary) (P : PT Γ Real) (Q : PT Γ Real) (O : PT Γ Real) (R : PT Γ Binary) (U : PT Γ Class) (i : PT Γ Num)
    (env : IEnv (Dom I.E D) Γ) :
    (least N z s A M E P Q O R U i).holds I env ↔
      Ordinary.least (eval I N env) (eval I z env) (eval I s env) (eval I A env) (eval I M env) (eval I E env) (eval I P env) (eval I Q env) (eval I O env) (eval I R env) (eval I U env) (eval I i env) := by
  simp only [least, Ordinary.least, IdFormula.holds,
    holds_frame, holds_real, holds_classCode, holds_le, holds_lt, holds_child, holds_arithmetic, holds_manyChildren, holds_condition, holds_subset, holds_classSubset, holds_regular, holds_isomorphism, holds_inCylinder, holds_cylinder, holds_splits,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

theorem holds_select (p : PT Γ Num) (q : PT Γ Num)
    (env : IEnv (Dom I.E D) Γ) :
    (select p q).holds I env ↔
      Ordinary.select (eval I p env) (eval I q env) := by
  simp only [select, Ordinary.select, IdFormula.holds,
    holds_frame, holds_real, holds_classCode, holds_le, holds_lt, holds_child, holds_arithmetic, holds_manyChildren, holds_condition, holds_subset, holds_classSubset, holds_regular, holds_isomorphism, holds_inCylinder, holds_cylinder, holds_splits, holds_least,
    eval_app, eval_weaken, eval_conj, eval_top, eval_bot,
    BooleanValued.eval, IEnv.get, sup_compl_eq_top, inf_compl_eq_bot]

/-- The closed pure selector, with the selected proposition as the last
conjunct. The outer existential is Boolean pooling, not a choice constant. -/
def selector : Term Signature.pure [] Real :=
  .lam (Term.exists' (σ := Num)
    (Term.conj (select Term.v1 Term.v0).term Term.v0))

set_option maxRecDepth 100000 in
theorem selector_closedTypes : selector.closedTypes = true := rfl

theorem selector_pure : selector.pure = true := selector.pure_of_pureSig

theorem eval_selector (p : D) :
    eval I selector .nil p = ⨆ q : D, truth (Ordinary.select p q) ⊓ q := by
  simp only [selector, eval_lam, eval_exists, eval_conj, eval_term,
    holds_select, eval_v0, eval_v1]

end

#print axioms holds_select
#print axioms selector_closedTypes
#print axioms eval_selector

end Classicism.Meta.Research.MaxAtomicityThirdOrderSyntax
