import Classicism.Results.Research.MaxAtomicityThirdOrderBridge
import Classicism.Semantics.BooleanValuedSoundness
import Classicism.Results.Research.MaxAtomicityDirectObstruction

/-!
# Pure Max + unboxed Atomicity, with the third-order code

The finite closed pure selector is defined in ThirdOrderSyntax. Its full
Boolean-valued interpretation is established by ThirdOrderBridge, using the
existing Jech--Shelah rigidity theorem. The direct Atomicity obstruction then
finishes the same exact inconsistency target as the retained certificate.

This module does not import the old final theorem, concrete HCode model,
hereditary-small-set coding, or Mostowski-collapse construction.
Direct source: original formalization, misc, 25 October 2026, implementing the
upstream simplification cited in the sibling modules.

Verification evidence for this replacement is recorded separately in
research/2026-10-25/proof-simplification/max-atomicity-third-order-status.json.
The retained original certificate applies to the original proof only.
-/

namespace Classicism.Meta.Research.MaxAtomicityThirdOrderInconsistency

set_option backward.isDefEq.respectTransparency false

open BooleanValued MaxAtomicityIdentityFormula MaxAtomicityThirdOrderSyntax
open MaxAtomicityThirdOrderBridge MaxAtomicityJechShelahCylinders
open MaxAtomicityEvalTools

noncomputable section

/-- Singleton individuals and full function domains at every arrow type. -/
def interpretation : Interpretation Signature.pure B := Interpretation.ofDomain Unit B

instance : Nonempty interpretation.E := inferInstanceAs (Nonempty Unit)

abbrev F : Term Signature.pure [] Real := selector

theorem F_closedTypes : F.closedTypes = true := selector_closedTypes

theorem F_splits (p : B) (hp : p ≠ ⊥) :
    p ⊓ eval interpretation F .nil p ≠ ⊥ ∧
      p ⊓ (eval interpretation F .nil p)ᶜ ≠ ⊥ := by
  obtain ⟨q, hq, hu, hl, hr⟩ := select_exists_unique hp
  have he : eval interpretation F .nil p = q := by
    rw [eval_selector]
    exact guardedSup_unique (Ordinary.select p) q hq hu
  rw [he]
  exact ⟨hl, hr⟩

theorem eval_split :
    eval interpretation (MaxAtomicityDirectObstruction.split F) .nil = ⊤ := by
  classical
  simp only [MaxAtomicityDirectObstruction.split,
    MaxAtomicityDirectObstruction.splitParts, eval_forall, eval_imp,
    eval_neg, eval_eq, eval_conj]
  simp only [eval_bot, eval_app, eval_weaken, eval_v0, compl_compl, inf_compl_eq_bot]
  apply top_unique
  apply le_iInf
  intro p
  by_cases hp : p = ⊥
  · simp [crisp, hp]
  · simpa [crisp, hp] using F_splits p hp

theorem split_identity_not_C_theorem :
    ¬ C.Theorem (Term.eq' (MaxAtomicityDirectObstruction.split F) Term.bot) := by
  apply unequal_values_not_identity interpretation
  rw [eval_split, eval_bot]
  exact top_ne_bot

/-- Pure Max(C), with bare-C theoremhood in the schema side condition, and
Atomicity at t, unboxed. No signature or optional strengthening is added. -/
theorem maximalism_atomicity_inconsistent :
    ¬ AxiomSet.Consistent (AxiomSet.maximalist ∪ P.AtomicityT.schema) :=
  MaxAtomicityDirectObstruction.inconsistent_of_split_not_zero_theorem
    F F_closedTypes split_identity_not_C_theorem

#print axioms F_closedTypes
#print axioms F_splits
#print axioms eval_split
#print axioms split_identity_not_C_theorem
#print axioms maximalism_atomicity_inconsistent

end

end Classicism.Meta.Research.MaxAtomicityThirdOrderInconsistency
