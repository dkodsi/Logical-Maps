import Classicism.Results.Research.MaxAtomicityThirdOrderDomains
import Classicism.Results.Research.MaxAtomicityJechShelahIndexCoding

/-!
# Arithmetic and indexed tree conditions in a standard numerical frame

External semantic layer for the finite third-order code. All arithmetic
conditions below are finite ordinary formulas. Their standard interpretation
and witnesses are proved, rather than supplied as formula-adequacy premises.
The subsequent C-syntax bridge must translate these formulas and establish its
own evaluation theorem. No HCode, hereditary universe, or old final theorem is
used. Original formalization, misc, 25 October 2026; the indexed forcing is
Jech--Shelah, Journal of Algebra 182 (1996), pp. 749--750.

Verification evidence is recorded in the accompanying third-order status and compiler manifests.
-/

namespace Classicism.Meta.Research.MaxAtomicityThirdOrderArithmetic

open MaxAtomicityThirdOrderDomains
open MaxAtomicityJechShelahTrees

noncomputable section

universe u

variable {B : Type u} [CompleteBooleanAlgebra B] [Nontrivial B]

structure Data (B : Type u) where
  add : B → B → B
  mul : B → B → B
  pow : B → B → B
  p : B → B
  n : B → B
  o : B → B
  ancestor : B → B → Prop

def Le (N : B → B) (a : Data B) (x y : B) : Prop :=
  ∃ d, N d = ⊤ ∧ a.add x d = y

def Lt (N : B → B) (s : B → B) (a : Data B) (x y : B) : Prop :=
  Le N a (s x) y

def Child (N : B → B) (s : B → B) (a : Data B) (k j : B) : Prop :=
  Le N a (a.o k) j ∧ Lt N s a j (a.add (a.o k) (a.n k))

structure Arithmetic {N : B → B} {z : B} {s : B → B}
    (h : NatFrame N z s) (a : Data B) : Prop where
  add_mem : ∀ x y, N x = ⊤ → N y = ⊤ → N (a.add x y) = ⊤
  mul_mem : ∀ x y, N x = ⊤ → N y = ⊤ → N (a.mul x y) = ⊤
  pow_mem : ∀ x y, N x = ⊤ → N y = ⊤ → N (a.pow x y) = ⊤
  p_mem : ∀ x, N x = ⊤ → N (a.p x) = ⊤
  n_mem : ∀ x, N x = ⊤ → N (a.n x) = ⊤
  o_mem : ∀ x, N x = ⊤ → N (a.o x) = ⊤
  add_zero : ∀ x, N x = ⊤ → a.add x z = x
  add_succ : ∀ x y, N x = ⊤ → N y = ⊤ → a.add x (s y) = s (a.add x y)
  mul_zero : ∀ x, N x = ⊤ → a.mul x z = z
  mul_succ : ∀ x y, N x = ⊤ → N y = ⊤ → a.mul x (s y) = a.add (a.mul x y) x
  pow_zero : ∀ x, N x = ⊤ → a.pow x z = s z
  pow_succ : ∀ x y, N x = ⊤ → N y = ⊤ → a.pow x (s y) = a.mul (a.pow x y) x
  p_zero : a.p z = s z
  n_zero : a.n z = s z
  o_zero : a.o z = s z
  p_succ : ∀ x, N x = ⊤ → a.p (s x) = a.mul (a.p x) (a.n x)
  n_succ : ∀ x, N x = ⊤ → a.n (s x) = a.pow (s (s z)) (a.p (s x))
  o_succ : ∀ x, N x = ⊤ → a.o (s x) = a.add (a.o x) (a.n x)
  ancestor_recursion : ∀ i j, N i = ⊤ → N j = ⊤ →
    (a.ancestor i j ↔ i = j ∨ ∃ k, N k = ⊤ ∧ Child N s a k j ∧ a.ancestor i k)

/-- A full carrier function is injective only on the specified finite initial
segment; nothing is required of its values outside that segment. -/
def ManyChildren (N : B → B) (s : B → B) (a : Data B)
    (X : B → B) (v r : B) : Prop :=
  ∃ f : B → B,
    (∀ i, N i = ⊤ → Lt N s a i r →
      N (f i) = ⊤ ∧ X (f i) = ⊤ ∧ Child N s a v (f i)) ∧
    (∀ i j, N i = ⊤ → N j = ⊤ → Lt N s a i r → Lt N s a j r →
      f i = f j → i = j)

def ConditionCode (N : B → B) (z : B) (s : B → B) (a : Data B)
    (X : B → B) : Prop :=
  RealCode N X ∧ X z = ⊤ ∧
    (∀ j, N j = ⊤ → X j = ⊤ → ∀ i, N i = ⊤ → a.ancestor i j → X i = ⊤) ∧
    ∀ i, N i = ⊤ → X i = ⊤ → ∀ m, N m = ⊤ →
      ∃ v, N v = ⊤ ∧ X v = ⊤ ∧ i ≠ v ∧ a.ancestor i v ∧
        ManyChildren N s a X v (a.pow (a.p v) m)

namespace Arithmetic

variable {N : B → B} {z : B} {s : B → B} {h : NatFrame N z s}
  {a : Data B} (ha : Arithmetic h a)

include ha

theorem add_numeral (m n : ℕ) :
    a.add (h.numeral m) (h.numeral n) = h.numeral (m + n) := by
  induction n with
  | zero => exact ha.add_zero _ (h.numeral_mem m)
  | succ n ih =>
    change a.add (h.numeral m) (s (h.numeral n)) = h.numeral ((m + n) + 1)
    rw [ha.add_succ _ _ (h.numeral_mem m) (h.numeral_mem n), ih, h.numeral_succ]

theorem mul_numeral (m n : ℕ) :
    a.mul (h.numeral m) (h.numeral n) = h.numeral (m * n) := by
  induction n with
  | zero => exact ha.mul_zero _ (h.numeral_mem m)
  | succ n ih =>
    change a.mul (h.numeral m) (s (h.numeral n)) = h.numeral (m * (n + 1))
    rw [ha.mul_succ _ _ (h.numeral_mem m) (h.numeral_mem n), ih,
      ha.add_numeral, Nat.mul_succ]

theorem pow_numeral (m n : ℕ) :
    a.pow (h.numeral m) (h.numeral n) = h.numeral (m ^ n) := by
  induction n with
  | zero =>
    rw [_root_.pow_zero, h.numeral_zero]
    change a.pow (h.numeral m) z = h.numeral (0 + 1)
    rw [h.numeral_succ, h.numeral_zero]
    exact ha.pow_zero _ (h.numeral_mem m)
  | succ n ih =>
    change a.pow (h.numeral m) (s (h.numeral n)) = h.numeral (m ^ (n + 1))
    rw [ha.pow_succ _ _ (h.numeral_mem m) (h.numeral_mem n), ih,
      ha.mul_numeral, _root_.pow_succ]

theorem growth_numeral (k : ℕ) :
    a.p (h.numeral k) = h.numeral (growthP k) ∧
    a.n (h.numeral k) = h.numeral (growthN k) ∧
    a.o (h.numeral k) = h.numeral (offset k) := by
  induction k with
  | zero => exact ⟨ha.p_zero, ha.n_zero, ha.o_zero⟩
  | succ k ih =>
    have hp : a.p (h.numeral (k + 1)) = h.numeral (growthP (k + 1)) := by
      change a.p (s (h.numeral k)) = _
      rw [ha.p_succ _ (h.numeral_mem k), ih.1, ih.2.1, ha.mul_numeral,
        growthP_succ]
    refine ⟨hp, ?_, ?_⟩
    · change a.n (s (h.numeral k)) = _
      rw [ha.n_succ _ (h.numeral_mem k)]
      change a.pow (h.numeral 2) (a.p (h.numeral (k + 1))) = _
      rw [hp, ha.pow_numeral, growthN_succ]
    · change a.o (s (h.numeral k)) = _
      rw [ha.o_succ _ (h.numeral_mem k), ih.2.2, ih.2.1, ha.add_numeral,
        offset_succ]

theorem p_numeral (k : ℕ) : a.p (h.numeral k) = h.numeral (growthP k) :=
  (ha.growth_numeral k).1

theorem n_numeral (k : ℕ) : a.n (h.numeral k) = h.numeral (growthN k) :=
  (ha.growth_numeral k).2.1

theorem o_numeral (k : ℕ) : a.o (h.numeral k) = h.numeral (offset k) :=
  (ha.growth_numeral k).2.2

theorem le_numeral (m n : ℕ) : Le N a (h.numeral m) (h.numeral n) ↔ m ≤ n := by
  constructor
  · rintro ⟨d, hd, heq⟩
    obtain ⟨k, rfl⟩ := (h.mem_iff_range d).1 hd
    rw [ha.add_numeral] at heq
    have hh := h.numeral_injective heq
    omega
  · intro hmn
    refine ⟨h.numeral (n - m), h.numeral_mem _, ?_⟩
    rw [ha.add_numeral, Nat.add_sub_of_le hmn]

theorem lt_numeral (m n : ℕ) :
    Lt N s a (h.numeral m) (h.numeral n) ↔ m < n := by
  change Le N a (h.numeral (m + 1)) (h.numeral n) ↔ m < n
  rw [ha.le_numeral]
  omega

theorem child_numeral (k j : ℕ) :
    Child N s a (h.numeral k) (h.numeral j) ↔ MaxAtomicityJechShelahIndexCoding.Child k j := by
  unfold Child MaxAtomicityJechShelahIndexCoding.Child
  rw [ha.o_numeral, ha.n_numeral, ha.add_numeral, ha.le_numeral, ha.lt_numeral]

theorem ancestor_numeral (i j : ℕ) :
    a.ancestor (h.numeral i) (h.numeral j) ↔ MaxAtomicityJechShelahIndexCoding.Ancestor i j := by
  apply MaxAtomicityJechShelahIndexCoding.ancestor_unique
    (fun k l => a.ancestor (h.numeral k) (h.numeral l)) ?_ i j
  intro k l
  rw [ha.ancestor_recursion _ _ (h.numeral_mem k) (h.numeral_mem l)]
  constructor
  · rintro (heq | ⟨v, hv, hc, hr⟩)
    · exact Or.inl (h.numeral_injective heq)
    · obtain ⟨n, rfl⟩ := (h.mem_iff_range v).1 hv
      exact Or.inr ⟨n, (ha.child_numeral n l).1 hc, hr⟩
  · rintro (heq | ⟨n, hc, hr⟩)
    · exact Or.inl (congrArg h.numeral heq)
    · exact Or.inr ⟨h.numeral n, h.numeral_mem n, (ha.child_numeral n l).2 hc, hr⟩

end Arithmetic

end

end Classicism.Meta.Research.MaxAtomicityThirdOrderArithmetic

namespace Classicism.Meta.Research.MaxAtomicityThirdOrderDomains.NatFrame

open Classicism.Meta.Research.MaxAtomicityThirdOrderArithmetic
open Classicism.Meta.Research.MaxAtomicityJechShelahTrees

noncomputable section

universe u

variable {B : Type u} [CompleteBooleanAlgebra B] [Nontrivial B]
variable {N : B → B} {z : B} {s : B → B} (h : NatFrame N z s)

def numberIndex (x : B) : ℕ := by
  classical
  exact if hx : N x = ⊤ then h.carrierEquiv ⟨x, hx⟩ else 0

@[simp] theorem numberIndex_numeral (n : ℕ) : h.numberIndex (h.numeral n) = n := by
  classical
  rw [numberIndex, dif_pos (h.numeral_mem n)]
  change h.numberEquiv.symm (h.numberEquiv n) = n
  exact h.numberEquiv.symm_apply_apply n

theorem numeral_numberIndex {x : B} (hx : N x = ⊤) :
    h.numeral (h.numberIndex x) = x := by
  classical
  rw [numberIndex, dif_pos hx]
  exact congrArg Subtype.val (h.numberEquiv.apply_symm_apply ⟨x, hx⟩)

def extendUnary (f : ℕ → ℕ) (x : B) : B := by
  classical
  exact if N x = ⊤ then h.numeral (f (h.numberIndex x)) else z

def extendBinary (f : ℕ → ℕ → ℕ) (x y : B) : B := by
  classical
  exact if N x = ⊤ ∧ N y = ⊤ then h.numeral (f (h.numberIndex x) (h.numberIndex y)) else z

@[simp] theorem extendUnary_numeral (f : ℕ → ℕ) (n : ℕ) :
    h.extendUnary f (h.numeral n) = h.numeral (f n) := by
  classical
  simp [extendUnary, h.numeral_mem n, h.numberIndex_numeral n]

@[simp] theorem extendBinary_numeral (f : ℕ → ℕ → ℕ) (m n : ℕ) :
    h.extendBinary f (h.numeral m) (h.numeral n) = h.numeral (f m n) := by
  classical
  simp [extendBinary, h.numeral_mem m, h.numeral_mem n,
    h.numberIndex_numeral m, h.numberIndex_numeral n]

theorem extendUnary_off (f : ℕ → ℕ) {x : B} (hx : N x ≠ ⊤) :
    h.extendUnary f x = z := by
  classical
  simp only [extendUnary, if_neg hx]

theorem extendBinary_off (f : ℕ → ℕ → ℕ) {x y : B}
    (hxy : ¬ (N x = ⊤ ∧ N y = ⊤)) : h.extendBinary f x y = z := by
  classical
  simp only [extendBinary, if_neg hxy]

theorem extendUnary_mem (f : ℕ → ℕ) (x : B) : N (h.extendUnary f x) = ⊤ := by
  classical
  by_cases hx : N x = ⊤
  · simpa only [extendUnary, if_pos hx] using h.numeral_mem (f (h.numberIndex x))
  · simpa only [extendUnary, if_neg hx] using h.zero_mem

theorem extendBinary_mem (f : ℕ → ℕ → ℕ) (x y : B) : N (h.extendBinary f x y) = ⊤ := by
  classical
  by_cases hxy : N x = ⊤ ∧ N y = ⊤
  · simpa only [extendBinary, if_pos hxy] using
      h.numeral_mem (f (h.numberIndex x) (h.numberIndex y))
  · simpa only [extendBinary, if_neg hxy] using h.zero_mem

def canonicalData : Data B where
  add := h.extendBinary (· + ·)
  mul := h.extendBinary (· * ·)
  pow := h.extendBinary (· ^ ·)
  p := h.extendUnary growthP
  n := h.extendUnary growthN
  o := h.extendUnary offset
  ancestor := fun x y => N x = ⊤ ∧ N y = ⊤ ∧
    MaxAtomicityJechShelahIndexCoding.Ancestor (h.numberIndex x) (h.numberIndex y)

theorem canonicalData_ancestor (i j : ℕ) :
    h.canonicalData.ancestor (h.numeral i) (h.numeral j) ↔
      MaxAtomicityJechShelahIndexCoding.Ancestor i j := by
  simp only [canonicalData, h.numeral_mem, h.numberIndex_numeral, true_and]

theorem canonical_le (m n : ℕ) :
    Le N h.canonicalData (h.numeral m) (h.numeral n) ↔ m ≤ n := by
  constructor
  · rintro ⟨d, hd, heq⟩
    obtain ⟨k, rfl⟩ := (h.mem_iff_range d).1 hd
    change h.extendBinary (· + ·) (h.numeral m) (h.numeral k) = _ at heq
    rw [h.extendBinary_numeral] at heq
    have hh := h.numeral_injective heq
    omega
  · intro hmn
    refine ⟨h.numeral (n - m), h.numeral_mem _, ?_⟩
    change h.extendBinary (· + ·) (h.numeral m) (h.numeral (n - m)) = _
    rw [h.extendBinary_numeral, Nat.add_sub_of_le hmn]

theorem canonical_lt (m n : ℕ) :
    Lt N s h.canonicalData (h.numeral m) (h.numeral n) ↔ m < n := by
  change Le N h.canonicalData (h.numeral (m + 1)) (h.numeral n) ↔ m < n
  rw [h.canonical_le]
  omega

theorem canonical_child (k j : ℕ) :
    Child N s h.canonicalData (h.numeral k) (h.numeral j) ↔
      MaxAtomicityJechShelahIndexCoding.Child k j := by
  unfold Child MaxAtomicityJechShelahIndexCoding.Child
  change (Le N h.canonicalData (h.extendUnary offset (h.numeral k)) (h.numeral j) ∧
    Lt N s h.canonicalData (h.numeral j)
      (h.extendBinary (· + ·) (h.extendUnary offset (h.numeral k))
        (h.extendUnary growthN (h.numeral k)))) ↔ _
  rw [h.extendUnary_numeral, h.extendUnary_numeral, h.extendBinary_numeral,
    h.canonical_le, h.canonical_lt]

theorem canonical_arithmetic : Arithmetic h h.canonicalData where
  add_mem := fun x y _ _ => h.extendBinary_mem (· + ·) x y
  mul_mem := fun x y _ _ => h.extendBinary_mem (· * ·) x y
  pow_mem := fun x y _ _ => h.extendBinary_mem (· ^ ·) x y
  p_mem := fun x _ => h.extendUnary_mem growthP x
  n_mem := fun x _ => h.extendUnary_mem growthN x
  o_mem := fun x _ => h.extendUnary_mem offset x
  add_zero := by
    intro x hx
    obtain ⟨m, rfl⟩ := (h.mem_iff_range x).1 hx
    change h.extendBinary (· + ·) (h.numeral m) (h.numeral 0) = _
    rw [h.extendBinary_numeral, Nat.add_zero]
  add_succ := by
    intro x y hx hy
    obtain ⟨m, rfl⟩ := (h.mem_iff_range x).1 hx
    obtain ⟨n, rfl⟩ := (h.mem_iff_range y).1 hy
    change h.extendBinary (· + ·) (h.numeral m) (h.numeral (n + 1)) =
      s (h.extendBinary (· + ·) (h.numeral m) (h.numeral n))
    rw [h.extendBinary_numeral, h.extendBinary_numeral, Nat.add_succ, h.numeral_succ]
  mul_zero := by
    intro x hx
    obtain ⟨m, rfl⟩ := (h.mem_iff_range x).1 hx
    change h.extendBinary (· * ·) (h.numeral m) (h.numeral 0) = h.numeral 0
    rw [h.extendBinary_numeral, Nat.mul_zero]
  mul_succ := by
    intro x y hx hy
    obtain ⟨m, rfl⟩ := (h.mem_iff_range x).1 hx
    obtain ⟨n, rfl⟩ := (h.mem_iff_range y).1 hy
    change h.extendBinary (· * ·) (h.numeral m) (h.numeral (n + 1)) =
      h.extendBinary (· + ·)
        (h.extendBinary (· * ·) (h.numeral m) (h.numeral n)) (h.numeral m)
    rw [h.extendBinary_numeral, h.extendBinary_numeral, h.extendBinary_numeral, Nat.mul_succ]
  pow_zero := by
    intro x hx
    obtain ⟨m, rfl⟩ := (h.mem_iff_range x).1 hx
    change h.extendBinary (· ^ ·) (h.numeral m) (h.numeral 0) = h.numeral 1
    rw [h.extendBinary_numeral, _root_.pow_zero]
  pow_succ := by
    intro x y hx hy
    obtain ⟨m, rfl⟩ := (h.mem_iff_range x).1 hx
    obtain ⟨n, rfl⟩ := (h.mem_iff_range y).1 hy
    change h.extendBinary (· ^ ·) (h.numeral m) (h.numeral (n + 1)) =
      h.extendBinary (· * ·)
        (h.extendBinary (· ^ ·) (h.numeral m) (h.numeral n)) (h.numeral m)
    rw [h.extendBinary_numeral, h.extendBinary_numeral, h.extendBinary_numeral, _root_.pow_succ]
  p_zero := h.extendUnary_numeral growthP 0
  n_zero := h.extendUnary_numeral growthN 0
  o_zero := h.extendUnary_numeral offset 0
  p_succ := by
    intro x hx
    obtain ⟨k, rfl⟩ := (h.mem_iff_range x).1 hx
    change h.extendUnary growthP (h.numeral (k + 1)) =
      h.extendBinary (· * ·) (h.extendUnary growthP (h.numeral k))
        (h.extendUnary growthN (h.numeral k))
    simp only [h.extendUnary_numeral, h.extendBinary_numeral, growthP_succ]
  n_succ := by
    intro x hx
    obtain ⟨k, rfl⟩ := (h.mem_iff_range x).1 hx
    change h.extendUnary growthN (h.numeral (k + 1)) =
      h.extendBinary (· ^ ·) (h.numeral 2) (h.extendUnary growthP (h.numeral (k + 1)))
    simp only [h.extendUnary_numeral, h.extendBinary_numeral, growthN_succ]
  o_succ := by
    intro x hx
    obtain ⟨k, rfl⟩ := (h.mem_iff_range x).1 hx
    change h.extendUnary offset (h.numeral (k + 1)) =
      h.extendBinary (· + ·) (h.extendUnary offset (h.numeral k))
        (h.extendUnary growthN (h.numeral k))
    simp only [h.extendUnary_numeral, h.extendBinary_numeral, offset_succ]
  ancestor_recursion := by
    intro x y hx hy
    obtain ⟨i, rfl⟩ := (h.mem_iff_range x).1 hx
    obtain ⟨j, rfl⟩ := (h.mem_iff_range y).1 hy
    constructor
    · intro hr
      rcases (MaxAtomicityJechShelahIndexCoding.ancestor_recursion i j).1
          ((h.canonicalData_ancestor i j).1 hr) with heq | ⟨k, hc, hk⟩
      · exact Or.inl (congrArg h.numeral heq)
      · exact Or.inr ⟨h.numeral k, h.numeral_mem k,
          (h.canonical_child k j).2 hc, (h.canonicalData_ancestor i k).2 hk⟩
    · intro hr
      apply (h.canonicalData_ancestor i j).2
      apply (MaxAtomicityJechShelahIndexCoding.ancestor_recursion i j).2
      rcases hr with heq | ⟨v, hv, hc, hk⟩
      · exact Or.inl (h.numeral_injective heq)
      · obtain ⟨k, rfl⟩ := (h.mem_iff_range v).1 hv
        exact Or.inr ⟨k, (h.canonical_child k j).1 hc,
          (h.canonicalData_ancestor i k).1 hk⟩

/-- A literal bottom/top relation represents the canonical Prop-valued
ancestor predicate, as required by the later C interpretation. -/
def canonicalRelation (x y : B) : B := by
  classical
  exact if h.canonicalData.ancestor x y then ⊤ else ⊥

theorem canonicalRelation_top_iff (x y : B) :
    h.canonicalRelation x y = ⊤ ↔ h.canonicalData.ancestor x y := by
  classical
  by_cases hxy : h.canonicalData.ancestor x y <;> simp [canonicalRelation, hxy]

theorem canonicalRelation_crisp (x y : B) :
    h.canonicalRelation x y = ⊤ ∨ h.canonicalRelation x y = ⊥ := by
  classical
  by_cases hxy : h.canonicalData.ancestor x y <;> simp [canonicalRelation, hxy]

theorem exists_arithmetic : ∃ a : Data B, Arithmetic h a :=
  ⟨h.canonicalData, h.canonical_arithmetic⟩

/-- This version has exactly the ancestor predicate obtained by reading a
Boolean-valued relation with equality to top. -/
def representedData : Data B :=
  {h.canonicalData with ancestor := fun x y => h.canonicalRelation x y = ⊤}

theorem representedData_eq : h.representedData = h.canonicalData := by
  have hr : (fun x y => h.canonicalRelation x y = ⊤) = h.canonicalData.ancestor := by
    funext x y
    exact propext (h.canonicalRelation_top_iff x y)
  unfold representedData
  rw [hr]

theorem represented_arithmetic : Arithmetic h h.representedData := by
  rw [h.representedData_eq]
  exact h.canonical_arithmetic

end

end Classicism.Meta.Research.MaxAtomicityThirdOrderDomains.NatFrame

namespace Classicism.Meta.Research.MaxAtomicityThirdOrderArithmetic

open MaxAtomicityThirdOrderDomains
open MaxAtomicityJechShelahTrees

noncomputable section

universe u

variable {B : Type u} [CompleteBooleanAlgebra B] [Nontrivial B]
variable {N : B → B} {z : B} {s : B → B} (h : NatFrame N z s)

/-- Keep the external constructor theorem at the arithmetic interface while
the frame methods live in the namespace used by generalized field notation. -/
theorem canonical_arithmetic : Arithmetic h h.canonicalData := h.canonical_arithmetic

namespace Arithmetic

variable {h} {a : Data B} (ha : Arithmetic h a)

include ha

theorem manyChildren_numeral (X : B → B) (v r : ℕ) :
    ManyChildren N s a X (h.numeral v) (h.numeral r) ↔
      ∃ g : Fin r → ℕ, Function.Injective g ∧
        ∀ i, g i ∈ h.realSet X ∧ MaxAtomicityJechShelahIndexCoding.Child v (g i) := by
  classical
  constructor
  · rintro ⟨f, hvalues, hinj⟩
    have hval (i : Fin r) := hvalues (h.numeral i.val) (h.numeral_mem i.val)
      ((ha.lt_numeral i.val r).2 i.isLt)
    let g : Fin r → ℕ := fun i => h.numberIndex (f (h.numeral i.val))
    have hnum (i : Fin r) : h.numeral (g i) = f (h.numeral i.val) :=
      h.numeral_numberIndex (hval i).1
    refine ⟨g, ?_, ?_⟩
    · intro i j hij
      apply Fin.ext
      apply h.numeral_injective
      apply hinj _ _ (h.numeral_mem i.val) (h.numeral_mem j.val)
        ((ha.lt_numeral i.val r).2 i.isLt) ((ha.lt_numeral j.val r).2 j.isLt)
      exact (hnum i).symm.trans ((congrArg h.numeral hij).trans (hnum j))
    · intro i
      constructor
      · change X (h.numeral (g i)) = ⊤
        rw [hnum i]
        exact (hval i).2.1
      · apply (ha.child_numeral v (g i)).1
        rw [hnum i]
        exact (hval i).2.2
  · rintro ⟨g, hg, hvalues⟩
    let f : B → B := fun x =>
      if hx : N x = ⊤ ∧ Lt N s a x (h.numeral r) then
        h.numeral (g ⟨h.numberIndex x, (ha.lt_numeral (h.numberIndex x) r).1
          (by rw [h.numeral_numberIndex hx.1]; exact hx.2)⟩)
      else z
    have hf (i : Fin r) : f (h.numeral i.val) = h.numeral (g i) := by
      have hi : N (h.numeral i.val) = ⊤ ∧ Lt N s a (h.numeral i.val) (h.numeral r) :=
        ⟨h.numeral_mem i.val, (ha.lt_numeral i.val r).2 i.isLt⟩
      dsimp only [f]
      rw [dif_pos hi]
      exact congrArg h.numeral (congrArg g (Fin.ext (h.numberIndex_numeral i.val)))
    refine ⟨f, ?_, ?_⟩
    · intro x hx hxr
      obtain ⟨m, rfl⟩ := (h.mem_iff_range x).1 hx
      let i : Fin r := ⟨m, (ha.lt_numeral m r).1 hxr⟩
      change N (f (h.numeral i.val)) = ⊤ ∧
        X (f (h.numeral i.val)) = ⊤ ∧ Child N s a (h.numeral v) (f (h.numeral i.val))
      rw [hf i]
      exact ⟨h.numeral_mem _, (hvalues i).1, (ha.child_numeral v (g i)).2 (hvalues i).2⟩
    · intro x y hx hy hxr hyr heq
      obtain ⟨m, rfl⟩ := (h.mem_iff_range x).1 hx
      obtain ⟨n, rfl⟩ := (h.mem_iff_range y).1 hy
      let i : Fin r := ⟨m, (ha.lt_numeral m r).1 hxr⟩
      let j : Fin r := ⟨n, (ha.lt_numeral n r).1 hyr⟩
      have hnum : h.numeral (g i) = h.numeral (g j) :=
        (hf i).symm.trans (heq.trans (hf j))
      exact congrArg h.numeral (congrArg Fin.val (hg (h.numeral_injective hnum)))

theorem conditionCode_iff (X : B → B) :
    ConditionCode N z s a X ↔
      RealCode N X ∧ MaxAtomicityJechShelahIndexCoding.IndexCondition (h.realSet X) := by
  constructor
  · rintro ⟨hX, hzero, hprefix, hbushy⟩
    refine ⟨hX, hzero, ?_, ?_⟩
    · intro j hj i hij
      exact hprefix (h.numeral j) (h.numeral_mem j) hj
        (h.numeral i) (h.numeral_mem i) ((ha.ancestor_numeral i j).2 hij)
    · intro i hi m
      obtain ⟨v, hv, hvX, hne, har, hmany⟩ :=
        hbushy (h.numeral i) (h.numeral_mem i) hi (h.numeral m) (h.numeral_mem m)
      obtain ⟨k, rfl⟩ := (h.mem_iff_range v).1 hv
      rw [ha.p_numeral, ha.pow_numeral] at hmany
      exact ⟨k, hvX, fun heq => hne (congrArg h.numeral heq),
        (ha.ancestor_numeral i k).1 har, (ha.manyChildren_numeral X k _).1 hmany⟩
  · rintro ⟨hX, hzero, hprefix, hbushy⟩
    refine ⟨hX, hzero, ?_, ?_⟩
    · intro y hy hyX x hx hxy
      obtain ⟨j, rfl⟩ := (h.mem_iff_range y).1 hy
      obtain ⟨i, rfl⟩ := (h.mem_iff_range x).1 hx
      exact hprefix j hyX i ((ha.ancestor_numeral i j).1 hxy)
    · intro x hx hxX y hy
      obtain ⟨i, rfl⟩ := (h.mem_iff_range x).1 hx
      obtain ⟨m, rfl⟩ := (h.mem_iff_range y).1 hy
      obtain ⟨k, hk, hne, har, hmany⟩ := hbushy i hxX m
      refine ⟨h.numeral k, h.numeral_mem k, hk,
        fun heq => hne (h.numeral_injective heq), (ha.ancestor_numeral i k).2 har, ?_⟩
      rw [ha.p_numeral, ha.pow_numeral]
      exact (ha.manyChildren_numeral X k _).2 hmany

theorem conditionCode_iff_of_real {X : B → B} (hX : RealCode N X) :
    ConditionCode N z s a X ↔ MaxAtomicityJechShelahIndexCoding.IndexCondition (h.realSet X) := by
  rw [ha.conditionCode_iff]
  exact ⟨And.right, fun hi => ⟨hX, hi⟩⟩

theorem encodeReal_condition_iff (I : Set ℕ) :
    ConditionCode N z s a (h.encodeReal I) ↔ MaxAtomicityJechShelahIndexCoding.IndexCondition I := by
  rw [ha.conditionCode_iff_of_real (h.encodeReal_code I), h.realSet_encodeReal I]

end Arithmetic

#print axioms Arithmetic.add_numeral
#print axioms Arithmetic.growth_numeral
#print axioms Arithmetic.ancestor_numeral
#print axioms canonical_arithmetic
#print axioms Arithmetic.manyChildren_numeral
#print axioms Arithmetic.conditionCode_iff
#print axioms Arithmetic.encodeReal_condition_iff

end

end Classicism.Meta.Research.MaxAtomicityThirdOrderArithmetic
