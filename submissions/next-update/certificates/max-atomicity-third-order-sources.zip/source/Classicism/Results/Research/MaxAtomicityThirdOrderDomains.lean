import Mathlib.Order.CompleteBooleanAlgebra
import Mathlib.Logic.Equiv.Set

/-!
# Standard numbers and canonical second- and third-order domains

External metatheory for the third-order simplification of the pure
Max--Atomicity proof. A full-induction natural-number frame is categorical;
predicates with values bottom/top and zero outside their intended domain give
actual copies of `Set Nat` and `Set (Set Nat)`.

Full induction is an explicit field of `NatFrame`, not a theorem asserted
about arbitrary Henkin models. The later syntax/semantics bridge must derive
this field from its particular full Boolean-valued interpretation. No such
bridge, forcing construction, rigidity premise, or final inconsistency theorem
is asserted in this module.

Direct source: original domain-coding proof, misc, 25 October 2026, following
the third-order presentation in the upstream Max--Atomicity write-up discussed
in `research/2026-10-25/proof-simplification/upstream-comparison.md`, section 1.
No hereditary universe, Mostowski collapse, or old final theorem is imported.

Verification evidence is recorded in the accompanying third-order status and compiler manifests.
-/

namespace Classicism.Meta.Research.MaxAtomicityThirdOrderDomains

noncomputable section

universe u

variable {B : Type u} [CompleteBooleanAlgebra B] [Nontrivial B]

/-- Only equality with top denotes membership. Values of `N` elsewhere are
irrelevant. Induction ranges over all external predicates on the carrier. -/
structure NatFrame (N : B → B) (z : B) (s : B → B) : Prop where
  zero_mem : N z = ⊤
  succ_mem : ∀ x, N x = ⊤ → N (s x) = ⊤
  succ_ne_zero : ∀ x, N x = ⊤ → s x ≠ z
  succ_injective : ∀ x y, N x = ⊤ → N y = ⊤ → s x = s y → x = y
  induction_on : ∀ P : B → Prop, P z →
    (∀ x, N x = ⊤ → P x → P (s x)) → ∀ x, N x = ⊤ → P x

/-- Canonical real codes are characteristic predicates, zero off the numbers. -/
def RealCode (N X : B → B) : Prop :=
  ∀ x, (N x = ⊤ ∧ X x = ⊤) ∨ X x = ⊥

/-- Canonical class codes are characteristic predicates, zero off real codes. -/
def ClassCode (N : B → B) (U : (B → B) → B) : Prop :=
  ∀ X, (RealCode N X ∧ U X = ⊤) ∨ U X = ⊥

theorem realCode_values {N X : B → B} (hX : RealCode N X) (x : B) :
    X x = ⊤ ∨ X x = ⊥ :=
  (hX x).elim (fun h => Or.inl h.2) Or.inr

theorem realCode_off {N X : B → B} (hX : RealCode N X) {x : B}
    (hx : N x ≠ ⊤) : X x = ⊥ :=
  (hX x).elim (fun h => (hx h.1).elim) id

theorem classCode_values {N : B → B} {U : (B → B) → B}
    (hU : ClassCode N U) (X : B → B) : U X = ⊤ ∨ U X = ⊥ :=
  (hU X).elim (fun h => Or.inl h.2) Or.inr

theorem classCode_off {N : B → B} {U : (B → B) → B}
    (hU : ClassCode N U) {X : B → B} (hX : ¬ RealCode N X) : U X = ⊥ :=
  (hU X).elim (fun h => (hX h.1).elim) id

namespace NatFrame

variable {N : B → B} {z : B} {s : B → B} (h : NatFrame N z s)

def numeral (h : NatFrame N z s) : ℕ → B
  | 0 => z
  | n + 1 => s (h.numeral n)

@[simp] theorem numeral_zero : h.numeral 0 = z := rfl

@[simp] theorem numeral_succ (n : ℕ) : h.numeral (n + 1) = s (h.numeral n) := rfl

theorem numeral_mem (n : ℕ) : N (h.numeral n) = ⊤ := by
  induction n with
  | zero => exact h.zero_mem
  | succ n ih => exact h.succ_mem _ ih

theorem numeral_injective : Function.Injective h.numeral := by
  intro m n
  induction m generalizing n with
  | zero =>
    cases n with
    | zero => intro _; rfl
    | succ n =>
      intro heq
      exact (h.succ_ne_zero _ (h.numeral_mem n) heq.symm).elim
  | succ m ih =>
    cases n with
    | zero =>
      intro heq
      exact (h.succ_ne_zero _ (h.numeral_mem m) heq).elim
    | succ n =>
      intro heq
      have hmn : h.numeral m = h.numeral n :=
        h.succ_injective _ _ (h.numeral_mem m) (h.numeral_mem n) heq
      exact congrArg Nat.succ (ih hmn)

theorem mem_iff_range (x : B) : N x = ⊤ ↔ ∃ n : ℕ, h.numeral n = x := by
  constructor
  · intro hx
    apply h.induction_on (fun x => ∃ n : ℕ, h.numeral n = x) ?_ ?_ x hx
    · exact ⟨0, rfl⟩
    · intro y _ hy
      obtain ⟨n, rfl⟩ := hy
      exact ⟨n + 1, rfl⟩
  · rintro ⟨n, rfl⟩
    exact h.numeral_mem n

def numberEquiv : ℕ ≃ {x : B // N x = ⊤} :=
  Equiv.ofBijective (fun n => ⟨h.numeral n, h.numeral_mem n⟩)
    ⟨fun _ _ heq => h.numeral_injective (congrArg Subtype.val heq), by
      intro x
      obtain ⟨n, hn⟩ := (h.mem_iff_range x.val).1 x.property
      exact ⟨n, Subtype.ext hn⟩⟩

@[simp] theorem numberEquiv_val (n : ℕ) :
    (h.numberEquiv n).val = h.numeral n := rfl

def carrierEquiv : {x : B // N x = ⊤} ≃ ℕ := h.numberEquiv.symm

theorem forall_number_iff (P : B → Prop) :
    (∀ x, N x = ⊤ → P x) ↔ ∀ n : ℕ, P (h.numeral n) := by
  constructor
  · intro hp n
    exact hp _ (h.numeral_mem n)
  · intro hp x hx
    obtain ⟨n, rfl⟩ := (h.mem_iff_range x).1 hx
    exact hp n

theorem exists_number_iff (P : B → Prop) :
    (∃ x, N x = ⊤ ∧ P x) ↔ ∃ n : ℕ, P (h.numeral n) := by
  constructor
  · rintro ⟨x, hx, hp⟩
    obtain ⟨n, rfl⟩ := (h.mem_iff_range x).1 hx
    exact ⟨n, hp⟩
  · rintro ⟨n, hp⟩
    exact ⟨h.numeral n, h.numeral_mem n, hp⟩

/-- Literal characteristic function of the image of a set of natural numbers. -/
def encodeReal (A : Set ℕ) (x : B) : B := by
  classical
  exact if ∃ n : ℕ, n ∈ A ∧ h.numeral n = x then ⊤ else ⊥

def realSet (X : B → B) : Set ℕ := {n | X (h.numeral n) = ⊤}

theorem encodeReal_mem (A : Set ℕ) (x : B) :
    h.encodeReal A x = ⊤ ↔ ∃ n : ℕ, n ∈ A ∧ h.numeral n = x := by
  classical
  by_cases hx : ∃ n : ℕ, n ∈ A ∧ h.numeral n = x
  · simp [encodeReal, hx]
  · simp [encodeReal, hx]

theorem encodeReal_numeral_mem (A : Set ℕ) (n : ℕ) :
    h.encodeReal A (h.numeral n) = ⊤ ↔ n ∈ A := by
  rw [h.encodeReal_mem]
  constructor
  · rintro ⟨m, hm, hmn⟩
    exact h.numeral_injective hmn ▸ hm
  · intro hn
    exact ⟨n, hn, rfl⟩

theorem encodeReal_off (A : Set ℕ) {x : B} (hx : N x ≠ ⊤) :
    h.encodeReal A x = ⊥ := by
  classical
  have hnone : ¬ ∃ n : ℕ, n ∈ A ∧ h.numeral n = x := by
    rintro ⟨n, _, rfl⟩
    exact hx (h.numeral_mem n)
  simp only [encodeReal, if_neg hnone]

theorem encodeReal_code (A : Set ℕ) : RealCode N (h.encodeReal A) := by
  classical
  intro x
  by_cases hx : ∃ n : ℕ, n ∈ A ∧ h.numeral n = x
  · left
    refine ⟨?_, (h.encodeReal_mem A x).2 hx⟩
    obtain ⟨n, _, rfl⟩ := hx
    exact h.numeral_mem n
  · right
    simp only [encodeReal, if_neg hx]

@[simp] theorem realSet_encodeReal (A : Set ℕ) :
    h.realSet (h.encodeReal A) = A := by
  apply Set.ext
  intro n
  exact h.encodeReal_numeral_mem A n

theorem encodeReal_realSet {X : B → B} (hX : RealCode N X) :
    h.encodeReal (h.realSet X) = X := by
  classical
  funext x
  rcases hX x with ⟨hxN, hx⟩ | hx
  · obtain ⟨n, hn⟩ := (h.mem_iff_range x).1 hxN
    have hnX : n ∈ h.realSet X := by
      change X (h.numeral n) = ⊤
      rw [hn]
      exact hx
    exact ((h.encodeReal_mem _ x).2 ⟨n, hnX, hn⟩).trans hx.symm
  · have hnone : ¬ ∃ n : ℕ, n ∈ h.realSet X ∧ h.numeral n = x := by
      rintro ⟨n, hnX, hn⟩
      have htop : X x = ⊤ := by
        change X (h.numeral n) = ⊤ at hnX
        simpa only [hn] using hnX
      exact bot_ne_top (hx.symm.trans htop)
    rw [encodeReal, if_neg hnone, hx]

theorem encodeReal_injective : Function.Injective h.encodeReal := by
  intro A C heq
  have hh := congrArg h.realSet heq
  simpa only [h.realSet_encodeReal] using hh

def realEquiv : {X : B → B // RealCode N X} ≃ Set ℕ where
  toFun X := h.realSet X.val
  invFun A := ⟨h.encodeReal A, h.encodeReal_code A⟩
  left_inv X := Subtype.ext (h.encodeReal_realSet X.property)
  right_inv A := h.realSet_encodeReal A

/-- Characteristic functions on the canonical real-code domain, zero elsewhere. -/
def encodeClass (C : Set (Set ℕ)) (X : B → B) : B := by
  classical
  exact if RealCode N X ∧ h.realSet X ∈ C then ⊤ else ⊥

def classSet (U : (B → B) → B) : Set (Set ℕ) :=
  {A | U (h.encodeReal A) = ⊤}

theorem encodeClass_mem (C : Set (Set ℕ)) (X : B → B) :
    h.encodeClass C X = ⊤ ↔ RealCode N X ∧ h.realSet X ∈ C := by
  classical
  by_cases hx : RealCode N X ∧ h.realSet X ∈ C
  · simp [encodeClass, hx]
  · simp [encodeClass, hx]

theorem encodeClass_real_mem (C : Set (Set ℕ)) (A : Set ℕ) :
    h.encodeClass C (h.encodeReal A) = ⊤ ↔ A ∈ C := by
  rw [h.encodeClass_mem]
  simp only [h.encodeReal_code A, h.realSet_encodeReal A, true_and]

theorem encodeClass_off (C : Set (Set ℕ)) {X : B → B}
    (hX : ¬ RealCode N X) : h.encodeClass C X = ⊥ := by
  classical
  simp [encodeClass, hX]

theorem encodeClass_code (C : Set (Set ℕ)) : ClassCode N (h.encodeClass C) := by
  classical
  intro X
  by_cases hX : RealCode N X ∧ h.realSet X ∈ C
  · exact Or.inl ⟨hX.1, (h.encodeClass_mem C X).2 hX⟩
  · right
    simp only [encodeClass, if_neg hX]

@[simp] theorem classSet_encodeClass (C : Set (Set ℕ)) :
    h.classSet (h.encodeClass C) = C := by
  apply Set.ext
  intro A
  exact h.encodeClass_real_mem C A

theorem encodeClass_classSet {U : (B → B) → B} (hU : ClassCode N U) :
    h.encodeClass (h.classSet U) = U := by
  classical
  funext X
  rcases hU X with ⟨hX, htop⟩ | hbot
  · have hmem : h.realSet X ∈ h.classSet U := by
      change U (h.encodeReal (h.realSet X)) = ⊤
      rw [h.encodeReal_realSet hX]
      exact htop
    exact ((h.encodeClass_mem _ X).2 ⟨hX, hmem⟩).trans htop.symm
  · have hnone : ¬ (RealCode N X ∧ h.realSet X ∈ h.classSet U) := by
      rintro ⟨hX, hmem⟩
      change U (h.encodeReal (h.realSet X)) = ⊤ at hmem
      rw [h.encodeReal_realSet hX] at hmem
      exact bot_ne_top (hbot.symm.trans hmem)
    rw [encodeClass, if_neg hnone, hbot]

theorem encodeClass_injective : Function.Injective h.encodeClass := by
  intro C D heq
  have hh := congrArg h.classSet heq
  simpa only [h.classSet_encodeClass] using hh

def classEquiv : {U : (B → B) → B // ClassCode N U} ≃ Set (Set ℕ) where
  toFun U := h.classSet U.val
  invFun C := ⟨h.encodeClass C, h.encodeClass_code C⟩
  left_inv U := Subtype.ext (h.encodeClass_classSet U.property)
  right_inv C := h.classSet_encodeClass C

end NatFrame

/-- A frame exists from an actual injection of the external naturals. No
infinity of an arbitrary Boolean algebra is silently assumed. -/
def embeddingN (e : ℕ ↪ B) (x : B) : B := by
  classical
  exact if ∃ n : ℕ, e n = x then ⊤ else ⊥

def embeddingZero (e : ℕ ↪ B) : B := e 0

def embeddingSucc (e : ℕ ↪ B) (x : B) : B := by
  classical
  exact if hx : ∃ n : ℕ, e n = x then e (Classical.choose hx + 1) else e 0

theorem embeddingN_mem (e : ℕ ↪ B) (x : B) :
    embeddingN e x = ⊤ ↔ ∃ n : ℕ, e n = x := by
  classical
  by_cases hx : ∃ n : ℕ, e n = x
  · simp [embeddingN, hx]
  · simp [embeddingN, hx]

@[simp] theorem embeddingN_apply (e : ℕ ↪ B) (n : ℕ) : embeddingN e (e n) = ⊤ :=
  (embeddingN_mem e (e n)).2 ⟨n, rfl⟩

@[simp] theorem embeddingSucc_apply (e : ℕ ↪ B) (n : ℕ) :
    embeddingSucc e (e n) = e (n + 1) := by
  classical
  have hn : ∃ k : ℕ, e k = e n := ⟨n, rfl⟩
  have hchoose : Classical.choose hn = n := e.injective (Classical.choose_spec hn)
  simp only [embeddingSucc, dif_pos hn, hchoose]

theorem embeddingFrame (e : ℕ ↪ B) :
    NatFrame (embeddingN e) (embeddingZero e) (embeddingSucc e) where
  zero_mem := embeddingN_apply e 0
  succ_mem := by
    intro x hx
    obtain ⟨n, rfl⟩ := (embeddingN_mem e x).1 hx
    rw [embeddingSucc_apply]
    exact embeddingN_apply e (n + 1)
  succ_ne_zero := by
    intro x hx heq
    obtain ⟨n, rfl⟩ := (embeddingN_mem e x).1 hx
    rw [embeddingSucc_apply] at heq
    exact Nat.succ_ne_zero n (e.injective heq)
  succ_injective := by
    intro x y hx hy heq
    obtain ⟨m, rfl⟩ := (embeddingN_mem e x).1 hx
    obtain ⟨n, rfl⟩ := (embeddingN_mem e y).1 hy
    rw [embeddingSucc_apply, embeddingSucc_apply] at heq
    exact congrArg e (Nat.succ.inj (e.injective heq))
  induction_on := by
    intro P hz hs x hx
    obtain ⟨n, rfl⟩ := (embeddingN_mem e x).1 hx
    induction n with
    | zero => exact hz
    | succ n ih =>
      simpa only [embeddingSucc_apply] using
        hs (e n) (embeddingN_apply e n) (ih (embeddingN_apply e n))

theorem embeddingFrame_numeral (e : ℕ ↪ B) (n : ℕ) :
    (embeddingFrame e).numeral n = e n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [NatFrame.numeral_succ, ih, embeddingSucc_apply]

theorem exists_natFrame_of_embedding (e : ℕ ↪ B) :
    ∃ (N : B → B) (z : B) (s : B → B), NatFrame N z s :=
  ⟨embeddingN e, embeddingZero e, embeddingSucc e, embeddingFrame e⟩

#print axioms NatFrame.numeral_injective
#print axioms NatFrame.mem_iff_range
#print axioms NatFrame.numberEquiv
#print axioms NatFrame.realEquiv
#print axioms NatFrame.classEquiv
#print axioms embeddingFrame
#print axioms exists_natFrame_of_embedding

end

end Classicism.Meta.Research.MaxAtomicityThirdOrderDomains
