import Classicism.Results.Research.InfinitaryComprehensionEndpointBootstrap

/-!
# Typed equality rigidity from endpoint separation

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 2--3; misc, 25 October 2026.

This bridge derives the equality clause for observer worlds from the original
translated reflexivity and Leibniz guards, finite Comprehension, and endpoint
separation. It assumes neither Classicism nor typed equality reflection.

First native ND at t, already proved in EndpointBootstrap, makes each qualified
observer read propositional equality literally. For arbitrary input type D,
finite Comprehension supplies the admitted predicate
  G(x) = identity_t (identity_D(a,x)) top.
The D-Leibniz guard transfers acceptance of G from a to b. Literal t-equality
then identifies identity_D(a,b) with top, and its ordinary H truth clause gives
a=b. Matrix codes, their truth clauses, and necessitated UI remain explicit;
no function-to-code constructor or pre-assumed relation faithfulness is used.
-/

namespace Classicism.Research.InfinitaryComprehension.EndpointEqualityBridge

open EndpointBootstrap

universe u v w x y z r m

variable {H : PropCore.{u}} {Obs : Type v} {observe : Obs → H.P → H.P}
variable {B : BooleanPresentation.{u,v,w,x,y} H Obs observe} {Q : Obs → Prop}

/-- Observer reflexivity and separation identify every reflexive equality
proposition with top, before any typed equality-reflection conclusion. -/
theorem reflexive_identity_top {D : Type z}
    (sep : PropSeparation B Q) (identity : D → D → H.P)
    (reflexive : ∀ E, Q E → B.GoodBoolean E → ∀ a : D,
      H.truth (observe E (identity a a))) (a : D) : identity a a = H.top := by
  apply sep (identity a a) H.top
  intro E hQ hB
  exact ⟨fun _ => (B.material hB).accepts_top,
    fun _ => reflexive E hQ hB a⟩

/-- This intermediate lemma consumes the already derived native ND_t. -/
theorem propositional_identity_iff_of_nd
    (identity : H.P → H.P → H.P)
    (reflexive : ∀ E, Q E → B.GoodBoolean E → ∀ p : H.P,
      H.truth (observe E (identity p p)))
    (nd : ∀ p q : H.P, p ≠ q → H.Box (H.neg (identity p q)))
    (E : Obs) (hQ : Q E) (hB : B.GoodBoolean E) (p q : H.P) :
    H.truth (observe E (identity p q)) ↔ p = q := by
  constructor
  · intro hid
    cases Classical.em (p = q) with
    | inl hpq => exact hpq
    | inr hpq =>
        have hn : H.neg (identity p q) = H.top := nd p q hpq
        have he : H.truth (observe E (H.neg (identity p q))) := by
          rw [hn]
          exact (B.material hB).accepts_top
        exact False.elim (((B.material hB).neg _).1 he hid)
  · intro hpq
    cases hpq
    exact reflexive E hQ hB p

/-- No ND premise remains: the endpoint ND theorem is used internally. -/
theorem endpoint_propositional_identity_iff
    (sep : PropSeparation B Q)
    (ui : B.unary.NecessaryUI) (comp : B.unary.Comprehension)
    (ends : ∀ E, Q E → B.GoodBoolean E → EndpointValued observe E)
    (identity : H.P → H.P → H.P)
    (reflexive : ∀ E, Q E → B.GoodBoolean E → ∀ p : H.P,
      H.truth (observe E (identity p p)))
    (leibniz : ∀ F, Q F → B.GoodBoolean F → ∀ p q E,
      H.truth (observe F (identity p q)) →
      H.truth (observe F (observe E p)) → H.truth (observe F (observe E q)))
    (E : Obs) (hQ : Q E) (hB : B.GoodBoolean E) (p q : H.P) :
    H.truth (observe E (identity p q)) ↔ p = q := by
  apply propositional_identity_iff_of_nd identity reflexive
    (fun p q hpq => endpoint_necessary_distinctness
      sep ui comp ends identity leibniz hpq) E hQ hB p q

/-- The typed step isolates its finite comprehension matrix. Propositional
equality reading is supplied by the preceding theorem in the main endpoint
result below, not assumed as an original observer qualification. -/
theorem typed_identity_iff_of_propositional_identity
    {D : Type z} {Pred : Type r} {papp : Pred → D → H.P}
    (M : MatrixDomain.{u,z,r,m} H D Pred papp)
    (sep : PropSeparation B Q) (ui : M.NecessaryUI) (comp : M.Comprehension)
    (identity_t : H.P → H.P → H.P)
    (literal_t : ∀ E, Q E → B.GoodBoolean E → ∀ p q : H.P,
      H.truth (observe E (identity_t p q)) ↔ p = q)
    (identity : D → D → H.P)
    (truth_identity : ∀ a b : D, H.truth (identity a b) ↔ a = b)
    (reflexive : ∀ E, Q E → B.GoodBoolean E → ∀ a : D,
      H.truth (observe E (identity a a)))
    (leibniz : ∀ E, Q E → B.GoodBoolean E → ∀ a b (F : Pred),
      H.truth (observe E (identity a b)) →
      H.truth (observe E (papp F a)) → H.truth (observe E (papp F b)))
    (testMatrix : D → M.Matrix)
    (test_value : ∀ a b, M.eval (testMatrix a) b = identity_t (identity a b) H.top)
    (E : Obs) (hQ : Q E) (hB : B.GoodBoolean E) (a b : D) :
    H.truth (observe E (identity a b)) ↔ a = b := by
  constructor
  · intro hid
    have haa := reflexive_identity_top sep identity reflexive a
    obtain ⟨G, hG⟩ := M.comprehension_exact sep ui comp (testMatrix a)
    have hg : ∀ d, papp G d = identity_t (identity a d) H.top :=
      fun d => (hG d).trans (test_value a d)
    have hGa : H.truth (observe E (papp G a)) := by
      rw [hg a, haa]
      exact (literal_t E hQ hB H.top H.top).2 rfl
    have hGb := leibniz E hQ hB a b G hid hGa
    rw [hg b] at hGb
    have hab := (literal_t E hQ hB (identity a b) H.top).1 hGb
    apply (truth_identity a b).1
    rw [hab]
    exact H.truth_top
  · intro hab
    cases hab
    exact reflexive E hQ hB a

/-- Main typed equality theorem: all inputs are the explicit H truth clauses,
original translated equality guards, common-representative Boolean separation,
endpoint range, and finite admitted comprehension with necessitated UI. -/
theorem endpoint_typed_identity_iff
    {D : Type z} {Pred : Type r} {papp : Pred → D → H.P}
    (M : MatrixDomain.{u,z,r,m} H D Pred papp)
    (sep : PropSeparation B Q)
    (ui_t : B.unary.NecessaryUI) (comp_t : B.unary.Comprehension)
    (ends : ∀ E, Q E → B.GoodBoolean E → EndpointValued observe E)
    (identity_t : H.P → H.P → H.P)
    (reflexive_t : ∀ E, Q E → B.GoodBoolean E → ∀ p : H.P,
      H.truth (observe E (identity_t p p)))
    (leibniz_t : ∀ F, Q F → B.GoodBoolean F → ∀ p q E,
      H.truth (observe F (identity_t p q)) →
      H.truth (observe F (observe E p)) → H.truth (observe F (observe E q)))
    (ui : M.NecessaryUI) (comp : M.Comprehension)
    (identity : D → D → H.P)
    (truth_identity : ∀ a b : D, H.truth (identity a b) ↔ a = b)
    (reflexive : ∀ E, Q E → B.GoodBoolean E → ∀ a : D,
      H.truth (observe E (identity a a)))
    (leibniz : ∀ E, Q E → B.GoodBoolean E → ∀ a b (F : Pred),
      H.truth (observe E (identity a b)) →
      H.truth (observe E (papp F a)) → H.truth (observe E (papp F b)))
    (testMatrix : D → M.Matrix)
    (test_value : ∀ a b, M.eval (testMatrix a) b = identity_t (identity a b) H.top)
    (E : Obs) (hQ : Q E) (hB : B.GoodBoolean E) (a b : D) :
    H.truth (observe E (identity a b)) ↔ a = b :=
  typed_identity_iff_of_propositional_identity M sep ui comp identity_t
    (endpoint_propositional_identity_iff sep ui_t comp_t ends identity_t
      reflexive_t leibniz_t)
    identity truth_identity reflexive leibniz testMatrix test_value E hQ hB a b

#print axioms reflexive_identity_top
#print axioms propositional_identity_iff_of_nd
#print axioms endpoint_propositional_identity_iff
#print axioms typed_identity_iff_of_propositional_identity
#print axioms endpoint_typed_identity_iff

end Classicism.Research.InfinitaryComprehension.EndpointEqualityBridge
