import Classicism.Results.Research.InfinitaryComprehensionFullness

/-!
# Fullness after the lambda-free endpoint reconstruction

Source: `research/2026-10-23/infinitary-comprehension/endpoint-development.md`,
sections 3--4 (misc, original research, 25 October 2026, unpaginated).

This module is the downstream semantic assembly. It imports no action
`Premodel`. Its input is an explicitly constructed `Henkin.Model`, together
with proved faithfulness, world separation, and truth of the actual
infinitary Comprehension schema. The independent H/endpoint reconstruction
must supply those inputs; none is inferred here from an unnamed observer
assumption. In particular, the constant-domain and universal-box truth
clauses are fields of the input presentation, not conclusions of this file.

Every support, proposition and allowed function is then represented. The
existence statements retain uniqueness, and the explicit equivalences have
truth and application themselves as their forward maps. The noncomputable
inverse maps use Lean's classical choice API. Accordingly this Lean
certificate is in the existing classical metatheory; it does not certify
the source argument's separate ZF metatheoretic refinement.
-/

namespace Classicism.Research.InfinitaryComprehension.EndpointFullness

open Classicism.Meta

universe u v

/-- An explicit equivalence of carriers, kept independent of Mathlib so
the downstream certificate retains the accepted core-only dependency chain. -/
structure CarrierEquiv (α : Type u) (β : Type v) where
  toFun : α → β
  invFun : β → α
  left_inv : ∀ a, invFun (toFun a) = a
  right_inv : ∀ b, toFun (invFun b) = b

instance {α : Type u} {β : Type v} :
    CoeFun (CarrierEquiv α β) (fun _ => α → β) := ⟨fun f => f.toFun⟩

noncomputable def CarrierEquiv.ofBijective {α : Type u} {β : Type v}
    (f : α → β) (hf : Function.Injective f ∧ Function.Surjective f) :
    CarrierEquiv α β where
  toFun := f
  invFun b := Classical.choose (hf.2 b)
  left_inv a := hf.1 (Classical.choose_spec (hf.2 (f a)))
  right_inv b := Classical.choose_spec (hf.2 b)

variable (M : Henkin.Model.{u})

/-- The conclusions of the downstream full-hierarchy construction. -/
structure FullStandard (w : M.World) : Prop where
  nonempty_e : Nonempty (M.Dom Ty.e)
  faithful : Henkin.Faithful M
  worldSeparated : Henkin.WorldSeparated M
  profiles : Henkin.FullProfiles M
  comprehension : ∀ v : M.World, Henkin.Comp M v
  propositions : ∀ U : M.World → Prop,
    ∃ p : M.Dom Ty.t, (∀ v : M.World, M.truth p v ↔ U v) ∧
      ∀ q : M.Dom Ty.t, (∀ v : M.World, M.truth q v ↔ U v) → q = p
  functions : ∀ (σ : Ty) (ρ : RTy) (f : M.Dom σ → M.Dom ρ),
    ∃ R : M.Dom (σ ⇒ ρ), (∀ x, M.app R x = f x) ∧
      ∀ S : M.Dom (σ ⇒ ρ), (∀ x, M.app S x = f x) → S = R

theorem truth_injective (hf : Henkin.Faithful M) :
    Function.Injective M.truth := by
  intro p q h
  apply hf [] p q
  intro xs v
  change M.truth p v ↔ M.truth q v
  exact Iff.of_eq (congrFun h v)

theorem unique_propositions {w : M.World} (hc : Henkin.Comp M w)
    (hf : Henkin.Faithful M) (hs : Henkin.WorldSeparated M)
    (U : M.World → Prop) :
    ∃ p : M.Dom Ty.t, (∀ v : M.World, M.truth p v ↔ U v) ∧
      ∀ q : M.Dom Ty.t, (∀ v : M.World, M.truth q v ↔ U v) → q = p := by
  obtain ⟨p, hp⟩ := Henkin.full_propositions M hc hf hs U
  refine ⟨p, hp, ?_⟩
  intro q hq
  apply hf [] q p
  intro xs v
  change M.truth q v ↔ M.truth p v
  exact (hq v).trans (hp v).symm

theorem unique_functions {w : M.World} (hc : Henkin.Comp M w)
    (hf : Henkin.Faithful M) (hs : Henkin.WorldSeparated M)
    (σ : Ty) (ρ : RTy) (f : M.Dom σ → M.Dom ρ) :
    ∃ R : M.Dom (σ ⇒ ρ), (∀ x, M.app R x = f x) ∧
      ∀ S : M.Dom (σ ⇒ ρ), (∀ x, M.app S x = f x) → S = R := by
  have hfull : Henkin.FullProfiles M :=
    (Henkin.comp_iff_full_profiles M w hf hs).1 hc
  obtain ⟨R, hR⟩ := Henkin.functions_of_full_profiles M hfull hf σ ρ f
  refine ⟨R, hR, ?_⟩
  intro S hS
  exact Henkin.application_injective M hf σ ρ S R
    (fun x => (hS x).trans (hR x).symm)

/-- Actual IC at the designated point supplies full profiles and IC at
every world of the presentation, together with unique function objects. -/
theorem full_standard_of_comprehension (w : M.World)
    (he : Nonempty (M.Dom Ty.e)) (hf : Henkin.Faithful M)
    (hs : Henkin.WorldSeparated M) (hc : Henkin.Comp M w) :
    FullStandard M w := by
  have hfull : Henkin.FullProfiles M :=
    (Henkin.comp_iff_full_profiles M w hf hs).1 hc
  exact
    { nonempty_e := he
      faithful := hf
      worldSeparated := hs
      profiles := hfull
      comprehension := Henkin.comp_of_full_profiles M hfull
      propositions := unique_propositions M hc hf hs
      functions := unique_functions M hc hf hs }

/-- The proposition representation is the actual truth-profile map. -/
noncomputable def propositionEquiv {w : M.World} (h : FullStandard M w) :
    CarrierEquiv (M.Dom Ty.t) (M.World → Prop) :=
  CarrierEquiv.ofBijective M.truth
    ⟨truth_injective M h.faithful, by
      intro U
      obtain ⟨p, hp, _⟩ := h.propositions U
      refine ⟨p, ?_⟩
      funext v
      exact propext (hp v)⟩

theorem propositionEquiv_apply {w : M.World} (h : FullStandard M w)
    (p : M.Dom Ty.t) : propositionEquiv M h p = M.truth p := rfl

/-- Application identifies each permitted arrow carrier with the full
function space. The codomain is explicitly relational. -/
noncomputable def functionEquiv {w : M.World} (h : FullStandard M w)
    (σ : Ty) (ρ : RTy) :
    CarrierEquiv (M.Dom (σ ⇒ ρ)) (M.Dom σ → M.Dom ρ) :=
  CarrierEquiv.ofBijective (fun R : M.Dom (σ ⇒ ρ) => fun x => M.app R x)
    ⟨by
      intro R S hRS
      exact Henkin.application_injective M h.faithful σ ρ R S
        (fun x => congrFun hRS x), by
      intro f
      obtain ⟨R, hR, _⟩ := h.functions σ ρ f
      exact ⟨R, funext hR⟩⟩

theorem functionEquiv_apply {w : M.World} (h : FullStandard M w)
    (σ : Ty) (ρ : RTy) (R : M.Dom (σ ⇒ ρ)) (x : M.Dom σ) :
    functionEquiv M h σ ρ R x = M.app R x := rfl

#print axioms full_standard_of_comprehension
#print axioms unique_propositions
#print axioms unique_functions
#print axioms propositionEquiv
#print axioms functionEquiv

end Classicism.Research.InfinitaryComprehension.EndpointFullness
