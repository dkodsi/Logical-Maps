import Classicism.Syntax.Types

/-!
# Native-box endpoint bootstrap without Classicism

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 1--3; misc, 25 October 2026.

This is ordinary semantic metatheory. The proposition carrier is an arbitrary
type, distinct from Lean `Prop`. Its primitive operations initially have only
their classical truth clauses. Neither modal K nor Intensionality is assumed.
Native box is identity with the explicitly defined tautology.

`MatrixDomain` keeps an admitted matrix code type. It has no constructor from
arbitrary functions and does not assert a full relation domain. `Same` is the
literal existence of a common boxed representative. Boolean preservation is
extracted from that definition before K and Intensionality are proved.

Necessary universal instantiation is an explicit, separately named input at
the finite-representation boundary. It is precisely the relevant instance of
the stipulated theorem-only necessitation of ordinary UI, not Intensionality,
Comprehension, an arbitrary local necessitation rule, or a representation
assumption. A syntax/model adapter must establish it for its admitted codes.

No C layer, first-class necessity operator, custom axiom or admitted proof is
used. This module does not by itself construct that syntax/model adapter.
-/

namespace Classicism.Research.InfinitaryComprehension.EndpointBootstrap

universe u v w x y z

/-- The truth-functional H fragment on an arbitrary proposition carrier. -/
structure PropCore where
  P : Type u
  truth : P → Prop
  seed : P
  neg : P → P
  conj : P → P → P
  disj : P → P → P
  truth_neg : ∀ p, truth (neg p) ↔ ¬ truth p
  truth_conj : ∀ p q, truth (conj p q) ↔ truth p ∧ truth q
  truth_disj : ∀ p q, truth (disj p q) ↔ truth p ∨ truth q

namespace PropCore

variable (H : PropCore.{u})

/-- In the object presentation `seed` is the fixed proposition `∀p.p`. -/
def top : H.P := H.disj H.seed (H.neg H.seed)
def bot : H.P := H.conj H.seed (H.neg H.seed)
def imp (p q : H.P) : H.P := H.disj (H.neg p) q
def iff (p q : H.P) : H.P := H.conj (H.imp p q) (H.imp q p)
def Box (p : H.P) : Prop := p = H.top

theorem truth_top : H.truth H.top := by
  apply (H.truth_disj _ _).2
  cases Classical.em (H.truth H.seed) with
  | inl h => exact Or.inl h
  | inr h => exact Or.inr ((H.truth_neg _).2 h)

theorem not_truth_bot : ¬ H.truth H.bot := by
  intro h
  have hh := (H.truth_conj _ _).1 h
  exact (H.truth_neg _).1 hh.2 hh.1

theorem top_ne_bot : H.top ≠ H.bot := by
  intro h
  exact H.not_truth_bot (h ▸ H.truth_top)

theorem truth_of_box {p : H.P} (h : H.Box p) : H.truth p := by
  change p = H.top at h
  rw [h]
  exact H.truth_top

theorem truth_imp (p q : H.P) :
    H.truth (H.imp p q) ↔ (H.truth p → H.truth q) := by
  constructor
  · intro h hp
    cases (H.truth_disj _ _).1 h with
    | inl hn => exact False.elim ((H.truth_neg _).1 hn hp)
    | inr hq => exact hq
  · intro h
    apply (H.truth_disj _ _).2
    cases Classical.em (H.truth p) with
    | inl hp => exact Or.inr (h hp)
    | inr hp => exact Or.inl ((H.truth_neg _).2 hp)

theorem truth_iff (p q : H.P) :
    H.truth (H.iff p q) ↔ (H.truth p ↔ H.truth q) := by
  constructor
  · intro h
    have hh := (H.truth_conj _ _).1 h
    exact ⟨(H.truth_imp _ _).1 hh.1, (H.truth_imp _ _).1 hh.2⟩
  · intro h
    exact (H.truth_conj _ _).2
      ⟨(H.truth_imp _ _).2 h.1, (H.truth_imp _ _).2 h.2⟩

end PropCore

/-- Admitted matrices at one finite argument spine. `Arg` may be the
metatheoretic product interpreting that spine, not a new object type. -/
structure MatrixDomain (H : PropCore.{u}) (Arg : Type v) (Rel : Type w)
    (app : Rel → Arg → H.P) where
  Matrix : Type x
  eval : Matrix → Arg → H.P
  all : Matrix → H.P
  truth_all : ∀ A, H.truth (all A) ↔ ∀ a, H.truth (eval A a)
  agreement : Rel → Matrix → Matrix
  eval_agreement : ∀ R A a, eval (agreement R A) a = H.iff (app R a) (eval A a)

namespace MatrixDomain

variable {H : PropCore.{u}} {Arg : Type v} {Rel : Type w}
variable {app : Rel → Arg → H.P} (M : MatrixDomain.{u,v,w,x} H Arg Rel app)

def Rep (R : Rel) (A : M.Matrix) : Prop := H.Box (M.all (M.agreement R A))
def Same (A B : M.Matrix) : Prop := ∃ R, M.Rep R A ∧ M.Rep R B
def Comprehension : Prop := ∀ A : M.Matrix, ∃ R : Rel, M.Rep R A

/-- The ordinary current truth consequence uses no modal K or Intensionality. -/
theorem rep_material {R : Rel} {A : M.Matrix} (h : M.Rep R A) (a : Arg) :
    H.truth (app R a) ↔ H.truth (M.eval A a) := by
  have hh := (M.truth_all (M.agreement R A)).1 (H.truth_of_box h) a
  rw [M.eval_agreement] at hh
  exact (H.truth_iff _ _).1 hh

theorem same_material {A B : M.Matrix} (h : M.Same A B) (a : Arg) :
    H.truth (M.eval A a) ↔ H.truth (M.eval B a) := by
  obtain ⟨R, hA, hB⟩ := h
  exact (M.rep_material hA a).symm.trans (M.rep_material hB a)

/-- Only necessitated UI for these admitted matrix codes is requested. -/
def NecessaryUI : Prop :=
  ∀ (A : M.Matrix) (a : Arg), H.Box (H.imp (M.all A) (M.eval A a))

end MatrixDomain

/-- The admitted whole operations occurring in Boolean qualification. -/
structure BooleanPresentation (H : PropCore.{u}) (Obs : Type v)
    (observe : Obs → H.P → H.P) where
  Binary : Type w
  binaryApp : Binary → (H.P × H.P) → H.P
  unary : MatrixDomain.{u,u,v,x} H H.P Obs observe
  binary : MatrixDomain.{u,u,w,y} H (H.P × H.P) Binary binaryApp
  negLeft : Obs → unary.Matrix
  negRight : Obs → unary.Matrix
  conjLeft : Obs → binary.Matrix
  conjRight : Obs → binary.Matrix
  disjLeft : Obs → binary.Matrix
  disjRight : Obs → binary.Matrix
  eval_negLeft : ∀ E p, unary.eval (negLeft E) p = observe E (H.neg p)
  eval_negRight : ∀ E p, unary.eval (negRight E) p = H.neg (observe E p)
  eval_conjLeft : ∀ E p q, binary.eval (conjLeft E) (p,q) = observe E (H.conj p q)
  eval_conjRight : ∀ E p q,
    binary.eval (conjRight E) (p,q) = H.conj (observe E p) (observe E q)
  eval_disjLeft : ∀ E p q, binary.eval (disjLeft E) (p,q) = observe E (H.disj p q)
  eval_disjRight : ∀ E p q,
    binary.eval (disjRight E) (p,q) = H.disj (observe E p) (observe E q)

/-- Material laws are a conclusion extracted from the whole-operation package. -/
structure MaterialBoolean (H : PropCore.{u}) (E : H.P → H.P) : Prop where
  neg : ∀ p, H.truth (E (H.neg p)) ↔ ¬ H.truth (E p)
  conj : ∀ p q, H.truth (E (H.conj p q)) ↔ H.truth (E p) ∧ H.truth (E q)
  disj : ∀ p q, H.truth (E (H.disj p q)) ↔ H.truth (E p) ∨ H.truth (E q)

namespace BooleanPresentation

variable {H : PropCore.{u}} {Obs : Type v} {observe : Obs → H.P → H.P}
variable (B : BooleanPresentation.{u,v,w,x,y} H Obs observe)

def GoodBoolean (E : Obs) : Prop :=
  B.unary.Same (B.negLeft E) (B.negRight E) ∧
  B.binary.Same (B.conjLeft E) (B.conjRight E) ∧
  B.binary.Same (B.disjLeft E) (B.disjRight E)

theorem material {E : Obs} (h : B.GoodBoolean E) : MaterialBoolean H (observe E) where
  neg p := by
    have hh := B.unary.same_material h.1 p
    rw [B.eval_negLeft, B.eval_negRight] at hh
    exact hh.trans (H.truth_neg _)
  conj p q := by
    have hh := B.binary.same_material h.2.1 (p,q)
    rw [B.eval_conjLeft, B.eval_conjRight] at hh
    exact hh.trans (H.truth_conj _ _)
  disj p q := by
    have hh := B.binary.same_material h.2.2 (p,q)
    rw [B.eval_disjLeft, B.eval_disjRight] at hh
    exact hh.trans (H.truth_disj _ _)

end BooleanPresentation

namespace MaterialBoolean

variable {H : PropCore.{u}} {E : H.P → H.P} (h : MaterialBoolean H E)

include h

theorem accepts_top : H.truth (E H.top) := by
  apply (h.disj _ _).2
  cases Classical.em (H.truth (E H.seed)) with
  | inl hp => exact Or.inl hp
  | inr hp => exact Or.inr ((h.neg _).2 hp)

theorem rejects_bot : ¬ H.truth (E H.bot) := by
  intro hb
  have hh := (h.conj _ _).1 hb
  exact (h.neg _).1 hh.2 hh.1

theorem imp (p q : H.P) :
    H.truth (E (H.imp p q)) ↔ (H.truth (E p) → H.truth (E q)) := by
  constructor
  · intro hpq hp
    cases (h.disj _ _).1 hpq with
    | inl hn => exact False.elim ((h.neg _).1 hn hp)
    | inr hq => exact hq
  · intro hpq
    apply (h.disj _ _).2
    cases Classical.em (H.truth (E p)) with
    | inl hp => exact Or.inr (hpq hp)
    | inr hp => exact Or.inl ((h.neg _).2 hp)

theorem iff (p q : H.P) :
    H.truth (E (H.iff p q)) ↔ (H.truth (E p) ↔ H.truth (E q)) := by
  constructor
  · intro hpq
    have hh := (h.conj _ _).1 hpq
    exact ⟨(h.imp _ _).1 hh.1, (h.imp _ _).1 hh.2⟩
  · intro hpq
    exact (h.conj _ _).2 ⟨(h.imp _ _).2 hpq.1, (h.imp _ _).2 hpq.2⟩

end MaterialBoolean

/-- Extra eligibility Q may include the quantifier clauses and equality guards.
The endpoint clause is kept separate from this Boolean bootstrap. -/
def PropSeparation {H : PropCore.{u}} {Obs : Type v}
    {observe : Obs → H.P → H.P} (B : BooleanPresentation H Obs observe)
    (Q : Obs → Prop) : Prop :=
  ∀ p q : H.P,
    (∀ E, Q E → B.GoodBoolean E → (H.truth (observe E p) ↔ H.truth (observe E q))) →
      p = q

def EndpointValued {H : PropCore.{u}} {Obs : Type v}
    (observe : Obs → H.P → H.P) (E : Obs) : Prop :=
  ∀ p, observe E p = H.top ∨ observe E p = H.bot

variable {H : PropCore.{u}} {Obs : Type v} {observe : Obs → H.P → H.P}
variable {B : BooleanPresentation.{u,v,w,x,y} H Obs observe} {Q : Obs → Prop}

theorem separation_K (sep : PropSeparation B Q) {p q : H.P}
    (hpq : H.Box (H.imp p q)) (hp : H.Box p) : H.Box q := by
  apply sep q H.top
  intro E hQ hB
  have hm := B.material hB
  have ht := hm.accepts_top
  have hep : H.truth (observe E p) := by
    change p = H.top at hp
    rw [hp]
    exact ht
  have heimp : H.truth (observe E (H.imp p q)) := by
    change H.imp p q = H.top at hpq
    rw [hpq]
    exact ht
  have heq := (hm.imp p q).1 heimp hep
  exact ⟨fun _ => ht, fun _ => heq⟩

theorem separation_intensionality (sep : PropSeparation B Q) {p q : H.P}
    (h : H.Box (H.iff p q)) : p = q := by
  apply sep p q
  intro E hQ hB
  have hm := B.material hB
  have hh : H.truth (observe E (H.iff p q)) := by
    change H.iff p q = H.top at h
    rw [h]
    exact hm.accepts_top
  exact (hm.iff p q).1 hh

/-- Full typed separation at one relation spine, expressed by its value profile.
It is an additional instance of the user's separation schema, not a function
extensionality axiom smuggled into the carrier. -/
def RelationSeparation {Arg : Type z} {Rel : Type _}
    (app : Rel → Arg → H.P) : Prop :=
  ∀ R S : Rel,
    (∀ E, Q E → B.GoodBoolean E → ∀ a,
      H.truth (observe E (app R a)) ↔ H.truth (observe E (app S a))) → R = S

theorem relation_functionality {Arg : Type z} {Rel : Type _}
    {app : Rel → Arg → H.P} (sepR : RelationSeparation (B := B) (Q := Q) app)
    {R S : Rel} (h : ∀ a, app R a = app S a) : R = S := by
  apply sepR R S
  intro E hQ hB a
  rw [h a]

/-- A boxed coextension at any admitted finite relation spine gives identity.
The domain of the spine is not assumed to be a full object function space. -/
theorem relation_intensionality {Arg : Type z} {Rel : Type _}
    {app : Rel → Arg → H.P} (M : MatrixDomain H Arg Rel app)
    (sep : PropSeparation B Q) (ui : M.NecessaryUI)
    (sepR : RelationSeparation (B := B) (Q := Q) app)
    (R S : Rel) (A : M.Matrix)
    (hA : ∀ a, M.eval A a = H.iff (app R a) (app S a))
    (h : H.Box (M.all A)) : R = S := by
  apply relation_functionality sepR
  intro a
  have hi := separation_K sep (ui A a) h
  rw [hA a] at hi
  exact separation_intensionality sep hi

namespace MatrixDomain

variable {Arg : Type z} {Rel : Type _} {app : Rel → Arg → H.P}
variable (M : MatrixDomain H Arg Rel app)

theorem rep_exact (sep : PropSeparation B Q) (ui : M.NecessaryUI)
    {R : Rel} {A : M.Matrix} (h : M.Rep R A) (a : Arg) : app R a = M.eval A a := by
  have hi := separation_K sep (ui (M.agreement R A) a) h
  rw [M.eval_agreement] at hi
  exact separation_intensionality sep hi

theorem rep_unique (sep : PropSeparation B Q) (ui : M.NecessaryUI)
    (sepR : RelationSeparation (B := B) (Q := Q) app)
    {R S : Rel} {A : M.Matrix} (hR : M.Rep R A) (hS : M.Rep S A) : R = S := by
  apply relation_functionality sepR
  intro a
  exact (M.rep_exact sep ui hR a).trans (M.rep_exact sep ui hS a).symm

/-- Finite or infinitary scope is controlled entirely by the admitted codes. -/
theorem comprehension_exact (sep : PropSeparation B Q) (ui : M.NecessaryUI)
    (comp : M.Comprehension) (A : M.Matrix) :
    ∃ R : Rel, ∀ a, app R a = M.eval A a := by
  obtain ⟨R, hR⟩ := comp A
  exact ⟨R, M.rep_exact sep ui hR⟩

theorem comprehension_unique_exact (sep : PropSeparation B Q) (ui : M.NecessaryUI)
    (sepR : RelationSeparation (B := B) (Q := Q) app)
    (comp : M.Comprehension) (A : M.Matrix) :
    ∃ R : Rel, (∀ a, app R a = M.eval A a) ∧
      ∀ S : Rel, (∀ a, app S a = M.eval A a) → S = R := by
  obtain ⟨R, hR⟩ := M.comprehension_exact sep ui comp A
  refine ⟨R, hR, ?_⟩
  intro S hS
  exact relation_functionality sepR (fun a => (hS a).trans (hR a).symm)

end MatrixDomain

/-- Extract the universal observer law from a literal common representative.
`right_truth` is the ordinary truth clause of its admitted quantified matrix. -/
theorem same_universal_material {Arg : Type z} {Pred : Type _} {Op : Type _}
    {oapp : Op → Pred → H.P} (M : MatrixDomain H Pred Op oapp)
    (papp : Pred → Arg → H.P) (all : Pred → H.P) (E : Obs)
    (left right : M.Matrix) (hs : M.Same left right)
    (left_value : ∀ F, M.eval left F = observe E (all F))
    (right_truth : ∀ F, H.truth (M.eval right F) ↔
      ∀ a, H.truth (observe E (papp F a))) (F : Pred) :
    H.truth (observe E (all F)) ↔ ∀ a, H.truth (observe E (papp F a)) := by
  have hh := M.same_material hs F
  rw [left_value F] at hh
  exact hh.trans (right_truth F)

/-- Every Boolean observer reads endpoint-valued outputs correctly. This says
nothing about whether it reads arbitrary propositions correctly. -/
theorem endpoint_read {F E : Obs} (hF : B.GoodBoolean F)
    (hE : EndpointValued observe E) (p : H.P) :
    H.truth (observe F (observe E p)) ↔ H.truth (observe E p) := by
  have hm := B.material hF
  cases hE p with
  | inl hp =>
      rw [hp]
      exact ⟨fun _ => H.truth_top, fun _ => hm.accepts_top⟩
  | inr hp =>
      rw [hp]
      exact ⟨fun h => False.elim (hm.rejects_bot h),
        fun h => False.elim (H.not_truth_bot h)⟩

/-- Endpoint separation derives native propositional ND. The equality guard is
the original translated Leibniz implication at type t, applied to arbitrary
admitted predicates. Its reverse is obtained using a finitely represented
negated predicate; no equality-reflection or identity-fixing guard is assumed.
No observer witness or local inequality premise is necessitated. -/
theorem endpoint_necessary_distinctness
    (sep : PropSeparation B Q)
    (ui : B.unary.NecessaryUI) (comp : B.unary.Comprehension)
    (ends : ∀ E, Q E → B.GoodBoolean E → EndpointValued observe E)
    (identity : H.P → H.P → H.P)
    (leibniz : ∀ F, Q F → B.GoodBoolean F → ∀ p q E,
      H.truth (observe F (identity p q)) →
      H.truth (observe F (observe E p)) → H.truth (observe F (observe E q)))
    {p q : H.P} (hne : p ≠ q) : H.Box (H.neg (identity p q)) := by
  apply sep (H.neg (identity p q)) H.top
  intro F hQF hBF
  have hmF := B.material hBF
  have hnot : ¬ H.truth (observe F (identity p q)) := by
    intro hid
    apply hne
    apply sep p q
    intro E hQE hBE
    have hEnd := ends E hQE hBE
    have hreadp := endpoint_read hBF hEnd p
    have hreadq := endpoint_read hBF hEnd q
    have hfwd : H.truth (observe E p) → H.truth (observe E q) := by
      intro hp
      exact hreadq.1 (leibniz F hQF hBF p q E hid (hreadp.2 hp))
    obtain ⟨N, hN⟩ := B.unary.comprehension_exact sep ui comp (B.negRight E)
    have hNp : observe N p = H.neg (observe E p) :=
      (hN p).trans (B.eval_negRight E p)
    have hNq : observe N q = H.neg (observe E q) :=
      (hN q).trans (B.eval_negRight E q)
    have hneg : ¬ H.truth (observe E p) → ¬ H.truth (observe E q) := by
      intro hp hq
      have hFp : ¬ H.truth (observe F (observe E p)) := fun h => hp (hreadp.1 h)
      have hFNp : H.truth (observe F (observe N p)) := by
        rw [hNp]
        exact (hmF.neg _).2 hFp
      have hFNq := leibniz F hQF hBF p q N hid hFNp
      rw [hNq] at hFNq
      exact (hmF.neg _).1 hFNq (hreadq.2 hq)
    refine ⟨hfwd, ?_⟩
    intro hq
    cases Classical.em (H.truth (observe E p)) with
    | inl hp => exact hp
    | inr hp => exact False.elim (hneg hp hq)
  have hneg := (hmF.neg _).2 hnot
  exact ⟨fun _ => hmF.accepts_top, fun _ => hneg⟩

/-- The BF step needs only this material universal-observer law. An application
extracts it from the corresponding common-representative quantifier clause. -/
theorem separation_barcan {Arg : Type z} {Pred : Type _}
    (papp : Pred → Arg → H.P) (all : Pred → H.P)
    (sep : PropSeparation B Q)
    (preserves : ∀ E, Q E → B.GoodBoolean E → ∀ F : Pred,
      H.truth (observe E (all F)) ↔ ∀ a, H.truth (observe E (papp F a)))
    (F : Pred) (hF : ∀ a, H.Box (papp F a)) : H.Box (all F) := by
  apply sep (all F) H.top
  intro E hQ hB
  have ht := (B.material hB).accepts_top
  have hall : H.truth (observe E (all F)) := by
    apply (preserves E hQ hB F).2
    intro a
    have hh : papp F a = H.top := hF a
    rw [hh]
    exact ht
  exact ⟨fun _ => ht, fun _ => hall⟩

/-- Construct the endpoint diagonal from an admitted finite matrix and unary
Comprehension. The universal operation is applied to its admitted predicate
witness, so no extensional binder on arbitrary functions is assumed. -/
theorem diagonal_exists
    (sep : PropSeparation B Q)
    (ui : B.unary.NecessaryUI) (comp : B.unary.Comprehension)
    (all : Obs → H.P)
    (diagonalMatrix : Obs → B.unary.Matrix)
    (diagonal_value : ∀ E p,
      B.unary.eval (diagonalMatrix E) p = H.imp (observe E p) p)
    (preserves : ∀ F, Q F → B.GoodBoolean F → ∀ R : Obs,
      H.truth (observe F (all R)) ↔ ∀ p, H.truth (observe F (observe R p)))
    (E : Obs) :
    ∃ d : H.P, ∀ F, Q F → B.GoodBoolean F →
      (H.truth (observe F d) ↔ ∀ p, H.truth (observe F (H.imp (observe E p) p))) := by
  obtain ⟨R, hR⟩ := B.unary.comprehension_exact sep ui comp (diagonalMatrix E)
  refine ⟨all R, ?_⟩
  intro F hQ hB
  have hexact : ∀ p, observe R p = H.imp (observe E p) p :=
    fun p => (hR p).trans (diagonal_value E p)
  constructor
  · intro hd p
    have hh := (preserves F hQ hB R).1 hd p
    rw [hexact p] at hh
    exact hh
  · intro hd
    apply (preserves F hQ hB R).2
    intro p
    rw [hexact p]
    exact hd p

#print axioms MatrixDomain.same_material
#print axioms BooleanPresentation.material
#print axioms separation_K
#print axioms separation_intensionality
#print axioms relation_functionality
#print axioms relation_intensionality
#print axioms MatrixDomain.comprehension_exact
#print axioms MatrixDomain.comprehension_unique_exact
#print axioms separation_barcan
#print axioms same_universal_material
#print axioms endpoint_necessary_distinctness
#print axioms diagonal_exists

end Classicism.Research.InfinitaryComprehension.EndpointBootstrap
