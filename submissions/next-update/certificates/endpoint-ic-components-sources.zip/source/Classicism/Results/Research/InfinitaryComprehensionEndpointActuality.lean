import Classicism.Results.Research.InfinitaryComprehensionEndpointAtoms

/-!
# The designated actual world is derived

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 3--4; misc, 25 October 2026.

Given the constructed endpoint diagonals and infinitary formation, the
ordinary CURRENT truth clause for conjunction supplies an actually true
diagonal. Its observer agrees with current truth on every proposition.
The resulting world is unique as an observer truth profile, even when
several admitted observers have the same profile. No actual observer,
actual atom, or designated world is an input premise.

This is a semantic bridge. `truth_inf` is the ordinary current truth clause
for the admitted infinitary conjunction, not relational Comprehension.
The algebraic meet laws and diagonal laws belong to the imported, separately
constructed endpoint presentation.
-/

namespace Classicism.Research.InfinitaryComprehension.EndpointActuality

open EndpointBootstrap EndpointAtoms

universe u

variable {H : PropCore.{u}} {O : Type u} (A : QuantifiedEndpoints H O)
variable (L : A.Infima)

/-- Classical infinitary disjunction has its ordinary current truth clause. -/
theorem truth_sup
    (truth_inf : ∀ (I : Type u) (f : I → H.P),
      H.truth (L.inf I f) ↔ ∀ i, H.truth (f i))
    (I : Type u) (f : I → H.P) :
    H.truth (A.Sup L I f) ↔ ∃ i, H.truth (f i) := by
  change H.truth (H.neg (L.inf I (fun i => H.neg (f i)))) ↔ _
  rw [H.truth_neg, truth_inf]
  constructor
  · intro hn
    apply Classical.byContradiction
    intro hex
    apply hn
    intro i
    apply (H.truth_neg _).2
    intro hi
    exact hex ⟨i, hi⟩
  · intro h hn
    obtain ⟨i, hi⟩ := h
    exact (H.truth_neg _).1 (hn i) hi

/-- Every observer accepts its own diagonal, so all diagonals cover top. -/
theorem diagonal_sup_top : A.Sup L O A.diagonal = H.top := by
  apply A.separation
  intro E
  exact ⟨fun _ => (A.boolean E).accepts_top,
    fun _ => (A.accepts_sup L O A.diagonal E).2 ⟨E, A.diagonal_self E⟩⟩

theorem true_diagonal_exists
    (truth_inf : ∀ (I : Type u) (f : I → H.P),
      H.truth (L.inf I f) ↔ ∀ i, H.truth (f i)) :
    ∃ E : O, H.truth (A.diagonal E) := by
  apply (truth_sup A L truth_inf O A.diagonal).1
  rw [diagonal_sup_top A L]
  exact H.truth_top

/-- A true diagonal's observer reads exactly the current truth values. -/
theorem true_diagonal_reads_current (E : O) (hd : H.truth (A.diagonal E))
    (p : H.P) : A.Accepts E p ↔ H.truth p := by
  have forward : ∀ q : H.P, A.Accepts E q → H.truth q := by
    intro q hq
    have hle := (A.diagonal_le_iff E q).2 hq
    exact (H.truth_imp _ _).1 (H.truth_of_box hle) hd
  constructor
  · exact forward p
  · intro hp
    cases Classical.em (A.Accepts E p) with
    | inl he => exact he
    | inr he =>
        have hn := forward (H.neg p) (((A.boolean E).neg p).2 he)
        exact False.elim ((H.truth_neg p).1 hn hp)

/-- Existence and uniqueness of the actual WORLD. Uniqueness of the admitted
observer itself is neither claimed nor required. -/
theorem actual_world_exists_unique
    (truth_inf : ∀ (I : Type u) (f : I → H.P),
      H.truth (L.inf I f) ↔ ∀ i, H.truth (f i)) :
    ∃ w₀ : A.World, (∀ p, A.Truth p w₀ ↔ H.truth p) ∧
      ∀ w : A.World, (∀ p, A.Truth p w ↔ H.truth p) → w = w₀ := by
  obtain ⟨E, hE⟩ := true_diagonal_exists A L truth_inf
  have he : ∀ p, A.Accepts E p ↔ H.truth p := true_diagonal_reads_current A E hE
  refine ⟨A.world E, he, ?_⟩
  intro w hw
  obtain ⟨F, rfl⟩ := A.world_surjective w
  apply (A.world_eq_iff F E).2
  intro p
  exact (hw p).trans (he p).symm

#print axioms truth_sup
#print axioms diagonal_sup_top
#print axioms true_diagonal_exists
#print axioms true_diagonal_reads_current
#print axioms actual_world_exists_unique

end Classicism.Research.InfinitaryComprehension.EndpointActuality
