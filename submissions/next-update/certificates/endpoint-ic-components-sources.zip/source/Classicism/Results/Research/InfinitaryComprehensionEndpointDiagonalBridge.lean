import Classicism.Results.Research.InfinitaryComprehensionEndpointAtoms

/-!
# Finite common-representative qualification supplies diagonal atoms

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 1--3; misc, 25 October 2026,
unpaginated.

This module discharges the `diagonal_law` input of `QuantifiedEndpoints`
using finite Comprehension for admitted matrix codes and the literal common
representative quantifier qualification. No arbitrary external predicate
matrix is admitted. For each E, the only new code requested is the finite
body p |-> (E p -> p). A represented predicate R_E is obtained by finite
Comprehension, and its actual universal quantification is the diagonal.

The code interface and necessary UI still need the concrete H syntax/model
adapter identified in `EndpointBootstrap`. Selecting the representatives to
package a structure uses ordinary Lean classical choice; this module makes
no choice-free metatheoretic claim.
-/

namespace Classicism.Research.InfinitaryComprehension.EndpointDiagonalBridge

open EndpointBootstrap EndpointAtoms

universe u v w x y z r

/-- The admitted composite operations in the t-quantifier qualification.
`matrices` ranges over explicit matrix codes with one predicate input. -/
structure UniversalPresentation (H : PropCore.{u}) (Obs : Type v)
    (observe : Obs → H.P → H.P) where
  Operators : Type w
  operatorApp : Operators → Obs → H.P
  matrices : MatrixDomain.{u,v,w,x} H Obs Operators operatorApp
  all : Obs → H.P
  left : Obs → matrices.Matrix
  right : Obs → matrices.Matrix
  eval_left : ∀ E F, matrices.eval (left E) F = observe E (all F)
  truth_right : ∀ E F, H.truth (matrices.eval (right E) F) ↔
    ∀ p : H.P, H.truth (observe E (observe F p))

namespace UniversalPresentation

variable {H : PropCore.{u}} {Obs : Type v} {observe : Obs → H.P → H.P}
variable (U : UniversalPresentation.{u,v,w,x} H Obs observe)

def Qualified (E : Obs) : Prop := U.matrices.Same (U.left E) (U.right E)

theorem material {E : Obs} (h : U.Qualified E) (F : Obs) :
    H.truth (observe E (U.all F)) ↔
      ∀ p : H.P, H.truth (observe E (observe F p)) :=
  same_universal_material U.matrices observe U.all E (U.left E) (U.right E)
    h (U.eval_left E) (U.truth_right E) F

end UniversalPresentation

variable {H : PropCore.{u}} {Obs : Type u} {observe : Obs → H.P → H.P}
variable (B : BooleanPresentation.{u,u,w,x,y} H Obs observe)

/-- The one finite admitted body needed by the diagonal argument. This is
an existing code supplied by finite formation, not a function-to-code map. -/
structure DiagonalCodes where
  body : Obs → B.unary.Matrix
  eval_body : ∀ E p, B.unary.eval (body E) p = H.imp (observe E p) p

def Eligible (Q : Obs → Prop) := {E : Obs // Q E ∧ B.GoodBoolean E}

noncomputable def diagonalRepresentative (D : DiagonalCodes B)
    (comp : B.unary.Comprehension) (E : Obs) : Obs :=
  Classical.choose (comp (D.body E))

theorem diagonalRepresentative_exact (D : DiagonalCodes B)
    {Q : Obs → Prop} (sep : PropSeparation B Q)
    (ui : B.unary.NecessaryUI) (comp : B.unary.Comprehension)
    (E : Obs) (p : H.P) :
    observe (diagonalRepresentative B D comp E) p = H.imp (observe E p) p := by
  have hrep : B.unary.Rep (diagonalRepresentative B D comp E) (D.body E) :=
    Classical.choose_spec (comp (D.body E))
  exact (B.unary.rep_exact sep ui hrep p).trans (D.eval_body E p)

/-- The diagonal structure is constructed from admitted finite matrices,
common-representative qualification, and the t-instance of separation.
No diagonal preservation assumption remains in the result. -/
noncomputable def quantifiedEndpoints (D : DiagonalCodes B)
    (U : UniversalPresentation.{u,u,z,r} H Obs observe)
    {Q : Obs → Prop} (sep : PropSeparation B Q)
    (ui : B.unary.NecessaryUI) (comp : B.unary.Comprehension)
    (ends : ∀ E, Q E → B.GoodBoolean E → EndpointValued observe E)
    (quant : ∀ E, Q E → B.GoodBoolean E → U.Qualified E) :
    QuantifiedEndpoints H (Eligible B Q) where
  observe E := observe E.val
  boolean E := B.material E.property.2
  endpoint E := ends E.val E.property.1 E.property.2
  separation p q h := sep p q (fun E hQ hB => h ⟨E, hQ, hB⟩)
  diagonal E := U.all (diagonalRepresentative B D comp E.val)
  diagonal_law E F := by
    have hU := U.material (quant F.val F.property.1 F.property.2)
      (diagonalRepresentative B D comp E.val)
    refine hU.trans ?_
    have hR (p : H.P) := diagonalRepresentative_exact B D sep ui comp E.val p
    constructor
    · intro h p
      rw [← hR p]
      exact h p
    · intro h p
      rw [hR p]
      exact h p

/-- Atomicity with the diagonal premise discharged by the displayed finite
formation, comprehension and quantifier qualification data. -/
theorem atomicity_of_finite_comprehension (D : DiagonalCodes B)
    (U : UniversalPresentation.{u,u,z,r} H Obs observe)
    {Q : Obs → Prop} (sep : PropSeparation B Q)
    (ui : B.unary.NecessaryUI) (comp : B.unary.Comprehension)
    (ends : ∀ E, Q E → B.GoodBoolean E → EndpointValued observe E)
    (quant : ∀ E, Q E → B.GoodBoolean E → U.Qualified E)
    {p : H.P} (hp : p ≠ H.bot) :
    let A := quantifiedEndpoints B D U sep ui comp ends quant
    ∃ a, A.Atom a ∧ A.Le a p :=
  (quantifiedEndpoints B D U sep ui comp ends quant).atomicity hp

#print axioms UniversalPresentation.material
#print axioms diagonalRepresentative_exact
#print axioms quantifiedEndpoints
#print axioms atomicity_of_finite_comprehension

end Classicism.Research.InfinitaryComprehension.EndpointDiagonalBridge
