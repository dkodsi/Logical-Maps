import Classicism.Results.Research.InfinitaryComprehensionEndpointBootstrap

/-!
# Infinitary Comprehension transfers quantified matrix truth

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, section 4; misc, 25 October 2026, unpaginated.

The existing finite observer qualification speaks about quantified admitted
predicate objects. A genuinely new infinitary matrix need not already have
such a predicate object. Infinitary Comprehension supplies one, and the
globally necessitated ordinary quantifier-congruence theorem identifies its
quantification with the actual bound matrix. Recovered K/Intensionality and
necessary UI then transfer observer truth to the latter.

Every matrix below belongs to `M.Matrix`; there is no constructor accepting
arbitrary external predicate functions. The necessity of the displayed
logical congruence theorem is an explicit adapter input, just as necessary
UI is in `EndpointBootstrap`. No local comprehension witness or local
equivalence premise is necessitated.

This discharges the quantified-matrix transfer step. It does not by itself
establish a complete syntax/model adapter or assume that one is available.
-/

namespace Classicism.Research.InfinitaryComprehension.EndpointBinderBridge

open EndpointBootstrap

universe u v w x y z r s

variable {H : PropCore.{u}} {Obs : Type v} {observe : Obs → H.P → H.P}
variable {B : BooleanPresentation.{u,v,w,x,y} H Obs observe} {Q : Obs → Prop}
variable {Arg : Type z} {Rel : Type r} {app : Rel → Arg → H.P}
variable (M : MatrixDomain.{u,z,r,s} H Arg Rel app)

/-- Necessary ordinary binder congruence, instantiated at an admitted
representative and matrix. For `binder = M.all` this is the universal case;
the existential case uses its actual admitted existential binder. -/
def NecessaryBinderCongruence (operation : Rel → H.P)
    (binder : M.Matrix → H.P) : Prop :=
  ∀ (R : Rel) (A : M.Matrix),
    H.Box (H.imp (M.all (M.agreement R A)) (H.iff (operation R) (binder A)))

/-- Recover the identity of the quantified predicate and actual quantified
matrix from its boxed representation; no binder extensionality is assumed. -/
theorem binder_identity_of_rep (sep : PropSeparation B Q)
    (operation : Rel → H.P) (binder : M.Matrix → H.P)
    (congruence : NecessaryBinderCongruence M operation binder)
    {R : Rel} {A : M.Matrix} (h : M.Rep R A) :
    operation R = binder A :=
  separation_intensionality sep (separation_K sep (congruence R A) h)

/-- Universal truth for a new admitted matrix follows from its IC witness
and the observer's existing universal law on admitted predicate objects. -/
theorem observed_all_of_comprehension (sep : PropSeparation B Q)
    (ui : M.NecessaryUI) (comp : M.Comprehension)
    (allOperation : Rel → H.P)
    (congruence : NecessaryBinderCongruence M allOperation M.all)
    (E : Obs)
    (preserves : ∀ R : Rel, H.truth (observe E (allOperation R)) ↔
      ∀ a : Arg, H.truth (observe E (app R a)))
    (A : M.Matrix) :
    H.truth (observe E (M.all A)) ↔
      ∀ a : Arg, H.truth (observe E (M.eval A a)) := by
  obtain ⟨R, hR⟩ := comp A
  have hb := binder_identity_of_rep M sep allOperation M.all congruence hR
  have hv := M.rep_exact sep ui hR
  rw [← hb]
  constructor
  · intro h a
    have ha := (preserves R).1 h a
    rw [hv a] at ha
    exact ha
  · intro h
    apply (preserves R).2
    intro a
    rw [hv a]
    exact h a

/-- Existential truth transfers by the same argument, retaining the actual
existential code binder rather than defining it on all external functions. -/
theorem observed_ex_of_comprehension (sep : PropSeparation B Q)
    (ui : M.NecessaryUI) (comp : M.Comprehension)
    (exOperation : Rel → H.P) (exBinder : M.Matrix → H.P)
    (congruence : NecessaryBinderCongruence M exOperation exBinder)
    (E : Obs)
    (preserves : ∀ R : Rel, H.truth (observe E (exOperation R)) ↔
      ∃ a : Arg, H.truth (observe E (app R a)))
    (A : M.Matrix) :
    H.truth (observe E (exBinder A)) ↔
      ∃ a : Arg, H.truth (observe E (M.eval A a)) := by
  obtain ⟨R, hR⟩ := comp A
  have hb := binder_identity_of_rep M sep exOperation exBinder congruence hR
  have hv := M.rep_exact sep ui hR
  rw [← hb]
  constructor
  · intro h
    obtain ⟨a, ha⟩ := (preserves R).1 h
    rw [hv a] at ha
    exact ⟨a, ha⟩
  · intro h
    obtain ⟨a, ha⟩ := h
    apply (preserves R).2
    refine ⟨a, ?_⟩
    rw [hv a]
    exact ha

#print axioms binder_identity_of_rep
#print axioms observed_all_of_comprehension
#print axioms observed_ex_of_comprehension

end Classicism.Research.InfinitaryComprehension.EndpointBinderBridge
