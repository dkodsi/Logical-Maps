import Classicism.Results.Research.InfinitaryComprehensionStandardLaws

/-!
# Endpoint observers and Infinitary Comprehension in full standard models

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 1 and 5, misc, 25 October 2026,
unpaginated.

This module proves the full-standard converse. Its observers are actual
members of the full `tt` domain, and qualification uses one common admitted
representative of each pair of composite operations. The original finite
types, arbitrary parameter families, and concrete infinitary matrices are
those of `InfinitaryComprehensionSyntax`.

This is ordinary semantic metatheory. It is not a derivation of the forward
representation theorem from a weak H calculus. In particular, extensionality
of these full domains is proved in Lean's metatheory and is not assumed to be
an object-language rule of H.
-/

namespace Classicism.Research.InfinitaryComprehension.EndpointStandard

open Classicism.Meta

universe u v

variable {E W : Type v}

abbrev Proposition (W : Type v) := W → Prop
abbrev Observer (W : Type v) := Proposition W → Proposition W

def top : Proposition W := fun _ => True
def bot : Proposition W := fun _ => False
def neg (p : Proposition W) : Proposition W := fun w => ¬ p w
def conj (p q : Proposition W) : Proposition W := fun w => p w ∧ q w
def disj (p q : Proposition W) : Proposition W := fun w => p w ∨ q w
def all (σ : Ty) (F : FullTy E W σ → Proposition W) : Proposition W :=
  fun w => ∀ x, F x w
def ex (σ : Ty) (F : FullTy E W σ → Proposition W) : Proposition W :=
  fun w => ∃ x, F x w

/-- The H abbreviation `u := ∀ p : t, p`, interpreted before using any
propositional identity principle. -/
def hU : Proposition W := fun w => ∀ p : Proposition W, p w
def hTop : Proposition W := disj hU (neg hU)
def hBot : Proposition W := conj hU (neg hU)

theorem hTop_eq_top : @hTop W = top := by
  funext w
  apply propext
  exact ⟨fun _ => True.intro, fun _ => Classical.em (hU w)⟩

theorem hBot_eq_bot : @hBot W = bot := by
  funext w
  apply propext
  exact ⟨fun h => h.2 h.1, fun h => False.elim h⟩

theorem box_eq_hTop (p : Proposition W) :
    (∀ w, p w) ↔ p = hTop := by
  rw [hTop_eq_top]
  exact Term.full_box_eq_top p

/-- `Rep` is exactly a necessary universal equivalence, with the finite
argument context explicit. -/
def Rep (Γ : Ctx) (R : FullRel E W (RTy.ofArgs Γ))
    (A : Env E W Γ → Proposition W) : Prop :=
  ∀ (xs : Env E W Γ) (w : W), uncurry E W Γ R xs w ↔ A xs w

/-- One common admitted representative, with no uniqueness presupposed. -/
def Same (Γ : Ctx) (A B : Env E W Γ → Proposition W) : Prop :=
  ∃ R : FullRel E W (RTy.ofArgs Γ), Rep Γ R A ∧ Rep Γ R B

theorem same_of_eq (Γ : Ctx) (A B : Env E W Γ → Proposition W)
    (h : A = B) : Same Γ A B := by
  subst B
  refine ⟨curry E W Γ A, ?_, ?_⟩ <;>
    intro xs w <;> rw [uncurry_curry]

/-- These are the semantic truth conditions of the lambda-free
common-representative qualification, including both translated equality
guards at every listed type. -/
structure Good (Δ : List Ty) (atWorld : W) (O : Observer W) : Prop where
  neg_law : Same (E := E) [Ty.t]
    (fun xs => O (neg (xs .zero)))
    (fun xs => neg (O (xs .zero)))
  conj_law : Same (E := E) [Ty.t, Ty.t]
    (fun xs => O (conj (xs .zero) (xs (.succ .zero))))
    (fun xs => conj (O (xs .zero)) (O (xs (.succ .zero))))
  disj_law : Same (E := E) [Ty.t, Ty.t]
    (fun xs => O (disj (xs .zero) (xs (.succ .zero))))
    (fun xs => disj (O (xs .zero)) (O (xs (.succ .zero))))
  all_law : ∀ σ ∈ Δ, Same (E := E) [σ ⇒ RTy.t]
    (fun xs => O (all σ (xs .zero)))
    (fun xs => all σ (fun x => O ((xs .zero) x)))
  ex_law : ∀ σ ∈ Δ, Same (E := E) [σ ⇒ RTy.t]
    (fun xs => O (ex σ (xs .zero)))
    (fun xs => ex σ (fun x => O ((xs .zero) x)))
  eq_refl : ∀ σ ∈ Δ, ∀ x : FullTy E W σ,
    O (fun _ => x = x) atWorld
  eq_subst : ∀ σ ∈ Δ, ∀ (x y : FullTy E W σ)
    (F : FullTy E W σ → Proposition W),
    O (fun _ => x = y) atWorld → O (F x) atWorld → O (F y) atWorld

def EndpointValued (O : Observer W) : Prop :=
  ∀ p, O p = top ∨ O p = bot

theorem endpointValued_iff_hEndpoints (O : Observer W) :
    EndpointValued O ↔ ∀ p, O p = hTop ∨ O p = hBot := by
  rw [hTop_eq_top, hBot_eq_bot]
  exact Iff.rfl

/-- Each world gives an actual `tt` object with constant endpoint outputs. -/
def worldReader (w : W) : FullTy E W (RTy.t ⇒ RTy.t) :=
  fun p _ => p w

theorem worldReader_endpoints (w : W) :
    EndpointValued (worldReader (E := E) w) := by
  classical
  intro p
  by_cases h : p w
  · left
    funext z
    exact propext ⟨fun _ => True.intro, fun _ => h⟩
  · right
    funext z
    exact propext ⟨h, False.elim⟩

theorem worldReader_good (Δ : List Ty) (w atWorld : W) :
    Good (E := E) Δ atWorld (worldReader (E := E) w) := by
  constructor
  · exact same_of_eq _ _ _ rfl
  · exact same_of_eq _ _ _ rfl
  · exact same_of_eq _ _ _ rfl
  · intro σ _
    exact same_of_eq _ _ _ rfl
  · intro σ _
    exact same_of_eq _ _ _ rfl
  · intro σ _ x
    exact rfl
  · intro σ _ x y F h hFx
    exact h ▸ hFx

/-- Observed coextension has the same finite application recursion as the
original relational type, including the empty tuple at `t`. -/
def ObservedCoext (O : Observer W) : (ρ : RTy) →
    FullRel E W ρ → FullRel E W ρ → W → Prop
  | .t, p, q, w => O p w ↔ O q w
  | .arr σ ρ, X, Y, w =>
      ∀ x : FullTy E W σ, ObservedCoext O ρ (X x) (Y x) w

theorem observedCoext_refl (O : Observer W) (ρ : RTy)
    (X : FullRel E W ρ) (w : W) : ObservedCoext O ρ X X w := by
  induction ρ using RTy.induction with
  | t => exact Iff.rfl
  | arr σ ρ ih => exact fun x => ih (X x)

theorem worldReader_observedCoext (ρ : RTy) (X Y : FullRel E W ρ)
    (w atWorld : W) :
    ObservedCoext (worldReader (E := E) w) ρ X Y atWorld ↔
      FullCoext E W ρ X Y w := by
  induction ρ using RTy.induction with
  | t => exact Iff.rfl
  | arr σ ρ ih =>
      exact ⟨fun h x => (ih (X x) (Y x)).1 (h x),
        fun h x => (ih (X x) (Y x)).2 (h x)⟩

/-- The full typed endpoint separation schema, for every finite list of
quantifier types. No proposition-only weakening is used here. -/
theorem full_endpoint_separation (Δ : List Ty) (ρ : RTy)
    (X Y : FullRel E W ρ) (atWorld : W) :
    X = Y ↔ ∀ O : Observer W,
      Good (E := E) Δ atWorld O ∧ EndpointValued O →
        ObservedCoext O ρ X Y atWorld := by
  constructor
  · intro h O _
    subst Y
    exact observedCoext_refl O ρ X atWorld
  · intro h
    apply full_coext_intensionality E W ρ X Y
    intro w
    exact (worldReader_observedCoext ρ X Y w atWorld).1
      (h (worldReader (E := E) w)
        ⟨worldReader_good Δ w atWorld, worldReader_endpoints w⟩)

/-- The same separation statement written directly with a finite argument
tuple, as in the mathematical presentation. -/
theorem full_tuple_endpoint_separation (Δ Γ : Ctx)
    (X Y : FullRel E W (RTy.ofArgs Γ)) (atWorld : W) :
    X = Y ↔ ∀ O : Observer W,
      Good (E := E) Δ atWorld O ∧ EndpointValued O →
        ∀ xs : Env E W Γ,
          O (uncurry E W Γ X xs) atWorld ↔
            O (uncurry E W Γ Y xs) atWorld := by
  constructor
  · intro h O _ xs
    subst Y
    exact Iff.rfl
  · intro h
    apply full_intensionality E W Γ X Y
    intro xs w
    exact h (worldReader (E := E) w)
      ⟨worldReader_good Δ w atWorld, worldReader_endpoints w⟩ xs

/-- Actual object syntax for two matrices having one common representative.
The represented variables are bound; arbitrary parameters remain free. -/
def sameFormula {Param : Ty → Type u} {Γ : Ctx}
    (A B : Formula Param Γ) : Formula Param [] :=
  .ex (.conj (.box (Term.closeAll Γ A.compBody))
    (.box (Term.closeAll Γ B.compBody)))

theorem eval_sameFormula {Param : Ty → Type u}
    (η : Assignment Param E W) {Γ : Ctx}
    (A B : Formula Param Γ) (atWorld : W) :
    Term.eval η (sameFormula A B) Env.nil atWorld ↔
      Same Γ (fun xs => Term.eval η A xs) (fun xs => Term.eval η B xs) := by
  change (∃ R : FullRel E W (RTy.ofArgs Γ),
    (∀ w : W, Term.eval η (Term.closeAll Γ A.compBody) (Env.cons R Env.nil) w) ∧
    (∀ w : W, Term.eval η (Term.closeAll Γ B.compBody) (Env.cons R Env.nil) w)) ↔ _
  have matrix (F : Formula Param Γ) (R : FullRel E W (RTy.ofArgs Γ)) :
      (∀ w : W, Term.eval η (Term.closeAll Γ F.compBody) (Env.cons R Env.nil) w) ↔
        Rep Γ R (fun xs => Term.eval η F xs) := by
    constructor
    · intro h xs w
      have hx := (Term.eval_closeAll η Γ F.compBody _ w).1 (h w) xs
      simpa only [Term.eval_compBody] using hx
    · intro h w
      apply (Term.eval_closeAll η Γ F.compBody _ w).2
      intro xs
      simpa only [Term.eval_compBody] using h xs w
  constructor
  · intro h
    cases h with
    | intro R hR => exact ⟨R, (matrix A R).1 hR.1, (matrix B R).1 hR.2⟩
  · intro h
    cases h with
    | intro R hR => exact ⟨R, (matrix A R).2 hR.1, (matrix B R).2 hR.2⟩

/-- Full standard models satisfy endpoint-valued OS and every concrete
infinitary Comprehension instance under every simultaneous assignment.
The individual nonemptiness premise is retained exactly where H needs it. -/
theorem full_standard_endpoint_OS_and_IC {Param : Ty → Type u}
    [Nonempty E] (η : Assignment Param E W) :
    Nonempty (FullTy E W Ty.e) ∧
      (∀ (Δ : List Ty) (ρ : RTy) (X Y : FullRel E W ρ) (w : W),
        X = Y ↔ ∀ O : Observer W,
          Good (E := E) Δ w O ∧ EndpointValued O → ObservedCoext O ρ X Y w) ∧
      (∀ (Γ : Ctx) (A : Formula Param Γ) (w : W),
        Term.eval η A.comprehension Env.nil w) :=
  ⟨inferInstance, full_endpoint_separation,
    fun _ A w => Term.full_comprehension η A w⟩

#print axioms hTop_eq_top
#print axioms hBot_eq_bot
#print axioms box_eq_hTop
#print axioms endpointValued_iff_hEndpoints
#print axioms worldReader_good
#print axioms worldReader_endpoints
#print axioms full_endpoint_separation
#print axioms full_tuple_endpoint_separation
#print axioms eval_sameFormula
#print axioms full_standard_endpoint_OS_and_IC

end Classicism.Research.InfinitaryComprehension.EndpointStandard
