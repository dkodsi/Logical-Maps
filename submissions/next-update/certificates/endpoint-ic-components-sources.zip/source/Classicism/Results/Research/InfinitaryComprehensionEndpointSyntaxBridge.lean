import Classicism.Results.Research.InfinitaryComprehensionEndpointBinderBridge
import Classicism.Results.Research.InfinitaryComprehensionEndpointAtoms

/-!
# Normalize admitted quantifier binders in the observer presentation

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, section 4; misc, 25 October 2026, unpaginated.

The observer construction has algebraic infinitary meets and joins. A raw
infinitary matrix binder need not initially be defined by those operations.
The IC binder bridge establishes its truth at every qualified observer;
separation then identifies the raw binder with the canonical meet or join.

The families normalized here are evaluations of a specific admitted matrix
code. No function-to-code constructor and no comprehension over arbitrary
external functions is assumed. The observer index map accommodates the
eligible-observer subtype constructed in `EndpointDiagonalBridge`.

These normalization results are a step toward a structural syntax truth
lemma. They retain the explicit raw-code and logical-schema inputs of the
binder bridge; they do not silently supply a missing concrete evaluator.
-/

namespace Classicism.Research.InfinitaryComprehension.EndpointSyntaxBridge

open EndpointBootstrap EndpointAtoms EndpointBinderBridge

universe u v w x y r s

variable {H : PropCore.{u}} {Obs : Type v} {observe : Obs → H.P → H.P}
variable {B : BooleanPresentation.{u,v,w,x,y} H Obs observe} {Q : Obs → Prop}
variable {Arg : Type u} {Rel : Type r} {app : Rel → Arg → H.P}
variable (M : MatrixDomain.{u,u,r,s} H Arg Rel app)
variable {O : Type u} (Aobs : QuantifiedEndpoints H O) (L : Aobs.Infima)

/-- The actual universally quantified matrix denotes the canonical
infimum of the admitted code's argument instances. -/
theorem raw_all_eq_inf
    (observerIndex : O → Obs)
    (observer_apply : ∀ (E : O) (p : H.P),
      Aobs.observe E p = observe (observerIndex E) p)
    (sep : PropSeparation B Q)
    (ui : M.NecessaryUI) (comp : M.Comprehension)
    (allOperation : Rel → H.P)
    (congruence : NecessaryBinderCongruence M allOperation M.all)
    (preserves : ∀ (E : O) (R : Rel),
      H.truth (observe (observerIndex E) (allOperation R)) ↔
        ∀ a : Arg, H.truth (observe (observerIndex E) (app R a)))
    (A : M.Matrix) : M.all A = L.inf Arg (M.eval A) := by
  apply Aobs.separation
  intro E
  have hraw := observed_all_of_comprehension M sep ui comp allOperation congruence
    (observerIndex E) (preserves E) A
  have hactual : Aobs.Accepts E (M.all A) ↔
      ∀ a : Arg, Aobs.Accepts E (M.eval A a) := by
    change H.truth (Aobs.observe E (M.all A)) ↔
      ∀ a : Arg, H.truth (Aobs.observe E (M.eval A a))
    simpa only [observer_apply] using hraw
  exact hactual.trans (Aobs.accepts_inf L Arg (M.eval A) E).symm

/-- The actual existentially quantified matrix denotes the canonical
supremum of the admitted code's argument instances. -/
theorem raw_ex_eq_sup
    (observerIndex : O → Obs)
    (observer_apply : ∀ (E : O) (p : H.P),
      Aobs.observe E p = observe (observerIndex E) p)
    (sep : PropSeparation B Q)
    (ui : M.NecessaryUI) (comp : M.Comprehension)
    (exOperation : Rel → H.P) (exBinder : M.Matrix → H.P)
    (congruence : NecessaryBinderCongruence M exOperation exBinder)
    (preserves : ∀ (E : O) (R : Rel),
      H.truth (observe (observerIndex E) (exOperation R)) ↔
        ∃ a : Arg, H.truth (observe (observerIndex E) (app R a)))
    (A : M.Matrix) : exBinder A = Aobs.Sup L Arg (M.eval A) := by
  apply Aobs.separation
  intro E
  have hraw := observed_ex_of_comprehension M sep ui comp exOperation exBinder congruence
    (observerIndex E) (preserves E) A
  have hactual : Aobs.Accepts E (exBinder A) ↔
      ∃ a : Arg, Aobs.Accepts E (M.eval A a) := by
    change H.truth (Aobs.observe E (exBinder A)) ↔
      ∃ a : Arg, H.truth (Aobs.observe E (M.eval A a))
    simpa only [observer_apply] using hraw
  exact hactual.trans (Aobs.accepts_sup L Arg (M.eval A) E).symm

#print axioms raw_all_eq_inf
#print axioms raw_ex_eq_sup

end Classicism.Research.InfinitaryComprehension.EndpointSyntaxBridge
