import Classicism.Results.Research.InfinitaryComprehensionEndpointAtoms

/-!
# Each finite observer qualification covers the same worlds

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 1--4; misc, 25 October 2026.

The base observer class is qualified at type t and has its proved diagonal
atoms. A richer finite qualification includes the base qualification and
has its own instance of propositional separation. These are the two actual
schema inputs. We prove that each base observer has the same proposition
truth profile as some richer observer; this is not a premise.

Applying the result separately to each finite list containing t and the
desired input type transfers quantifier laws and equality guards to every
base world. No observer is assumed to qualify simultaneously at an infinite
list of types. No action premodel or full relation carrier is used.
-/

namespace Classicism.Research.InfinitaryComprehension.EndpointQualificationBridge

open EndpointBootstrap EndpointAtoms

universe u v w z

variable {H : PropCore.{u}} {O : Type u} (A : QuantifiedEndpoints H O)

/-- Inclusion of a stronger finite qualification, together with that
qualification's own propositional separation instance. -/
structure Refinement (Rich : Type v) where
  toBase : Rich → O
  separates : ∀ p q : H.P,
    (∀ F : Rich, A.Accepts (toBase F) p ↔ A.Accepts (toBase F) q) → p = q

namespace Refinement

variable {A} {Rich : Type v} (Q : Refinement A Rich)

theorem nonbottom_has_rich {p : H.P} (hp : p ≠ H.bot) :
    ∃ F : Rich, A.Accepts (Q.toBase F) p := by
  classical
  apply Classical.byContradiction
  intro hn
  apply hp
  apply Q.separates p H.bot
  intro F
  constructor
  · intro h
    exact False.elim (hn ⟨F, h⟩)
  · intro h
    exact False.elim ((A.boolean (Q.toBase F)).rejects_bot h)

/-- A richer observer accepting the base diagonal has exactly the base
observer's truth profile, by the already proved diagonal characterization. -/
theorem observer_profile (E : O) :
    ∃ F : Rich, ∀ p : H.P, A.Accepts E p ↔ A.Accepts (Q.toBase F) p := by
  obtain ⟨F, hF⟩ := Q.nonbottom_has_rich (A.diagonal_atom E).1
  exact ⟨F, (A.diagonal_profile_iff E (Q.toBase F)).1 hF⟩

theorem covers_worlds :
    Function.Surjective (fun F : Rich => A.world (Q.toBase F)) := by
  intro w
  obtain ⟨E, rfl⟩ := A.world_surjective w
  obtain ⟨F, hF⟩ := Q.observer_profile E
  exact ⟨F, ((A.world_eq_iff E (Q.toBase F)).2 hF).symm⟩

/-- Transfer the material universal law extracted from the richer finite
common-representative clause. -/
theorem universal {Arg : Type w} {Pred : Type z}
    (papp : Pred → Arg → H.P) (all : Pred → H.P)
    (rich : ∀ F : Rich, ∀ P : Pred,
      A.Accepts (Q.toBase F) (all P) ↔
        ∀ a, A.Accepts (Q.toBase F) (papp P a)) (E : O) (P : Pred) :
    A.Accepts E (all P) ↔ ∀ a, A.Accepts E (papp P a) := by
  obtain ⟨F, hF⟩ := Q.observer_profile E
  constructor
  · intro h a
    exact (hF (papp P a)).2 ((rich F P).1 ((hF (all P)).1 h) a)
  · intro h
    exact (hF (all P)).2 ((rich F P).2 (fun a => (hF (papp P a)).1 (h a)))

theorem existential {Arg : Type w} {Pred : Type z}
    (papp : Pred → Arg → H.P) (ex : Pred → H.P)
    (rich : ∀ F : Rich, ∀ P : Pred,
      A.Accepts (Q.toBase F) (ex P) ↔
        ∃ a, A.Accepts (Q.toBase F) (papp P a)) (E : O) (P : Pred) :
    A.Accepts E (ex P) ↔ ∃ a, A.Accepts E (papp P a) := by
  obtain ⟨F, hF⟩ := Q.observer_profile E
  constructor
  · intro h
    obtain ⟨a, ha⟩ := (rich F P).1 ((hF (ex P)).1 h)
    exact ⟨a, (hF (papp P a)).2 ha⟩
  · intro h
    obtain ⟨a, ha⟩ := h
    exact (hF (ex P)).2 ((rich F P).2 ⟨a, (hF (papp P a)).1 ha⟩)

theorem equality_reflexivity {Arg : Type w}
    (identity : Arg → Arg → H.P)
    (rich : ∀ F : Rich, ∀ a, A.Accepts (Q.toBase F) (identity a a))
    (E : O) (a : Arg) : A.Accepts E (identity a a) := by
  obtain ⟨F, hF⟩ := Q.observer_profile E
  exact (hF (identity a a)).2 (rich F a)

/-- Only the stated translated Leibniz implication is transported. No
identity-reflection law is introduced as part of observer qualification. -/
theorem equality_leibniz {Arg : Type w} {Pred : Type z}
    (identity : Arg → Arg → H.P) (papp : Pred → Arg → H.P)
    (rich : ∀ F : Rich, ∀ a b P,
      A.Accepts (Q.toBase F) (identity a b) →
      A.Accepts (Q.toBase F) (papp P a) →
      A.Accepts (Q.toBase F) (papp P b))
    (E : O) (a b : Arg) (P : Pred)
    (heq : A.Accepts E (identity a b))
    (ha : A.Accepts E (papp P a)) : A.Accepts E (papp P b) := by
  obtain ⟨F, hF⟩ := Q.observer_profile E
  exact (hF (papp P b)).2
    (rich F a b P ((hF (identity a b)).1 heq) ((hF (papp P a)).1 ha))

end Refinement

#print axioms Refinement.observer_profile
#print axioms Refinement.covers_worlds
#print axioms Refinement.universal
#print axioms Refinement.existential
#print axioms Refinement.equality_reflexivity
#print axioms Refinement.equality_leibniz

end Classicism.Research.InfinitaryComprehension.EndpointQualificationBridge
