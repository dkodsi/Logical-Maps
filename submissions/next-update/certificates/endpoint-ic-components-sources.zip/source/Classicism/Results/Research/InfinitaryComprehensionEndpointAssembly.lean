import Classicism.Results.Research.InfinitaryComprehensionEndpointCanonical
import Classicism.Results.Research.InfinitaryComprehensionEndpointActuality
import Classicism.Results.Research.InfinitaryComprehensionEndpointFullness

/-!
# Assembly and the explicit remaining syntax boundary

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 3--4; misc, 25 October 2026.

This theorem assembles the direct observer interpretation, its actual world,
actual Comprehension and full relational carriers. `MatrixInterpretation`
is the explicit remaining adapter: it must associate each actual infinitary
term/assignment with an admitted raw matrix code and prove evaluation
agreement. That agreement is not proved by defining the structure. In
particular this file must not be advertised as an unconditional certificate
for arbitrary lambda-free H syntax. BinderBridge/SyntaxBridge supply the
nontrivial binder normalization lemma needed to implement the adapter.

The actual Comprehension premise is on the raw admitted codes. Its transfer
to Henkin.Comp is proved below, not included as a field. No faithful or full
Henkin model is an input; both are conclusions. Original-closed-type
grounding remains an additional adapter obligation when auxiliary type
variables are not part of the starting theory.
-/

namespace Classicism.Research.InfinitaryComprehension.EndpointAssembly

open Classicism.Meta EndpointBootstrap EndpointAtoms EndpointCanonical

universe u x

variable (S : TypedOps.{u}) {O : Type u}
variable (A : QuantifiedEndpoints S.core O) (L : A.Infima)
variable (boxObj : S.Dom (RTy.t ⇒ RTy.t))
variable (box_value : ∀ p : S.Dom Ty.t, S.app boxObj p = S.eq p S.core.top)
variable (eq_observed : ∀ {σ : Ty} (a b : S.Dom σ) (E : O),
  A.Accepts E (S.eq a b) ↔ a = b)

/-- The concrete syntax adapter is data with a substantive evaluation law.
This package is not itself a construction of that adapter. -/
structure MatrixInterpretation where
  matrices : ∀ Γ : Ctx,
    MatrixDomain.{u,u,u,x} S.core (S.Env Γ) (S.Dom (RTy.ofArgs Γ)) (S.uncurry Γ)
  code : ∀ {Param : Ty → Type u}
    (η : Henkin.Assignment (model S A L boxObj box_value eq_observed) Param)
    {Γ : Ctx}, Term Param Γ Ty.t → (matrices Γ).Matrix
  code_eval : ∀ {Param : Ty → Type u}
    (η : Henkin.Assignment (model S A L boxObj box_value eq_observed) Param)
    {Γ : Ctx} (p : Term Param Γ Ty.t) (xs : S.Env Γ),
    (matrices Γ).eval (code η p) xs =
      Henkin.eval (model S A L boxObj box_value eq_observed) η p xs

variable (J : MatrixInterpretation.{u,x} S A L boxObj box_value eq_observed)

/-- Exactness is derived from native box, necessitated UI and the already
constructed separating Boolean observer family. -/
theorem rep_exact {Γ : Ctx} (ui : (J.matrices Γ).NecessaryUI)
    {R : S.Dom (RTy.ofArgs Γ)} {p : (J.matrices Γ).Matrix}
    (h : (J.matrices Γ).Rep R p) (xs : S.Env Γ) :
    S.uncurry Γ R xs = (J.matrices Γ).eval p xs := by
  apply A.separation
  intro E
  have ht : A.Accepts E ((J.matrices Γ).all ((J.matrices Γ).agreement R p)) := by
    change (J.matrices Γ).all ((J.matrices Γ).agreement R p) = S.core.top at h
    rw [h]
    exact (A.boolean E).accepts_top
  have hi := (A.le_iff _ _).1 (ui ((J.matrices Γ).agreement R p) xs) E ht
  rw [(J.matrices Γ).eval_agreement] at hi
  exact ((A.boolean E).iff _ _).1 hi

/-- The actual boxed-existential IC formula holds in the constructed model,
by transporting its raw-code representative and interpreting that formula. -/
theorem comprehension_transfer
    (ui : ∀ Γ, (J.matrices Γ).NecessaryUI)
    (comp : ∀ Γ, (J.matrices Γ).Comprehension)
    (w : A.World) :
    Henkin.Comp (model S A L boxObj box_value eq_observed) w := by
  intro Param η Γ p
  apply (Henkin.eval_comprehension_iff
    (model S A L boxObj box_value eq_observed) η p w).2
  obtain ⟨R,hR⟩ := comp Γ (J.code η p)
  refine ⟨R, ?_⟩
  intro xs v
  have he := rep_exact S A L boxObj box_value eq_observed J (ui Γ) hR xs
  have hv := he.trans (J.code_eval η p xs)
  have hu := model_uncurry S A L boxObj box_value eq_observed Γ R xs
  exact Iff.of_eq (congrArg
    (fun z => (model S A L boxObj box_value eq_observed).truth z v)
    (hu.trans hv))

/-- Conditional endpoint with every remaining adapter obligation visible.
The output preserves actual truth and fills every permitted typed carrier. -/
theorem full_standard_representation
    (sep : TypedSeparation S A)
    (truth_inf : ∀ (I : Type u) (f : I → S.core.P),
      S.core.truth (L.inf I f) ↔ ∀ i, S.core.truth (f i))
    (ui : ∀ Γ, (J.matrices Γ).NecessaryUI)
    (comp : ∀ Γ, (J.matrices Γ).Comprehension) :
    ∃ w : A.World,
      (∀ p : S.Dom Ty.t, A.Truth p w ↔ S.truth p) ∧
      EndpointFullness.FullStandard (model S A L boxObj box_value eq_observed) w := by
  obtain ⟨w,hw,_⟩ := EndpointActuality.actual_world_exists_unique A L truth_inf
  refine ⟨w,hw,?_⟩
  exact EndpointFullness.full_standard_of_comprehension
    (model S A L boxObj box_value eq_observed) w S.nonempty_e
    (model_faithful S A L boxObj box_value eq_observed sep)
    (model_worldSeparated S A L boxObj box_value eq_observed)
    (comprehension_transfer S A L boxObj box_value eq_observed J ui comp w)

#print axioms rep_exact
#print axioms comprehension_transfer
#print axioms full_standard_representation

end Classicism.Research.InfinitaryComprehension.EndpointAssembly
