import Classicism.Results.Research.InfinitaryComprehensionEndpointBootstrap

/-!
# Diagonal atoms and infinitary truth for endpoint observers

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 3--4; misc, 25 October 2026, unpaginated.

This is a semantic intermediate theorem, not a new axiom of the object
theory. `QuantifiedEndpoints` displays the precise finite operational input:
Boolean preservation, endpoint range, separation, and preservation of the
admitted diagonal matrix p ↦ (E p → p) under its proposition quantifier.
The diagonal law must be obtained from finite Comprehension and the actual
quantifier qualification in a syntax/model adapter. It is not asserted for
arbitrary external predicate functions.

The conclusions are diagonal atoms, Atomicity, and preservation of every
existing algebraic infinitary meet and join by each observer. Consequently,
infinitary formation with those meet/join laws gives every set of observer
worlds as a proposition. Infinitary relation Comprehension is not used here.
The separate raw-H syntax adapter and relation-domain construction are not
assumed to have been certified by this module.
-/

namespace Classicism.Research.InfinitaryComprehension.EndpointAtoms

open EndpointBootstrap

universe u

structure QuantifiedEndpoints (H : PropCore.{u}) (O : Type u) where
  observe : O → H.P → H.P
  boolean : ∀ E, MaterialBoolean H (observe E)
  endpoint : ∀ E p, observe E p = H.top ∨ observe E p = H.bot
  separation : ∀ p q, (∀ E, H.truth (observe E p) ↔ H.truth (observe E q)) → p = q
  diagonal : O → H.P
  diagonal_law : ∀ E F,
    H.truth (observe F (diagonal E)) ↔
      ∀ p, H.truth (observe F (H.imp (observe E p) p))

namespace QuantifiedEndpoints

variable {H : PropCore.{u}} {O : Type u} (A : QuantifiedEndpoints H O)

def Accepts (E : O) (p : H.P) : Prop := H.truth (A.observe E p)

def Le (_A : QuantifiedEndpoints H O) (p q : H.P) : Prop := H.Box (H.imp p q)

theorem le_iff (p q : H.P) :
    A.Le p q ↔ ∀ E, A.Accepts E p → A.Accepts E q := by
  constructor
  · intro h E hp
    have ht := (A.boolean E).accepts_top
    change H.imp p q = H.top at h
    rw [← h] at ht
    exact ((A.boolean E).imp p q).1 ht hp
  · intro h
    apply A.separation (H.imp p q) H.top
    intro E
    exact ⟨fun _ => (A.boolean E).accepts_top,
      fun _ => ((A.boolean E).imp p q).2 (h E)⟩

theorem fixes_top (E : O) : A.observe E H.top = H.top := by
  cases A.endpoint E H.top with
  | inl h => exact h
  | inr h =>
    have ht := (A.boolean E).accepts_top
    rw [h] at ht
    exact False.elim (H.not_truth_bot ht)

theorem fixes_bot (E : O) : A.observe E H.bot = H.bot := by
  cases A.endpoint E H.bot with
  | inl h =>
    have hn := (A.boolean E).rejects_bot
    rw [h] at hn
    exact False.elim (hn H.truth_top)
  | inr h => exact h

/-- Every qualified observer fixes every other observer's endpoint output. -/
theorem fixes_output (E F : O) (p : H.P) :
    A.observe F (A.observe E p) = A.observe E p := by
  cases A.endpoint E p with
  | inl h => rw [h]; exact A.fixes_top F
  | inr h => rw [h]; exact A.fixes_bot F

theorem diagonal_profile (E F : O) :
    A.Accepts F (A.diagonal E) ↔ ∀ p, A.Accepts E p → A.Accepts F p := by
  rw [Accepts, A.diagonal_law]
  constructor
  · intro h p hp
    have hi := ((A.boolean F).imp _ _).1 (h p)
    rw [A.fixes_output] at hi
    exact hi hp
  · intro h p
    apply ((A.boolean F).imp _ _).2
    rw [A.fixes_output]
    exact h p

theorem diagonal_self (E : O) : A.Accepts E (A.diagonal E) :=
  (A.diagonal_profile E E).2 (fun _ h => h)

/-- Inclusion of Boolean truth sets is equality, using complements. -/
theorem accepts_iff_of_inclusion {E F : O}
    (h : ∀ p, A.Accepts E p → A.Accepts F p) (p : H.P) :
    A.Accepts E p ↔ A.Accepts F p := by
  constructor
  · exact h p
  · intro hf
    by_cases he : A.Accepts E p
    · exact he
    · have hn := h (H.neg p) (((A.boolean E).neg p).2 he)
      exact False.elim (((A.boolean F).neg p).1 hn hf)

theorem diagonal_profile_iff (E F : O) :
    A.Accepts F (A.diagonal E) ↔ ∀ p, A.Accepts E p ↔ A.Accepts F p := by
  constructor
  · intro h
    exact A.accepts_iff_of_inclusion ((A.diagonal_profile E F).1 h)
  · intro h
    exact (A.diagonal_profile E F).2 (fun p => (h p).1)

theorem diagonal_le_iff (E : O) (p : H.P) :
    A.Le (A.diagonal E) p ↔ A.Accepts E p := by
  constructor
  · intro h
    exact (A.le_iff _ _).1 h E (A.diagonal_self E)
  · intro hp
    apply (A.le_iff _ _).2
    intro F hf
    exact (A.diagonal_profile E F).1 hf p hp

def Atom (a : H.P) : Prop :=
  a ≠ H.bot ∧ ∀ p, A.Le a p ∨ A.Le a (H.neg p)

theorem diagonal_atom (E : O) : A.Atom (A.diagonal E) := by
  constructor
  · intro h
    have ha := A.diagonal_self E
    rw [h] at ha
    exact (A.boolean E).rejects_bot ha
  · intro p
    by_cases hp : A.Accepts E p
    · exact Or.inl ((A.diagonal_le_iff E p).2 hp)
    · exact Or.inr ((A.diagonal_le_iff E (H.neg p)).2
        (((A.boolean E).neg p).2 hp))

theorem nonbottom_has_observer {p : H.P} (hp : p ≠ H.bot) :
    ∃ E, A.Accepts E p := by
  classical
  apply Classical.byContradiction
  intro hn
  apply hp
  apply A.separation p H.bot
  intro E
  constructor
  · intro h
    exact False.elim (hn ⟨E,h⟩)
  · intro h
    exact False.elim ((A.boolean E).rejects_bot h)

theorem atomicity {p : H.P} (hp : p ≠ H.bot) :
    ∃ a, A.Atom a ∧ A.Le a p := by
  obtain ⟨E, hE⟩ := A.nonbottom_has_observer hp
  exact ⟨A.diagonal E, A.diagonal_atom E, (A.diagonal_le_iff E p).2 hE⟩

/-- Algebraic infinitary formation, with its greatest-lower-bound law.
This is not relation Comprehension and supplies no relation objects. -/
structure Infima where
  inf : (I : Type u) → (I → H.P) → H.P
  lower : ∀ I f i, A.Le (inf I f) (f i)
  greatest : ∀ I f p, (∀ i, A.Le p (f i)) → A.Le p (inf I f)

/-- The two explicit infinitary logical inputs: box commutes with arbitrary
conjunction, and the globally necessitated classical distribution tautology.
Neither field supplies a relation representative or an atomicity premise. -/
structure Formation where
  inf : (I : Type u) → (I → H.P) → H.P
  box_inf : ∀ I f, H.Box (inf I f) ↔ ∀ i, H.Box (f i)
  implication_inf : ∀ I f p,
    H.Box (H.iff (H.imp p (inf I f)) (inf I (fun i => H.imp p (f i))))

theorem intensionality (A : QuantifiedEndpoints H O)
    {p q : H.P} (h : H.Box (H.iff p q)) : p = q := by
  apply A.separation p q
  intro E
  have ht := (A.boolean E).accepts_top
  change H.iff p q = H.top at h
  rw [← h] at ht
  exact ((A.boolean E).iff p q).1 ht

theorem le_inf_iff (F : Formation (H := H)) (I : Type u) (f : I → H.P) (p : H.P) :
    A.Le p (F.inf I f) ↔ ∀ i, A.Le p (f i) := by
  have hi := A.intensionality (F.implication_inf I f p)
  change H.Box (H.imp p (F.inf I f)) ↔ ∀ i, H.Box (H.imp p (f i))
  rw [hi]
  exact F.box_inf I (fun i => H.imp p (f i))

/-- The algebraic meet property is derived from formation's logical laws. -/
def infima_of_formation (F : Formation (H := H)) : A.Infima where
  inf := F.inf
  lower I f i := (A.le_inf_iff F I f (F.inf I f)).1
    ((A.le_iff _ _).2 (fun _ h => h)) i
  greatest I f p := (A.le_inf_iff F I f p).2

variable (L : A.Infima)

/-- Completeness of each observer is proved from its diagonal atom. -/
theorem accepts_inf (I : Type u) (f : I → H.P) (E : O) :
    A.Accepts E (L.inf I f) ↔ ∀ i, A.Accepts E (f i) := by
  constructor
  · intro h i
    exact (A.le_iff _ _).1 (L.lower I f i) E h
  · intro h
    apply (A.diagonal_le_iff E _).1
    exact L.greatest I f (A.diagonal E)
      (fun i => (A.diagonal_le_iff E (f i)).2 (h i))

def Sup (I : Type u) (f : I → H.P) : H.P :=
  H.neg (L.inf I (fun i => H.neg (f i)))

theorem accepts_sup (I : Type u) (f : I → H.P) (E : O) :
    A.Accepts E (A.Sup L I f) ↔ ∃ i, A.Accepts E (f i) := by
  classical
  change H.truth (A.observe E (H.neg _)) ↔ _
  rw [(A.boolean E).neg]
  change (¬ A.Accepts E (L.inf I (fun i => H.neg (f i)))) ↔ _
  rw [A.accepts_inf L]
  constructor
  · intro h
    apply Classical.byContradiction
    intro hn
    apply h
    intro i
    apply ((A.boolean E).neg _).2
    intro hi
    exact hn ⟨i,hi⟩
  · intro h hn
    obtain ⟨i,hi⟩ := h
    exact ((A.boolean E).neg _).1 (hn i) hi

/-- Worlds are the distinct observer truth profiles; duplicate observers
do not produce duplicate worlds. -/
def World := {f : H.P → Prop // ∃ E : O, f = A.Accepts E}

def world (E : O) : A.World := ⟨A.Accepts E, E, rfl⟩

def Truth (p : H.P) (w : A.World) : Prop := w.val p

theorem world_surjective (w : A.World) : ∃ E, A.world E = w := by
  obtain ⟨E,hE⟩ := w.property
  exact ⟨E, Subtype.ext hE.symm⟩

theorem world_eq_iff (E F : O) :
    A.world E = A.world F ↔ ∀ p, A.Accepts E p ↔ A.Accepts F p := by
  constructor
  · intro h p
    exact Iff.of_eq (congrFun (congrArg Subtype.val h) p)
  · intro h
    apply Subtype.ext
    funext p
    exact propext (h p)

theorem world_nonempty : Nonempty A.World := by
  obtain ⟨E,_⟩ := A.nonbottom_has_observer H.top_ne_bot
  exact ⟨A.world E⟩

theorem faithful (p q : H.P)
    (h : ∀ w, A.Truth p w ↔ A.Truth q w) : p = q :=
  A.separation p q (fun E => h (A.world E))

/-- Infinitary formation already fills the proposition carrier. -/
theorem full_propositions (L : A.Infima) (U : A.World → Prop) :
    ∃ p : H.P, (∀ w, A.Truth p w ↔ U w) ∧
      ∀ q : H.P, (∀ w, A.Truth q w ↔ U w) → q = p := by
  let I := {E : O // U (A.world E)}
  let p := A.Sup L I (fun E => A.diagonal E.val)
  have hp : ∀ w, A.Truth p w ↔ U w := by
    intro w
    obtain ⟨F,rfl⟩ := A.world_surjective w
    change A.Accepts F p ↔ U (A.world F)
    rw [A.accepts_sup L]
    constructor
    · intro h
      obtain ⟨E,hE⟩ := h
      have hw := (A.world_eq_iff E.val F).2 ((A.diagonal_profile_iff E.val F).1 hE)
      exact hw ▸ E.property
    · intro hF
      exact ⟨⟨F,hF⟩, A.diagonal_self F⟩
  refine ⟨p,hp,?_⟩
  intro q hq
  exact A.faithful q p (fun w => (hq w).trans (hp w).symm)

#print axioms fixes_output
#print axioms diagonal_atom
#print axioms atomicity
#print axioms infima_of_formation
#print axioms accepts_inf
#print axioms full_propositions

end QuantifiedEndpoints

end Classicism.Research.InfinitaryComprehension.EndpointAtoms
