import Classicism.Results.Research.InfinitaryComprehensionEndpointAtoms
import Classicism.Results.Research.InfinitaryComprehensionSupport

/-!
# The canonical observer interpretation on the original typed carriers

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 3--4; misc, 25 October 2026.

The raw typed operations below have only current H truth clauses. They do
not include worlds, intensional faithfulness, full function carriers, or a
constant-domain modal interpretation. Worlds are constructed as the distinct
profiles of the already derived endpoint observers. Their Boolean and
infinitary truth clauses come from the proved diagonal-atom results.

The remaining inputs are explicit upstream conclusions: the equality
bridge's observed identity law, a finite-IC representative of native box,
and the full typed endpoint-separation instances. They must be supplied by
the raw syntax/axiom adapter, not presumed to follow from the raw operations.
This file derives the Henkin interpretation, faithfulness and world
separation. It does not assert the designated-current-world or IC transfer
lemmas, which must relate this interpretation to the raw syntax separately.
-/

namespace Classicism.Research.InfinitaryComprehension.EndpointCanonical

open Classicism.Meta EndpointBootstrap EndpointAtoms

universe u

/-- Raw typed H operations; equality is literal at the current evaluation
point, without a modal rigidity premise. -/
structure TypedOps where
  Dom : Ty → Type u
  app : ∀ {σ : Ty} {ρ : RTy}, Dom (σ ⇒ ρ) → Dom σ → Dom ρ
  truth : Dom Ty.t → Prop
  seed : Dom Ty.t
  neg : Dom Ty.t → Dom Ty.t
  conj : Dom Ty.t → Dom Ty.t → Dom Ty.t
  disj : Dom Ty.t → Dom Ty.t → Dom Ty.t
  truth_neg : ∀ p, truth (neg p) ↔ ¬ truth p
  truth_conj : ∀ p q, truth (conj p q) ↔ truth p ∧ truth q
  truth_disj : ∀ p q, truth (disj p q) ↔ truth p ∨ truth q
  eq : ∀ {σ : Ty}, Dom σ → Dom σ → Dom Ty.t
  truth_eq : ∀ {σ : Ty} (a b : Dom σ), truth (eq a b) ↔ a = b
  nonempty_e : Nonempty (Dom Ty.e)

namespace TypedOps

variable (S : TypedOps.{u})

def core : PropCore.{u} where
  P := S.Dom Ty.t
  truth := S.truth
  seed := S.seed
  neg := S.neg
  conj := S.conj
  disj := S.disj
  truth_neg := S.truth_neg
  truth_conj := S.truth_conj
  truth_disj := S.truth_disj

abbrev Env (Γ : Ctx) := ∀ {σ : Ty}, Var Γ σ → S.Dom σ

def uncurry : (Γ : Ctx) → S.Dom (RTy.ofArgs Γ) → S.Env Γ → S.Dom Ty.t
  | [], R, _ => R
  | _ :: Γ, R, xs => uncurry Γ (S.app R (xs .zero)) (fun v => xs (.succ v))

end TypedOps

variable (S : TypedOps.{u}) {O : Type u}
variable (A : QuantifiedEndpoints S.core O) (L : A.Infima)

/-- The original full typed separation schema, on finite argument tuples.
Its observer class is the selected t-qualified class. -/
def TypedSeparation : Prop :=
  ∀ (Γ : Ctx) (R T : S.Dom (RTy.ofArgs Γ)),
    (∀ E : O, ∀ xs : S.Env Γ,
      A.Accepts E (S.uncurry Γ R xs) ↔ A.Accepts E (S.uncurry Γ T xs)) → R = T

theorem box_iff_all_worlds (p : S.Dom Ty.t) :
    S.core.Box p ↔ ∀ w : A.World, A.Truth p w := by
  constructor
  · intro hp w
    obtain ⟨E, rfl⟩ := A.world_surjective w
    change A.Accepts E p
    change p = S.core.top at hp
    rw [hp]
    exact (A.boolean E).accepts_top
  · intro hp
    apply A.separation p S.core.top
    intro E
    exact ⟨fun _ => (A.boolean E).accepts_top, fun _ => hp (A.world E)⟩

variable (boxObj : S.Dom (RTy.t ⇒ RTy.t))
variable (box_value : ∀ p : S.Dom Ty.t, S.app boxObj p = S.eq p S.core.top)
variable (eq_observed : ∀ {σ : Ty} (a b : S.Dom σ) (E : O),
  A.Accepts E (S.eq a b) ↔ a = b)

/-- Construct the fixed-domain observer interpretation, keeping every raw
typed carrier. Neither Henkin faithfulness nor fullness is assumed. -/
def model : Henkin.Model.{u} where
  Dom := S.Dom
  World := A.World
  truth := A.Truth
  app := S.app
  top := S.core.top
  bot := S.core.bot
  neg := S.neg
  conj := S.conj
  disj := S.disj
  imp := S.core.imp
  iff := S.core.iff
  eq := S.eq
  boxObj := boxObj
  iAnd := L.inf
  iOr := A.Sup L
  top_spec w := by
    obtain ⟨E, rfl⟩ := A.world_surjective w
    exact (A.boolean E).accepts_top
  bot_spec w := by
    obtain ⟨E, rfl⟩ := A.world_surjective w
    exact (A.boolean E).rejects_bot
  neg_spec p w := by
    obtain ⟨E, rfl⟩ := A.world_surjective w
    exact (A.boolean E).neg p
  conj_spec p q w := by
    obtain ⟨E, rfl⟩ := A.world_surjective w
    exact (A.boolean E).conj p q
  disj_spec p q w := by
    obtain ⟨E, rfl⟩ := A.world_surjective w
    exact (A.boolean E).disj p q
  imp_spec p q w := by
    obtain ⟨E, rfl⟩ := A.world_surjective w
    exact (A.boolean E).imp p q
  iff_spec p q w := by
    obtain ⟨E, rfl⟩ := A.world_surjective w
    exact (A.boolean E).iff p q
  eq_spec a b w := by
    obtain ⟨E, rfl⟩ := A.world_surjective w
    exact eq_observed a b E
  box_spec p w := by
    obtain ⟨E, rfl⟩ := A.world_surjective w
    change A.Accepts E (S.app boxObj p) ↔ ∀ v : A.World, A.Truth p v
    rw [box_value p, eq_observed p S.core.top E]
    exact box_iff_all_worlds S A p
  iAnd_spec I f w := by
    obtain ⟨E, rfl⟩ := A.world_surjective w
    exact A.accepts_inf L I f E
  iOr_spec I f w := by
    obtain ⟨E, rfl⟩ := A.world_surjective w
    exact A.accepts_sup L I f E

theorem model_domain (σ : Ty) :
    (model S A L boxObj box_value eq_observed).Dom σ = S.Dom σ := rfl

theorem model_uncurry : ∀ (Γ : Ctx) (R : S.Dom (RTy.ofArgs Γ)) (xs : S.Env Γ),
    Henkin.uncurry (model S A L boxObj box_value eq_observed) Γ R xs =
      S.uncurry Γ R xs := by
  intro Γ
  induction Γ with
  | nil => intros; rfl
  | cons σ Γ ih =>
    intro R xs
    exact ih (S.app R (xs .zero)) (fun v => xs (.succ v))

theorem model_faithful (sep : TypedSeparation S A) :
    Henkin.Faithful (model S A L boxObj box_value eq_observed) := by
  intro Γ R T h
  apply sep Γ R T
  intro E xs
  have hh := h xs (A.world E)
  change A.Accepts E
    (Henkin.uncurry (model S A L boxObj box_value eq_observed) Γ R xs) ↔
      A.Accepts E
        (Henkin.uncurry (model S A L boxObj box_value eq_observed) Γ T xs) at hh
  have hr := congrArg (A.Accepts E)
    (model_uncurry S A L boxObj box_value eq_observed Γ R xs)
  have ht := congrArg (A.Accepts E)
    (model_uncurry S A L boxObj box_value eq_observed Γ T xs)
  exact ⟨fun hR => Eq.mp ht (hh.mp (Eq.mpr hr hR)),
    fun hT => Eq.mp hr (hh.mpr (Eq.mpr ht hT))⟩

/-- Canonical worlds are distinguished by diagonal propositions. -/
theorem model_worldSeparated :
    Henkin.WorldSeparated (model S A L boxObj box_value eq_observed) := by
  intro w v hne
  obtain ⟨E, rfl⟩ := A.world_surjective w
  obtain ⟨F, rfl⟩ := A.world_surjective v
  refine ⟨A.diagonal E, A.diagonal_self E, ?_⟩
  intro hF
  exact hne ((A.world_eq_iff E F).2 ((A.diagonal_profile_iff E F).1 hF))

theorem model_nonempty_e :
    Nonempty ((model S A L boxObj box_value eq_observed).Dom Ty.e) := S.nonempty_e

#print axioms box_iff_all_worlds
#print axioms model
#print axioms model_domain
#print axioms model_faithful
#print axioms model_worldSeparated

end Classicism.Research.InfinitaryComprehension.EndpointCanonical
