import Classicism.Results.Research.InfinitaryComprehensionEndpointBootstrap

/-!
# Endpoint-valued separation implies propositional necessary distinctness

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 1--3; misc, 25 October 2026,
unpaginated.

This is ordinary metatheory over the nonextensional proposition carrier of
`EndpointBootstrap`. It does not assume C, K, Intensionality, or NI. Besides
the endpoint separation instance, its inputs are the retained translated
equality substitution guard at type t and the globally necessitated ordinary
H theorem of equality symmetry. No local premise is necessitated.

The argument uses the endpoint restriction essentially: every eligible
observer agrees with current truth on the two output endpoints. If any
eligible observer accepted p=q, its equality guards would force all eligible
observers to agree on p and q. Separation would identify p and q. Therefore
when p and q are distinct, every eligible observer accepts their inequality;
separation from top makes that inequality necessary.

As with the bootstrap module, a concrete syntax/model adapter must supply
the explicitly named H theorem and guard inputs. This module does not claim
that adapter or the subsequent boxed-ND/constant-domain construction.
-/

namespace Classicism.Research.InfinitaryComprehension.EndpointDistinctness

open EndpointBootstrap

universe u v w x y

variable {H : PropCore.{u}}

/-- An ordinary equality proposition with its actual truth clause and the
one globally necessitated H theorem used below. The identity proposition
need not be a constant endpoint. -/
structure PropositionalEquality (H : PropCore.{u}) where
  eq : H.P → H.P → H.P
  truth_eq : ∀ p q, H.truth (eq p q) ↔ p = q
  necessary_symmetry : ∀ p q, H.Box (H.imp (eq p q) (eq q p))

theorem accepts_box {D : H.P → H.P} (hD : MaterialBoolean H D)
    {p : H.P} (hp : H.Box p) : H.truth (D p) := by
  change p = H.top at hp
  rw [hp]
  exact hD.accepts_top

/-- Every Boolean-qualified observer reflects the current truth of either
endpoint. No statement about arbitrary propositions is made here. -/
theorem endpoint_reflect {D : H.P → H.P} (hD : MaterialBoolean H D)
    {p : H.P} (hp : p = H.top ∨ p = H.bot) :
    H.truth (D p) ↔ H.truth p := by
  cases hp with
  | inl hp =>
      rw [hp]
      exact ⟨fun _ => H.truth_top, fun _ => hD.accepts_top⟩
  | inr hp =>
      rw [hp]
      exact ⟨fun h => False.elim (hD.rejects_bot h),
        fun h => False.elim (H.not_truth_bot h)⟩

variable {Obs : Type v} {observe : Obs → H.P → H.P}
variable {B : BooleanPresentation.{u,v,w,x,y} H Obs observe} {Q : Obs → Prop}

/-- The t-instance of the original translated equality substitution guard.
Its predicate F ranges over all admitted tt objects, not only observers
which themselves meet the qualification. -/
def EqualityGuard (EqP : PropositionalEquality H) : Prop :=
  ∀ D : Obs, Q D → B.GoodBoolean D → ∀ (F : Obs) (p q : H.P),
    H.truth (observe D (EqP.eq p q)) →
    H.truth (observe D (observe F p)) → H.truth (observe D (observe F q))

/-- Endpoint-valued logical separation proves the unboxed ND_t schema.
The conclusion is necessary inequality for arbitrary p and q; it is not
yet the necessity of the universally closed ND_t schema. -/
theorem endpoint_necessary_distinctness (EqP : PropositionalEquality H)
    (sep : PropSeparation B Q)
    (ends : ∀ E, Q E → B.GoodBoolean E → EndpointValued observe E)
    (guard : EqualityGuard (B := B) (Q := Q) EqP)
    {p q : H.P} (hpq : p ≠ q) : H.Box (H.neg (EqP.eq p q)) := by
  apply sep (H.neg (EqP.eq p q)) H.top
  intro D hQD hBD
  have hD := B.material hBD
  have hnot : ¬ H.truth (observe D (EqP.eq p q)) := by
    intro hDEq
    apply hpq
    apply sep p q
    intro E hQE hBE
    have hsymm : H.truth (observe D (EqP.eq q p)) :=
      (hD.imp _ _).1 (accepts_box hD (EqP.necessary_symmetry p q)) hDEq
    have hforward := guard D hQD hBD E p q hDEq
    have hreverse := guard D hQD hBD E q p hsymm
    have hp := endpoint_reflect hD (ends E hQE hBE p)
    have hq := endpoint_reflect hD (ends E hQE hBE q)
    exact ⟨fun h => hq.1 (hforward (hp.2 h)),
      fun h => hp.1 (hreverse (hq.2 h))⟩
  exact ⟨fun _ => hD.accepts_top, fun _ => (hD.neg _).2 hnot⟩

#print axioms endpoint_reflect
#print axioms endpoint_necessary_distinctness

end Classicism.Research.InfinitaryComprehension.EndpointDistinctness
