import Classicism.Results.Research.InfinitaryComprehensionHOriginalTheorem
import Classicism.Results.Research.InfinitaryComprehensionHStandard
import Classicism.Results.Research.InfinitaryComprehensionHEndpointLanguage

/-!
Combined audit of the full native, original-type H endpoint theorem.
Direct source: research/2026-10-23/infinitary-comprehension/endpoint-development.md,
sections 1--5, misc, 26 October 2026, unpaginated.
No statement here adds a premise or supplies an admitted proof.
-/

open Classicism.Research.InfinitaryComprehension

#check HOriginalTheorem.full_standard_representation
#check HOriginalTheorem.original_carriers_preserved
#check HOriginalTheorem.original_syntax_interpretation
#check HStandard.full_standard_satisfies

#print axioms HLanguage.Term.subst_compBody
#print axioms HLanguage.Term.instantiate_repBody
#print axioms HModel.Model.eval_rename
#print axioms HModel.Model.native_top
#print axioms HBootstrap.truth_comprehension
#print axioms HBootstrap.truth_same
#print axioms HBootstrap.ui
#print axioms HBootstrap.all_congruence
#print axioms HBootstrap.ex_congruence
#print axioms HBootstrap.boxRepresentative_exists
#print axioms HEndpoint.observers
#print axioms HEndpoint.observed_equality
#print axioms HEndpoint.box_inf
#print axioms HEndpoint.all_value
#print axioms HEndpoint.ex_value
#print axioms HEndpoint.typed_separation
#print axioms HEndpointLanguage.truth_endpointFormula
#print axioms HEndpointLanguage.truth_reflexivityFormula
#print axioms HEndpointLanguage.truth_leibnizFormula
#print axioms HEndpointLanguage.endpointOS_biconditional
#print axioms HInterpretation.eval_compatible
#print axioms HInterpretation.interpretation
#print axioms HTheorem.full_standard_representation
#print axioms HTheorem.native_syntax_interpretation
#print axioms HOriginalModel.ground_logicalAxiom
#print axioms HOriginalModel.Model.toModel
#print axioms HOriginalICGrounding.groundTerm_comprehension
#print axioms HOriginalICGrounding.groundTerm_same
#print axioms HOriginalICGrounding.comprehension_lift
#print axioms HOriginalEndpoint.toModel_endpointOS
#print axioms HOriginalRetraction.original_term_retract
#print axioms HOriginalRetraction.eval_original_formula
#print axioms HOriginalTheorem.full_standard_representation
#print axioms HOriginalTheorem.original_carriers_preserved
#print axioms HOriginalTheorem.grounded_syntax_interpretation
#print axioms HOriginalTheorem.original_syntax_interpretation
#print axioms HStandard.logical_valid
#print axioms HStandard.model
#print axioms HStandard.comprehension
#print axioms HStandard.endpointOS
#print axioms HStandard.full_standard_satisfies
