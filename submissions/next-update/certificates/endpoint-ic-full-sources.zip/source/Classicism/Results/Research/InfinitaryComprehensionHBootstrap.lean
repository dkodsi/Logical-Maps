import Classicism.Results.Research.InfinitaryComprehensionHModel
import Classicism.Results.Research.InfinitaryComprehensionEndpointDiagonalBridge
import Classicism.Results.Research.InfinitaryComprehensionEndpointBinderBridge

/-!
# Concrete native-H matrices and finite observer operations

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 1--4; misc, 26 October 2026,
unpaginated.

All matrix carriers in this module are actual native lambda-free syntax.
The comprehension and common-representative interfaces are extracted from
the current truth of their displayed object-language formulas. Necessary UI
and binder congruence are instances of the explicitly necessitated ordinary
logical schemas of HModel; no K, Intensionality or ND is assumed here.
-/

namespace Classicism.Research.InfinitaryComprehension.HBootstrap

open Classicism.Meta HLanguage EndpointCanonical EndpointBootstrap
open EndpointDiagonalBridge EndpointBinderBridge

universe u

variable {S : TypedOps.{u}} (M : HModel.Model S)

theorem eval_instantiate {Γ σ τ} (p : HLanguage.Term S.Dom (σ :: Γ) τ)
    (a : S.Dom σ) (xs : HLanguage.Env S.Dom Γ) :
    M.eval (p.instantiate (.param a)) xs = M.eval p (HLanguage.Env.cons a xs) := by
  rw [HLanguage.Term.instantiate, M.eval_subst]
  congr 1
  funext ρ v
  cases v with
  | zero => exact M.eval_param a xs
  | succ v => exact M.eval_var v xs

theorem eval_applyVars {Δ : Ctx} (Γ : Ctx)
    (R : HLanguage.Term S.Dom Δ (RTy.ofArgs Γ))
    (args : ∀ {σ}, Var Γ σ → HLanguage.Term S.Dom Δ σ) (xs : HLanguage.Env S.Dom Δ) :
    M.eval (HLanguage.Term.applyVars Γ R args) xs =
      S.uncurry Γ (M.eval R xs) (fun v => M.eval (args v) xs) := by
  induction Γ with
  | nil => rfl
  | cons σ Γ ih =>
      change M.eval (HLanguage.Term.applyVars Γ (.app R (args .zero))
        (fun v => args (.succ v))) xs = _
      rw [ih, M.eval_app]
      rfl

theorem truth_closeAll {Δ : Ctx} (Γ : Ctx)
    (A : HLanguage.Formula S.Dom (Γ ++ Δ)) (ys : HLanguage.Env S.Dom Δ) :
    S.truth (M.eval (HLanguage.Term.closeAll Γ A) ys) ↔
      ∀ xs : HLanguage.Env S.Dom Γ, S.truth (M.eval A (HLanguage.Env.append xs ys)) := by
  induction Γ with
  | nil =>
      constructor
      · intro h xs
        exact h
      · intro h
        exact h HLanguage.Env.nil
  | cons σ Γ ih =>
      change S.truth (M.eval (HLanguage.Term.closeAll Γ (.all A)) ys) ↔ _
      rw [ih]
      constructor
      · intro h xs
        have hh := (M.truth_all A (HLanguage.Env.append (HLanguage.Env.tail xs) ys)).mp
          (h (HLanguage.Env.tail xs)) (xs .zero)
        exact hh
      · intro h xs
        apply (M.truth_all A (HLanguage.Env.append xs ys)).mpr
        intro a
        exact h (HLanguage.Env.cons a xs)

theorem truth_universalClosure {Γ : Ctx} (A : HLanguage.Formula S.Dom Γ) :
    S.truth (M.eval A.universalClosure HLanguage.Env.nil) ↔
      ∀ xs : HLanguage.Env S.Dom Γ, S.truth (M.eval A xs) := by
  rw [HLanguage.Term.universalClosure, truth_closeAll]
  apply forall_congr'
  intro xs
  rw [M.eval_rename]
  have he : (fun {σ} (v : Var Γ σ) =>
      HLanguage.Env.append xs HLanguage.Env.nil (HLanguage.Ren.embed Γ [] v) :
        HLanguage.Env S.Dom Γ) = @xs := by
    funext σ v
    exact HLanguage.Env.append_embed xs HLanguage.Env.nil v
  rw [he]

/-- Every finite argument matrix is an actual H formula. -/
def matrices (Γ : Ctx) :
    MatrixDomain S.core (HLanguage.Env S.Dom Γ) (S.Dom (RTy.ofArgs Γ)) (S.uncurry Γ) where
  Matrix := HLanguage.Formula S.Dom Γ
  eval := M.eval
  all A := M.eval A.universalClosure HLanguage.Env.nil
  truth_all := truth_universalClosure M
  agreement R A := .iff (HLanguage.Term.applyVars Γ (.param R) (fun v => .var v)) A
  eval_agreement R A xs := by
    rw [M.eval_iff, eval_applyVars, M.eval_param]
    have he : (fun {σ} (v : Var Γ σ) => M.eval (.var v) xs :
        HLanguage.Env S.Dom Γ) = @xs := by
      funext σ v
      exact M.eval_var v xs
    rw [he]

theorem ui (Γ : Ctx) : (matrices M Γ).NecessaryUI := by
  change ∀ (A : HLanguage.Formula S.Dom Γ) (xs : HLanguage.Env S.Dom Γ),
    S.core.Box (S.core.imp (M.eval A.universalClosure HLanguage.Env.nil) (M.eval A xs))
  intro A xs
  have h := M.necessary_logical
    (HModel.LogicalAxiom.universalInstantiation A (fun v => .param (xs v)))
  rw [M.eval_imp, M.eval_closed_subst] at h
  exact h

/-- A literal representative formula states the old semantic Rep relation. -/
theorem truth_repFormula {Γ : Ctx} (R : S.Dom (RTy.ofArgs Γ))
    (A : HLanguage.Formula S.Dom Γ) :
    S.truth (M.eval (HLanguage.Term.repFormula R A) HLanguage.Env.nil) ↔
      (matrices M Γ).Rep R A := by
  exact M.truth_box _ HLanguage.Env.nil

theorem truth_repBody {Γ : Ctx} (A : HLanguage.Formula S.Dom Γ)
    (R : S.Dom (RTy.ofArgs Γ)) :
    S.truth (M.eval A.repBody (HLanguage.Env.cons R HLanguage.Env.nil)) ↔
      (matrices M Γ).Rep R A := by
  rw [← eval_instantiate M A.repBody R HLanguage.Env.nil, HLanguage.Term.instantiate_repBody]
  exact truth_repFormula M R A

theorem truth_comprehension {Γ : Ctx} (A : HLanguage.Formula S.Dom Γ) :
    S.truth (M.eval A.comprehension HLanguage.Env.nil) ↔
      ∃ R, (matrices M Γ).Rep R A := by
  rw [HLanguage.Term.comprehension, M.truth_ex]
  apply exists_congr
  intro R
  exact truth_repBody M A R

theorem comprehension (hIC : M.Comprehension) (Γ : Ctx) :
    (matrices M Γ).Comprehension := by
  intro A
  exact (truth_comprehension M A).mp (hIC A)

theorem truth_same {Γ : Ctx} (A B : HLanguage.Formula S.Dom Γ) :
    S.truth (M.eval (HLanguage.Term.sameFormula A B) HLanguage.Env.nil) ↔
      (matrices M Γ).Same A B := by
  rw [HLanguage.Term.sameFormula, M.truth_ex]
  apply exists_congr
  intro R
  rw [M.eval_conj, S.truth_conj, truth_repBody, truth_repBody]

/-- Unary admitted codes, retaining their original typed predicate carrier. -/
def unary (σ : Ty) :
    MatrixDomain S.core (S.Dom σ) (S.Dom (σ ⇒ RTy.t)) S.app where
  Matrix := HLanguage.Formula S.Dom [σ]
  eval A x := M.eval A (HLanguage.Env.cons x HLanguage.Env.nil)
  all := (matrices M [σ]).all
  truth_all A := by
    change S.truth (M.eval A.universalClosure HLanguage.Env.nil) ↔
      ∀ x : S.Dom σ, S.truth (M.eval A (HLanguage.Env.cons x HLanguage.Env.nil))
    rw [truth_universalClosure M A]
    constructor
    · intro h x
      exact h (HLanguage.Env.cons x HLanguage.Env.nil)
    · intro h xs
      have he : (HLanguage.Env.cons (xs .zero) HLanguage.Env.nil :
          HLanguage.Env S.Dom [σ]) = @xs := by
        funext τ v
        cases v with
        | zero => rfl
        | succ v => nomatch v
      rw [← he]
      exact h (xs .zero)
  agreement := (matrices M [σ]).agreement
  eval_agreement R A x := (matrices M [σ]).eval_agreement R A (HLanguage.Env.cons x HLanguage.Env.nil)

theorem unary_ui (σ : Ty) : (unary M σ).NecessaryUI := by
  intro A x
  exact ui M [σ] A (HLanguage.Env.cons x HLanguage.Env.nil)

theorem unary_comprehension (hIC : M.Comprehension) (σ : Ty) :
    (unary M σ).Comprehension := comprehension M hIC [σ]

theorem truth_unary_same {σ : Ty} (A B : HLanguage.Formula S.Dom [σ]) :
    S.truth (M.eval (HLanguage.Term.sameFormula A B) HLanguage.Env.nil) ↔
      (unary M σ).Same A B := truth_same M A B

/-- Two proposition variables are a finite argument spine, not a new type. -/
def binary : MatrixDomain S.core (S.Dom Ty.t × S.Dom Ty.t)
    (S.Dom (Ty.t ⇒ Ty.t ⇒ RTy.t))
    (fun R pq => S.app (S.app R pq.1) pq.2) where
  Matrix := HLanguage.Formula S.Dom [Ty.t, Ty.t]
  eval A pq := M.eval A (HLanguage.Env.cons pq.1 (HLanguage.Env.cons pq.2 HLanguage.Env.nil))
  all := (matrices M [Ty.t, Ty.t]).all
  truth_all A := by
    change S.truth (M.eval A.universalClosure HLanguage.Env.nil) ↔
      ∀ pq : S.Dom Ty.t × S.Dom Ty.t,
        S.truth (M.eval A (HLanguage.Env.cons pq.1 (HLanguage.Env.cons pq.2 HLanguage.Env.nil)))
    rw [truth_universalClosure M A]
    constructor
    · intro h pq
      exact h (HLanguage.Env.cons pq.1 (HLanguage.Env.cons pq.2 HLanguage.Env.nil))
    · intro h xs
      have he : (HLanguage.Env.cons (xs .zero)
          (HLanguage.Env.cons (xs (.succ .zero)) HLanguage.Env.nil) :
          HLanguage.Env S.Dom [Ty.t, Ty.t]) = @xs := by
        funext τ v
        cases v with
        | zero => rfl
        | succ v =>
            cases v with
            | zero => rfl
            | succ v => nomatch v
      rw [← he]
      exact h (xs .zero, xs (.succ .zero))
  agreement := (matrices M [Ty.t, Ty.t]).agreement
  eval_agreement R A pq := (matrices M [Ty.t, Ty.t]).eval_agreement R A
    (HLanguage.Env.cons pq.1 (HLanguage.Env.cons pq.2 HLanguage.Env.nil))

theorem truth_binary_same (A B : HLanguage.Formula S.Dom [Ty.t, Ty.t]) :
    S.truth (M.eval (HLanguage.Term.sameFormula A B) HLanguage.Env.nil) ↔
      (binary M).Same A B := truth_same M A B

abbrev Observer := S.Dom (Ty.t ⇒ RTy.t)

/-- The qualification consists of six finite, literal operation codes. -/
def booleans : BooleanPresentation S.core (Observer (S := S)) S.app where
  Binary := S.Dom (Ty.t ⇒ Ty.t ⇒ RTy.t)
  binaryApp R pq := S.app (S.app R pq.1) pq.2
  unary := unary M Ty.t
  binary := binary M
  negLeft E := .app (.param E) (.neg (.var .zero))
  negRight E := .neg (.app (.param E) (.var .zero))
  conjLeft E := .app (.param E) (.conj (.var .zero) (.var (.succ .zero)))
  conjRight E := .conj (.app (.param E) (.var .zero))
    (.app (.param E) (.var (.succ .zero)))
  disjLeft E := .app (.param E) (.disj (.var .zero) (.var (.succ .zero)))
  disjRight E := .disj (.app (.param E) (.var .zero))
    (.app (.param E) (.var (.succ .zero)))
  eval_negLeft E p := by
    exact (M.eval_app _ _ _).trans (by rw [M.eval_param, M.eval_neg, M.eval_var]; rfl)
  eval_negRight E p := by
    exact (M.eval_neg _ _).trans (by rw [M.eval_app, M.eval_param, M.eval_var]; rfl)
  eval_conjLeft E p q := by
    exact (M.eval_app _ _ _).trans
      (by rw [M.eval_param, M.eval_conj, M.eval_var, M.eval_var]; rfl)
  eval_conjRight E p q := by
    exact (M.eval_conj _ _ _).trans
      (by rw [M.eval_app, M.eval_app, M.eval_param, M.eval_var, M.eval_var]; rfl)
  eval_disjLeft E p q := by
    exact (M.eval_app _ _ _).trans
      (by rw [M.eval_param, M.eval_disj, M.eval_var, M.eval_var]; rfl)
  eval_disjRight E p q := by
    exact (M.eval_disj _ _ _).trans
      (by rw [M.eval_app, M.eval_app, M.eval_param, M.eval_var, M.eval_var]; rfl)

def allOperation (σ : Ty) (R : S.Dom (σ ⇒ RTy.t)) : S.Dom Ty.t :=
  M.eval (.all (.app (.param R) (.var .zero))) HLanguage.Env.nil

def exOperation (σ : Ty) (R : S.Dom (σ ⇒ RTy.t)) : S.Dom Ty.t :=
  M.eval (.ex (.app (.param R) (.var .zero))) HLanguage.Env.nil

def exBinder (σ : Ty) (A : (unary M σ).Matrix) : S.Dom Ty.t :=
  M.eval (.ex A) HLanguage.Env.nil

def allLeft (_M : HModel.Model S) (σ : Ty) (E : Observer (S := S)) : HLanguage.Formula S.Dom [σ ⇒ RTy.t] :=
  .app (.param E) (.all (.app (.var (.succ .zero)) (.var .zero)))

def allRight (_M : HModel.Model S) (σ : Ty) (E : Observer (S := S)) : HLanguage.Formula S.Dom [σ ⇒ RTy.t] :=
  .all (.app (.param E) (.app (.var (.succ .zero)) (.var .zero)))

def exLeft (_M : HModel.Model S) (σ : Ty) (E : Observer (S := S)) : HLanguage.Formula S.Dom [σ ⇒ RTy.t] :=
  .app (.param E) (.ex (.app (.var (.succ .zero)) (.var .zero)))

def exRight (_M : HModel.Model S) (σ : Ty) (E : Observer (S := S)) : HLanguage.Formula S.Dom [σ ⇒ RTy.t] :=
  .ex (.app (.param E) (.app (.var (.succ .zero)) (.var .zero)))

theorem unaryClosure {σ : Ty} (A : HLanguage.Formula S.Dom [σ]) :
    A.universalClosure = .all A := by
  have hr : (@HLanguage.Ren.embed [σ] [] : HLanguage.Ren [σ] [σ]) =
      (@HLanguage.Ren.id [σ] : HLanguage.Ren [σ] [σ]) := by
    funext τ v
    cases v with
    | zero => rfl
    | succ v => nomatch v
  change HLanguage.Term.all (A.rename (HLanguage.Ren.embed [σ] [])) = _
  rw [hr, HLanguage.Term.rename_id]

theorem eval_allLeft (σ : Ty) (E : Observer (S := S)) (R : S.Dom (σ ⇒ RTy.t)) :
    (unary M (σ ⇒ RTy.t)).eval (allLeft M σ E) R =
      S.app E (allOperation M σ R) := by
  change M.eval (.app (.param E)
    (.all (.app (.var (.succ .zero)) (.var .zero))))
    (HLanguage.Env.cons R HLanguage.Env.nil) = _
  rw [M.eval_app, M.eval_param]
  apply congrArg (S.app E)
  exact (eval_instantiate M
    (.all (.app (.var (.succ .zero)) (.var .zero)) :
      HLanguage.Formula S.Dom [σ ⇒ RTy.t]) R HLanguage.Env.nil).symm

theorem truth_allRight (σ : Ty) (E : Observer (S := S)) (R : S.Dom (σ ⇒ RTy.t)) :
    S.truth ((unary M (σ ⇒ RTy.t)).eval (allRight M σ E) R) ↔
      ∀ x : S.Dom σ, S.truth (S.app E (S.app R x)) := by
  change S.truth (M.eval (.all (.app (.param E)
    (.app (.var (.succ .zero)) (.var .zero))))
      (HLanguage.Env.cons R HLanguage.Env.nil)) ↔ _
  rw [M.truth_all]
  apply forall_congr'
  intro x
  rw [M.eval_app, M.eval_param, M.eval_app, M.eval_var, M.eval_var]
  rfl

theorem eval_exLeft (σ : Ty) (E : Observer (S := S)) (R : S.Dom (σ ⇒ RTy.t)) :
    (unary M (σ ⇒ RTy.t)).eval (exLeft M σ E) R =
      S.app E (exOperation M σ R) := by
  change M.eval (.app (.param E)
    (.ex (.app (.var (.succ .zero)) (.var .zero))))
    (HLanguage.Env.cons R HLanguage.Env.nil) = _
  rw [M.eval_app, M.eval_param]
  apply congrArg (S.app E)
  exact (eval_instantiate M
    (.ex (.app (.var (.succ .zero)) (.var .zero)) :
      HLanguage.Formula S.Dom [σ ⇒ RTy.t]) R HLanguage.Env.nil).symm

theorem truth_exRight (σ : Ty) (E : Observer (S := S)) (R : S.Dom (σ ⇒ RTy.t)) :
    S.truth ((unary M (σ ⇒ RTy.t)).eval (exRight M σ E) R) ↔
      ∃ x : S.Dom σ, S.truth (S.app E (S.app R x)) := by
  change S.truth (M.eval (.ex (.app (.param E)
    (.app (.var (.succ .zero)) (.var .zero))))
      (HLanguage.Env.cons R HLanguage.Env.nil)) ↔ _
  rw [M.truth_ex]
  apply exists_congr
  intro x
  rw [M.eval_app, M.eval_param, M.eval_app, M.eval_var, M.eval_var]
  rfl

def universalt : UniversalPresentation S.core (Observer (S := S)) S.app where
  Operators := S.Dom ((Ty.t ⇒ RTy.t) ⇒ RTy.t)
  operatorApp := S.app
  matrices := unary M (Ty.t ⇒ RTy.t)
  all := allOperation M Ty.t
  left := allLeft M Ty.t
  right := allRight M Ty.t
  eval_left := eval_allLeft M Ty.t
  truth_right := truth_allRight M Ty.t

def diagonals : DiagonalCodes (booleans M) where
  body E := .imp (.app (.param E) (.var .zero)) (.var .zero)
  eval_body E p := by
    change M.eval (.imp (.app (.param E) (.var .zero)) (.var .zero))
      (HLanguage.Env.cons p HLanguage.Env.nil) = _
    rw [M.eval_imp, M.eval_app, M.eval_param, M.eval_var]
    rfl

theorem all_congruence (σ : Ty) :
    NecessaryBinderCongruence (unary M σ) (allOperation M σ) (unary M σ).all := by
  intro R A
  have h := M.necessary_logical
    (HModel.LogicalAxiom.universalCongruence
      (.app (.param R) (.var .zero)) A)
  rw [M.eval_imp, M.eval_iff] at h
  change S.core.Box (S.core.imp
    (M.eval (HLanguage.Term.universalClosure
      (.iff (.app (.param R) (.var .zero)) A)) HLanguage.Env.nil)
    (S.core.iff (allOperation M σ R) (M.eval A.universalClosure HLanguage.Env.nil)))
  rw [unaryClosure A]
  exact h

theorem ex_congruence (σ : Ty) :
    NecessaryBinderCongruence (unary M σ) (exOperation M σ) (exBinder M σ) := by
  intro R A
  have h := M.necessary_logical
    (HModel.LogicalAxiom.existentialCongruence
      (.app (.param R) (.var .zero)) A)
  rw [M.eval_imp, M.eval_iff] at h
  exact h

def nativeBoxMatrix (_M : HModel.Model S) : HLanguage.Formula S.Dom [Ty.t] :=
  .eq (.var .zero) .top

theorem eval_nativeBoxMatrix (p : S.Dom Ty.t) :
    (unary M Ty.t).eval (nativeBoxMatrix M) p = S.eq p S.core.top := by
  change M.eval (.eq (.var .zero) .top) (HLanguage.Env.cons p HLanguage.Env.nil) = _
  rw [M.eval_eq, M.eval_var, M.eval_top]
  rfl

theorem boxRepresentative_exists {Q : Observer (S := S) → Prop}
    (sep : PropSeparation (booleans M) Q) (hIC : M.Comprehension) :
    ∃ R : Observer (S := S), ∀ p : S.Dom Ty.t, S.app R p = S.eq p S.core.top := by
  obtain ⟨R, hR⟩ := unary_comprehension M hIC Ty.t (nativeBoxMatrix M)
  refine ⟨R, fun p => ?_⟩
  exact ((unary M Ty.t).rep_exact sep (unary_ui M Ty.t) hR p).trans
    (eval_nativeBoxMatrix M p)

def equalityTest (_M : HModel.Model S) (σ : Ty) (a : S.Dom σ) : HLanguage.Formula S.Dom [σ] :=
  .eq (.eq (.param a) (.var .zero)) .top

theorem eval_equalityTest (σ : Ty) (a b : S.Dom σ) :
    (unary M σ).eval (equalityTest M σ a) b = S.eq (S.eq a b) S.core.top := by
  change M.eval (.eq (.eq (.param a) (.var .zero)) .top)
    (HLanguage.Env.cons b HLanguage.Env.nil) = _
  rw [M.eval_eq, M.eval_eq, M.eval_param, M.eval_var, M.eval_top]
  rfl

#print axioms comprehension
#print axioms truth_same
#print axioms booleans
#print axioms universalt
#print axioms all_congruence
#print axioms boxRepresentative_exists

end Classicism.Research.InfinitaryComprehension.HBootstrap
