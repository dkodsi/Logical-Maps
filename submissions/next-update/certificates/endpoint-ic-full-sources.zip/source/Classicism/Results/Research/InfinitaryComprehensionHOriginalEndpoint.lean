import Classicism.Results.Research.InfinitaryComprehensionHOriginalSchemas
import Classicism.Results.Research.InfinitaryComprehensionHEndpoint

/-!
# Original-type endpoint separation and its grounding transport

Original research, misc, 26 October 2026. The source schema below ranges
only over closed original argument types and closed original qualification
types. Its common-representative clauses are actual native H formulas.
The all-index implementation schema is derived by the concrete grounding
translation; there is no additional schema premise at an auxiliary type.
-/

namespace Classicism.Research.InfinitaryComprehension.HOriginalEndpoint

open Classicism.Meta Grounding HOriginalTypes HOriginalModel HOriginalSchemas
open EndpointOriginalTypes (OriginalTypedOps)

universe u

variable (S : OriginalTypedOps.{u})

/-- Transport between equal original relation types, with proof irrelevance
handling their closedness certificates. -/
def castRel {ρ τ : RTy} (hρ : ρ.Closed) (hτ : τ.Closed) (h : ρ = τ)
    (f : S.Dom ρ hρ) : S.Dom τ hτ := by
  cases h
  exact f

theorem castRel_injective {ρ τ : RTy} (hρ : ρ.Closed) (hτ : τ.Closed)
    (h : ρ = τ) {f g : S.Dom ρ hρ}
    (he : castRel S hρ hτ h f = castRel S hρ hτ h g) : f = g := by
  cases h
  exact he

theorem castRel_app {σ : Ty} {ρ τ : RTy} (hσ : σ.Closed)
    (hρ : ρ.Closed) (hτ : τ.Closed) (h : ρ = τ)
    (f : S.Dom (σ ⇒ ρ) ⟨hσ,hρ⟩) (a : S.Dom σ hσ) :
    S.app hσ hτ (castRel S (ρ := RTy.arr σ ρ) (τ := RTy.arr σ τ) ⟨hσ,hρ⟩ ⟨hσ,hτ⟩
      (congrArg (RTy.arr σ) h) f) a =
      castRel S hρ hτ h (S.app hσ hρ f a) := by
  cases h
  rfl

def uncurry : (Γ : Ctx) → (hΓ : ContextClosed Γ) →
    S.Dom (RTy.ofArgs Γ) (Formation.ofArgs_closed Γ hΓ) →
    S.Env Γ hΓ → S.Dom Ty.t trivial
  | [], _, R, _ => R
  | σ :: Γ, hΓ, R, xs =>
      uncurry Γ (Formation.context_cons.mp hΓ).2
        (S.app (Formation.context_cons.mp hΓ).1
          (Formation.ofArgs_closed Γ (Formation.context_cons.mp hΓ).2) R (xs .zero))
        (fun v => xs (.succ v))

def groundRelation (Γ : Ctx) (R : S.toTypedOps.Dom (RTy.ofArgs Γ)) :
    S.Dom (RTy.ofArgs (groundCtx Γ))
      (Formation.ofArgs_closed _ (Formation.ground_context_closed Γ)) :=
  castRel S (groundRTy_closed (RTy.ofArgs Γ))
    (Formation.ofArgs_closed _ (Formation.ground_context_closed Γ))
    (groundRTy_ofArgs Γ) R

theorem ground_uncurry (Γ : Ctx) (R : S.toTypedOps.Dom (RTy.ofArgs Γ))
    (xs : HLanguage.Env S.toTypedOps.Dom Γ) :
    uncurry S (groundCtx Γ) (Formation.ground_context_closed Γ)
      (groundRelation S Γ R) (S.groundEnv xs) = S.toTypedOps.uncurry Γ R xs := by
  induction Γ with
  | nil => rfl
  | cons σ Γ ih =>
      change uncurry S (groundCtx Γ) _
        (S.app (groundTy_closed σ) _
          (castRel S _ _ (groundRTy_ofArgs (σ :: Γ)) R) (xs .zero))
        (S.groundEnv (fun v => xs (.succ v))) = _
      have happ := castRel_app S (groundTy_closed σ)
        (groundRTy_closed (RTy.ofArgs Γ))
        (Formation.ofArgs_closed _ (Formation.ground_context_closed Γ))
        (groundRTy_ofArgs Γ) R (xs .zero)
      exact (congrArg (fun Q : S.Dom (RTy.ofArgs (groundCtx Γ))
          (Formation.ofArgs_closed _ (Formation.ground_context_closed Γ)) =>
        uncurry S (groundCtx Γ) (Formation.ground_context_closed Γ) Q
          (S.groundEnv (fun v => xs (.succ v)))) happ).trans
        (ih (S.toTypedOps.app R (xs .zero)) (fun v => xs (.succ v)))

def ungroundEnv {Γ : Ctx}
    (xs : S.Env (groundCtx Γ) (Formation.ground_context_closed Γ)) :
    HLanguage.Env S.toTypedOps.Dom Γ := fun v => xs (groundVar v)

theorem ground_unground_env {Γ : Ctx}
    (xs : S.Env (groundCtx Γ) (Formation.ground_context_closed Γ)) :
    @Eq (S.Env (groundCtx Γ) (Formation.ground_context_closed Γ))
      (S.groundEnv (ungroundEnv S xs)) xs := by
  induction Γ with
  | nil => funext τ v; cases v
  | cons σ Γ ih =>
      funext τ v
      cases v with
      | zero => rfl
      | succ v =>
          exact congrArg (fun ys : S.Env (groundCtx Γ)
            (Formation.ground_context_closed Γ) => ys v)
            (ih (fun w => xs (.succ w)))

abbrev Observer := S.Dom (Ty.t ⇒ RTy.t) ⟨trivial,trivial⟩

def allLeft (σ : Ty) (E : Observer S) : OFormula S [σ ⇒ RTy.t] :=
  .app (.param (OriginalCarrier.value (σ := Ty.t ⇒ RTy.t) ⟨trivial,trivial⟩ E))
    (.all (.app (.var (.succ .zero)) (.var .zero)))
def allRight (σ : Ty) (E : Observer S) : OFormula S [σ ⇒ RTy.t] :=
  .all (.app (.param (OriginalCarrier.value (σ := Ty.t ⇒ RTy.t) ⟨trivial,trivial⟩ E))
    (.app (.var (.succ .zero)) (.var .zero)))
def exLeft (σ : Ty) (E : Observer S) : OFormula S [σ ⇒ RTy.t] :=
  .app (.param (OriginalCarrier.value (σ := Ty.t ⇒ RTy.t) ⟨trivial,trivial⟩ E))
    (.ex (.app (.var (.succ .zero)) (.var .zero)))
def exRight (σ : Ty) (E : Observer S) : OFormula S [σ ⇒ RTy.t] :=
  .ex (.app (.param (OriginalCarrier.value (σ := Ty.t ⇒ RTy.t) ⟨trivial,trivial⟩ E))
    (.app (.var (.succ .zero)) (.var .zero)))

theorem closed_singleton {σ : Ty} (hσ : σ.Closed) : ContextClosed [σ] :=
  Formation.context_cons.mpr ⟨hσ, Formation.context_nil⟩

theorem formed_allLeft (σ : Ty) (hσ : σ.Closed) (E : Observer S) :
    formed (allLeft S σ E) := ⟨⟨trivial,trivial⟩, hσ, ⟨hσ,trivial⟩, hσ⟩
theorem formed_allRight (σ : Ty) (hσ : σ.Closed) (E : Observer S) :
    formed (allRight S σ E) := ⟨hσ, ⟨trivial,trivial⟩, ⟨hσ,trivial⟩, hσ⟩
theorem formed_exLeft (σ : Ty) (hσ : σ.Closed) (E : Observer S) :
    formed (exLeft S σ E) := ⟨⟨trivial,trivial⟩, hσ, ⟨hσ,trivial⟩, hσ⟩
theorem formed_exRight (σ : Ty) (hσ : σ.Closed) (E : Observer S) :
    formed (exRight S σ E) := ⟨hσ, ⟨trivial,trivial⟩, ⟨hσ,trivial⟩, hσ⟩

variable {S} (M : HOriginalModel.Model S)

structure GoodAt (σ : Ty) (hσ : σ.Closed) (E : Observer S) : Prop where
  all : S.truth (M.eval Formation.context_nil
    (HLanguage.Term.sameFormula (allLeft S σ E) (allRight S σ E))
    (formed_same (closed_singleton (σ := σ ⇒ RTy.t) ⟨hσ,trivial⟩) _ _
      (formed_allLeft S σ hσ E) (formed_allRight S σ hσ E)) (envNil S))
  ex : S.truth (M.eval Formation.context_nil
    (HLanguage.Term.sameFormula (exLeft S σ E) (exRight S σ E))
    (formed_same (closed_singleton (σ := σ ⇒ RTy.t) ⟨hσ,trivial⟩) _ _
      (formed_exLeft S σ hσ E) (formed_exRight S σ hσ E)) (envNil S))
  reflexive : ∀ x : S.Dom σ hσ,
    S.truth (S.app (σ := Ty.t) (ρ := RTy.t) trivial trivial E (S.eq hσ x x))
  leibniz : ∀ x y : S.Dom σ hσ, ∀ F : S.Dom (σ ⇒ RTy.t) ⟨hσ,trivial⟩,
    S.truth (S.app (σ := Ty.t) (ρ := RTy.t) trivial trivial E (S.eq hσ x y)) →
    S.truth (S.app (σ := Ty.t) (ρ := RTy.t) trivial trivial E (S.app (σ := σ) (ρ := RTy.t) hσ trivial F x)) →
    S.truth (S.app (σ := Ty.t) (ρ := RTy.t) trivial trivial E (S.app (σ := σ) (ρ := RTy.t) hσ trivial F y))

theorem ground_goodAt (σ : Ty) (E : Observer S) :
    HEndpoint.GoodAt M.toModel σ E ↔ GoodAt M (groundTy σ) (groundTy_closed σ) E := by
  constructor <;> intro h
  · exact ⟨h.all, h.ex, h.reflexive, h.leibniz⟩
  · exact ⟨h.all, h.ex, h.reflexive, h.leibniz⟩

def Qualification (Δ : List Ty) (hΔ : ContextClosed Δ) (E : Observer S) : Prop :=
  (∀ p : S.Dom Ty.t trivial,
    S.app (σ := Ty.t) (ρ := RTy.t) trivial trivial E p = S.toTypedOps.core.top ∨
    S.app (σ := Ty.t) (ρ := RTy.t) trivial trivial E p = S.toTypedOps.core.bot) ∧
  ∀ σ (hσ : σ ∈ Δ), GoodAt M σ (hΔ σ hσ) E

theorem ground_qualification (Δ : List Ty) (E : Observer S)
    (h : Qualification M (groundCtx Δ) (Formation.ground_context_closed Δ) E) :
    HEndpoint.Qualification M.toModel Δ E := by
  refine ⟨h.1, ?_⟩
  intro σ hσ
  exact (ground_goodAt M σ E).mpr
    (h.2 (groundTy σ) (List.mem_map.mpr ⟨σ,hσ,rfl⟩))

def negLeft (E : Observer S) : OFormula S [Ty.t] :=
  .app (.param (OriginalCarrier.value (σ := Ty.t ⇒ RTy.t) ⟨trivial,trivial⟩ E)) (.neg (.var .zero))
def negRight (E : Observer S) : OFormula S [Ty.t] :=
  .neg (.app (.param (OriginalCarrier.value (σ := Ty.t ⇒ RTy.t) ⟨trivial,trivial⟩ E)) (.var .zero))
def conjLeft (E : Observer S) : OFormula S [Ty.t, Ty.t] :=
  .app (.param (OriginalCarrier.value (σ := Ty.t ⇒ RTy.t) ⟨trivial,trivial⟩ E))
    (.conj (.var .zero) (.var (.succ .zero)))
def conjRight (E : Observer S) : OFormula S [Ty.t, Ty.t] :=
  .conj (.app (.param (OriginalCarrier.value (σ := Ty.t ⇒ RTy.t) ⟨trivial,trivial⟩ E)) (.var .zero))
    (.app (.param (OriginalCarrier.value (σ := Ty.t ⇒ RTy.t) ⟨trivial,trivial⟩ E)) (.var (.succ .zero)))
def disjLeft (E : Observer S) : OFormula S [Ty.t, Ty.t] :=
  .app (.param (OriginalCarrier.value (σ := Ty.t ⇒ RTy.t) ⟨trivial,trivial⟩ E))
    (.disj (.var .zero) (.var (.succ .zero)))
def disjRight (E : Observer S) : OFormula S [Ty.t, Ty.t] :=
  .disj (.app (.param (OriginalCarrier.value (σ := Ty.t ⇒ RTy.t) ⟨trivial,trivial⟩ E)) (.var .zero))
    (.app (.param (OriginalCarrier.value (σ := Ty.t ⇒ RTy.t) ⟨trivial,trivial⟩ E)) (.var (.succ .zero)))

theorem closed_tt : ContextClosed [Ty.t, Ty.t] :=
  Formation.context_cons.mpr ⟨trivial, closed_singleton (σ := Ty.t) trivial⟩

def GoodBoolean (E : Observer S) : Prop :=
  S.truth (M.eval Formation.context_nil
    (HLanguage.Term.sameFormula (negLeft E) (negRight E))
    (formed_same (closed_singleton (σ := Ty.t) trivial) _ _
      ⟨⟨trivial,trivial⟩, trivial⟩ ⟨⟨trivial,trivial⟩, trivial⟩) (envNil S)) ∧
  S.truth (M.eval Formation.context_nil
    (HLanguage.Term.sameFormula (conjLeft E) (conjRight E))
    (formed_same closed_tt _ _ ⟨⟨trivial,trivial⟩, trivial, trivial⟩
      ⟨⟨⟨trivial,trivial⟩, trivial⟩, ⟨⟨trivial,trivial⟩, trivial⟩⟩) (envNil S)) ∧
  S.truth (M.eval Formation.context_nil
    (HLanguage.Term.sameFormula (disjLeft E) (disjRight E))
    (formed_same closed_tt _ _ ⟨⟨trivial,trivial⟩, trivial, trivial⟩
      ⟨⟨⟨trivial,trivial⟩, trivial⟩, ⟨⟨trivial,trivial⟩, trivial⟩⟩) (envNil S))

theorem ground_boolean (E : Observer S) :
    (HBootstrap.booleans M.toModel).GoodBoolean E ↔ GoodBoolean M E := by
  constructor
  · intro h
    exact (HEndpoint.boolean_qualification M.toModel E).mp h
  · intro h
    exact (HEndpoint.boolean_qualification M.toModel E).mpr h

/-- The original closed-type endpoint-valued observer separation schema.
Every type quantified here has an explicit original closedness certificate;
the operations and native Same codes are those of the original model. -/
def EndpointOS : Prop :=
  ∀ (Γ : Ctx) (hΓ : ContextClosed Γ) (Δ : List Ty) (hΔ : ContextClosed Δ)
    (R T : S.Dom (RTy.ofArgs Γ) (Formation.ofArgs_closed Γ hΓ)),
    (∀ E : Observer S, Qualification M Δ hΔ E → GoodBoolean M E →
      ∀ xs : S.Env Γ hΓ,
      S.truth (S.app (σ := Ty.t) (ρ := RTy.t) trivial trivial E (uncurry S Γ hΓ R xs)) ↔
      S.truth (S.app (σ := Ty.t) (ρ := RTy.t) trivial trivial E (uncurry S Γ hΓ T xs))) → R = T

theorem toModel_endpointOS (hOS : EndpointOS M) : HEndpoint.EndpointOS M.toModel := by
  intro Γ Δ R T h
  apply castRel_injective S (groundRTy_closed (RTy.ofArgs Γ))
    (Formation.ofArgs_closed _ (Formation.ground_context_closed Γ)) (groundRTy_ofArgs Γ)
  apply hOS (groundCtx Γ) (Formation.ground_context_closed Γ)
    (groundCtx Δ) (Formation.ground_context_closed Δ)
  intro E hQ hB xs
  have hr := ground_uncurry S Γ R (ungroundEnv S xs)
  have ht := ground_uncurry S Γ T (ungroundEnv S xs)
  rw [ground_unground_env] at hr ht
  have hh := h E (ground_qualification M Δ E hQ) ((ground_boolean M E).mpr hB)
    (ungroundEnv S xs)
  exact (iff_of_eq (congrArg (fun p => S.truth
      (S.app (σ := Ty.t) (ρ := RTy.t) trivial trivial E p)) hr)).trans
    (hh.trans (iff_of_eq (congrArg (fun p => S.truth
      (S.app (σ := Ty.t) (ρ := RTy.t) trivial trivial E p)) ht)).symm)

#print axioms ground_uncurry
#print axioms ground_goodAt
#print axioms ground_boolean
#print axioms toModel_endpointOS

end Classicism.Research.InfinitaryComprehension.HOriginalEndpoint
