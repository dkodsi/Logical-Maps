import Classicism.Results.Research.InfinitaryComprehensionHEndpoint
import Classicism.Results.Research.InfinitaryComprehensionEndpointStandard

/-!
# Full standard models satisfy the native H endpoint and IC schemas

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 1 and 5; misc, 26 October 2026,
unpaginated.

The native interpretation below is defined by recursion on actual lambda-free
syntax. Its assignment law and every necessitated logical schema are proved.
Full Infinitary Comprehension follows by finite currying, and the separating
observers are the admitted endpoint-valued world readers. There is no assumed
comparison with the canonical interpretation of the forward theorem.
-/

namespace Classicism.Research.InfinitaryComprehension.HStandard

open Classicism.Meta EndpointCanonical

universe u

variable {E W : Type u}

def ops [Nonempty E] (w0 : W) : TypedOps.{u} where
  Dom := FullTy E W
  app f a := f a
  truth p := p w0
  seed := EndpointStandard.hU
  neg := EndpointStandard.neg
  conj := EndpointStandard.conj
  disj := EndpointStandard.disj
  truth_neg _ := Iff.rfl
  truth_conj _ _ := Iff.rfl
  truth_disj _ _ := Iff.rfl
  eq a b := fun _ => a = b
  truth_eq _ _ := Iff.rfl
  nonempty_e := inferInstance

/-- Native terms are interpreted directly. Material connectives have H's
specified Boolean definitions, including its explicit fixed top and bottom. -/
def eval : {Γ : Ctx} → {σ : Ty} →
    HLanguage.Term (FullTy E W) Γ σ → HLanguage.Env (FullTy E W) Γ → FullTy E W σ
  | _, _, .var v, xs => xs v
  | _, _, .param p, _ => p
  | _, _, .app f a, xs => eval f xs (eval a xs)
  | _, _, .top, _ => EndpointStandard.hTop
  | _, _, .bot, _ => EndpointStandard.hBot
  | _, _, .neg p, xs => fun w => ¬ eval p xs w
  | _, _, .conj p q, xs => fun w => eval p xs w ∧ eval q xs w
  | _, _, .disj p q, xs => fun w => eval p xs w ∨ eval q xs w
  | _, _, .imp p q, xs => fun w => ¬ eval p xs w ∨ eval q xs w
  | _, _, .iff p q, xs => fun w =>
      (¬ eval p xs w ∨ eval q xs w) ∧ (¬ eval q xs w ∨ eval p xs w)
  | _, _, .eq a b, xs => fun _ => eval a xs = eval b xs
  | _, _, .all p, xs => fun w => ∀ a, eval p (HLanguage.Env.cons a xs) w
  | _, _, .ex p, xs => fun w => ∃ a, eval p (HLanguage.Env.cons a xs) w
  | _, _, .iAnd I p, xs => fun w => ∀ i : I, eval (p i) xs w
  | _, _, .iOr I p, xs => fun w => ∃ i : I, eval (p i) xs w

theorem eval_rename {Γ σ} (p : HLanguage.Term (FullTy E W) Γ σ) :
    ∀ {Δ} (r : HLanguage.Ren Γ Δ) (xs : HLanguage.Env (FullTy E W) Γ)
      (ys : HLanguage.Env (FullTy E W) Δ),
      (∀ {τ} (v : Var Γ τ), ys (r v) = xs v) → eval (p.rename r) ys = eval p xs := by
  induction p with
  | var v => intro Δ r xs ys h; exact h v
  | param p => intros; rfl
  | top => intros; rfl
  | bot => intros; rfl
  | app p q ihp ihq =>
      intro Δ r xs ys h
      simp only [HLanguage.Term.rename, eval, ihp r xs ys h, ihq r xs ys h]
  | neg p ih =>
      intro Δ r xs ys h
      simp only [HLanguage.Term.rename, eval, ih r xs ys h]
  | conj p q ihp ihq =>
      intro Δ r xs ys h
      simp only [HLanguage.Term.rename, eval, ihp r xs ys h, ihq r xs ys h]
  | disj p q ihp ihq =>
      intro Δ r xs ys h
      simp only [HLanguage.Term.rename, eval, ihp r xs ys h, ihq r xs ys h]
  | imp p q ihp ihq =>
      intro Δ r xs ys h
      simp only [HLanguage.Term.rename, eval, ihp r xs ys h, ihq r xs ys h]
  | iff p q ihp ihq =>
      intro Δ r xs ys h
      simp only [HLanguage.Term.rename, eval, ihp r xs ys h, ihq r xs ys h]
  | eq p q ihp ihq =>
      intro Δ r xs ys h
      simp only [HLanguage.Term.rename, eval, ihp r xs ys h, ihq r xs ys h]
  | all p ih =>
      intro Δ r xs ys h
      have hx (a) : eval (p.rename (HLanguage.Ren.lift r)) (HLanguage.Env.cons a ys) =
          eval p (HLanguage.Env.cons a xs) := by
        apply ih
        intro τ v
        cases v with
        | zero => rfl
        | succ v => exact h v
      exact congrArg (fun f => fun w => ∀ a, f a w) (funext hx)
  | ex p ih =>
      intro Δ r xs ys h
      have hx (a) : eval (p.rename (HLanguage.Ren.lift r)) (HLanguage.Env.cons a ys) =
          eval p (HLanguage.Env.cons a xs) := by
        apply ih
        intro τ v
        cases v with
        | zero => rfl
        | succ v => exact h v
      exact congrArg (fun f => fun w => ∃ a, f a w) (funext hx)
  | iAnd I p ih =>
      intro Δ r xs ys h
      exact congrArg (fun f => fun w => ∀ i : I, f i w)
        (funext (fun i => ih i r xs ys h))
  | iOr I p ih =>
      intro Δ r xs ys h
      exact congrArg (fun f => fun w => ∃ i : I, f i w)
        (funext (fun i => ih i r xs ys h))

theorem eval_lift {Γ Δ σ} (s : HLanguage.Subst (FullTy E W) Γ Δ)
    (xs : HLanguage.Env (FullTy E W) Δ) (a : FullTy E W σ) :
    (fun {τ} (v : Var (σ :: Γ) τ) =>
      eval (HLanguage.Subst.lift s v) (HLanguage.Env.cons a xs) :
      HLanguage.Env (FullTy E W) (σ :: Γ)) =
    (HLanguage.Env.cons a (fun v => eval (s v) xs) : HLanguage.Env (FullTy E W) (σ :: Γ)) := by
  funext τ v
  cases v with
  | zero => rfl
  | succ v =>
      exact eval_rename (s v) HLanguage.Ren.shift xs
        (HLanguage.Env.cons a xs) (fun _ => rfl)

theorem eval_subst {Γ σ} (p : HLanguage.Term (FullTy E W) Γ σ) :
    ∀ {Δ} (s : HLanguage.Subst (FullTy E W) Γ Δ)
      (xs : HLanguage.Env (FullTy E W) Δ),
      eval (p.subst s) xs = eval p (fun v => eval (s v) xs) := by
  induction p with
  | var v => intros; rfl
  | param p => intros; rfl
  | top => intros; rfl
  | bot => intros; rfl
  | app p q ihp ihq =>
      intro Δ s xs
      simp only [HLanguage.Term.subst, eval, ihp s xs, ihq s xs]
  | neg p ih =>
      intro Δ s xs
      simp only [HLanguage.Term.subst, eval, ih s xs]
  | conj p q ihp ihq =>
      intro Δ s xs
      simp only [HLanguage.Term.subst, eval, ihp s xs, ihq s xs]
  | disj p q ihp ihq =>
      intro Δ s xs
      simp only [HLanguage.Term.subst, eval, ihp s xs, ihq s xs]
  | imp p q ihp ihq =>
      intro Δ s xs
      simp only [HLanguage.Term.subst, eval, ihp s xs, ihq s xs]
  | iff p q ihp ihq =>
      intro Δ s xs
      simp only [HLanguage.Term.subst, eval, ihp s xs, ihq s xs]
  | eq p q ihp ihq =>
      intro Δ s xs
      simp only [HLanguage.Term.subst, eval, ihp s xs, ihq s xs]
  | all p ih =>
      intro Δ s xs
      have hx (a) : eval (p.subst (HLanguage.Subst.lift s)) (HLanguage.Env.cons a xs) =
          eval p (HLanguage.Env.cons a (fun v => eval (s v) xs)) := by
        rw [ih, eval_lift]
      exact congrArg (fun f => fun w => ∀ a, f a w) (funext hx)
  | ex p ih =>
      intro Δ s xs
      have hx (a) : eval (p.subst (HLanguage.Subst.lift s)) (HLanguage.Env.cons a xs) =
          eval p (HLanguage.Env.cons a (fun v => eval (s v) xs)) := by
        rw [ih, eval_lift]
      exact congrArg (fun f => fun w => ∃ a, f a w) (funext hx)
  | iAnd I p ih =>
      intro Δ s xs
      exact congrArg (fun f => fun w => ∀ i : I, f i w)
        (funext (fun i => ih i s xs))
  | iOr I p ih =>
      intro Δ s xs
      exact congrArg (fun f => fun w => ∃ i : I, f i w)
        (funext (fun i => ih i s xs))

theorem eval_closeAll {Δ : Ctx} (Γ : Ctx)
    (A : HLanguage.Formula (FullTy E W) (Γ ++ Δ))
    (ys : HLanguage.Env (FullTy E W) Δ) (w : W) :
    eval (HLanguage.Term.closeAll Γ A) ys w ↔
      ∀ xs : HLanguage.Env (FullTy E W) Γ, eval A (HLanguage.Env.append xs ys) w := by
  induction Γ with
  | nil => exact ⟨fun h _ => h, fun h => h HLanguage.Env.nil⟩
  | cons σ Γ ih =>
      change eval (HLanguage.Term.closeAll Γ (.all A)) ys w ↔ _
      rw [ih]
      exact ⟨fun h xs => h (HLanguage.Env.tail xs) (xs .zero),
        fun h xs a => h (HLanguage.Env.cons a xs)⟩

theorem eval_universalClosure {Γ : Ctx} (A : HLanguage.Formula (FullTy E W) Γ) (w : W) :
    eval A.universalClosure HLanguage.Env.nil w ↔
      ∀ xs : HLanguage.Env (FullTy E W) Γ, eval A xs w := by
  rw [HLanguage.Term.universalClosure, eval_closeAll]
  apply forall_congr'
  intro xs
  rw [eval_rename A (HLanguage.Ren.embed Γ []) xs
    (HLanguage.Env.append xs HLanguage.Env.nil) (HLanguage.Env.append_embed xs HLanguage.Env.nil)]

theorem eval_imp_truth {Γ : Ctx} (A B : HLanguage.Formula (FullTy E W) Γ)
    (xs : HLanguage.Env (FullTy E W) Γ) (w : W) :
    eval (.imp A B) xs w ↔ (eval A xs w → eval B xs w) := by
  constructor
  · intro h ha
    exact h.elim (fun hn => False.elim (hn ha)) (fun hb => hb)
  · intro h
    exact (Classical.em (eval A xs w)).elim (fun ha => Or.inr (h ha)) Or.inl

theorem eval_iff_truth {Γ : Ctx} (A B : HLanguage.Formula (FullTy E W) Γ)
    (xs : HLanguage.Env (FullTy E W) Γ) (w : W) :
    eval (.iff A B) xs w ↔ (eval A xs w ↔ eval B xs w) := by
  change (eval (.imp A B) xs w ∧ eval (.imp B A) xs w) ↔ _
  rw [eval_imp_truth, eval_imp_truth]
  exact ⟨fun h => ⟨h.1, h.2⟩, fun h => ⟨h.mp, h.mpr⟩⟩

theorem logical_valid {p : HLanguage.Formula (FullTy E W) []}
    (h : HModel.LogicalAxiom (FullTy E W) p) (w : W) : eval p HLanguage.Env.nil w := by
  classical
  cases h with
  | universalInstantiation A s =>
      apply (eval_imp_truth _ _ _ w).mpr
      intro h
      rw [eval_subst]
      exact (eval_universalClosure A w).mp h (fun v => eval (s v) HLanguage.Env.nil)
  | universalCongruence A B =>
      apply (eval_imp_truth _ _ _ w).mpr
      intro h
      apply (eval_iff_truth _ _ _ w).mpr
      have hx (a) := (eval_iff_truth A B (HLanguage.Env.cons a HLanguage.Env.nil) w).mp
        ((eval_universalClosure (.iff A B) w).mp h (HLanguage.Env.cons a HLanguage.Env.nil))
      exact ⟨fun ha a => (hx a).mp (ha a), fun hb a => (hx a).mpr (hb a)⟩
  | existentialCongruence A B =>
      apply (eval_imp_truth _ _ _ w).mpr
      intro h
      apply (eval_iff_truth _ _ _ w).mpr
      have hx (a) := (eval_iff_truth A B (HLanguage.Env.cons a HLanguage.Env.nil) w).mp
        ((eval_universalClosure (.iff A B) w).mp h (HLanguage.Env.cons a HLanguage.Env.nil))
      exact ⟨fun ⟨a, ha⟩ => ⟨a, (hx a).mp ha⟩, fun ⟨a, hb⟩ => ⟨a, (hx a).mpr hb⟩⟩
  | infimumProjection I A i =>
      exact (eval_imp_truth _ _ _ w).mpr (fun h => h i)
  | infimumTop I =>
      exact fun _ => Classical.em (EndpointStandard.hU w)
  | implicationInfimum I A p =>
      apply (eval_iff_truth _ _ _ w).mpr
      rw [eval_imp_truth]
      constructor
      · intro h i
        exact (eval_imp_truth _ _ _ w).mpr (fun hp => h hp i)
      · intro h hp i
        exact (eval_imp_truth _ _ _ w).mp (h i) hp
  | disjunctionDeMorgan I A =>
      apply (eval_iff_truth _ _ _ w).mpr
      change (∃ i, eval (A i) HLanguage.Env.nil w) ↔
        ¬ ∀ i, ¬ eval (A i) HLanguage.Env.nil w
      constructor
      · intro ⟨i, hi⟩ h
        exact h i hi
      · intro h
        exact Classical.byContradiction (fun hn => h (fun i hi => hn ⟨i, hi⟩))

/-- The entire raw H interpretation is supplied by full standard semantics. -/
def model [Nonempty E] (w0 : W) : HModel.Model (ops (E := E) w0) where
  eval := eval
  iAnd _ f := fun w => ∀ i, f i w
  iOr _ f := fun w => ∃ i, f i w
  eval_var _ _ := rfl
  eval_param _ _ := rfl
  eval_app _ _ _ := rfl
  eval_top _ := rfl
  eval_bot _ := rfl
  eval_neg _ _ := rfl
  eval_conj _ _ _ := rfl
  eval_disj _ _ _ := rfl
  eval_imp _ _ _ := rfl
  eval_iff _ _ _ := rfl
  eval_eq _ _ _ := rfl
  eval_iAnd _ _ _ := rfl
  eval_iOr _ _ _ := rfl
  truth_all _ _ := Iff.rfl
  truth_ex _ _ := Iff.rfl
  truth_iAnd _ _ := Iff.rfl
  truth_iOr _ _ := Iff.rfl
  eval_subst p s xs := eval_subst p s xs
  seed_eq := rfl
  logicalNecessitation p h := (EndpointStandard.box_eq_hTop (eval p HLanguage.Env.nil)).mp
    (logical_valid h)

theorem uncurry_value [Nonempty E] (w0 : W) :
    ∀ (Γ : Ctx) (R : FullRel E W (RTy.ofArgs Γ)) (xs : HLanguage.Env (FullTy E W) Γ),
      (ops (E := E) w0).uncurry Γ R xs = uncurry E W Γ R xs := by
  intro Γ
  induction Γ with
  | nil => intros; rfl
  | cons σ Γ ih =>
      intro R xs
      exact ih (R (xs .zero)) (fun v => xs (.succ v))

/-- A full standard value profile satisfies the literal boxed representation
formula because its entire universal equivalence is true at every world. -/
theorem rep_of_profile [Nonempty E] (w0 : W) {Γ : Ctx}
    (R : FullRel E W (RTy.ofArgs Γ)) (A : HLanguage.Formula (FullTy E W) Γ)
    (h : ∀ (xs : HLanguage.Env (FullTy E W) Γ) (w : W),
      uncurry E W Γ R xs w ↔ eval A xs w) :
    (HBootstrap.matrices (model (E := E) w0) Γ).Rep R A := by
  change eval (HLanguage.Term.universalClosure
    (.iff (HLanguage.Term.applyVars Γ (.param R) (fun v => .var v)) A))
    HLanguage.Env.nil = EndpointStandard.hTop
  apply (EndpointStandard.box_eq_hTop _).mp
  intro w
  apply (eval_universalClosure _ w).mpr
  intro xs
  apply (eval_iff_truth _ _ xs w).mpr
  have hv := HBootstrap.eval_applyVars (model (E := E) w0) Γ
    (.param R) (fun v => .var v) xs
  change eval (HLanguage.Term.applyVars Γ (.param R) (fun v => .var v)) xs =
    (ops (E := E) w0).uncurry Γ R xs at hv
  rw [hv, uncurry_value]
  exact h xs w

theorem comprehension [Nonempty E] (w0 : W) : (model (E := E) w0).Comprehension := by
  intro Γ A
  apply (HBootstrap.truth_comprehension (model (E := E) w0) A).mpr
  refine ⟨curry E W Γ (fun xs => eval A xs), rep_of_profile w0 _ A ?_⟩
  intro xs w
  rw [uncurry_curry]

theorem same_of_values [Nonempty E] (w0 : W) {Γ : Ctx}
    (A B : HLanguage.Formula (FullTy E W) Γ)
    (h : ∀ xs : HLanguage.Env (FullTy E W) Γ, eval A xs = eval B xs) :
    (HBootstrap.matrices (model (E := E) w0) Γ).Same A B := by
  refine ⟨curry E W Γ (fun xs => eval A xs), rep_of_profile w0 _ A ?_,
    rep_of_profile w0 _ B ?_⟩
  · intro xs w
    rw [uncurry_curry]
  · intro xs w
    rw [uncurry_curry, h xs]

theorem unary_same_of_values [Nonempty E] (w0 : W) {σ : Ty}
    (A B : HLanguage.Formula (FullTy E W) [σ])
    (h : ∀ x : FullTy E W σ,
      eval A (HLanguage.Env.cons x HLanguage.Env.nil) =
      eval B (HLanguage.Env.cons x HLanguage.Env.nil)) :
    (HBootstrap.unary (model (E := E) w0) σ).Same A B := by
  change (HBootstrap.matrices (model (E := E) w0) [σ]).Same A B
  apply same_of_values w0 A B
  intro xs
  have he : (HLanguage.Env.cons (xs .zero) HLanguage.Env.nil :
      HLanguage.Env (FullTy E W) [σ]) = @xs := by
    funext τ v
    cases v with
    | zero => rfl
    | succ v => nomatch v
  rw [← he]
  exact h (xs .zero)

theorem binary_same_of_values [Nonempty E] (w0 : W)
    (A B : HLanguage.Formula (FullTy E W) [Ty.t, Ty.t])
    (h : ∀ p q : FullTy E W Ty.t,
      eval A (HLanguage.Env.cons p (HLanguage.Env.cons q HLanguage.Env.nil)) =
      eval B (HLanguage.Env.cons p (HLanguage.Env.cons q HLanguage.Env.nil))) :
    (HBootstrap.binary (model (E := E) w0)).Same A B := by
  change (HBootstrap.matrices (model (E := E) w0) [Ty.t, Ty.t]).Same A B
  apply same_of_values w0 A B
  intro xs
  have he : (HLanguage.Env.cons (xs .zero)
      (HLanguage.Env.cons (xs (.succ .zero)) HLanguage.Env.nil) :
      HLanguage.Env (FullTy E W) [Ty.t, Ty.t]) = @xs := by
    funext τ v
    cases v with
    | zero => rfl
    | succ v =>
        cases v with
        | zero => rfl
        | succ v => nomatch v
  rw [← he]
  exact h (xs .zero) (xs (.succ .zero))

theorem reader_boolean [Nonempty E] (w0 w : W) :
    (HBootstrap.booleans (model (E := E) w0)).GoodBoolean
      (EndpointStandard.worldReader (E := E) w) := by
  refine ⟨?_, ?_, ?_⟩
  · apply unary_same_of_values w0
    intro p
    rfl
  · apply binary_same_of_values w0
    intro p q
    rfl
  · apply binary_same_of_values w0
    intro p q
    rfl

theorem reader_goodAt [Nonempty E] (w0 w : W) (σ : Ty) :
    HEndpoint.GoodAt (model (E := E) w0) σ (EndpointStandard.worldReader (E := E) w) := by
  constructor
  · apply (HBootstrap.truth_unary_same (model (E := E) w0) _ _).mpr
    apply unary_same_of_values w0
    intro R
    rfl
  · apply (HBootstrap.truth_unary_same (model (E := E) w0) _ _).mpr
    apply unary_same_of_values w0
    intro R
    rfl
  · intro x
    rfl
  · intro x y F h hx
    exact h ▸ hx

theorem reader_qualification [Nonempty E] (w0 w : W) (Δ : List Ty) :
    HEndpoint.Qualification (model (E := E) w0) Δ
      (EndpointStandard.worldReader (E := E) w) := by
  constructor
  · exact (EndpointStandard.endpointValued_iff_hEndpoints
      (EndpointStandard.worldReader (E := E) w)).mp (EndpointStandard.worldReader_endpoints w)
  · intro σ _
    exact reader_goodAt w0 w σ

/-- Every world reader is an actual full `tt` object. Their finite qualified
instances separate every original finite relational application profile. -/
theorem endpointOS [Nonempty E] (w0 : W) : HEndpoint.EndpointOS (model (E := E) w0) := by
  intro Γ Δ R T h
  apply full_intensionality E W Γ R T
  intro xs w
  have hh := h (EndpointStandard.worldReader (E := E) w)
    (reader_qualification w0 w Δ) (reader_boolean w0 w) xs
  change (ops (E := E) w0).uncurry Γ R xs w ↔
    (ops (E := E) w0).uncurry Γ T xs w at hh
  rw [uncurry_value w0 Γ R xs, uncurry_value w0 Γ T xs] at hh
  exact hh

/-- The full-standard converse uses the same concrete H model, endpoint
schema and native infinitary comprehension schema as the forward theorem. -/
theorem full_standard_satisfies [Nonempty E] (w0 : W) :
    HEndpoint.EndpointOS (model (E := E) w0) ∧ (model (E := E) w0).Comprehension :=
  ⟨endpointOS w0, comprehension w0⟩

#print axioms eval_subst
#print axioms logical_valid
#print axioms model
#print axioms comprehension
#print axioms endpointOS
#print axioms full_standard_satisfies

end Classicism.Research.InfinitaryComprehension.HStandard
