import Classicism.Results.Research.InfinitaryComprehensionHOriginalTypes
import Classicism.Results.Research.InfinitaryComprehensionHModel

/-!
# Lift a genuinely original-type H interpretation by grounding

Original research, misc, 26 October 2026. The source interpretation below
has only original closed-type carriers, original formed native H terms,
and original logical schema instances. The target's auxiliary type indices
are interpreted by the actual type-grounding translation; no new source
schema instance at `Ty.var` is postulated.

The grammar remains the native lambda-free grammar, with box defined as
identity with top. Logical-axiom preservation is proved by the seven actual
constructors, independently of any interpretation. The evaluator lift is
then a construction satisfying every field of `HModel.Model`.
-/

namespace Classicism.Research.InfinitaryComprehension.HOriginalModel

open Classicism.Meta Grounding HOriginalTypes
open EndpointOriginalTypes (OriginalTypedOps)

universe u

theorem ground_logicalAxiom {Param Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ))
    {p : HLanguage.Formula Param []} (h : HModel.LogicalAxiom Param p) :
    HModel.LogicalAxiom Param' (HOriginalTypes.groundTerm mapParam p) := by
  cases h with
  | universalInstantiation A s =>
      change HModel.LogicalAxiom Param' (.imp
        (HOriginalTypes.groundTerm mapParam A.universalClosure)
        (HOriginalTypes.groundTerm mapParam (A.subst s)))
      rw [groundTerm_universalClosure, groundTerm_subst_ground]
      exact HModel.LogicalAxiom.universalInstantiation
        (show HLanguage.Formula Param' _ from HOriginalTypes.groundTerm mapParam A)
        (show HLanguage.Subst Param' _ [] from groundSubst mapParam s)
  | universalCongruence A B =>
      simpa only [HOriginalTypes.groundTerm, groundTerm_universalClosure] using
        HModel.LogicalAxiom.universalCongruence
          (HOriginalTypes.groundTerm mapParam A) (HOriginalTypes.groundTerm mapParam B)
  | existentialCongruence A B =>
      simpa only [HOriginalTypes.groundTerm, groundTerm_universalClosure] using
        HModel.LogicalAxiom.existentialCongruence
          (HOriginalTypes.groundTerm mapParam A) (HOriginalTypes.groundTerm mapParam B)
  | infimumProjection I A i =>
      exact HModel.LogicalAxiom.infimumProjection I
        (fun i => HOriginalTypes.groundTerm mapParam (A i)) i
  | infimumTop I => exact HModel.LogicalAxiom.infimumTop I
  | implicationInfimum I A p =>
      exact HModel.LogicalAxiom.implicationInfimum I
        (fun i => HOriginalTypes.groundTerm mapParam (A i))
        (HOriginalTypes.groundTerm mapParam p)
  | disjunctionDeMorgan I A =>
      exact HModel.LogicalAxiom.disjunctionDeMorgan I
        (fun i => HOriginalTypes.groundTerm mapParam (A i))

abbrev OTerm (S : OriginalTypedOps.{u}) (Γ : Ctx) (σ : Ty) :=
  HLanguage.Term (OriginalCarrier S) Γ σ
abbrev OFormula (S : OriginalTypedOps.{u}) (Γ : Ctx) := OTerm S Γ Ty.t

def envNil (S : OriginalTypedOps.{u}) : S.Env [] Formation.context_nil :=
  fun v => nomatch v

def envCons (S : OriginalTypedOps.{u}) {Γ σ}
    (hΓ : ContextClosed Γ) (hσ : σ.Closed) (a : S.Dom σ hσ) (xs : S.Env Γ hΓ) :
    S.Env (σ :: Γ) (Formation.context_cons.mpr ⟨hσ, hΓ⟩)
  | _, .zero => a
  | _, .succ v => xs v

theorem groundEnv_cons (S : OriginalTypedOps.{u}) {Γ σ}
    (a : S.toTypedOps.Dom σ) (xs : HLanguage.Env S.toTypedOps.Dom Γ) :
    @Eq (S.Env (groundCtx (σ :: Γ)) (Formation.ground_context_closed (σ :: Γ)))
      (S.groundEnv (HLanguage.Env.cons a xs))
      (envCons S (Formation.ground_context_closed Γ) (groundTy_closed σ) a (S.groundEnv xs)) := by
  funext τ v
  cases v <;> rfl

/-- An interpretation with no auxiliary-type operation or schema premise.
All its term inputs and substitution instances are explicitly formed in
the original closed-type language. -/
structure Model (S : OriginalTypedOps.{u}) where
  eval : ∀ {Γ σ} (hΓ : ContextClosed Γ) (p : OTerm S Γ σ) (hp : formed p),
    S.Env Γ hΓ → S.Dom σ (formed_result_type p hp)
  iAnd : (I : Type u) → (I → S.Dom Ty.t trivial) → S.Dom Ty.t trivial
  iOr : (I : Type u) → (I → S.Dom Ty.t trivial) → S.Dom Ty.t trivial
  eval_var : ∀ {Γ σ} (hΓ : ContextClosed Γ) (v : Var Γ σ) (xs : S.Env Γ hΓ),
    eval hΓ (.var v) (Formation.var_type_closed hΓ v) xs = xs v
  eval_param : ∀ {Γ σ} (hΓ : ContextClosed Γ) (hσ : σ.Closed)
    (p : OriginalCarrier S σ) (xs : S.Env Γ hΓ),
    eval hΓ (.param p) hσ xs = OriginalCarrier.read S hσ p
  eval_app : ∀ {Γ σ} {ρ : RTy} (hΓ : ContextClosed Γ)
    (f : OTerm S Γ (σ ⇒ ρ)) (a : OTerm S Γ σ) (hf : formed f) (ha : formed a)
    (xs : S.Env Γ hΓ),
    eval hΓ (.app f a) ⟨hf, ha⟩ xs =
      S.app (formed_result_type a ha) (formed_result_type f hf).2
        (eval hΓ f hf xs) (eval hΓ a ha xs)
  eval_top : ∀ {Γ} (hΓ : ContextClosed Γ) (xs : S.Env Γ hΓ),
    eval hΓ .top trivial xs = S.toTypedOps.core.top
  eval_bot : ∀ {Γ} (hΓ : ContextClosed Γ) (xs : S.Env Γ hΓ),
    eval hΓ .bot trivial xs = S.toTypedOps.core.bot
  eval_neg : ∀ {Γ} (hΓ : ContextClosed Γ) (p : OFormula S Γ)
    (hp : formed p) (xs : S.Env Γ hΓ),
    eval hΓ (.neg p) hp xs = S.neg (eval hΓ p hp xs)
  eval_conj : ∀ {Γ} (hΓ : ContextClosed Γ) (p q : OFormula S Γ)
    (hp : formed p) (hq : formed q) (xs : S.Env Γ hΓ),
    eval hΓ (.conj p q) ⟨hp,hq⟩ xs = S.conj (eval hΓ p hp xs) (eval hΓ q hq xs)
  eval_disj : ∀ {Γ} (hΓ : ContextClosed Γ) (p q : OFormula S Γ)
    (hp : formed p) (hq : formed q) (xs : S.Env Γ hΓ),
    eval hΓ (.disj p q) ⟨hp,hq⟩ xs = S.disj (eval hΓ p hp xs) (eval hΓ q hq xs)
  eval_imp : ∀ {Γ} (hΓ : ContextClosed Γ) (p q : OFormula S Γ)
    (hp : formed p) (hq : formed q) (xs : S.Env Γ hΓ),
    eval hΓ (.imp p q) ⟨hp,hq⟩ xs = S.toTypedOps.core.imp
      (eval hΓ p hp xs) (eval hΓ q hq xs)
  eval_iff : ∀ {Γ} (hΓ : ContextClosed Γ) (p q : OFormula S Γ)
    (hp : formed p) (hq : formed q) (xs : S.Env Γ hΓ),
    eval hΓ (.iff p q) ⟨hp,hq⟩ xs = S.toTypedOps.core.iff
      (eval hΓ p hp xs) (eval hΓ q hq xs)
  eval_eq : ∀ {Γ σ} (hΓ : ContextClosed Γ) (p q : OTerm S Γ σ)
    (hp : formed p) (hq : formed q) (xs : S.Env Γ hΓ),
    eval hΓ (.eq p q) ⟨hp,hq⟩ xs = S.eq (formed_result_type p hp)
      (eval hΓ p hp xs) (eval hΓ q hq xs)
  eval_iAnd : ∀ {Γ} (hΓ : ContextClosed Γ) (I : Type u)
    (p : I → OFormula S Γ) (hp : ∀ i, formed (p i)) (xs : S.Env Γ hΓ),
    eval hΓ (.iAnd I p) hp xs = iAnd I (fun i => eval hΓ (p i) (hp i) xs)
  eval_iOr : ∀ {Γ} (hΓ : ContextClosed Γ) (I : Type u)
    (p : I → OFormula S Γ) (hp : ∀ i, formed (p i)) (xs : S.Env Γ hΓ),
    eval hΓ (.iOr I p) hp xs = iOr I (fun i => eval hΓ (p i) (hp i) xs)
  truth_all : ∀ {Γ σ} (hΓ : ContextClosed Γ) (hσ : σ.Closed)
    (p : OFormula S (σ :: Γ)) (hp : formed p) (xs : S.Env Γ hΓ),
    S.truth (eval hΓ (.all p) ⟨hσ,hp⟩ xs) ↔
      ∀ x : S.Dom σ hσ, S.truth
        (eval (Formation.context_cons.mpr ⟨hσ,hΓ⟩) p hp (envCons S hΓ hσ x xs))
  truth_ex : ∀ {Γ σ} (hΓ : ContextClosed Γ) (hσ : σ.Closed)
    (p : OFormula S (σ :: Γ)) (hp : formed p) (xs : S.Env Γ hΓ),
    S.truth (eval hΓ (.ex p) ⟨hσ,hp⟩ xs) ↔
      ∃ x : S.Dom σ hσ, S.truth
        (eval (Formation.context_cons.mpr ⟨hσ,hΓ⟩) p hp (envCons S hΓ hσ x xs))
  truth_iAnd : ∀ I p, S.truth (iAnd I p) ↔ ∀ i, S.truth (p i)
  truth_iOr : ∀ I p, S.truth (iOr I p) ↔ ∃ i, S.truth (p i)
  eval_subst : ∀ {Γ Δ σ} (hΓ : ContextClosed Γ) (hΔ : ContextClosed Δ)
    (p : OTerm S Γ σ) (hp : formed p) (s : HLanguage.Subst (OriginalCarrier S) Γ Δ)
    (hs : ∀ {τ} (v : Var Γ τ), formed (s v)) (xs : S.Env Δ hΔ),
    eval hΔ (p.subst s) (formed_subst p s hp hs) xs =
      eval hΓ p hp (fun v => eval hΔ (s v) (hs v) xs)
  seed_eq : S.seed = eval Formation.context_nil
    (.all (.var .zero : OFormula S [Ty.t])) ⟨trivial,trivial⟩ (envNil S)
  logicalNecessitation : ∀ (p : OFormula S []) (hp : formed p),
    HModel.LogicalAxiom (OriginalCarrier S) p →
      S.truth (eval Formation.context_nil p.box ⟨hp,trivial⟩ (envNil S))

namespace Model

variable {S : OriginalTypedOps.{u}} (M : Model S)

theorem eval_congr {Γ σ} (hΓ : ContextClosed Γ) {p q : OTerm S Γ σ}
    (h : p = q) (hp : formed p) (hq : formed q) (xs : S.Env Γ hΓ) :
    M.eval hΓ p hp xs = M.eval hΓ q hq xs := by
  cases h
  rfl

def liftEval {Γ σ} (p : HLanguage.Term S.toTypedOps.Dom Γ σ)
    (xs : HLanguage.Env S.toTypedOps.Dom Γ) : S.toTypedOps.Dom σ :=
  M.eval (Formation.ground_context_closed Γ)
    (HOriginalTypes.groundTerm (OriginalCarrier.groundParam S) p)
    (groundTerm_formed (OriginalCarrier.groundParam S) p) (S.groundEnv xs)

theorem eval_groundSubst_env : ∀ {Γ Δ : Ctx}
    (s : HLanguage.Subst S.toTypedOps.Dom Γ Δ) (xs : HLanguage.Env S.toTypedOps.Dom Δ),
    (fun {τ} (v : Var (groundCtx Γ) τ) =>
      M.eval (Formation.ground_context_closed Δ)
        (groundSubst (OriginalCarrier.groundParam S) s v)
        (groundSubst_formed (OriginalCarrier.groundParam S) s v) (S.groundEnv xs)) =
      (fun {τ} (v : Var (groundCtx Γ) τ) =>
        S.groundEnv (fun w => M.liftEval (s w) xs) v) := by
  intro Γ
  induction Γ with
  | nil => intro Δ s xs; funext τ v; cases v
  | cons σ Γ ih =>
      intro Δ s xs
      funext τ v
      cases v with
      | zero => rfl
      | succ v =>
          exact congrArg (fun ys : S.Env (groundCtx Γ)
            (Formation.ground_context_closed Γ) => ys v)
            (ih (fun w => s (.succ w)) xs)

/-- A full implementation-index model built solely by original-type
evaluation of the actual ground translation. -/
def toModel : HModel.Model S.toTypedOps where
  eval := M.liftEval
  iAnd := M.iAnd
  iOr := M.iOr
  eval_var v xs := (M.eval_var _ (groundVar v) (S.groundEnv xs)).trans (S.groundEnv_get xs v)
  eval_param p xs := M.eval_param _ _ (OriginalCarrier.groundParam S p) (S.groundEnv xs)
  eval_app f a xs := M.eval_app _ _ _ _ _ (S.groundEnv xs)
  eval_top xs := M.eval_top _ (S.groundEnv xs)
  eval_bot xs := M.eval_bot _ (S.groundEnv xs)
  eval_neg p xs := M.eval_neg _ _ _ (S.groundEnv xs)
  eval_conj p q xs := M.eval_conj _ _ _ _ _ (S.groundEnv xs)
  eval_disj p q xs := M.eval_disj _ _ _ _ _ (S.groundEnv xs)
  eval_imp p q xs := M.eval_imp _ _ _ _ _ (S.groundEnv xs)
  eval_iff p q xs := M.eval_iff _ _ _ _ _ (S.groundEnv xs)
  eval_eq p q xs := M.eval_eq _ _ _ _ _ (S.groundEnv xs)
  eval_iAnd I p xs := M.eval_iAnd _ I _ _ (S.groundEnv xs)
  eval_iOr I p xs := M.eval_iOr _ I _ _ (S.groundEnv xs)
  truth_all := by
    intro Γ σ p xs
    refine (M.truth_all (Formation.ground_context_closed Γ) (groundTy_closed σ)
      (HOriginalTypes.groundTerm (OriginalCarrier.groundParam S) p)
      (groundTerm_formed (OriginalCarrier.groundParam S) p) (S.groundEnv xs)).trans ?_
    apply forall_congr'
    intro x
    exact iff_of_eq (congrArg S.truth (congrArg (M.eval _ _ _)
      (groundEnv_cons S x xs).symm))
  truth_ex := by
    intro Γ σ p xs
    refine (M.truth_ex (Formation.ground_context_closed Γ) (groundTy_closed σ)
      (HOriginalTypes.groundTerm (OriginalCarrier.groundParam S) p)
      (groundTerm_formed (OriginalCarrier.groundParam S) p) (S.groundEnv xs)).trans ?_
    apply exists_congr
    intro x
    exact iff_of_eq (congrArg S.truth (congrArg (M.eval _ _ _)
      (groundEnv_cons S x xs).symm))
  truth_iAnd := M.truth_iAnd
  truth_iOr := M.truth_iOr
  eval_subst p s xs := by
    exact (M.eval_congr _ (groundTerm_subst_ground (OriginalCarrier.groundParam S) p s)
      _ _ (S.groundEnv xs)).trans
      ((M.eval_subst _ _ _ _ _ _ (S.groundEnv xs)).trans
        (congrArg (M.eval _ _ _) (M.eval_groundSubst_env s xs)))
  seed_eq := M.seed_eq
  logicalNecessitation p hp := M.logicalNecessitation
    (HOriginalTypes.groundTerm (OriginalCarrier.groundParam S) p)
    (groundTerm_formed (OriginalCarrier.groundParam S) p)
    (ground_logicalAxiom (OriginalCarrier.groundParam S) hp)

theorem toModel_eval {Γ σ} (p : HLanguage.Term S.toTypedOps.Dom Γ σ)
    (xs : HLanguage.Env S.toTypedOps.Dom Γ) :
    M.toModel.eval p xs =
      M.eval (Formation.ground_context_closed Γ)
        (HOriginalTypes.groundTerm (OriginalCarrier.groundParam S) p)
        (groundTerm_formed (OriginalCarrier.groundParam S) p) (S.groundEnv xs) := rfl

end Model

#print axioms ground_logicalAxiom
#print axioms Model.toModel
#print axioms Model.toModel_eval

end Classicism.Research.InfinitaryComprehension.HOriginalModel
