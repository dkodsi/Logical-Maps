import Classicism.Results.Research.InfinitaryComprehensionHOriginalICGrounding
import Classicism.Results.Research.InfinitaryComprehensionHOriginalEndpoint
import Classicism.Results.Research.InfinitaryComprehensionHTheorem
import Classicism.Results.Research.InfinitaryComprehensionHNativeInterpretation
import Classicism.Results.Research.InfinitaryComprehensionHOriginalRetraction

/-!
# The full H-based representation theorem at original object types

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 1--4; misc, 26 October 2026, unpaginated.

Only original closed-type H carriers, formed native terms and original
closed-type instances of endpoint OS and Infinitary Comprehension occur in
the hypotheses. The auxiliary type-index extension, its logical necessities,
its IC and OS instances, the concrete syntax interpretation, and the full
canonical hierarchy are all constructed by proved translations.

The certificate uses Lean's ordinary classical metatheory. It does not
formalize the separate ZF refinement or an infinitary proof-calculus
completeness theorem.
-/

namespace Classicism.Research.InfinitaryComprehension.HOriginalTheorem

open Classicism.Meta Grounding HOriginalTypes
open EndpointOriginalTypes (OriginalTypedOps)

universe u

variable {S : OriginalTypedOps.{u}} (M : HOriginalModel.Model S)
variable (hOS : HOriginalEndpoint.EndpointOS M) (hIC : HOriginalSchemas.Comprehension M)

noncomputable def canonical : Henkin.Model.{u} :=
  HTheorem.canonical M.toModel (HOriginalEndpoint.toModel_endpointOS M hOS)
    (HOriginalICGrounding.comprehension_lift M hIC)

/-- Complete original-language forward theorem. Neither implementation-type
schemas nor an abstract interpretation/normalization adapter are premises. -/
theorem full_standard_representation :
    ∃ w : (canonical M hOS hIC).World,
      (∀ p : S.Dom Ty.t trivial, (canonical M hOS hIC).truth p w ↔ S.truth p) ∧
      EndpointFullness.FullStandard (canonical M hOS hIC) w :=
  HTheorem.full_standard_representation M.toModel
    (HOriginalEndpoint.toModel_endpointOS M hOS)
    (HOriginalICGrounding.comprehension_lift M hIC)

/-- Every original carrier is preserved, including all permitted relational
function types. The auxiliary index extension has not replaced it. -/
theorem original_carriers_preserved (σ : Ty) (hσ : σ.Closed) :
    (canonical M hOS hIC).Dom σ = S.Dom σ hσ :=
  S.closed_domain σ hσ

/-- Evaluation of the actual translated term is proved to agree with the
canonical model, for arbitrary simultaneous parameters and finite contexts.
The left hand side is the original source evaluator on a formed original term. -/
theorem grounded_syntax_interpretation {Param : Ty → Type u}
    (η : ∀ {σ : Ty}, Param σ → S.toTypedOps.Dom σ) {Γ σ}
    (p : InfinitaryComprehension.Term Param Γ σ) (xs : S.toTypedOps.Env Γ) :
    let b := HTheorem.boxObject M.toModel (HOriginalEndpoint.toModel_endpointOS M hOS)
      (HOriginalICGrounding.comprehension_lift M hIC)
    let q := HExpandedSyntax.translate b η p
    M.eval (Formation.ground_context_closed Γ)
      (HOriginalTypes.groundTerm (OriginalCarrier.groundParam S) q)
      (groundTerm_formed (OriginalCarrier.groundParam S) q) (S.groundEnv xs) =
        Henkin.eval (canonical M hOS hIC) η p xs :=
  HTheorem.syntax_interpretation M.toModel (HOriginalEndpoint.toModel_endpointOS M hOS)
    (HOriginalICGrounding.comprehension_lift M hIC) η p xs

/-- Every actual original formula retains its entire proposition value,
not merely its current truth. All original carrier parameters are allowed. -/
theorem original_syntax_interpretation (p : HOriginalModel.OFormula S [])
    (hp : formed p) :
    M.eval Formation.context_nil p hp (HOriginalModel.envNil S) =
      Henkin.eval (canonical M hOS hIC) (HOriginalRetraction.liftParameter S)
        (HNativeInterpretation.embed p) Henkin.Env.nil :=
  (HOriginalRetraction.eval_original_formula S M p hp).symm.trans
    (HTheorem.native_syntax_interpretation M.toModel
      (HOriginalEndpoint.toModel_endpointOS M hOS)
      (HOriginalICGrounding.comprehension_lift M hIC)
      (HOriginalRetraction.liftParameter S) p HLanguage.Env.nil)

#print axioms full_standard_representation
#print axioms original_carriers_preserved
#print axioms grounded_syntax_interpretation
#print axioms original_syntax_interpretation

end Classicism.Research.InfinitaryComprehension.HOriginalTheorem
