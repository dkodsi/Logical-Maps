import Classicism.Results.Research.InfinitaryComprehensionHOriginalModel

/-!
# Original native syntax is retained by the grounding construction

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, section 4; misc, 26 October 2026, unpaginated.

Grounding fixes every already-original formed term, including its actual
infinitary children and all finite binders. Heterogeneous equality expresses
only the harmless context/type casts. The semantic corollary preserves the
current value of every original closed formula with arbitrary carrier
parameters. No new semantic or logical premise is added.
-/

namespace Classicism.Research.InfinitaryComprehension.HOriginalRetraction

open Classicism.Meta Grounding HOriginalTypes
open EndpointOriginalTypes (OriginalTypedOps)

universe u

theorem context_eq {Γ : Ctx} (hΓ : ContextClosed Γ) : groundCtx Γ = Γ := by
  induction Γ with
  | nil => rfl
  | cons σ Γ ih =>
      have h := Formation.context_cons.mp hΓ
      exact HLanguage.congrArg2 List.cons (groundTy_eq_of_closed σ h.1) (ih h.2)

private theorem zero_heq {Γ Δ : Ctx} {σ τ : Ty} (hΓ : Γ = Δ) (hσ : σ = τ) :
    HEq (.zero : Var (σ :: Γ) σ) (.zero : Var (τ :: Δ) τ) := by
  cases hΓ
  cases hσ
  rfl

private theorem succ_heq {Γ Δ : Ctx} {σ σ' τ τ' : Ty}
    (hΓ : Γ = Δ) (hσ : σ = σ') (hτ : τ = τ')
    {v : Var Γ σ} {w : Var Δ σ'} (h : HEq v w) :
    HEq (.succ v : Var (τ :: Γ) σ) (.succ w : Var (τ' :: Δ) σ') := by
  cases hΓ
  cases hσ
  cases hτ
  cases eq_of_heq h
  rfl

theorem variable_retract {Γ σ} (v : Var Γ σ) :
    ∀ hΓ : ContextClosed Γ, HEq (groundVar v) v := by
  induction v with
  | zero =>
      intro hΓ
      have h := Formation.context_cons.mp hΓ
      exact zero_heq (context_eq h.2) (groundTy_eq_of_closed _ h.1)
  | succ v ih =>
      intro hΓ
      have h := Formation.context_cons.mp hΓ
      exact succ_heq (context_eq h.2)
        (groundTy_eq_of_closed _ (Formation.var_type_closed h.2 v))
        (groundTy_eq_of_closed _ h.1) (ih h.2)

section Congruence

variable {P : Ty → Type u}

private theorem var_heq {Γ Δ : Ctx} {σ τ : Ty} (hΓ : Γ = Δ) (hσ : σ = τ)
    {v : Var Γ σ} {w : Var Δ τ} (h : HEq v w) :
    HEq (.var v : HLanguage.Term P Γ σ) (.var w : HLanguage.Term P Δ τ) := by
  cases hΓ
  cases hσ
  cases eq_of_heq h
  rfl

private theorem param_heq {Γ Δ : Ctx} {σ τ : Ty} (hΓ : Γ = Δ) (hσ : σ = τ)
    {a : P σ} {b : P τ} (h : HEq a b) :
    HEq (.param a : HLanguage.Term P Γ σ) (.param b : HLanguage.Term P Δ τ) := by
  cases hΓ
  cases hσ
  cases eq_of_heq h
  rfl

private theorem app_heq {Γ Δ : Ctx} {σ σ' : Ty} {ρ ρ' : RTy}
    (hΓ : Γ = Δ) (hσ : σ = σ') (hρ : ρ = ρ')
    {f : HLanguage.Term P Γ (σ ⇒ ρ)} {g : HLanguage.Term P Δ (σ' ⇒ ρ')}
    {a : HLanguage.Term P Γ σ} {b : HLanguage.Term P Δ σ'}
    (hf : HEq f g) (ha : HEq a b) :
    HEq (HLanguage.Term.app f a) (HLanguage.Term.app g b) := by
  cases hΓ
  cases hσ
  cases hρ
  cases eq_of_heq hf
  cases eq_of_heq ha
  rfl

private theorem constant_heq (op : ∀ {Γ : Ctx}, HLanguage.Formula P Γ)
    {Γ Δ : Ctx} (hΓ : Γ = Δ) : HEq (@op Γ) (@op Δ) := by
  cases hΓ
  rfl

private theorem unary_heq
    (op : ∀ {Γ : Ctx}, HLanguage.Formula P Γ → HLanguage.Formula P Γ)
    {Γ Δ : Ctx} (hΓ : Γ = Δ) {p : HLanguage.Formula P Γ} {q : HLanguage.Formula P Δ}
    (h : HEq p q) : HEq (op p) (op q) := by
  cases hΓ
  cases eq_of_heq h
  rfl

private theorem binary_heq
    (op : ∀ {Γ : Ctx}, HLanguage.Formula P Γ → HLanguage.Formula P Γ → HLanguage.Formula P Γ)
    {Γ Δ : Ctx} (hΓ : Γ = Δ) {p q : HLanguage.Formula P Γ} {r s : HLanguage.Formula P Δ}
    (hp : HEq p r) (hq : HEq q s) : HEq (op p q) (op r s) := by
  cases hΓ
  cases eq_of_heq hp
  cases eq_of_heq hq
  rfl

private theorem eq_heq {Γ Δ : Ctx} {σ τ : Ty} (hΓ : Γ = Δ) (hσ : σ = τ)
    {p q : HLanguage.Term P Γ σ} {r s : HLanguage.Term P Δ τ}
    (hp : HEq p r) (hq : HEq q s) : HEq (HLanguage.Term.eq p q) (HLanguage.Term.eq r s) := by
  cases hΓ
  cases hσ
  cases eq_of_heq hp
  cases eq_of_heq hq
  rfl

private theorem binder_heq
    (op : ∀ {Γ : Ctx} {σ : Ty}, HLanguage.Formula P (σ :: Γ) → HLanguage.Formula P Γ)
    {Γ Δ : Ctx} {σ τ : Ty} (hΓ : Γ = Δ) (hσ : σ = τ)
    {p : HLanguage.Formula P (σ :: Γ)} {q : HLanguage.Formula P (τ :: Δ)}
    (h : HEq p q) : HEq (op p) (op q) := by
  cases hΓ
  cases hσ
  cases eq_of_heq h
  rfl

private theorem infinitary_heq
    (op : ∀ {Γ : Ctx} (I : Type u), (I → HLanguage.Formula P Γ) → HLanguage.Formula P Γ)
    {Γ Δ : Ctx} (hΓ : Γ = Δ) (I : Type u)
    (p : I → HLanguage.Formula P Γ) (q : I → HLanguage.Formula P Δ)
    (h : ∀ i, HEq (p i) (q i)) : HEq (op I p) (op I q) := by
  cases hΓ
  have he : p = q := funext (fun i => eq_of_heq (h i))
  cases he
  rfl

end Congruence

/-- Grounding is the identity on formed original syntax whenever it fixes
the original parameter tokens. All context/type changes are only casts. -/
theorem ground_retract {P : Ty → Type u}
    (g : ∀ {σ : Ty}, P σ → P (groundTy σ))
    (hg : ∀ {σ : Ty} (a : P σ), σ.Closed → HEq (g a) a)
    {Γ σ} (p : HLanguage.Term P Γ σ) :
    ∀ (hΓ : ContextClosed Γ) (hp : formed p), HEq (groundTerm g p) p := by
  induction p with
  | var v =>
      intro hΓ hp
      exact var_heq (context_eq hΓ) (groundTy_eq_of_closed _ hp) (variable_retract v hΓ)
  | param a =>
      intro hΓ hp
      exact param_heq (context_eq hΓ) (groundTy_eq_of_closed _ hp) (hg a hp)
  | app f a ihf iha =>
      intro hΓ hp
      exact app_heq (context_eq hΓ)
        (groundTy_eq_of_closed _ (formed_result_type a hp.2))
        (groundRTy_eq_of_closed _ (formed_result_type f hp.1).2)
        (ihf hΓ hp.1) (iha hΓ hp.2)
  | top => intro hΓ _; exact constant_heq HLanguage.Term.top (context_eq hΓ)
  | bot => intro hΓ _; exact constant_heq HLanguage.Term.bot (context_eq hΓ)
  | neg p ih => intro hΓ hp; exact unary_heq HLanguage.Term.neg (context_eq hΓ) (ih hΓ hp)
  | conj p q ihp ihq =>
      intro hΓ hp
      exact binary_heq HLanguage.Term.conj (context_eq hΓ) (ihp hΓ hp.1) (ihq hΓ hp.2)
  | disj p q ihp ihq =>
      intro hΓ hp
      exact binary_heq HLanguage.Term.disj (context_eq hΓ) (ihp hΓ hp.1) (ihq hΓ hp.2)
  | imp p q ihp ihq =>
      intro hΓ hp
      exact binary_heq HLanguage.Term.imp (context_eq hΓ) (ihp hΓ hp.1) (ihq hΓ hp.2)
  | iff p q ihp ihq =>
      intro hΓ hp
      exact binary_heq HLanguage.Term.iff (context_eq hΓ) (ihp hΓ hp.1) (ihq hΓ hp.2)
  | eq p q ihp ihq =>
      intro hΓ hp
      exact eq_heq (context_eq hΓ) (groundTy_eq_of_closed _ (formed_result_type p hp.1))
        (ihp hΓ hp.1) (ihq hΓ hp.2)
  | all p ih =>
      intro hΓ hp
      exact binder_heq HLanguage.Term.all (context_eq hΓ) (groundTy_eq_of_closed _ hp.1)
        (ih (Formation.context_cons.mpr ⟨hp.1,hΓ⟩) hp.2)
  | ex p ih =>
      intro hΓ hp
      exact binder_heq HLanguage.Term.ex (context_eq hΓ) (groundTy_eq_of_closed _ hp.1)
        (ih (Formation.context_cons.mpr ⟨hp.1,hΓ⟩) hp.2)
  | iAnd I p ih =>
      intro hΓ hp
      exact infinitary_heq HLanguage.Term.iAnd (context_eq hΓ) I _ _ (fun i => ih i hΓ (hp i))
  | iOr I p ih =>
      intro hΓ hp
      exact infinitary_heq HLanguage.Term.iOr (context_eq hΓ) I _ _ (fun i => ih i hΓ (hp i))

variable (S : OriginalTypedOps.{u})

/-- An original carrier token, interpreted in the lifted carrier at the
same original type; the equality is already proved by closed grounding. -/
def liftParameter {σ : Ty} : OriginalCarrier S σ → S.toTypedOps.Dom σ
  | .value h a => cast (S.closed_domain σ h).symm a

private theorem cast_value_heq {α β : Type u} (h : α = β) (a : α) : HEq (cast h a) a := by
  cases h
  rfl

private theorem carrier_value_heq {σ τ : Ty} (h : σ = τ)
    (hσ : σ.Closed) (hτ : τ.Closed) (a : S.Dom σ hσ) (b : S.Dom τ hτ)
    (hab : HEq a b) : HEq (OriginalCarrier.value hσ a) (OriginalCarrier.value hτ b) := by
  cases h
  cases eq_of_heq hab
  rfl

theorem parameter_roundtrip {σ : Ty} (a : OriginalCarrier S σ) :
    HEq (OriginalCarrier.groundParam S (liftParameter S a)) a := by
  cases a with
  | value h a =>
      exact carrier_value_heq S (groundTy_eq_of_closed σ h)
        (groundTy_closed σ) h _ a (cast_value_heq (S.closed_domain σ h).symm a)

theorem ground_mapParam {P P' P'' : Ty → Type u}
    (g : ∀ {σ}, P' σ → P'' (groundTy σ)) (f : ∀ {σ}, P σ → P' σ)
    {Γ σ} (p : HLanguage.Term P Γ σ) :
    groundTerm g (p.mapParam f) = groundTerm (fun a => g (f a)) p := by
  induction p with
  | var | param | top | bot => rfl
  | app p q ihp ihq => exact HLanguage.congrArg2 HLanguage.Term.app ihp ihq
  | neg p ih => exact congrArg HLanguage.Term.neg ih
  | conj p q ihp ihq => exact HLanguage.congrArg2 HLanguage.Term.conj ihp ihq
  | disj p q ihp ihq => exact HLanguage.congrArg2 HLanguage.Term.disj ihp ihq
  | imp p q ihp ihq => exact HLanguage.congrArg2 HLanguage.Term.imp ihp ihq
  | iff p q ihp ihq => exact HLanguage.congrArg2 HLanguage.Term.iff ihp ihq
  | eq p q ihp ihq => exact HLanguage.congrArg2 HLanguage.Term.eq ihp ihq
  | all p ih => exact congrArg HLanguage.Term.all ih
  | ex p ih => exact congrArg HLanguage.Term.ex ih
  | iAnd I p ih => exact congrArg (HLanguage.Term.iAnd I) (funext ih)
  | iOr I p ih => exact congrArg (HLanguage.Term.iOr I) (funext ih)

/-- The actual source-to-implementation-to-source syntax round trip. -/
theorem original_term_retract {Γ σ} (hΓ : ContextClosed Γ)
    (p : HOriginalModel.OTerm S Γ σ) (hp : formed p) :
    HEq (groundTerm (OriginalCarrier.groundParam S) (p.mapParam (liftParameter S))) p := by
  rw [ground_mapParam]
  exact ground_retract (fun a => OriginalCarrier.groundParam S (liftParameter S a))
    (fun a _ => parameter_roundtrip S a) p hΓ hp

/-- Original closed formulas keep their exact original proposition value,
including arbitrary simultaneous original carrier parameters. -/
theorem eval_original_formula (M : HOriginalModel.Model S)
    (p : HOriginalModel.OFormula S []) (hp : formed p) :
    M.toModel.eval (p.mapParam (liftParameter S)) HLanguage.Env.nil =
      M.eval Formation.context_nil p hp (HOriginalModel.envNil S) := by
  change M.eval Formation.context_nil
    (groundTerm (OriginalCarrier.groundParam S) (p.mapParam (liftParameter S))) _
    (HOriginalModel.envNil S) = _
  exact M.eval_congr Formation.context_nil
    (eq_of_heq (original_term_retract S Formation.context_nil p hp)) _ _ (HOriginalModel.envNil S)

#print axioms ground_retract
#print axioms original_term_retract
#print axioms eval_original_formula

end Classicism.Research.InfinitaryComprehension.HOriginalRetraction
