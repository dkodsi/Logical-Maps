import Classicism.Results.Research.InfinitaryComprehensionHExpandedSyntax
import Classicism.Results.Research.InfinitaryComprehensionHBootstrap
import Classicism.Results.Research.InfinitaryComprehensionEndpointAssembly

/-!
# Construct the concrete evaluator adapter

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 3--4; misc, 26 October 2026, unpaginated.

The raw input interprets actual native H terms, including primitive finite
binders. The only normalization premises of this intermediate theorem are
single-variable raw binder normalizations and identities of the admitted
infinitary operations. The H/OS/IC bootstrap discharges these separately.
No equality with the canonical evaluator is assumed: it is proved here by
structural induction on the actual expanded infinitary term.

For a binder in a nonempty outer context, capture-avoiding substitution
first closes precisely those outer variables into carrier parameters. Its
denotation is preserved by the ordinary substitution law. The unary raw
binder theorem then applies to that actual matrix code. There is no
function-to-code constructor and no external-function comprehension.
-/

namespace Classicism.Research.InfinitaryComprehension.HInterpretation

open Classicism.Meta EndpointCanonical EndpointAtoms

universe u

variable {S : TypedOps.{u}} (M : HModel.Model S)

/-- Close the outer variables of a raw matrix, retaining its bound argument. -/
def outerCode {Γ σ τ} (p : HLanguage.Term S.Dom (σ :: Γ) τ)
    (xs : HLanguage.Env S.Dom Γ) : HLanguage.Term S.Dom [σ] τ :=
  p.subst (HLanguage.Subst.lift (fun v => .param (xs v)))

theorem eval_outerCode {Γ σ τ} (p : HLanguage.Term S.Dom (σ :: Γ) τ)
    (xs : HLanguage.Env S.Dom Γ) (a : S.Dom σ) :
    M.eval (outerCode p xs) (HLanguage.Env.cons a HLanguage.Env.nil) =
      M.eval p (HLanguage.Env.cons a xs) := by
  rw [outerCode, M.eval_subst]
  apply congrArg (fun env : HLanguage.Env S.Dom (σ :: Γ) => M.eval p env)
  funext ρ v
  cases v with
  | zero => exact M.eval_var .zero (HLanguage.Env.cons a HLanguage.Env.nil)
  | succ v => exact M.eval_param (xs v) (HLanguage.Env.cons a HLanguage.Env.nil)

theorem eval_all_outer {Γ σ} (p : HLanguage.Formula S.Dom (σ :: Γ))
    (xs : HLanguage.Env S.Dom Γ) :
    M.eval (.all p) xs = M.eval (.all (outerCode p xs)) HLanguage.Env.nil :=
  (M.eval_closed_subst (.all p) xs).symm

theorem eval_ex_outer {Γ σ} (p : HLanguage.Formula S.Dom (σ :: Γ))
    (xs : HLanguage.Env S.Dom Γ) :
    M.eval (.ex p) xs = M.eval (.ex (outerCode p xs)) HLanguage.Env.nil :=
  (M.eval_closed_subst (.ex p) xs).symm

/-- The uniform finite closure agrees syntactically with a single binder. -/
theorem universalClosure_single {σ} (p : HLanguage.Formula S.Dom [σ]) :
    p.universalClosure = .all p := by
  have he : @Eq (HLanguage.Ren [σ] [σ])
      (HLanguage.Ren.embed [σ] []) HLanguage.Ren.id := by
    funext τ v
    cases v with
    | zero => rfl
    | succ v => nomatch v
  change HLanguage.Term.all (p.rename (HLanguage.Ren.embed [σ] [])) = .all p
  rw [he, HLanguage.Term.rename_id]

variable {O : Type u} (A : QuantifiedEndpoints S.core O) (L : A.Infima)

variable
  (all_value : ∀ (σ : Ty) (p : HLanguage.Formula S.Dom [σ]),
    M.eval (.all p) HLanguage.Env.nil =
      L.inf (S.Dom σ) (fun x => M.eval p (HLanguage.Env.cons x HLanguage.Env.nil)))
  (ex_value : ∀ (σ : Ty) (p : HLanguage.Formula S.Dom [σ]),
    M.eval (.ex p) HLanguage.Env.nil =
      A.Sup L (S.Dom σ) (fun x => M.eval p (HLanguage.Env.cons x HLanguage.Env.nil)))

include all_value in
theorem eval_all {Γ σ} (p : HLanguage.Formula S.Dom (σ :: Γ))
    (xs : HLanguage.Env S.Dom Γ) :
    M.eval (.all p) xs = L.inf (S.Dom σ) (fun x => M.eval p (HLanguage.Env.cons x xs)) := by
  rw [eval_all_outer M p xs, all_value]
  apply congrArg (L.inf (S.Dom σ))
  funext x
  exact eval_outerCode M p xs x

include ex_value in
theorem eval_ex {Γ σ} (p : HLanguage.Formula S.Dom (σ :: Γ))
    (xs : HLanguage.Env S.Dom Γ) :
    M.eval (.ex p) xs = A.Sup L (S.Dom σ) (fun x => M.eval p (HLanguage.Env.cons x xs)) := by
  rw [eval_ex_outer M p xs, ex_value]
  apply congrArg (A.Sup L (S.Dom σ))
  funext x
  exact eval_outerCode M p xs x

variable
  (inf_value : ∀ (I : Type u) (f : I → S.Dom Ty.t), M.iAnd I f = L.inf I f)
  (sup_value : ∀ (I : Type u) (f : I → S.Dom Ty.t), M.iOr I f = A.Sup L I f)
  (boxObj : S.Dom (RTy.t ⇒ RTy.t))
  (box_value : ∀ p : S.Dom Ty.t, S.app boxObj p = S.eq p S.core.top)
  (eq_observed : ∀ {σ : Ty} (a b : S.Dom σ) (E : O), A.Accepts E (S.eq a b) ↔ a = b)

include all_value ex_value inf_value sup_value

/-- Structural equality of denotations for the actual expanded grammar.
The necessity-object case is interpreted by its supplied finite IC witness;
its native application equation is retained in the canonical-model input. -/
theorem eval_compatible {Param : Ty → Type u}
    (η : ∀ {σ : Ty}, Param σ → S.Dom σ) :
    ∀ {Γ σ} (p : InfinitaryComprehension.Term Param Γ σ) (xs : S.Env Γ),
      M.eval (HExpandedSyntax.translate boxObj η p) xs =
        Henkin.eval (model S A L boxObj box_value eq_observed) η p xs := by
  intro Γ σ p
  induction p with
  | var v => intro xs; exact M.eval_var v xs
  | param p => intro xs; exact M.eval_param (η p) xs
  | app p q ihp ihq =>
      intro xs
      change M.eval (.app (HExpandedSyntax.translate boxObj η p)
        (HExpandedSyntax.translate boxObj η q)) xs = S.app _ _
      rw [M.eval_app]
      exact HLanguage.congrArg2 S.app (ihp xs) (ihq xs)
  | top => intro xs; exact M.eval_top xs
  | bot => intro xs; exact M.eval_bot xs
  | neg p ih =>
      intro xs
      change M.eval (.neg (HExpandedSyntax.translate boxObj η p)) xs = S.neg _
      rw [M.eval_neg]
      exact congrArg S.neg (ih xs)
  | conj p q ihp ihq =>
      intro xs
      change M.eval (.conj (HExpandedSyntax.translate boxObj η p)
        (HExpandedSyntax.translate boxObj η q)) xs = S.conj _ _
      rw [M.eval_conj]
      exact HLanguage.congrArg2 S.conj (ihp xs) (ihq xs)
  | disj p q ihp ihq =>
      intro xs
      change M.eval (.disj (HExpandedSyntax.translate boxObj η p)
        (HExpandedSyntax.translate boxObj η q)) xs = S.disj _ _
      rw [M.eval_disj]
      exact HLanguage.congrArg2 S.disj (ihp xs) (ihq xs)
  | imp p q ihp ihq =>
      intro xs
      change M.eval (.imp (HExpandedSyntax.translate boxObj η p)
        (HExpandedSyntax.translate boxObj η q)) xs = S.core.imp _ _
      rw [M.eval_imp]
      exact HLanguage.congrArg2 S.core.imp (ihp xs) (ihq xs)
  | iff p q ihp ihq =>
      intro xs
      change M.eval (.iff (HExpandedSyntax.translate boxObj η p)
        (HExpandedSyntax.translate boxObj η q)) xs = S.core.iff _ _
      rw [M.eval_iff]
      exact HLanguage.congrArg2 S.core.iff (ihp xs) (ihq xs)
  | eq p q ihp ihq =>
      intro xs
      change M.eval (.eq (HExpandedSyntax.translate boxObj η p)
        (HExpandedSyntax.translate boxObj η q)) xs = S.eq _ _
      rw [M.eval_eq]
      exact HLanguage.congrArg2 S.eq (ihp xs) (ihq xs)
  | boxOp => intro xs; exact M.eval_param boxObj xs
  | all p ih =>
      intro xs
      change M.eval (.all (HExpandedSyntax.translate boxObj η p)) xs =
        L.inf _ (fun x => Henkin.eval (model S A L boxObj box_value eq_observed)
          η p (Henkin.Env.cons x xs))
      rw [eval_all M A L all_value]
      apply congrArg (L.inf _)
      funext x
      exact ih (HLanguage.Env.cons x xs)
  | ex p ih =>
      intro xs
      change M.eval (.ex (HExpandedSyntax.translate boxObj η p)) xs =
        A.Sup L _ (fun x => Henkin.eval (model S A L boxObj box_value eq_observed)
          η p (Henkin.Env.cons x xs))
      rw [eval_ex M A L ex_value]
      apply congrArg (A.Sup L _)
      funext x
      exact ih (HLanguage.Env.cons x xs)
  | iAnd I p ih =>
      intro xs
      change M.eval (.iAnd I (fun i => HExpandedSyntax.translate boxObj η (p i))) xs =
        L.inf I (fun i => Henkin.eval (model S A L boxObj box_value eq_observed) η (p i) xs)
      rw [M.eval_iAnd, inf_value]
      apply congrArg (L.inf I)
      exact funext (fun i => ih i xs)
  | iOr I p ih =>
      intro xs
      change M.eval (.iOr I (fun i => HExpandedSyntax.translate boxObj η (p i))) xs =
        A.Sup L I (fun i => Henkin.eval (model S A L boxObj box_value eq_observed) η (p i) xs)
      rw [M.eval_iOr, sup_value]
      apply congrArg (A.Sup L I)
      exact funext (fun i => ih i xs)

/-- The previously abstract syntax adapter is now a concrete construction.
Its matrix carrier is actual native H syntax and its evaluation law is the
structural theorem above. -/
def interpretation :
    EndpointAssembly.MatrixInterpretation.{u,u+1} S A L boxObj box_value eq_observed where
  matrices := HBootstrap.matrices M
  code := fun {Param} η {Γ} p => HExpandedSyntax.translate boxObj η p
  code_eval := fun {Param} η {Γ} p xs =>
    eval_compatible M A L all_value ex_value inf_value sup_value
      boxObj box_value eq_observed η p xs

/-- Native IC supplies the actual comprehension premise of the constructed
adapter, by the separately proved witness-extraction theorem. -/
theorem interpretation_comprehension (hIC : M.Comprehension) (Γ : Ctx) :
    ((interpretation M A L all_value ex_value inf_value sup_value
      boxObj box_value eq_observed).matrices Γ).Comprehension :=
  HBootstrap.comprehension M hIC Γ

theorem interpretation_ui (Γ : Ctx) :
    ((interpretation M A L all_value ex_value inf_value sup_value
      boxObj box_value eq_observed).matrices Γ).NecessaryUI :=
  HBootstrap.ui M Γ

#print axioms eval_compatible
#print axioms interpretation
#print axioms interpretation_comprehension

end Classicism.Research.InfinitaryComprehension.HInterpretation
