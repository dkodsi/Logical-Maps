import Classicism.Results.Research.InfinitaryComprehensionHEndpoint
import Classicism.Results.Research.InfinitaryComprehensionHInterpretation

/-!
# Full standard representation from native H, endpoint OS and IC

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 1--4; misc, 26 October 2026, unpaginated.

This assembles the concrete syntax interpretation. Its starting premises are
an ordinary current interpretation of the native lambda-free H language with
theorem-only logical necessitation, the full typed endpoint OS schema, and
the native boxed-existential Infinitary Comprehension schema. All canonical
worlds, modal and intensional laws, typed equality rigidity, necessity's
operation object, and evaluation compatibility are derived constructions.
The original-type source adapter is applied in HOriginalTheorem.
-/

namespace Classicism.Research.InfinitaryComprehension.HTheorem

open Classicism.Meta EndpointCanonical HEndpoint

universe u

variable {S : TypedOps.{u}} (M : HModel.Model S)
variable (hOS : EndpointOS M) (hIC : M.Comprehension)

noncomputable def boxObject : S.Dom (Ty.t ⇒ RTy.t) :=
  Classical.choose (HBootstrap.boxRepresentative_exists M (separation M hOS [Ty.t]) hIC)

theorem box_value (p : S.Dom Ty.t) :
    S.app (boxObject M hOS hIC) p = S.eq p S.core.top :=
  Classical.choose_spec (HBootstrap.boxRepresentative_exists M (separation M hOS [Ty.t]) hIC) p

noncomputable def canonical : Henkin.Model.{u} :=
  EndpointCanonical.model S (observers M hOS hIC) (infima M hOS hIC)
    (boxObject M hOS hIC) (box_value M hOS hIC) (observed_equality M hOS hIC)

noncomputable def interpretation :
    EndpointAssembly.MatrixInterpretation.{u,u+1} S (observers M hOS hIC) (infima M hOS hIC)
      (boxObject M hOS hIC) (box_value M hOS hIC) (observed_equality M hOS hIC) :=
  HInterpretation.interpretation M (observers M hOS hIC) (infima M hOS hIC)
    (all_value M hOS hIC) (ex_value M hOS hIC) (fun _ _ => rfl)
    (sup_value M hOS hIC) (boxObject M hOS hIC) (box_value M hOS hIC)
    (observed_equality M hOS hIC)

/-- The full forward theorem: no abstract syntax interpretation, binder
normalization, equality reflection or full-carrier premise remains. -/
theorem full_standard_representation :
    ∃ w : (canonical M hOS hIC).World,
      (∀ p : S.Dom Ty.t, (canonical M hOS hIC).truth p w ↔ S.truth p) ∧
      EndpointFullness.FullStandard (canonical M hOS hIC) w := by
  exact EndpointAssembly.full_standard_representation S
    (observers M hOS hIC) (infima M hOS hIC)
    (boxObject M hOS hIC) (box_value M hOS hIC) (observed_equality M hOS hIC)
    (interpretation M hOS hIC) (typed_separation M hOS hIC)
    M.truth_iAnd (HBootstrap.ui M) (HBootstrap.comprehension M hIC)

/-- Every typed carrier is retained literally by the reconstructed model. -/
theorem carrier_preserved (σ : Ty) : (canonical M hOS hIC).Dom σ = S.Dom σ := rfl

theorem application_preserved {σ : Ty} {ρ : RTy}
    (f : S.Dom (σ ⇒ ρ)) (x : S.Dom σ) :
    (canonical M hOS hIC).app f x = S.app f x := rfl

/-- The evaluation theorem includes arbitrary simultaneous parameters,
actual infinitary matrices and all primitive finite binder constructors. -/
theorem syntax_interpretation {Param : Ty → Type u}
    (η : ∀ {σ}, Param σ → S.Dom σ) {Γ σ}
    (p : InfinitaryComprehension.Term Param Γ σ) (xs : S.Env Γ) :
    M.eval (HExpandedSyntax.translate (boxObject M hOS hIC) η p) xs =
      Henkin.eval (canonical M hOS hIC) η p xs :=
  HInterpretation.eval_compatible M (observers M hOS hIC) (infima M hOS hIC)
    (all_value M hOS hIC) (ex_value M hOS hIC) (fun _ _ => rfl)
    (sup_value M hOS hIC) (boxObject M hOS hIC) (box_value M hOS hIC)
    (observed_equality M hOS hIC) η p xs

#print axioms full_standard_representation
#print axioms carrier_preserved
#print axioms application_preserved
#print axioms syntax_interpretation

end Classicism.Research.InfinitaryComprehension.HTheorem
