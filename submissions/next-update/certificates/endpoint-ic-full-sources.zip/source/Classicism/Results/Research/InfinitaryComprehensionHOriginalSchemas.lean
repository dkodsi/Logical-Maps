import Classicism.Results.Research.InfinitaryComprehensionHOriginalModel

/-!
# Original-language comprehension and its grounding transport

Original research, misc, 26 October 2026. Schema assumptions in this module
range over formed native formulas and finite contexts of original closed
types. Auxiliary implementation types are introduced only by the explicit
syntax translation. No extra source comprehension instance is postulated.
-/

namespace Classicism.Research.InfinitaryComprehension.HOriginalSchemas

open Classicism.Meta Grounding HOriginalTypes
open EndpointOriginalTypes (OriginalTypedOps)

universe u

variable {Param : Ty → Type u}

theorem formed_applyVars (Γ : Ctx) :
    ∀ {Δ : Ctx} (R : HLanguage.Term Param Δ (RTy.ofArgs Γ))
      (xs : ∀ {σ}, Var Γ σ → HLanguage.Term Param Δ σ),
      formed R → (∀ {σ} (v : Var Γ σ), formed (xs v)) →
        formed (HLanguage.Term.applyVars Γ R xs) := by
  induction Γ with
  | nil => intro Δ R xs hR _; exact hR
  | cons σ Γ ih =>
      intro Δ R xs hR hxs
      exact ih (.app R (xs .zero)) (fun v => xs (.succ v))
        ⟨hR, hxs .zero⟩ (fun v => hxs (.succ v))

theorem formed_closeAll (Γ : Ctx) (hΓ : ContextClosed Γ) :
    ∀ {Δ : Ctx} (A : HLanguage.Formula Param (Γ ++ Δ)),
      formed A → formed (HLanguage.Term.closeAll Γ A) := by
  induction Γ with
  | nil => intro Δ A hA; exact hA
  | cons σ Γ ih =>
      intro Δ A hA
      exact ih (Formation.context_cons.mp hΓ).2 (.all A)
        ⟨(Formation.context_cons.mp hΓ).1, hA⟩

theorem formed_compBody {Γ : Ctx} (hΓ : ContextClosed Γ)
    (A : HLanguage.Formula Param Γ) (hA : formed A) : formed A.compBody := by
  refine ⟨?_, (formed_rename_iff A (HLanguage.Ren.embed Γ _)).2 hA⟩
  apply formed_applyVars Γ
  · exact Formation.ofArgs_closed Γ hΓ
  · intro σ v
    exact Formation.var_type_closed hΓ v

theorem formed_repBody {Γ : Ctx} (hΓ : ContextClosed Γ)
    (A : HLanguage.Formula Param Γ) (hA : formed A) : formed A.repBody :=
  ⟨formed_closeAll Γ hΓ A.compBody (formed_compBody hΓ A hA), trivial⟩

theorem formed_comprehension {Γ : Ctx} (hΓ : ContextClosed Γ)
    (A : HLanguage.Formula Param Γ) (hA : formed A) : formed A.comprehension :=
  ⟨Formation.ofArgs_closed Γ hΓ, formed_repBody hΓ A hA⟩

theorem formed_same {Γ : Ctx} (hΓ : ContextClosed Γ)
    (A B : HLanguage.Formula Param Γ) (hA : formed A) (hB : formed B) :
    formed (HLanguage.Term.sameFormula A B) :=
  ⟨Formation.ofArgs_closed Γ hΓ, formed_repBody hΓ A hA, formed_repBody hΓ B hB⟩

/-- Exactly the original closed-type, native infinitary comprehension schema. -/
def Comprehension {S : OriginalTypedOps.{u}} (M : HOriginalModel.Model S) : Prop :=
  ∀ {Γ : Ctx} (hΓ : ContextClosed Γ) (A : HOriginalModel.OFormula S Γ)
    (hA : formed A),
    S.truth (M.eval Formation.context_nil A.comprehension
      (formed_comprehension hΓ A hA) (HOriginalModel.envNil S))


#print axioms formed_comprehension
#print axioms formed_same

end Classicism.Research.InfinitaryComprehension.HOriginalSchemas
