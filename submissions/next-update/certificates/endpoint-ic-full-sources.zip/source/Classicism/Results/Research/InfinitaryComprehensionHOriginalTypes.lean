import Classicism.Results.Research.InfinitaryComprehensionEndpointOriginalTypes
import Classicism.Results.Research.InfinitaryComprehensionHLanguage

/-!
# Ground the native lambda-free H grammar to original types

Original research, misc, 26 October 2026. This is the explicit syntactic
translation for the original-type endpoint construction. The native source
and target grammar have no primitive necessity object or lambda constructor.
Every auxiliary type is translated to an original closed type, while all
finite variable positions and arbitrary infinitary index sets are retained.

Original parameter tokens contain an original closed-type proof and an
actual original carrier value. There are no parameter values at auxiliary
variable types, and no original axiom schema will be required there.
-/

namespace Classicism.Research.InfinitaryComprehension.HOriginalTypes

open Classicism.Meta Grounding
open EndpointOriginalTypes (OriginalTypedOps)

universe u

abbrev ContextClosed := Formation.ContextClosed

def formed {Param : Ty → Type u} :
    {Γ : Ctx} → {σ : Ty} → HLanguage.Term Param Γ σ → Prop
  | _, σ, .var _ => σ.Closed
  | _, σ, .param _ => σ.Closed
  | _, _, .app f a => formed f ∧ formed a
  | _, _, .top => True
  | _, _, .bot => True
  | _, _, .neg p => formed p
  | _, _, .conj p q => formed p ∧ formed q
  | _, _, .disj p q => formed p ∧ formed q
  | _, _, .imp p q => formed p ∧ formed q
  | _, _, .iff p q => formed p ∧ formed q
  | _, _, .eq a b => formed a ∧ formed b
  | _, _, .all (σ := σ) p => σ.Closed ∧ formed p
  | _, _, .ex (σ := σ) p => σ.Closed ∧ formed p
  | _, _, .iAnd _ p => ∀ i, formed (p i)
  | _, _, .iOr _ p => ∀ i, formed (p i)

theorem formed_result_type {Param : Ty → Type u} {Γ σ}
    (p : HLanguage.Term Param Γ σ) (hp : formed p) : σ.Closed := by
  induction p with
  | var => exact hp
  | param => exact hp
  | app f a ihf _ => exact (ihf hp.1).2
  | top | bot | neg | conj | disj | imp | iff | eq | all | ex | iAnd | iOr => trivial

theorem formed_rename_iff {Param : Ty → Type u} {Γ σ}
    (p : HLanguage.Term Param Γ σ) :
    ∀ {Δ} (r : HLanguage.Ren Γ Δ), formed (p.rename r) ↔ formed p := by
  induction p with
  | var | param | top | bot => intros; rfl
  | app f a ihf iha => intro Δ r; exact and_congr (ihf r) (iha r)
  | neg p ih => intro Δ r; exact ih r
  | conj p q ihp ihq => intro Δ r; exact and_congr (ihp r) (ihq r)
  | disj p q ihp ihq => intro Δ r; exact and_congr (ihp r) (ihq r)
  | imp p q ihp ihq => intro Δ r; exact and_congr (ihp r) (ihq r)
  | iff p q ihp ihq => intro Δ r; exact and_congr (ihp r) (ihq r)
  | eq p q ihp ihq => intro Δ r; exact and_congr (ihp r) (ihq r)
  | all p ih => intro Δ r; exact and_congr Iff.rfl (ih (HLanguage.Ren.lift r))
  | ex p ih => intro Δ r; exact and_congr Iff.rfl (ih (HLanguage.Ren.lift r))
  | iAnd I p ih => intro Δ r; exact forall_congr' (fun i => ih i r)
  | iOr I p ih => intro Δ r; exact forall_congr' (fun i => ih i r)

theorem formed_subst {Param : Ty → Type u} {Γ σ}
    (p : HLanguage.Term Param Γ σ) :
    ∀ {Δ} (s : HLanguage.Subst Param Γ Δ), formed p →
      (∀ {τ} (v : Var Γ τ), formed (s v)) → formed (p.subst s) := by
  induction p with
  | var v => intro Δ s _ hs; exact hs v
  | param p => intro Δ s hp _; exact hp
  | app f a ihf iha => intro Δ s hp hs; exact ⟨ihf s hp.1 hs, iha s hp.2 hs⟩
  | top | bot => intros; trivial
  | neg p ih => intro Δ s hp hs; exact ih s hp hs
  | conj p q ihp ihq => intro Δ s hp hs; exact ⟨ihp s hp.1 hs, ihq s hp.2 hs⟩
  | disj p q ihp ihq => intro Δ s hp hs; exact ⟨ihp s hp.1 hs, ihq s hp.2 hs⟩
  | imp p q ihp ihq => intro Δ s hp hs; exact ⟨ihp s hp.1 hs, ihq s hp.2 hs⟩
  | iff p q ihp ihq => intro Δ s hp hs; exact ⟨ihp s hp.1 hs, ihq s hp.2 hs⟩
  | eq p q ihp ihq => intro Δ s hp hs; exact ⟨ihp s hp.1 hs, ihq s hp.2 hs⟩
  | all p ih =>
      intro Δ s hp hs
      refine ⟨hp.1, ih (HLanguage.Subst.lift s) hp.2 ?_⟩
      intro τ v
      cases v with
      | zero => exact hp.1
      | succ v => exact (formed_rename_iff (s v) HLanguage.Ren.shift).2 (hs v)
  | ex p ih =>
      intro Δ s hp hs
      refine ⟨hp.1, ih (HLanguage.Subst.lift s) hp.2 ?_⟩
      intro τ v
      cases v with
      | zero => exact hp.1
      | succ v => exact (formed_rename_iff (s v) HLanguage.Ren.shift).2 (hs v)
  | iAnd I p ih => intro Δ s hp hs i; exact ih i s (hp i) hs
  | iOr I p ih => intro Δ s hp hs i; exact ih i s (hp i) hs

def groundTerm {Param Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ)) :
    {Γ : Ctx} → {σ : Ty} → HLanguage.Term Param Γ σ →
      HLanguage.Term Param' (groundCtx Γ) (groundTy σ)
  | _, _, .var v => .var (groundVar v)
  | _, _, .param p => .param (mapParam p)
  | _, _, .app f a => .app (groundTerm mapParam f) (groundTerm mapParam a)
  | _, _, .top => .top
  | _, _, .bot => .bot
  | _, _, .neg p => .neg (groundTerm mapParam p)
  | _, _, .conj p q => .conj (groundTerm mapParam p) (groundTerm mapParam q)
  | _, _, .disj p q => .disj (groundTerm mapParam p) (groundTerm mapParam q)
  | _, _, .imp p q => .imp (groundTerm mapParam p) (groundTerm mapParam q)
  | _, _, .iff p q => .iff (groundTerm mapParam p) (groundTerm mapParam q)
  | _, _, .eq a b => .eq (groundTerm mapParam a) (groundTerm mapParam b)
  | _, _, .all p => .all (groundTerm mapParam p)
  | _, _, .ex p => .ex (groundTerm mapParam p)
  | _, _, .iAnd I p => .iAnd I (fun i => groundTerm mapParam (p i))
  | _, _, .iOr I p => .iOr I (fun i => groundTerm mapParam (p i))

theorem groundTerm_formed {Param Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ))
    {Γ σ} (p : HLanguage.Term Param Γ σ) : formed (groundTerm mapParam p) := by
  induction p with
  | var | param => exact groundTy_closed _
  | app f a ihf iha => exact ⟨ihf, iha⟩
  | top | bot => trivial
  | neg p ih => exact ih
  | conj p q ihp ihq => exact ⟨ihp, ihq⟩
  | disj p q ihp ihq => exact ⟨ihp, ihq⟩
  | imp p q ihp ihq => exact ⟨ihp, ihq⟩
  | iff p q ihp ihq => exact ⟨ihp, ihq⟩
  | eq p q ihp ihq => exact ⟨ihp, ihq⟩
  | all p ih => exact ⟨groundTy_closed _, ih⟩
  | ex p ih => exact ⟨groundTy_closed _, ih⟩
  | iAnd I p ih => exact ih
  | iOr I p ih => exact ih

theorem groundTerm_box {Param Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ))
    {Γ} (p : HLanguage.Formula Param Γ) :
    groundTerm mapParam p.box = (groundTerm mapParam p).box := rfl

theorem groundTerm_rename {Param Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ)) :
    ∀ {Γ σ} (p : HLanguage.Term Param Γ σ) {Δ}
      (r : HLanguage.Ren Γ Δ)
      (s : HLanguage.Ren (groundCtx Γ) (groundCtx Δ)),
      (∀ {τ} (v : Var Γ τ), s (groundVar v) = groundVar (r v)) →
      groundTerm mapParam (p.rename r) = (groundTerm mapParam p).rename s := by
  intro Γ σ p
  induction p with
  | var v => intro Δ r s h; exact congrArg HLanguage.Term.var (h v).symm
  | param p => intros; rfl
  | app f a ihf iha =>
      intro Δ r s h
      exact HLanguage.congrArg2 HLanguage.Term.app (ihf r s h) (iha r s h)
  | top | bot => intros; rfl
  | neg p ih => intro Δ r s h; exact congrArg HLanguage.Term.neg (ih r s h)
  | conj p q ihp ihq =>
      intro Δ r s h
      exact HLanguage.congrArg2 HLanguage.Term.conj (ihp r s h) (ihq r s h)
  | disj p q ihp ihq =>
      intro Δ r s h
      exact HLanguage.congrArg2 HLanguage.Term.disj (ihp r s h) (ihq r s h)
  | imp p q ihp ihq =>
      intro Δ r s h
      exact HLanguage.congrArg2 HLanguage.Term.imp (ihp r s h) (ihq r s h)
  | iff p q ihp ihq =>
      intro Δ r s h
      exact HLanguage.congrArg2 HLanguage.Term.iff (ihp r s h) (ihq r s h)
  | eq p q ihp ihq =>
      intro Δ r s h
      exact HLanguage.congrArg2 HLanguage.Term.eq (ihp r s h) (ihq r s h)
  | all p ih =>
      intro Δ r s h
      apply congrArg HLanguage.Term.all
      apply ih (HLanguage.Ren.lift r) (HLanguage.Ren.lift s)
      intro τ v
      cases v with
      | zero => rfl
      | succ v => exact congrArg Var.succ (h v)
  | ex p ih =>
      intro Δ r s h
      apply congrArg HLanguage.Term.ex
      apply ih (HLanguage.Ren.lift r) (HLanguage.Ren.lift s)
      intro τ v
      cases v with
      | zero => rfl
      | succ v => exact congrArg Var.succ (h v)
  | iAnd I p ih =>
      intro Δ r s h
      exact congrArg (HLanguage.Term.iAnd I) (funext (fun i => ih i r s h))
  | iOr I p ih =>
      intro Δ r s h
      exact congrArg (HLanguage.Term.iOr I) (funext (fun i => ih i r s h))

theorem groundTerm_subst {Param Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ)) :
    ∀ {Γ σ} (p : HLanguage.Term Param Γ σ) {Δ}
      (s : HLanguage.Subst Param Γ Δ)
      (t : HLanguage.Subst Param' (groundCtx Γ) (groundCtx Δ)),
      (∀ {τ} (v : Var Γ τ), groundTerm mapParam (s v) = t (groundVar v)) →
      groundTerm mapParam (p.subst s) = (groundTerm mapParam p).subst t := by
  intro Γ σ p
  induction p with
  | var v => intro Δ s t h; exact h v
  | param p => intros; rfl
  | app f a ihf iha =>
      intro Δ s t h
      exact HLanguage.congrArg2 HLanguage.Term.app (ihf s t h) (iha s t h)
  | top | bot => intros; rfl
  | neg p ih => intro Δ s t h; exact congrArg HLanguage.Term.neg (ih s t h)
  | conj p q ihp ihq =>
      intro Δ s t h
      exact HLanguage.congrArg2 HLanguage.Term.conj (ihp s t h) (ihq s t h)
  | disj p q ihp ihq =>
      intro Δ s t h
      exact HLanguage.congrArg2 HLanguage.Term.disj (ihp s t h) (ihq s t h)
  | imp p q ihp ihq =>
      intro Δ s t h
      exact HLanguage.congrArg2 HLanguage.Term.imp (ihp s t h) (ihq s t h)
  | iff p q ihp ihq =>
      intro Δ s t h
      exact HLanguage.congrArg2 HLanguage.Term.iff (ihp s t h) (ihq s t h)
  | eq p q ihp ihq =>
      intro Δ s t h
      exact HLanguage.congrArg2 HLanguage.Term.eq (ihp s t h) (ihq s t h)
  | all p ih =>
      intro Δ s t h
      apply congrArg HLanguage.Term.all
      apply ih (HLanguage.Subst.lift s) (HLanguage.Subst.lift t)
      intro τ v
      cases v with
      | zero => rfl
      | succ v =>
          change groundTerm mapParam ((s v).rename HLanguage.Ren.shift) =
            (t (groundVar v)).rename HLanguage.Ren.shift
          rw [groundTerm_rename mapParam (s v) HLanguage.Ren.shift HLanguage.Ren.shift
            (fun _ => rfl), h v]
  | ex p ih =>
      intro Δ s t h
      apply congrArg HLanguage.Term.ex
      apply ih (HLanguage.Subst.lift s) (HLanguage.Subst.lift t)
      intro τ v
      cases v with
      | zero => rfl
      | succ v =>
          change groundTerm mapParam ((s v).rename HLanguage.Ren.shift) =
            (t (groundVar v)).rename HLanguage.Ren.shift
          rw [groundTerm_rename mapParam (s v) HLanguage.Ren.shift HLanguage.Ren.shift
            (fun _ => rfl), h v]
  | iAnd I p ih =>
      intro Δ s t h
      exact congrArg (HLanguage.Term.iAnd I) (funext (fun i => ih i s t h))
  | iOr I p ih =>
      intro Δ s t h
      exact congrArg (HLanguage.Term.iOr I) (funext (fun i => ih i s t h))

/-- Substitution on grounded variable positions is constructed, rather
than required as an additional semantic or schema assumption. -/
def groundSubst {Param Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ)) {Δ : Ctx} :
    {Γ : Ctx} → HLanguage.Subst Param Γ Δ →
      HLanguage.Subst Param' (groundCtx Γ) (groundCtx Δ)
  | [], _ => HLanguage.Subst.nil
  | _ :: _, s => HLanguage.Subst.cons (groundTerm mapParam (s .zero))
      (groundSubst mapParam (fun v => s (.succ v)))

theorem groundSubst_get {Param Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ))
    {Γ Δ : Ctx} (s : HLanguage.Subst Param Γ Δ) {σ : Ty} (v : Var Γ σ) :
    groundSubst mapParam s (groundVar v) = groundTerm mapParam (s v) := by
  induction v with
  | zero => rfl
  | succ v ih => exact ih (fun w => s (.succ w))

theorem groundSubst_formed {Param Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ)) :
    ∀ {Γ Δ : Ctx} (s : HLanguage.Subst Param Γ Δ)
      {σ : Ty} (v : Var (groundCtx Γ) σ),
      formed (groundSubst mapParam s v) := by
  intro Γ
  induction Γ with
  | nil => intro Δ s σ v; cases v
  | cons τ Γ ih =>
      intro Δ s σ v
      cases v with
      | zero => exact groundTerm_formed mapParam (s .zero)
      | succ v => exact ih (fun w => s (.succ w)) v

theorem groundTerm_subst_ground {Param Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ))
    {Γ Δ σ} (p : HLanguage.Term Param Γ σ) (s : HLanguage.Subst Param Γ Δ) :
    groundTerm mapParam (p.subst s) =
      (groundTerm mapParam p).subst (groundSubst mapParam s) :=
  groundTerm_subst mapParam p s (groundSubst mapParam s)
    (fun v => (groundSubst_get mapParam s v).symm)

theorem universalClosure_nil {Param : Ty → Type u}
    (p : HLanguage.Formula Param []) : p.universalClosure = p := by
  unfold HLanguage.Term.universalClosure HLanguage.Term.closeAll
  have h : @Eq (HLanguage.Ren [] [])
      (@HLanguage.Ren.embed [] []) (@HLanguage.Ren.id []) := by
    funext σ v
    cases v
  rw [h]
  exact HLanguage.Term.rename_id p

theorem universalClosure_cons {Param : Ty → Type u} {Γ σ}
    (p : HLanguage.Formula Param (σ :: Γ)) :
    p.universalClosure = (HLanguage.Term.all p).universalClosure := by
  have h : @Eq (HLanguage.Ren (σ :: Γ) (σ :: (Γ ++ [])))
      (show HLanguage.Ren (σ :: Γ) (σ :: (Γ ++ [])) from by
        exact @HLanguage.Ren.embed (σ :: Γ) [])
      (@HLanguage.Ren.lift Γ (Γ ++ []) σ (@HLanguage.Ren.embed Γ [])) := by
    funext τ v
    cases v <;> rfl
  change HLanguage.Term.closeAll Γ (.all (p.rename (HLanguage.Ren.embed (σ :: Γ) []))) =
    HLanguage.Term.closeAll Γ (.all (p.rename (HLanguage.Ren.lift (HLanguage.Ren.embed Γ []))))
  exact congrArg (fun r : HLanguage.Ren (σ :: Γ) (σ :: (Γ ++ [])) =>
    HLanguage.Term.closeAll Γ (.all (p.rename r))) h

theorem groundTerm_universalClosure {Param Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ)) :
    ∀ {Γ : Ctx} (p : HLanguage.Formula Param Γ),
      groundTerm mapParam p.universalClosure =
        (groundTerm mapParam p).universalClosure := by
  intro Γ
  induction Γ with
  | nil =>
      intro p
      exact (congrArg (fun q : HLanguage.Formula Param [] => groundTerm mapParam q)
        (universalClosure_nil p)).trans
        (universalClosure_nil (show HLanguage.Formula Param' [] from
          groundTerm mapParam p)).symm
  | cons σ Γ ih =>
      intro p
      exact (congrArg (fun q : HLanguage.Formula Param [] => groundTerm mapParam q)
        (universalClosure_cons p)).trans ((ih (.all p)).trans
          (universalClosure_cons (show HLanguage.Formula Param' (groundTy σ :: groundCtx Γ)
            from groundTerm mapParam p)).symm)

/-- A source parameter exists only at an original closed object type. -/
inductive OriginalCarrier (S : OriginalTypedOps.{u}) : Ty → Type u
  | value {σ : Ty} (hσ : σ.Closed) (a : S.Dom σ hσ) : OriginalCarrier S σ

namespace OriginalCarrier

variable (S : OriginalTypedOps.{u})

def read {σ : Ty} (hσ : σ.Closed) : OriginalCarrier S σ → S.Dom σ hσ
  | .value _ a => a

def groundParam {σ : Ty} (a : S.toTypedOps.Dom σ) :
    OriginalCarrier S (groundTy σ) := .value (groundTy_closed σ) a

theorem read_groundParam {σ : Ty} (a : S.toTypedOps.Dom σ) :
    read S (groundTy_closed σ) (groundParam S a) = a := rfl

theorem no_auxiliary_value (i : Nat) (p : OriginalCarrier S (.var i)) : False := by
  cases p with | value h _ => exact h

end OriginalCarrier

#print axioms groundTerm_formed
#print axioms groundTerm_rename
#print axioms groundTerm_subst
#print axioms groundTerm_universalClosure
#print axioms OriginalCarrier.no_auxiliary_value

end Classicism.Research.InfinitaryComprehension.HOriginalTypes
