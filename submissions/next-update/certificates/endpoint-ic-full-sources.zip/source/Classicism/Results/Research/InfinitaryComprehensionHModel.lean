import Classicism.Results.Research.InfinitaryComprehensionHLanguage
import Classicism.Results.Research.InfinitaryComprehensionEndpointCanonical

/-!
# Interpretation of the concrete native H language

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 1--4; misc, 26 October 2026, unpaginated.

The interpretation is on actual well-founded terms. Object binders act on
their syntactic matrices, not on arbitrary external predicate functions.
The substitution law is the usual assignment lemma. There is no assumption
of intensionality, modal K, relation fullness, canonical worlds, or equality
with a canonical evaluator.

`LogicalAxiom` is a small explicit fragment of the ordinary logical schemas
used below. Its definition is independent of any model. Necessitation applies
to these logical schemas only; it is not a rule from truth in a model.
The modal infinitary formation law is derived later from the ordinary
infinitary projection and all-top logical schemas together with recovered K.
-/

namespace Classicism.Research.InfinitaryComprehension.HModel

open Classicism.Meta HLanguage EndpointCanonical EndpointBootstrap

universe u

/-- Actual ordinary logical formulas used in the reconstruction. All
substitutions are capture avoiding and all displayed matrices are syntax. -/
inductive LogicalAxiom (Param : Ty → Type u) : HLanguage.Formula Param [] → Prop
  | universalInstantiation {Γ : Ctx} (A : HLanguage.Formula Param Γ)
      (s : HLanguage.Subst Param Γ []) :
      LogicalAxiom Param (.imp A.universalClosure (A.subst s))
  | universalCongruence {σ : Ty} (A B : HLanguage.Formula Param [σ]) :
      LogicalAxiom Param
        (.imp (HLanguage.Term.universalClosure (.iff A B)) (.iff (.all A) (.all B)))
  | existentialCongruence {σ : Ty} (A B : HLanguage.Formula Param [σ]) :
      LogicalAxiom Param
        (.imp (HLanguage.Term.universalClosure (.iff A B)) (.iff (.ex A) (.ex B)))
  | infimumProjection (I : Type u) (A : I → HLanguage.Formula Param []) (i : I) :
      LogicalAxiom Param (.imp (.iAnd I A) (A i))
  | infimumTop (I : Type u) : LogicalAxiom Param (.iAnd I (fun _ => .top))
  | implicationInfimum (I : Type u) (A : I → HLanguage.Formula Param [])
      (p : HLanguage.Formula Param []) :
      LogicalAxiom Param
        (.iff (.imp p (.iAnd I A)) (.iAnd I (fun i => .imp p (A i))))
  | disjunctionDeMorgan (I : Type u) (A : I → HLanguage.Formula Param []) :
      LogicalAxiom Param (.iff (.iOr I A) (.neg (.iAnd I (fun i => .neg (A i)))))

/-- A current H interpretation with ordinary assignment/substitution laws,
the stipulated logical necessitation, and classical infinitary truth clauses. -/
structure Model (S : TypedOps.{u}) where
  eval : ∀ {Γ : Ctx} {σ : Ty}, HLanguage.Term S.Dom Γ σ → HLanguage.Env S.Dom Γ → S.Dom σ
  iAnd : (I : Type u) → (I → S.Dom Ty.t) → S.Dom Ty.t
  iOr : (I : Type u) → (I → S.Dom Ty.t) → S.Dom Ty.t
  eval_var : ∀ {Γ σ} (v : Var Γ σ) (xs : HLanguage.Env S.Dom Γ), eval (.var v) xs = xs v
  eval_param : ∀ {Γ σ} (p : S.Dom σ) (xs : HLanguage.Env S.Dom Γ), eval (.param p) xs = p
  eval_app : ∀ {Γ σ} {ρ : RTy} (f : HLanguage.Term S.Dom Γ (σ ⇒ ρ))
    (a : HLanguage.Term S.Dom Γ σ) (xs : HLanguage.Env S.Dom Γ),
    eval (.app f a) xs = S.app (eval f xs) (eval a xs)
  eval_top : ∀ {Γ} (xs : HLanguage.Env S.Dom Γ), eval .top xs = S.core.top
  eval_bot : ∀ {Γ} (xs : HLanguage.Env S.Dom Γ), eval .bot xs = S.core.bot
  eval_neg : ∀ {Γ} (p : HLanguage.Formula S.Dom Γ) (xs : HLanguage.Env S.Dom Γ),
    eval (.neg p) xs = S.neg (eval p xs)
  eval_conj : ∀ {Γ} (p q : HLanguage.Formula S.Dom Γ) (xs : HLanguage.Env S.Dom Γ),
    eval (.conj p q) xs = S.conj (eval p xs) (eval q xs)
  eval_disj : ∀ {Γ} (p q : HLanguage.Formula S.Dom Γ) (xs : HLanguage.Env S.Dom Γ),
    eval (.disj p q) xs = S.disj (eval p xs) (eval q xs)
  eval_imp : ∀ {Γ} (p q : HLanguage.Formula S.Dom Γ) (xs : HLanguage.Env S.Dom Γ),
    eval (.imp p q) xs = S.core.imp (eval p xs) (eval q xs)
  eval_iff : ∀ {Γ} (p q : HLanguage.Formula S.Dom Γ) (xs : HLanguage.Env S.Dom Γ),
    eval (.iff p q) xs = S.core.iff (eval p xs) (eval q xs)
  eval_eq : ∀ {Γ σ} (p q : HLanguage.Term S.Dom Γ σ) (xs : HLanguage.Env S.Dom Γ),
    eval (.eq p q) xs = S.eq (eval p xs) (eval q xs)
  eval_iAnd : ∀ {Γ} (I : Type u) (p : I → HLanguage.Formula S.Dom Γ) (xs : HLanguage.Env S.Dom Γ),
    eval (.iAnd I p) xs = iAnd I (fun i => eval (p i) xs)
  eval_iOr : ∀ {Γ} (I : Type u) (p : I → HLanguage.Formula S.Dom Γ) (xs : HLanguage.Env S.Dom Γ),
    eval (.iOr I p) xs = iOr I (fun i => eval (p i) xs)
  truth_all : ∀ {Γ σ} (p : HLanguage.Formula S.Dom (σ :: Γ)) (xs : HLanguage.Env S.Dom Γ),
    S.truth (eval (.all p) xs) ↔ ∀ x : S.Dom σ, S.truth (eval p (HLanguage.Env.cons x xs))
  truth_ex : ∀ {Γ σ} (p : HLanguage.Formula S.Dom (σ :: Γ)) (xs : HLanguage.Env S.Dom Γ),
    S.truth (eval (.ex p) xs) ↔ ∃ x : S.Dom σ, S.truth (eval p (HLanguage.Env.cons x xs))
  truth_iAnd : ∀ I p, S.truth (iAnd I p) ↔ ∀ i, S.truth (p i)
  truth_iOr : ∀ I p, S.truth (iOr I p) ↔ ∃ i, S.truth (p i)
  eval_subst : ∀ {Γ Δ σ} (p : HLanguage.Term S.Dom Γ σ) (s : HLanguage.Subst S.Dom Γ Δ)
    (xs : HLanguage.Env S.Dom Δ), eval (p.subst s) xs = eval p (fun v => eval (s v) xs)
  seed_eq : S.seed = eval (.all (.var .zero : HLanguage.Formula S.Dom [Ty.t])) HLanguage.Env.nil
  logicalNecessitation : ∀ p : HLanguage.Formula S.Dom [], LogicalAxiom S.Dom p →
    S.truth (eval p.box HLanguage.Env.nil)

namespace Model

variable {S : TypedOps.{u}} (M : Model S)

@[simp] theorem eval_box {Γ} (p : HLanguage.Formula S.Dom Γ) (xs : HLanguage.Env S.Dom Γ) :
    M.eval p.box xs = S.eq (M.eval p xs) S.core.top := by
  rw [HLanguage.Term.box, M.eval_eq, M.eval_top]

theorem truth_box {Γ} (p : HLanguage.Formula S.Dom Γ) (xs : HLanguage.Env S.Dom Γ) :
    S.truth (M.eval p.box xs) ↔ S.core.Box (M.eval p xs) := by
  rw [M.eval_box]
  exact S.truth_eq (M.eval p xs) S.core.top

theorem necessary_logical {p : HLanguage.Formula S.Dom []} (h : LogicalAxiom S.Dom p) :
    S.core.Box (M.eval p HLanguage.Env.nil) :=
  (M.truth_box p HLanguage.Env.nil).mp (M.logicalNecessitation p h)

theorem eval_closed_subst {Γ σ} (p : HLanguage.Term S.Dom Γ σ) (xs : HLanguage.Env S.Dom Γ) :
    M.eval (p.subst (fun v => .param (xs v))) HLanguage.Env.nil = M.eval p xs := by
  rw [M.eval_subst]
  congr 1
  funext τ v
  exact M.eval_param (xs v) HLanguage.Env.nil

theorem eval_rename {Γ Δ σ} (p : HLanguage.Term S.Dom Γ σ) (r : HLanguage.Ren Γ Δ)
    (xs : HLanguage.Env S.Dom Δ) : M.eval (p.rename r) xs = M.eval p (fun v => xs (r v)) := by
  have h := M.eval_closed_subst (p.rename r) xs
  rw [HLanguage.Term.subst_rename] at h
  exact h.symm.trans (M.eval_closed_subst p (fun v => xs (r v)))

/-- Native top and bottom really use H's fixed `u = ∀p.p`. -/
theorem native_top : S.core.top =
    S.disj (M.eval (.all (.var .zero : HLanguage.Formula S.Dom [Ty.t])) HLanguage.Env.nil)
      (S.neg (M.eval (.all (.var .zero : HLanguage.Formula S.Dom [Ty.t])) HLanguage.Env.nil)) := by
  change S.disj S.seed (S.neg S.seed) = _
  rw [M.seed_eq]

def Comprehension : Prop :=
  ∀ {Γ : Ctx} (A : HLanguage.Formula S.Dom Γ), S.truth (M.eval A.comprehension HLanguage.Env.nil)

end Model
end Classicism.Research.InfinitaryComprehension.HModel
