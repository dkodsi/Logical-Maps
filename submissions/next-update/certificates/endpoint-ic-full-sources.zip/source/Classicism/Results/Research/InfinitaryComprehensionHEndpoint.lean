import Classicism.Results.Research.InfinitaryComprehensionHBootstrap
import Classicism.Results.Research.InfinitaryComprehensionEndpointQualificationBridge
import Classicism.Results.Research.InfinitaryComprehensionEndpointEqualityBridge
import Classicism.Results.Research.InfinitaryComprehensionEndpointSyntaxBridge

/-!
# Reconstruct the observer interpretation from the native H schemas

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 1--4; misc, 26 October 2026, unpaginated.

`EndpointOS` below is satisfaction of the displayed full typed schema.
The outer finite universal binders and the translated equality guards are
expanded using their ordinary current truth clauses. The inner whole-operation
clauses retain the actual native `sameFormula`, including its existential
representative and native identity box. No modal, intensional, equality-rigidity,
world-coverage or canonical-evaluation conclusion is a starting premise.
-/

namespace Classicism.Research.InfinitaryComprehension.HEndpoint

open Classicism.Meta EndpointCanonical EndpointBootstrap EndpointDiagonalBridge
open EndpointAtoms EndpointQualificationBridge EndpointEqualityBridge EndpointSyntaxBridge
open HBootstrap

universe u

variable {S : TypedOps.{u}} (M : HModel.Model S)

/-- The literal common-representative quantifier clauses, followed by the
translated reflexivity and Leibniz guards with current binders expanded. -/
structure GoodAt (σ : Ty) (E : Observer (S := S)) : Prop where
  all : S.truth (M.eval
    (HLanguage.Term.sameFormula (allLeft M σ E) (allRight M σ E)) HLanguage.Env.nil)
  ex : S.truth (M.eval
    (HLanguage.Term.sameFormula (exLeft M σ E) (exRight M σ E)) HLanguage.Env.nil)
  reflexive : ∀ x : S.Dom σ, S.truth (S.app E (S.eq x x))
  leibniz : ∀ x y : S.Dom σ, ∀ F : S.Dom (σ ⇒ RTy.t),
    S.truth (S.app E (S.eq x y)) →
    S.truth (S.app E (S.app F x)) → S.truth (S.app E (S.app F y))

/-- A finite list indexes precisely the original finite qualification schema. -/
def Qualification (Δ : List Ty) (E : Observer (S := S)) : Prop :=
  EndpointValued (H := S.core) S.app E ∧ ∀ σ ∈ Δ, GoodAt M σ E

/-- The current truth of full typed endpoint-valued separation, with the
outer universal binders expanded. The reverse implication is equality substitution. -/
def EndpointOS : Prop :=
  ∀ (Γ : Ctx) (Δ : List Ty) (R T : S.Dom (RTy.ofArgs Γ)),
    (∀ E : Observer (S := S), Qualification M Δ E → (booleans M).GoodBoolean E →
      ∀ xs : S.Env Γ,
      S.truth (S.app E (S.uncurry Γ R xs)) ↔
      S.truth (S.app E (S.uncurry Γ T xs))) → R = T

theorem separation (hOS : EndpointOS M) (Δ : List Ty) :
    PropSeparation (booleans M) (Qualification M Δ) := by
  intro p q h
  exact hOS [] Δ p q (fun E hQ hB _ => h E hQ hB)

/-- The Boolean qualification is itself the truth of three native Same formulas. -/
theorem boolean_qualification (E : Observer (S := S)) :
    (booleans M).GoodBoolean E ↔
      S.truth (M.eval (HLanguage.Term.sameFormula
        ((booleans M).negLeft E) ((booleans M).negRight E)) HLanguage.Env.nil) ∧
      S.truth (M.eval (HLanguage.Term.sameFormula
        ((booleans M).conjLeft E) ((booleans M).conjRight E)) HLanguage.Env.nil) ∧
      S.truth (M.eval (HLanguage.Term.sameFormula
        ((booleans M).disjLeft E) ((booleans M).disjRight E)) HLanguage.Env.nil) := by
  constructor
  · intro h
    exact ⟨(truth_unary_same M _ _).mpr h.1,
      (truth_binary_same M _ _).mpr h.2.1,
      (truth_binary_same M _ _).mpr h.2.2⟩
  · intro h
    exact ⟨(truth_unary_same M _ _).mp h.1,
      (truth_binary_same M _ _).mp h.2.1,
      (truth_binary_same M _ _).mp h.2.2⟩

abbrev BaseObserver := Eligible (booleans M) (Qualification M [Ty.t])

noncomputable def observers (hOS : EndpointOS M) (hIC : M.Comprehension) :
    QuantifiedEndpoints S.core (BaseObserver M) :=
  quantifiedEndpoints (booleans M) (diagonals M) (universalt M)
    (separation M hOS [Ty.t]) (unary_ui M Ty.t) (unary_comprehension M hIC Ty.t)
    (fun _ hQ _ => hQ.1)
    (fun E hQ _ => (truth_unary_same M _ _).mp ((hQ.2 Ty.t (by simp)).all))

variable (hOS : EndpointOS M) (hIC : M.Comprehension)

abbrev RichObserver (σ : Ty) := Eligible (booleans M) (Qualification M [Ty.t, σ])

def refinement (σ : Ty) : Refinement (observers M hOS hIC) (RichObserver M σ) where
  toBase F := ⟨F.val, ⟨⟨F.property.1.1, fun τ hτ =>
    F.property.1.2 τ (List.mem_cons.mpr (Or.inl (List.mem_singleton.mp hτ)))⟩,
    F.property.2⟩⟩
  separates p q h := by
    apply separation M hOS [Ty.t, σ] p q
    intro E hQ hB
    exact h ⟨E, hQ, hB⟩

theorem good_all (σ : Ty) (E : Observer (S := S)) (h : GoodAt M σ E)
    (R : S.Dom (σ ⇒ RTy.t)) :
    S.truth (S.app E (allOperation M σ R)) ↔
      ∀ x : S.Dom σ, S.truth (S.app E (S.app R x)) := by
  have hs := (unary M (σ ⇒ RTy.t)).same_material
    ((truth_unary_same M _ _).mp h.all) R
  rw [eval_allLeft] at hs
  exact hs.trans (truth_allRight M σ E R)

theorem good_ex (σ : Ty) (E : Observer (S := S)) (h : GoodAt M σ E)
    (R : S.Dom (σ ⇒ RTy.t)) :
    S.truth (S.app E (exOperation M σ R)) ↔
      ∃ x : S.Dom σ, S.truth (S.app E (S.app R x)) := by
  have hs := (unary M (σ ⇒ RTy.t)).same_material
    ((truth_unary_same M _ _).mp h.ex) R
  rw [eval_exLeft] at hs
  exact hs.trans (truth_exRight M σ E R)

theorem preserves_all (σ : Ty) (E : BaseObserver M) (R : S.Dom (σ ⇒ RTy.t)) :
    (observers M hOS hIC).Accepts E (allOperation M σ R) ↔
      ∀ x : S.Dom σ, (observers M hOS hIC).Accepts E (S.app R x) :=
  (refinement M hOS hIC σ).universal S.app (allOperation M σ)
    (fun F P => good_all M σ F.val (F.property.1.2 σ (by simp)) P) E R

theorem preserves_ex (σ : Ty) (E : BaseObserver M) (R : S.Dom (σ ⇒ RTy.t)) :
    (observers M hOS hIC).Accepts E (exOperation M σ R) ↔
      ∃ x : S.Dom σ, (observers M hOS hIC).Accepts E (S.app R x) :=
  (refinement M hOS hIC σ).existential S.app (exOperation M σ)
    (fun F P => good_ex M σ F.val (F.property.1.2 σ (by simp)) P) E R

theorem reflexivity (σ : Ty) (E : BaseObserver M) (x : S.Dom σ) :
    (observers M hOS hIC).Accepts E (S.eq x x) :=
  (refinement M hOS hIC σ).equality_reflexivity S.eq
    (fun F a => (F.property.1.2 σ (by simp)).reflexive a) E x

theorem leibniz (σ : Ty) (E : BaseObserver M) (x y : S.Dom σ)
    (F : S.Dom (σ ⇒ RTy.t))
    (heq : (observers M hOS hIC).Accepts E (S.eq x y))
    (hx : (observers M hOS hIC).Accepts E (S.app F x)) :
    (observers M hOS hIC).Accepts E (S.app F y) :=
  (refinement M hOS hIC σ).equality_leibniz S.eq S.app
    (fun G a b P => (G.property.1.2 σ (by simp)).leibniz a b P) E x y F heq hx

theorem observed_equality {σ : Ty} (a b : S.Dom σ) (E : BaseObserver M) :
    (observers M hOS hIC).Accepts E (S.eq a b) ↔ a = b := by
  exact endpoint_typed_identity_iff (unary M σ) (separation M hOS [Ty.t])
    (unary_ui M Ty.t) (unary_comprehension M hIC Ty.t)
    (fun _ hQ _ => hQ.1) S.eq
    (fun F hQ hB p => reflexivity M hOS hIC Ty.t ⟨F,hQ,hB⟩ p)
    (fun F hQ hB p q G => leibniz M hOS hIC Ty.t ⟨F,hQ,hB⟩ p q G)
    (unary_ui M σ) (unary_comprehension M hIC σ) S.eq S.truth_eq
    (fun F hQ hB x => reflexivity M hOS hIC σ ⟨F,hQ,hB⟩ x)
    (fun F hQ hB x y G => leibniz M hOS hIC σ ⟨F,hQ,hB⟩ x y G)
    (equalityTest M σ) (eval_equalityTest M σ) E.val E.property.1 E.property.2 a b

include hOS in
/-- Necessitated projection and the all-top logical theorem suffice for
native box to commute with arbitrary conjunction. This is derived, not a model field. -/
theorem box_inf (I : Type u) (f : I → S.Dom Ty.t) :
    S.core.Box (M.iAnd I f) ↔ ∀ i, S.core.Box (f i) := by
  constructor
  · intro h i
    have hp := M.necessary_logical (HModel.LogicalAxiom.infimumProjection I
      (fun j => .param (f j)) i)
    simp only [M.eval_imp, M.eval_iAnd, M.eval_param] at hp
    exact separation_K (separation M hOS [Ty.t]) hp h
  · intro h
    have he : f = fun _ => S.core.top := funext h
    rw [he]
    have ht := M.necessary_logical (HModel.LogicalAxiom.infimumTop (Param := S.Dom) I)
    simpa only [M.eval_iAnd, M.eval_top] using ht

theorem implication_inf (I : Type u) (f : I → S.Dom Ty.t) (p : S.Dom Ty.t) :
    S.core.Box (S.core.iff (S.core.imp p (M.iAnd I f))
      (M.iAnd I (fun i => S.core.imp p (f i)))) := by
  have h := M.necessary_logical (HModel.LogicalAxiom.implicationInfimum I
    (fun i => .param (f i)) (.param p))
  simpa only [M.eval_iff, M.eval_imp, M.eval_iAnd, M.eval_param] using h

def formation : QuantifiedEndpoints.Formation (H := S.core) where
  inf := M.iAnd
  box_inf := box_inf M hOS
  implication_inf := implication_inf M

noncomputable def infima : (observers M hOS hIC).Infima :=
  (observers M hOS hIC).infima_of_formation (formation M hOS)

theorem sup_value (I : Type u) (f : I → S.Dom Ty.t) :
    M.iOr I f = (observers M hOS hIC).Sup (infima M hOS hIC) I f := by
  apply (observers M hOS hIC).intensionality
  have h := M.necessary_logical (HModel.LogicalAxiom.disjunctionDeMorgan I
    (fun i => .param (f i)))
  change S.core.Box (S.core.iff (M.iOr I f) (S.neg (M.iAnd I (fun i => S.neg (f i)))))
  simpa only [M.eval_iff, M.eval_iOr, M.eval_neg, M.eval_iAnd, M.eval_param] using h

theorem all_value (σ : Ty) (p : HLanguage.Formula S.Dom [σ]) :
    M.eval (.all p) HLanguage.Env.nil =
      (infima M hOS hIC).inf (S.Dom σ)
        (fun x => M.eval p (HLanguage.Env.cons x HLanguage.Env.nil)) := by
  have h := raw_all_eq_inf (unary M σ) (observers M hOS hIC) (infima M hOS hIC)
    Subtype.val (fun _ _ => rfl) (separation M hOS [Ty.t])
    (unary_ui M σ) (unary_comprehension M hIC σ)
    (allOperation M σ) (all_congruence M σ) (preserves_all M hOS hIC σ) p
  change M.eval p.universalClosure HLanguage.Env.nil = _ at h
  rw [unaryClosure p] at h
  exact h

theorem ex_value (σ : Ty) (p : HLanguage.Formula S.Dom [σ]) :
    M.eval (.ex p) HLanguage.Env.nil =
      (observers M hOS hIC).Sup (infima M hOS hIC) (S.Dom σ)
        (fun x => M.eval p (HLanguage.Env.cons x HLanguage.Env.nil)) :=
  raw_ex_eq_sup (unary M σ) (observers M hOS hIC) (infima M hOS hIC)
    Subtype.val (fun _ _ => rfl) (separation M hOS [Ty.t])
    (unary_ui M σ) (unary_comprehension M hIC σ)
    (exOperation M σ) (exBinder M σ) (ex_congruence M σ) (preserves_ex M hOS hIC σ) p

theorem typed_separation : TypedSeparation S (observers M hOS hIC) := by
  intro Γ R T h
  exact hOS Γ [Ty.t] R T (fun E hQ hB xs => h ⟨E,hQ,hB⟩ xs)

#print axioms observers
#print axioms observed_equality
#print axioms box_inf
#print axioms all_value
#print axioms ex_value
#print axioms typed_separation

end Classicism.Research.InfinitaryComprehension.HEndpoint
