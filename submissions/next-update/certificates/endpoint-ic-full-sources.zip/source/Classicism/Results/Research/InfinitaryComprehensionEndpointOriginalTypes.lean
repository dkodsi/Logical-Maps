import Classicism.Results.Research.InfinitaryComprehensionEndpointCanonical
import Classicism.Results.Research.InfinitaryComprehensionFormation

/-!
# Original-type carriers for the endpoint reconstruction

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 1 and 4; misc, 25 October 2026,
unpaginated.

The starting carriers and their H operations below are indexed only by
original closed types. The auxiliary repository constructor `Ty.var` is
handled by the concrete translation `Grounding.groundTy`, which sends it
to e. No carrier, equality law or application operation at an auxiliary
type is requested from the starting structure.

The resulting `TypedOps` is an implementation index extension. Every one
of its operations is an original closed-type operation. The term-level
translation is the actual existing `groundTerm`, with arbitrary simultaneous
parameters retained and all infinitary index sets unchanged.
-/

namespace Classicism.Research.InfinitaryComprehension.EndpointOriginalTypes

open Classicism.Meta Grounding Formation EndpointCanonical

universe u

/-- H carriers and operations only at original closed object types. -/
structure OriginalTypedOps where
  Dom : (σ : Ty) → σ.Closed → Type u
  app : ∀ {σ : Ty} {ρ : RTy} (hσ : σ.Closed) (hρ : ρ.Closed),
    Dom (σ ⇒ ρ) ⟨hσ, hρ⟩ → Dom σ hσ → Dom ρ hρ
  truth : Dom Ty.t trivial → Prop
  seed : Dom Ty.t trivial
  neg : Dom Ty.t trivial → Dom Ty.t trivial
  conj : Dom Ty.t trivial → Dom Ty.t trivial → Dom Ty.t trivial
  disj : Dom Ty.t trivial → Dom Ty.t trivial → Dom Ty.t trivial
  truth_neg : ∀ p, truth (neg p) ↔ ¬ truth p
  truth_conj : ∀ p q, truth (conj p q) ↔ truth p ∧ truth q
  truth_disj : ∀ p q, truth (disj p q) ↔ truth p ∨ truth q
  eq : ∀ {σ : Ty} (hσ : σ.Closed), Dom σ hσ → Dom σ hσ → Dom Ty.t trivial
  truth_eq : ∀ {σ : Ty} (hσ : σ.Closed) (a b : Dom σ hσ),
    truth (eq hσ a b) ↔ a = b
  nonempty_e : Nonempty (Dom Ty.e trivial)

namespace OriginalTypedOps

variable (S : OriginalTypedOps.{u})

/-- Concrete index extension. Even its auxiliary variable cases use only
the given original e carrier and original closed-type laws. -/
def toTypedOps : TypedOps.{u} where
  Dom σ := S.Dom (groundTy σ) (groundTy_closed σ)
  app {σ} {ρ} := S.app (groundTy_closed σ) (groundRTy_closed ρ)
  truth := S.truth
  seed := S.seed
  neg := S.neg
  conj := S.conj
  disj := S.disj
  truth_neg := S.truth_neg
  truth_conj := S.truth_conj
  truth_disj := S.truth_disj
  eq {σ} := S.eq (groundTy_closed σ)
  truth_eq {σ} := S.truth_eq (groundTy_closed σ)
  nonempty_e := S.nonempty_e

theorem variable_domain (i : Nat) :
    S.toTypedOps.Dom (.var i) = S.Dom Ty.e trivial := rfl

/-- The original carriers are preserved, not merely replaced by isomorphic
full function spaces. -/
theorem closed_domain (σ : Ty) (hσ : σ.Closed) :
    S.toTypedOps.Dom σ = S.Dom σ hσ := by
  change S.Dom (groundTy σ) (groundTy_closed σ) = S.Dom σ hσ
  have he : (⟨groundTy σ, groundTy_closed σ⟩ : {τ : Ty // τ.Closed}) =
      ⟨σ, hσ⟩ := Subtype.ext (groundTy_eq_of_closed σ hσ)
  exact congrArg (fun τ : {τ : Ty // τ.Closed} => S.Dom τ.val τ.property) he

theorem closed_context (Γ : Ctx) (hΓ : ContextClosed Γ) : groundCtx Γ = Γ := by
  induction Γ with
  | nil => rfl
  | cons σ Γ ih =>
      have hh := context_cons.mp hΓ
      change groundTy σ :: groundCtx Γ = σ :: Γ
      rw [groundTy_eq_of_closed σ hh.1, ih hh.2]

/-- A relation over a finite auxiliary context is the original relation
over its grounded finite context. This is the result-type transport needed
by the Comprehension schema. -/
theorem relation_domain (Γ : Ctx) :
    S.toTypedOps.Dom (RTy.ofArgs Γ) =
      S.Dom (RTy.ofArgs (groundCtx Γ))
        (ofArgs_closed (groundCtx Γ) (ground_context_closed Γ)) := by
  change S.Dom (groundTy (RTy.ofArgs Γ)) (groundTy_closed _) = _
  have he : (⟨groundTy (RTy.ofArgs Γ), groundTy_closed _⟩ : {τ : Ty // τ.Closed}) =
      ⟨RTy.ofArgs (groundCtx Γ),
        ofArgs_closed (groundCtx Γ) (ground_context_closed Γ)⟩ :=
    Subtype.ext (congrArg Ty.rel (groundRTy_ofArgs Γ))
  exact congrArg (fun τ : {τ : Ty // τ.Closed} => S.Dom τ.val τ.property) he

/-- At every implementation type, application is literally application at
its original closed grounding. -/
theorem app_ground {σ : Ty} {ρ : RTy}
    (f : S.toTypedOps.Dom (σ ⇒ ρ)) (a : S.toTypedOps.Dom σ) :
    S.toTypedOps.app f a = S.app (groundTy_closed σ) (groundRTy_closed ρ) f a := rfl

theorem eq_ground {σ : Ty} (a b : S.toTypedOps.Dom σ) :
    S.toTypedOps.eq a b = S.eq (groundTy_closed σ) a b := rfl

/-- Assignments at original types need no values at auxiliary types. -/
abbrev Assignment (Param : Ty → Type u) :=
  ∀ {σ : Ty} (hσ : σ.Closed), Param σ → S.Dom σ hσ

abbrev Env (Γ : Ctx) (hΓ : ContextClosed Γ) :=
  ∀ {σ : Ty} (v : Var Γ σ), S.Dom σ (var_type_closed hΓ v)

/-- Retagging simultaneous parameters remembers their original positions;
two source parameter sorts are not identified when their type labels ground
to the same closed type. -/
structure GroundParam (Param : Ty → Type u) (τ : Ty) : Type u where
  source : Ty
  type_eq : groundTy source = τ
  value : Param source

def tagParam {Param : Ty → Type u} {σ : Ty} (p : Param σ) :
    GroundParam Param (groundTy σ) := ⟨σ, rfl, p⟩

def groundAssignment {Param : Ty → Type u}
    (η : ∀ {σ : Ty}, Param σ → S.toTypedOps.Dom σ) :
    S.Assignment (GroundParam Param) := by
  intro τ hτ p
  rcases p with ⟨σ, h, p⟩
  cases h
  exact η p

def groundEnv : {Γ : Ctx} → S.toTypedOps.Env Γ →
    S.Env (groundCtx Γ) (ground_context_closed Γ)
  | [], _ => fun v => nomatch v
  | _ :: Γ, xs => fun v =>
      match v with
      | .zero => xs .zero
      | .succ v => groundEnv (fun w => xs (.succ w)) v

theorem groundEnv_get {Γ : Ctx} (xs : S.toTypedOps.Env Γ)
    {σ : Ty} (v : Var Γ σ) :
    S.groundEnv xs (groundVar v) = xs v := by
  induction v with
  | zero => rfl
  | succ v ih => exact ih (fun w => xs (.succ w))

/-- The entire actual term, not only its result type, is in the original
language after this explicit grounding translation. -/
theorem translated_formed {Param : Ty → Type u} {Γ σ}
    (p : Term Param Γ σ) :
    ContextClosed (groundCtx Γ) ∧ formed (groundTerm (@tagParam Param) p) :=
  ⟨ground_context_closed Γ, groundTerm_formed (@tagParam Param) p⟩

end OriginalTypedOps

#print axioms OriginalTypedOps.toTypedOps
#print axioms OriginalTypedOps.closed_domain
#print axioms OriginalTypedOps.relation_domain
#print axioms OriginalTypedOps.groundEnv_get
#print axioms OriginalTypedOps.translated_formed

end Classicism.Research.InfinitaryComprehension.EndpointOriginalTypes
