import Classicism.Syntax.Term

/-!
# Native infinitary, lambda-free H syntax

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 1--4; misc, 26 October 2026, unpaginated.

This is concrete well-founded syntax. Finite quantifiers bind variables in
matrices; no constructor admits an arbitrary external predicate function.
Infinitary conjunction and disjunction admit arbitrary universe-small index
sets. Necessity is the native identity formula `p = top`: there is neither
lambda abstraction nor a primitive first-class necessity operation.

The substitution and parameter-closing operations below manipulate syntax.
They contain no model, representation, faithfulness or fullness premise.
-/

namespace Classicism.Research.InfinitaryComprehension.HLanguage

open Classicism.Meta

universe u v w

/-- Binary congruence, proved here so the language retains a core-only import. -/
theorem congrArg2 {α : Sort u} {β : Sort v} {γ : Sort w}
    (f : α → β → γ) {a a' : α} {b b' : β} (ha : a = a') (hb : b = b') :
    f a b = f a' b' := by
  cases ha
  cases hb
  rfl

inductive Term (Param : Ty → Type u) : Ctx → Ty → Type (u + 1)
  | var {Γ σ} : Var Γ σ → Term Param Γ σ
  | param {Γ σ} : Param σ → Term Param Γ σ
  | app {Γ σ} {ρ : RTy} :
      Term Param Γ (σ ⇒ ρ) → Term Param Γ σ → Term Param Γ ρ
  | top {Γ} : Term Param Γ Ty.t
  | bot {Γ} : Term Param Γ Ty.t
  | neg {Γ} : Term Param Γ Ty.t → Term Param Γ Ty.t
  | conj {Γ} : Term Param Γ Ty.t → Term Param Γ Ty.t → Term Param Γ Ty.t
  | disj {Γ} : Term Param Γ Ty.t → Term Param Γ Ty.t → Term Param Γ Ty.t
  | imp {Γ} : Term Param Γ Ty.t → Term Param Γ Ty.t → Term Param Γ Ty.t
  | iff {Γ} : Term Param Γ Ty.t → Term Param Γ Ty.t → Term Param Γ Ty.t
  | eq {Γ σ} : Term Param Γ σ → Term Param Γ σ → Term Param Γ Ty.t
  | all {Γ σ} : Term Param (σ :: Γ) Ty.t → Term Param Γ Ty.t
  | ex {Γ σ} : Term Param (σ :: Γ) Ty.t → Term Param Γ Ty.t
  | iAnd {Γ} (I : Type u) : (I → Term Param Γ Ty.t) → Term Param Γ Ty.t
  | iOr {Γ} (I : Type u) : (I → Term Param Γ Ty.t) → Term Param Γ Ty.t

abbrev Formula (Param : Ty → Type u) (Γ : Ctx) := Term Param Γ Ty.t
abbrev Env (D : Ty → Type u) (Γ : Ctx) := ∀ {σ : Ty}, Var Γ σ → D σ
abbrev Assignment (D Param : Ty → Type u) := ∀ {σ : Ty}, Param σ → D σ
abbrev Ren (Γ Δ : Ctx) := ∀ {σ : Ty}, Var Γ σ → Var Δ σ

namespace Ren

def id : Ren Γ Γ := fun v => v
def shift : Ren Γ (σ :: Γ) := fun v => .succ v
def comp (r : Ren Δ Θ) (s : Ren Γ Δ) : Ren Γ Θ := fun v => r (s v)
def lift (r : Ren Γ Δ) : Ren (σ :: Γ) (σ :: Δ)
  | _, .zero => .zero
  | _, .succ v => .succ (r v)
def embed : (Γ Δ : Ctx) → Ren Γ (Γ ++ Δ)
  | [], _, _, v => nomatch v
  | _ :: _, _, _, .zero => .zero
  | _ :: Γ, Δ, _, .succ v => .succ (embed Γ Δ v)

theorem lift_id : @Eq (Ren (σ :: Γ) (σ :: Γ)) (Ren.lift Ren.id) Ren.id := by
  funext τ v
  cases v <;> rfl

theorem lift_comp (r : Ren Δ Θ) (s : Ren Γ Δ) :
    @Eq (Ren (σ :: Γ) (σ :: Θ))
      (Ren.lift (Ren.comp r s)) (Ren.comp (Ren.lift r) (Ren.lift s)) := by
  funext τ v
  cases v <;> rfl

end Ren

def lastVar (Γ : Ctx) (σ : Ty) : Var (Γ ++ [σ]) σ :=
  match Γ with
  | [] => .zero
  | _ :: Γ => .succ (lastVar Γ σ)

namespace Env

variable {D : Ty → Type u}

def nil : Env D [] := fun v => nomatch v
def cons {Γ σ} (x : D σ) (xs : Env D Γ) : Env D (σ :: Γ)
  | _, .zero => x
  | _, .succ v => xs v
def tail {Γ σ} (xs : Env D (σ :: Γ)) : Env D Γ := fun v => xs (.succ v)

theorem nil_eta (xs : Env D []) : @Eq (Env D []) xs nil := by
  funext σ v
  cases v

theorem cons_eta {Γ σ} (xs : Env D (σ :: Γ)) :
    @Eq (Env D (σ :: Γ)) (cons (xs .zero) (tail xs)) xs := by
  funext τ v
  cases v <;> rfl

@[simp] theorem cons_zero {Γ σ} (x : D σ) (xs : Env D Γ) :
    cons x xs .zero = x := rfl
@[simp] theorem cons_succ {Γ σ τ} (x : D σ) (xs : Env D Γ) (v : Var Γ τ) :
    cons x xs (.succ v) = xs v := rfl
@[simp] theorem tail_cons {Γ σ} (x : D σ) (xs : Env D Γ) :
    @Eq (Env D Γ) (tail (cons x xs)) xs := rfl

def append {Δ : Ctx} : {Γ : Ctx} → Env D Γ → Env D Δ → Env D (Γ ++ Δ)
  | [], _, ys => ys
  | _ :: _, xs, ys => cons (xs .zero) (append (tail xs) ys)

theorem append_embed {Γ Δ} (xs : Env D Γ) (ys : Env D Δ)
    {σ} (v : Var Γ σ) : append xs ys (Ren.embed Γ Δ v) = xs v := by
  induction v with
  | zero => rfl
  | succ v ih => exact ih (tail xs)

theorem append_last (Γ : Ctx) (xs : Env D Γ) {σ} (x : D σ) :
    append xs (cons x nil) (lastVar Γ σ) = x := by
  induction Γ with
  | nil => rfl
  | cons τ Γ ih => exact ih (tail xs)

end Env

namespace Term

variable {Param : Ty → Type u}

abbrev box {Γ} (p : Formula Param Γ) : Formula Param Γ := .eq p .top

def rename {Γ Δ σ} (r : Ren Γ Δ) : Term Param Γ σ → Term Param Δ σ
  | .var v => .var (r v)
  | .param p => .param p
  | .app f a => .app (rename r f) (rename r a)
  | .top => .top
  | .bot => .bot
  | .neg p => .neg (rename r p)
  | .conj p q => .conj (rename r p) (rename r q)
  | .disj p q => .disj (rename r p) (rename r q)
  | .imp p q => .imp (rename r p) (rename r q)
  | .iff p q => .iff (rename r p) (rename r q)
  | .eq p q => .eq (rename r p) (rename r q)
  | .all p => .all (rename (Ren.lift r) p)
  | .ex p => .ex (rename (Ren.lift r) p)
  | .iAnd I p => .iAnd I (fun i => rename r (p i))
  | .iOr I p => .iOr I (fun i => rename r (p i))

abbrev wk {Γ σ τ} (p : Term Param Γ σ) : Term Param (τ :: Γ) σ :=
  p.rename Ren.shift

def mapParam {Param' : Ty → Type u} (f : ∀ {σ}, Param σ → Param' σ) :
    {Γ : Ctx} → {σ : Ty} → Term Param Γ σ → Term Param' Γ σ
  | _, _, .var v => .var v
  | _, _, .param p => .param (f p)
  | _, _, .app p q => .app (mapParam f p) (mapParam f q)
  | _, _, .top => .top
  | _, _, .bot => .bot
  | _, _, .neg p => .neg (mapParam f p)
  | _, _, .conj p q => .conj (mapParam f p) (mapParam f q)
  | _, _, .disj p q => .disj (mapParam f p) (mapParam f q)
  | _, _, .imp p q => .imp (mapParam f p) (mapParam f q)
  | _, _, .iff p q => .iff (mapParam f p) (mapParam f q)
  | _, _, .eq p q => .eq (mapParam f p) (mapParam f q)
  | _, _, .all p => .all (mapParam f p)
  | _, _, .ex p => .ex (mapParam f p)
  | _, _, .iAnd I p => .iAnd I (fun i => mapParam f (p i))
  | _, _, .iOr I p => .iOr I (fun i => mapParam f (p i))

theorem rename_id {Γ σ} (p : Term Param Γ σ) : p.rename Ren.id = p := by
  induction p with
  | var | param | top | bot => rfl
  | app p q ihp ihq => exact congrArg2 Term.app ihp ihq
  | neg p ih => exact congrArg Term.neg ih
  | conj p q ihp ihq => exact congrArg2 Term.conj ihp ihq
  | disj p q ihp ihq => exact congrArg2 Term.disj ihp ihq
  | imp p q ihp ihq => exact congrArg2 Term.imp ihp ihq
  | iff p q ihp ihq => exact congrArg2 Term.iff ihp ihq
  | eq p q ihp ihq => exact congrArg2 Term.eq ihp ihq
  | all p ih => simpa only [rename, Ren.lift_id] using congrArg Term.all ih
  | ex p ih => simpa only [rename, Ren.lift_id] using congrArg Term.ex ih
  | iAnd I p ih => exact congrArg (Term.iAnd I) (funext ih)
  | iOr I p ih => exact congrArg (Term.iOr I) (funext ih)

theorem rename_rename {Γ σ} (p : Term Param Γ σ) :
    ∀ {Δ Θ} (r : Ren Γ Δ) (s : Ren Δ Θ),
      (p.rename r).rename s = p.rename (Ren.comp s r) := by
  induction p with
  | var | param | top | bot => intros; rfl
  | app p q ihp ihq => intro Δ Θ r s; exact congrArg2 Term.app (ihp r s) (ihq r s)
  | neg p ih => intro Δ Θ r s; exact congrArg Term.neg (ih r s)
  | conj p q ihp ihq => intro Δ Θ r s; exact congrArg2 Term.conj (ihp r s) (ihq r s)
  | disj p q ihp ihq => intro Δ Θ r s; exact congrArg2 Term.disj (ihp r s) (ihq r s)
  | imp p q ihp ihq => intro Δ Θ r s; exact congrArg2 Term.imp (ihp r s) (ihq r s)
  | iff p q ihp ihq => intro Δ Θ r s; exact congrArg2 Term.iff (ihp r s) (ihq r s)
  | eq p q ihp ihq => intro Δ Θ r s; exact congrArg2 Term.eq (ihp r s) (ihq r s)
  | all p ih =>
      intro Δ Θ r s
      simpa only [rename, Ren.lift_comp] using congrArg Term.all (ih (Ren.lift r) (Ren.lift s))
  | ex p ih =>
      intro Δ Θ r s
      simpa only [rename, Ren.lift_comp] using congrArg Term.ex (ih (Ren.lift r) (Ren.lift s))
  | iAnd I p ih => intro Δ Θ r s; exact congrArg (Term.iAnd I) (funext (fun i => ih i r s))
  | iOr I p ih => intro Δ Θ r s; exact congrArg (Term.iOr I) (funext (fun i => ih i r s))

end Term

abbrev Subst (Param : Ty → Type u) (Γ Δ : Ctx) :=
  ∀ {σ : Ty}, Var Γ σ → Term Param Δ σ

namespace Subst

variable {Param : Ty → Type u}

def id : Subst Param Γ Γ := fun v => .var v
def nil : Subst Param [] Δ := fun v => nomatch v
def cons (p : Term Param Δ σ) (s : Subst Param Γ Δ) : Subst Param (σ :: Γ) Δ
  | _, .zero => p
  | _, .succ v => s v
def lift (s : Subst Param Γ Δ) : Subst Param (σ :: Γ) (σ :: Δ)
  | _, .zero => .var .zero
  | _, .succ v => (s v).wk

theorem lift_id : @Eq (Subst Param (σ :: Γ) (σ :: Γ))
    (Subst.lift Subst.id) Subst.id := by
  funext τ v
  cases v <;> rfl

theorem lift_compRen (s : Subst Param Δ Θ) (r : Ren Γ Δ) {σ : Ty} :
    @Eq (Subst Param (σ :: Γ) (σ :: Θ))
      (fun v => Subst.lift s (Ren.lift r v))
      (Subst.lift (fun v => s (r v))) := by
  funext τ v
  cases v <;> rfl

def ofRen (r : Ren Γ Δ) : Subst Param Γ Δ := fun v => .var (r v)

theorem lift_ofRen (r : Ren Γ Δ) {σ : Ty} :
    @Eq (Subst Param (σ :: Γ) (σ :: Δ))
      (Subst.lift (Subst.ofRen r)) (Subst.ofRen (Ren.lift r)) := by
  funext τ v
  cases v <;> rfl

/-- Lift a substitution under a finite tuple of bound argument variables. -/
def liftMany {Δ Θ : Ctx} : (Γ : Ctx) → Subst Param Δ Θ →
    Subst Param (Γ ++ Δ) (Γ ++ Θ)
  | [], s => s
  | _ :: Γ, s => Subst.lift (liftMany Γ s)

theorem liftMany_embed {Γ Δ Θ} (s : Subst Param Δ Θ)
    {σ} (v : Var Γ σ) :
    liftMany Γ s (Ren.embed Γ Δ v) = .var (Ren.embed Γ Θ v) := by
  induction v with
  | zero => rfl
  | succ v ih =>
      change (liftMany _ s (Ren.embed _ Δ v)).wk = _
      rw [ih]
      rfl

theorem liftMany_last_param (Γ : Ctx) {σ} (R : Param σ) :
    liftMany Γ (Subst.cons (.param R) (Subst.id : Subst Param [] []))
      (lastVar Γ σ) = .param R := by
  induction Γ with
  | nil => rfl
  | cons τ Γ ih =>
      change (liftMany Γ (Subst.cons (.param R) (Subst.id : Subst Param [] []))
        (lastVar Γ σ)).wk = _
      rw [ih]
      rfl

def append {Θ Δ : Ctx} : {Γ : Ctx} →
    Subst Param Γ Δ → Subst Param Θ Δ → Subst Param (Γ ++ Θ) Δ
  | [], _, t => t
  | _ :: _, s, t => cons (s .zero) (append (fun v => s (.succ v)) t)

theorem append_embed {Γ Θ Δ} (s : Subst Param Γ Δ) (t : Subst Param Θ Δ)
    {σ} (v : Var Γ σ) : append s t (Ren.embed Γ Θ v) = s v := by
  induction v with
  | zero => rfl
  | succ v ih => exact ih (fun v => s (.succ v))

theorem append_last (Γ : Ctx) {Δ σ} (s : Subst Param Γ Δ) (p : Term Param Δ σ) :
    append s (cons p nil) (lastVar Γ σ) = p := by
  induction Γ with
  | nil => rfl
  | cons τ Γ ih => exact ih (fun v => s (.succ v))

/-- Replace the final outer variable, retaining the displayed argument tuple. -/
def replaceLast (Γ : Ctx) {σ} (p : Term Param Γ σ) : Subst Param (Γ ++ [σ]) Γ :=
  append id (cons p nil)

theorem replaceLast_embed (Γ : Ctx) {σ τ} (p : Term Param Γ σ) (v : Var Γ τ) :
    replaceLast Γ p (Ren.embed Γ [σ] v) = .var v := append_embed _ _ v

theorem replaceLast_last (Γ : Ctx) {σ} (p : Term Param Γ σ) :
    replaceLast Γ p (lastVar Γ σ) = p := append_last Γ _ p

end Subst

namespace Term

variable {Param : Ty → Type u}

def subst {Γ Δ σ} (s : Subst Param Γ Δ) : Term Param Γ σ → Term Param Δ σ
  | .var v => s v
  | .param p => .param p
  | .app p q => .app (subst s p) (subst s q)
  | .top => .top
  | .bot => .bot
  | .neg p => .neg (subst s p)
  | .conj p q => .conj (subst s p) (subst s q)
  | .disj p q => .disj (subst s p) (subst s q)
  | .imp p q => .imp (subst s p) (subst s q)
  | .iff p q => .iff (subst s p) (subst s q)
  | .eq p q => .eq (subst s p) (subst s q)
  | .all p => .all (subst (Subst.lift s) p)
  | .ex p => .ex (subst (Subst.lift s) p)
  | .iAnd I p => .iAnd I (fun i => subst s (p i))
  | .iOr I p => .iOr I (fun i => subst s (p i))

@[simp] theorem subst_var {Γ Δ σ} (s : Subst Param Γ Δ) (v : Var Γ σ) :
    (.var v : Term Param Γ σ).subst s = s v := rfl

@[simp] theorem subst_param {Γ Δ σ} (s : Subst Param Γ Δ) (p : Param σ) :
    (.param p : Term Param Γ σ).subst s = .param p := rfl

theorem subst_id {Γ σ} (p : Term Param Γ σ) : p.subst Subst.id = p := by
  induction p with
  | var | param | top | bot => rfl
  | app p q ihp ihq => exact congrArg2 Term.app ihp ihq
  | neg p ih => exact congrArg Term.neg ih
  | conj p q ihp ihq => exact congrArg2 Term.conj ihp ihq
  | disj p q ihp ihq => exact congrArg2 Term.disj ihp ihq
  | imp p q ihp ihq => exact congrArg2 Term.imp ihp ihq
  | iff p q ihp ihq => exact congrArg2 Term.iff ihp ihq
  | eq p q ihp ihq => exact congrArg2 Term.eq ihp ihq
  | all p ih => simpa only [subst, Subst.lift_id] using congrArg Term.all ih
  | ex p ih => simpa only [subst, Subst.lift_id] using congrArg Term.ex ih
  | iAnd I p ih => exact congrArg (Term.iAnd I) (funext ih)
  | iOr I p ih => exact congrArg (Term.iOr I) (funext ih)

theorem subst_rename {Γ σ} (p : Term Param Γ σ) :
    ∀ {Δ Θ} (r : Ren Γ Δ) (s : Subst Param Δ Θ),
      (p.rename r).subst s = p.subst (fun v => s (r v)) := by
  induction p with
  | var | param | top | bot => intros; rfl
  | app p q ihp ihq => intro Δ Θ r s; exact congrArg2 Term.app (ihp r s) (ihq r s)
  | neg p ih => intro Δ Θ r s; exact congrArg Term.neg (ih r s)
  | conj p q ihp ihq => intro Δ Θ r s; exact congrArg2 Term.conj (ihp r s) (ihq r s)
  | disj p q ihp ihq => intro Δ Θ r s; exact congrArg2 Term.disj (ihp r s) (ihq r s)
  | imp p q ihp ihq => intro Δ Θ r s; exact congrArg2 Term.imp (ihp r s) (ihq r s)
  | iff p q ihp ihq => intro Δ Θ r s; exact congrArg2 Term.iff (ihp r s) (ihq r s)
  | eq p q ihp ihq => intro Δ Θ r s; exact congrArg2 Term.eq (ihp r s) (ihq r s)
  | all p ih =>
      intro Δ Θ r s
      simpa only [rename, subst, Subst.lift_compRen] using
        congrArg Term.all (ih (Ren.lift r) (Subst.lift s))
  | ex p ih =>
      intro Δ Θ r s
      simpa only [rename, subst, Subst.lift_compRen] using
        congrArg Term.ex (ih (Ren.lift r) (Subst.lift s))
  | iAnd I p ih => intro Δ Θ r s; exact congrArg (Term.iAnd I) (funext (fun i => ih i r s))
  | iOr I p ih => intro Δ Θ r s; exact congrArg (Term.iOr I) (funext (fun i => ih i r s))


/-- Renaming is the special case of substitution replacing variables by variables. -/
theorem rename_eq_subst {Γ σ} (p : Term Param Γ σ) :
    ∀ {Δ} (r : Ren Γ Δ), p.rename r = p.subst (Subst.ofRen r) := by
  induction p with
  | var | param | top | bot => intros; rfl
  | app p q ihp ihq => intro Δ r; exact congrArg2 Term.app (ihp r) (ihq r)
  | neg p ih => intro Δ r; exact congrArg Term.neg (ih r)
  | conj p q ihp ihq => intro Δ r; exact congrArg2 Term.conj (ihp r) (ihq r)
  | disj p q ihp ihq => intro Δ r; exact congrArg2 Term.disj (ihp r) (ihq r)
  | imp p q ihp ihq => intro Δ r; exact congrArg2 Term.imp (ihp r) (ihq r)
  | iff p q ihp ihq => intro Δ r; exact congrArg2 Term.iff (ihp r) (ihq r)
  | eq p q ihp ihq => intro Δ r; exact congrArg2 Term.eq (ihp r) (ihq r)
  | all p ih =>
      intro Δ r
      simpa only [rename, subst, Subst.lift_ofRen] using
        congrArg Term.all (ih (Ren.lift r))
  | ex p ih =>
      intro Δ r
      simpa only [rename, subst, Subst.lift_ofRen] using
        congrArg Term.ex (ih (Ren.lift r))
  | iAnd I p ih => intro Δ r; exact congrArg (Term.iAnd I) (funext (fun i => ih i r))
  | iOr I p ih => intro Δ r; exact congrArg (Term.iOr I) (funext (fun i => ih i r))

/-- Substituting after weakening discards the new variable's replacement. -/
theorem subst_wk {Γ Δ σ τ} (p : Term Param Γ σ) (s : Subst Param (τ :: Γ) Δ) :
    p.wk.subst s = p.subst (fun v => s (.succ v)) :=
  subst_rename p Ren.shift s

/-- Substitute an actual parameter for the newly bound variable. -/
def instantiate {Γ σ τ} (p : Term Param (σ :: Γ) τ) (a : Term Param Γ σ) :
    Term Param Γ τ := p.subst (Subst.cons a Subst.id)

theorem instantiate_wk {Γ σ τ} (p : Term Param Γ τ) (a : Term Param Γ σ) :
    p.wk.instantiate a = p := by
  exact (subst_wk p (Subst.cons a Subst.id)).trans (subst_id p)

/-- Replace all free parameter tokens and context variables by carrier tokens.
This is a purely syntactic closing operation, not evaluation. -/
def closeParams {D : Ty → Type u} {Γ σ}
    (η : ∀ {τ}, Param τ → D τ) (xs : Env D Γ) (p : Term Param Γ σ) : Term D [] σ :=
  (p.mapParam η).subst (fun v => .param (xs v))

@[simp] theorem closeParams_var {D : Ty → Type u} {Γ σ}
    (η : ∀ {τ}, Param τ → D τ) (xs : Env D Γ) (v : Var Γ σ) :
    closeParams η xs (.var v) = .param (xs v) := rfl

@[simp] theorem closeParams_param {D : Ty → Type u} {Γ σ}
    (η : ∀ {τ}, Param τ → D τ) (xs : Env D Γ) (p : Param σ) :
    closeParams η xs (.param p) = .param (η p) := rfl

/-- Close only the outer context while preserving one bound variable. -/
def closeOuter {D : Ty → Type u} {Γ σ τ}
    (η : ∀ {ρ}, Param ρ → D ρ) (xs : Env D Γ) (p : Term Param (σ :: Γ) τ) :
    Term D [σ] τ :=
  (p.mapParam η).subst (Subst.lift (fun v => .param (xs v)))

@[simp] theorem closeParams_all {D : Ty → Type u} {Γ σ}
    (η : ∀ {τ}, Param τ → D τ) (xs : Env D Γ) (p : Formula Param (σ :: Γ)) :
    closeParams η xs (.all p) = .all (closeOuter η xs p) := rfl

@[simp] theorem closeParams_ex {D : Ty → Type u} {Γ σ}
    (η : ∀ {τ}, Param τ → D τ) (xs : Env D Γ) (p : Formula Param (σ :: Γ)) :
    closeParams η xs (.ex p) = .ex (closeOuter η xs p) := rfl

/-- Apply a relation to the displayed finite argument variables. -/
def applyVars {Δ : Ctx} : (Γ : Ctx) → Term Param Δ (RTy.ofArgs Γ) →
    (∀ {σ}, Var Γ σ → Term Param Δ σ) → Formula Param Δ
  | [], R, _ => R
  | _ :: Γ, R, xs => applyVars Γ (.app R (xs .zero)) (fun v => xs (.succ v))

/-- Bind the displayed finite argument context. -/
def closeAll {Δ : Ctx} : (Γ : Ctx) → Formula Param (Γ ++ Δ) → Formula Param Δ
  | [], p => p
  | _ :: Γ, p => closeAll Γ (.all p)

/-- Close a matrix whose context is written without the empty suffix. -/
def universalClosure {Γ : Ctx} (A : Formula Param Γ) : Formula Param [] :=
  closeAll Γ (A.rename (Ren.embed Γ []))

def compBody {Γ : Ctx} (A : Formula Param Γ) :
    Formula Param (Γ ++ [Ty.rel (RTy.ofArgs Γ)]) :=
  .iff (applyVars Γ (.var (lastVar Γ _)) (fun v => .var (Ren.embed Γ _ v)))
    (A.rename (Ren.embed Γ _))

/-- The actual native boxed representation matrix with its R variable free. -/
def repBody {Γ : Ctx} (A : Formula Param Γ) :
    Formula Param [Ty.rel (RTy.ofArgs Γ)] := .box (closeAll Γ A.compBody)

/-- Infinitary Comprehension: the object-language formula ∃R □∀xs(R[xs]↔A). -/
def comprehension {Γ : Ctx} (A : Formula Param Γ) : Formula Param [] :=
  .ex A.repBody

/-- Whole-operation sameness: one R is a boxed representative of both codes. -/
def sameFormula {Γ : Ctx} (A B : Formula Param Γ) : Formula Param [] :=
  .ex (.conj A.repBody B.repBody)

/-- Representation by a named parameter, with the finite argument spine closed. -/
def repFormula {Γ : Ctx} (R : Param (RTy.ofArgs Γ)) (A : Formula Param Γ) :
    Formula Param [] :=
  .box (universalClosure (.iff (applyVars Γ (.param R) (fun v => .var v)) A))

theorem subst_applyVars {Δ Θ : Ctx} (s : Subst Param Δ Θ) :
    ∀ (Γ : Ctx) (R : Term Param Δ (RTy.ofArgs Γ))
      (xs : ∀ {σ}, Var Γ σ → Term Param Δ σ),
      (applyVars Γ R xs).subst s =
        applyVars Γ (R.subst s) (fun v => (xs v).subst s) := by
  intro Γ
  induction Γ with
  | nil => intros; rfl
  | cons σ Γ ih =>
      intro R xs
      exact ih (.app R (xs .zero)) (fun v => xs (.succ v))


theorem rename_applyVars {Δ Θ : Ctx} (r : Ren Δ Θ) :
    ∀ (Γ : Ctx) (R : Term Param Δ (RTy.ofArgs Γ))
      (xs : ∀ {σ}, Var Γ σ → Term Param Δ σ),
      (applyVars Γ R xs).rename r =
        applyVars Γ (R.rename r) (fun v => (xs v).rename r) := by
  intro Γ
  induction Γ with
  | nil => intros; rfl
  | cons σ Γ ih =>
      intro R xs
      exact ih (.app R (xs .zero)) (fun v => xs (.succ v))

/-- A substitution into outer variables commutes with finite universal closure. -/
theorem subst_closeAll {Δ Θ : Ctx} (s : Subst Param Δ Θ) :
    ∀ (Γ : Ctx) (A : Formula Param (Γ ++ Δ)),
      (closeAll Γ A).subst s = closeAll Γ (A.subst (Subst.liftMany Γ s)) := by
  intro Γ
  induction Γ with
  | nil => intros; rfl
  | cons σ Γ ih => intro A; exact ih (.all A)

/-- General substitution formula for the concrete comprehension matrix. -/
theorem subst_compBody_general {Γ Δ : Ctx} (A : Formula Param Γ)
    (s : Subst Param (Γ ++ [Ty.rel (RTy.ofArgs Γ)]) Δ) :
    A.compBody.subst s =
      .iff (applyVars Γ (s (lastVar Γ _)) (fun v => s (Ren.embed Γ _ v)))
        (A.subst (fun v => s (Ren.embed Γ _ v))) := by
  change Term.iff
    ((applyVars Γ (.var (lastVar Γ _)) (fun v => .var (Ren.embed Γ _ v))).subst s)
    ((A.rename (Ren.embed Γ _)).subst s) = _
  rw [subst_applyVars, subst_rename]
  rfl

/-- Replacing the outer representative in the concrete comprehension body
leaves the original matrix and its finite argument variables unchanged. -/
theorem subst_compBody {Γ : Ctx} (A : Formula Param Γ)
    (R : Term Param Γ (RTy.ofArgs Γ)) :
    A.compBody.subst (Subst.replaceLast Γ R) =
      .iff (applyVars Γ R (fun v => .var v)) A := by
  change Term.iff
    ((applyVars Γ (.var (lastVar Γ _)) (fun v => .var (Ren.embed Γ _ v))).subst _)
    ((A.rename (Ren.embed Γ _)).subst _) = _
  apply congrArg2 Term.iff
  · rw [subst_applyVars]
    simp only [subst_var, Subst.replaceLast_last, Subst.replaceLast_embed]
  · rw [subst_rename]
    have h : @Eq (Subst Param Γ Γ)
        (fun v => Subst.replaceLast Γ R (Ren.embed Γ _ v)) Subst.id := by
      funext σ v
      exact Subst.replaceLast_embed Γ R v
    rw [h]
    exact subst_id A


/-- Extracting the existential witness from IC gives exactly the displayed
native boxed representation formula. This identity needs no C principle. -/
theorem instantiate_repBody {Γ : Ctx} (A : Formula Param Γ)
    (R : Param (RTy.ofArgs Γ)) :
    A.repBody.instantiate (.param R) = repFormula R A := by
  change Term.eq
    ((closeAll Γ A.compBody).subst
      (Subst.cons (.param R) (Subst.id : Subst Param [] []))) .top = _
  rw [subst_closeAll]
  apply congrArg (fun p : Formula Param [] => Term.eq p Term.top)
  apply congrArg (closeAll Γ)
  rw [subst_compBody_general]
  change Term.iff
    (applyVars Γ
      (Subst.liftMany Γ (Subst.cons (.param R) (Subst.id : Subst Param [] []))
        (lastVar Γ _))
      (fun v => Subst.liftMany Γ
        (Subst.cons (.param R) (Subst.id : Subst Param [] [])) (Ren.embed Γ _ v)))
    (A.subst (fun v => Subst.liftMany Γ
      (Subst.cons (.param R) (Subst.id : Subst Param [] [])) (Ren.embed Γ _ v))) =
      Term.iff
        ((applyVars Γ (.param R) (fun v => .var v)).rename (Ren.embed Γ []))
        (A.rename (Ren.embed Γ []))
  rw [rename_applyVars]
  apply congrArg2 Term.iff
  · simp only [Subst.liftMany_last_param, Subst.liftMany_embed, rename]
  · simp only [Subst.liftMany_embed]
    exact (rename_eq_subst A (Ren.embed Γ [])).symm

#print axioms subst_compBody
#print axioms instantiate_repBody
#print axioms rename_eq_subst
#print axioms subst_id
#print axioms subst_wk

end Term

end Classicism.Research.InfinitaryComprehension.HLanguage
