import Classicism.Results.Research.InfinitaryComprehensionHEndpoint

/-!
# The remaining endpoint clauses in the native object language

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, section 1; misc, 26 October 2026, unpaginated.

The inner Same clauses have already been interpreted in HBootstrap. These
lemmas check the endpoint range and translated equality guards against
actual native formulas, and restore the two directions of the displayed
separation biconditional. The outer schema quantifiers are read by the
ordinary current binder clauses; there is no model-relative language extension.
-/

namespace Classicism.Research.InfinitaryComprehension.HEndpointLanguage

open Classicism.Meta EndpointCanonical EndpointBootstrap HBootstrap HEndpoint

universe u

variable {S : TypedOps.{u}} (M : HModel.Model S)

def endpointFormula (E : Observer (S := S)) : HLanguage.Formula S.Dom [] :=
  .all (.disj (.eq (.app (.param E) (.var .zero)) .top)
    (.eq (.app (.param E) (.var .zero)) .bot))

theorem truth_endpointFormula (E : Observer (S := S)) :
    S.truth (M.eval (endpointFormula E) HLanguage.Env.nil) ↔
      EndpointValued (H := S.core) S.app E := by
  change S.truth (M.eval (.all _) HLanguage.Env.nil) ↔ _
  rw [M.truth_all]
  apply forall_congr'
  intro p
  rw [M.eval_disj, S.truth_disj, M.eval_eq, M.eval_eq,
    M.eval_app, M.eval_param, M.eval_var, M.eval_top, M.eval_bot]
  exact or_congr (S.truth_eq (S.app E p) S.core.top) (S.truth_eq (S.app E p) S.core.bot)

def reflexivityFormula (σ : Ty) (E : Observer (S := S)) : HLanguage.Formula S.Dom [] :=
  .all (.app (.param E) (.eq (.var (.zero : Var [σ] σ)) (.var .zero)))

theorem truth_reflexivityFormula (σ : Ty) (E : Observer (S := S)) :
    S.truth (M.eval (reflexivityFormula σ E) HLanguage.Env.nil) ↔
      ∀ x : S.Dom σ, S.truth (S.app E (S.eq x x)) := by
  change S.truth (M.eval (.all _) HLanguage.Env.nil) ↔ _
  rw [M.truth_all]
  apply forall_congr'
  intro x
  rw [M.eval_app, M.eval_param, M.eval_eq, M.eval_var]
  rfl

def leibnizFormula (σ : Ty) (E : Observer (S := S)) : HLanguage.Formula S.Dom [] :=
  .all (.all (.all (.imp
    (.app (.param E) (.eq
      (.var (.succ (.succ (.zero : Var [σ] σ)) : Var [σ ⇒ RTy.t, σ, σ] σ))
      (.var (.succ .zero))))
    (.imp
      (.app (.param E) (.app (.var .zero) (.var (.succ (.succ .zero)))))
      (.app (.param E) (.app (.var .zero) (.var (.succ .zero))))))))

theorem truth_leibnizFormula (σ : Ty) (E : Observer (S := S)) :
    S.truth (M.eval (leibnizFormula σ E) HLanguage.Env.nil) ↔
      ∀ x y : S.Dom σ, ∀ F : S.Dom (σ ⇒ RTy.t),
      S.truth (S.app E (S.eq x y)) →
      S.truth (S.app E (S.app F x)) → S.truth (S.app E (S.app F y)) := by
  change S.truth (M.eval (.all _) HLanguage.Env.nil) ↔ _
  rw [M.truth_all]
  apply forall_congr'
  intro x
  rw [M.truth_all]
  apply forall_congr'
  intro y
  rw [M.truth_all]
  apply forall_congr'
  intro F
  simp only [M.eval_imp, M.eval_app, M.eval_param, M.eval_eq, M.eval_var]
  exact (S.core.truth_imp _ _).trans
    (imp_congr_right (fun _ => S.core.truth_imp _ _))

/-- Only the separating direction needs to be assumed. The other direction
of the user's object-language biconditional is ordinary equality substitution. -/
theorem endpointOS_biconditional : EndpointOS M ↔
    ∀ (Γ : Ctx) (Δ : List Ty) (R T : S.Dom (RTy.ofArgs Γ)),
      S.truth (S.eq R T) ↔
        ∀ E : Observer (S := S), Qualification M Δ E → (booleans M).GoodBoolean E →
          ∀ xs : S.Env Γ,
          S.truth (S.app E (S.uncurry Γ R xs)) ↔
          S.truth (S.app E (S.uncurry Γ T xs)) := by
  constructor
  · intro h Γ Δ R T
    constructor
    · intro he
      cases (S.truth_eq R T).mp he
      intro E hQ hB xs
      exact Iff.rfl
    · intro hprof
      exact (S.truth_eq R T).mpr (h Γ Δ R T hprof)
  · intro h Γ Δ R T hprof
    exact (S.truth_eq R T).mp ((h Γ Δ R T).mpr hprof)

#print axioms truth_endpointFormula
#print axioms truth_reflexivityFormula
#print axioms truth_leibnizFormula
#print axioms endpointOS_biconditional

end Classicism.Research.InfinitaryComprehension.HEndpointLanguage
