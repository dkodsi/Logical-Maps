import Classicism.Results.Research.InfinitaryComprehensionHTheorem

/-!
# Direct interpretation of native H syntax

Original research, misc, 26 October 2026. Every constructor of the native
lambda-free grammar embeds literally into the expanded grammar used by
the certified standard interpretation. The embedding introduces no
`boxOp` node. In particular native necessity remains identity with top.
The inverse translation is proved on actual syntax, including arbitrary
infinitary conjunctions and disjunctions. This gives a direct evaluation
theorem for native terms with simultaneous parameters.
-/

namespace Classicism.Research.InfinitaryComprehension.HNativeInterpretation

open Classicism.Meta

universe u

variable {Param D : Ty → Type u}

def embed : {Γ : Ctx} → {σ : Ty} →
    HLanguage.Term Param Γ σ → InfinitaryComprehension.Term Param Γ σ
  | _, _, .var v => .var v
  | _, _, .param p => .param p
  | _, _, .app p q => .app (embed p) (embed q)
  | _, _, .top => .top
  | _, _, .bot => .bot
  | _, _, .neg p => .neg (embed p)
  | _, _, .conj p q => .conj (embed p) (embed q)
  | _, _, .disj p q => .disj (embed p) (embed q)
  | _, _, .imp p q => .imp (embed p) (embed q)
  | _, _, .iff p q => .iff (embed p) (embed q)
  | _, _, .eq p q => .eq (embed p) (embed q)
  | _, _, .all p => .all (embed p)
  | _, _, .ex p => .ex (embed p)
  | _, _, .iAnd I p => .iAnd I (fun i => embed (p i))
  | _, _, .iOr I p => .iOr I (fun i => embed (p i))

theorem embed_native_box {Γ : Ctx} (p : HLanguage.Formula Param Γ) :
    embed p.box = InfinitaryComprehension.Term.eq (embed p) .top := rfl

theorem translate_embed (boxObj : D (Ty.t ⇒ RTy.t))
    (η : ∀ {σ : Ty}, Param σ → D σ) {Γ σ}
    (p : HLanguage.Term Param Γ σ) :
    HExpandedSyntax.translate boxObj η (embed p) = p.mapParam η := by
  induction p with
  | var | param | top | bot => rfl
  | app p q ihp ihq => exact HLanguage.congrArg2 HLanguage.Term.app ihp ihq
  | neg p ih => exact congrArg HLanguage.Term.neg ih
  | conj p q ihp ihq => exact HLanguage.congrArg2 HLanguage.Term.conj ihp ihq
  | disj p q ihp ihq => exact HLanguage.congrArg2 HLanguage.Term.disj ihp ihq
  | imp p q ihp ihq => exact HLanguage.congrArg2 HLanguage.Term.imp ihp ihq
  | iff p q ihp ihq => exact HLanguage.congrArg2 HLanguage.Term.iff ihp ihq
  | eq p q ihp ihq => exact HLanguage.congrArg2 HLanguage.Term.eq ihp ihq
  | all p ih => exact congrArg HLanguage.Term.all ih
  | ex p ih => exact congrArg HLanguage.Term.ex ih
  | iAnd I p ih => exact congrArg (HLanguage.Term.iAnd I) (funext ih)
  | iOr I p ih => exact congrArg (HLanguage.Term.iOr I) (funext ih)

#print axioms translate_embed

end Classicism.Research.InfinitaryComprehension.HNativeInterpretation

namespace Classicism.Research.InfinitaryComprehension.HTheorem

open Classicism.Meta EndpointCanonical HEndpoint

universe u

variable {S : TypedOps.{u}} (M : HModel.Model S)
variable (hOS : EndpointOS M) (hIC : M.Comprehension)

/-- Direct interpretation of actual native syntax. Native identity with
top, arbitrary finite binders, simultaneous parameters and both infinitary
connectives are retained by the displayed embedding. -/
theorem native_syntax_interpretation {Param : Ty → Type u}
    (η : ∀ {σ}, Param σ → S.Dom σ) {Γ σ}
    (p : HLanguage.Term Param Γ σ) (xs : S.Env Γ) :
    M.eval (p.mapParam η) xs =
      Henkin.eval (canonical M hOS hIC) η (HNativeInterpretation.embed p) xs :=
  (congrArg (fun q : HLanguage.Term S.Dom Γ σ => M.eval q xs)
    (HNativeInterpretation.translate_embed (boxObject M hOS hIC) η p).symm).trans
      (syntax_interpretation M hOS hIC η (HNativeInterpretation.embed p) xs)

#print axioms native_syntax_interpretation

end Classicism.Research.InfinitaryComprehension.HTheorem
