import Classicism.Results.Research.InfinitaryComprehensionHLanguage
import Classicism.Results.Research.InfinitaryComprehensionSyntax

/-!
# Translate the expanded infinitary grammar into native H syntax

Direct source: `research/2026-10-23/infinitary-comprehension/
endpoint-development.md`, sections 1--4; misc, 26 October 2026, unpaginated.

The earlier canonical-model grammar contains a first-class `boxOp` node.
This translation replaces that node by a supplied carrier parameter. The
semantic adapter must obtain that parameter by finite IC and prove its
application is native identity with top. No primitive box operation is
introduced into H by this syntax translation.

Every binder and infinitary index set is retained. The translation commutes
with renaming, finite application spines, finite universal closure and the
actual comprehension matrix. A translated expanded box is an application;
its agreement with native box is a semantic theorem, not syntactic identity.
-/

namespace Classicism.Research.InfinitaryComprehension.HExpandedSyntax

open Classicism.Meta

universe u

variable {Param D : Ty → Type u}

def translate (boxObj : D (RTy.t ⇒ RTy.t))
    (η : ∀ {σ : Ty}, Param σ → D σ) :
    {Γ : Ctx} → {σ : Ty} →
      InfinitaryComprehension.Term Param Γ σ → HLanguage.Term D Γ σ
  | _, _, .var v => .var v
  | _, _, .param p => .param (η p)
  | _, _, .app p q => .app (translate boxObj η p) (translate boxObj η q)
  | _, _, .top => .top
  | _, _, .bot => .bot
  | _, _, .neg p => .neg (translate boxObj η p)
  | _, _, .conj p q => .conj (translate boxObj η p) (translate boxObj η q)
  | _, _, .disj p q => .disj (translate boxObj η p) (translate boxObj η q)
  | _, _, .imp p q => .imp (translate boxObj η p) (translate boxObj η q)
  | _, _, .iff p q => .iff (translate boxObj η p) (translate boxObj η q)
  | _, _, .eq p q => .eq (translate boxObj η p) (translate boxObj η q)
  | _, _, .boxOp => .param boxObj
  | _, _, .all p => .all (translate boxObj η p)
  | _, _, .ex p => .ex (translate boxObj η p)
  | _, _, .iAnd I p => .iAnd I (fun i => translate boxObj η (p i))
  | _, _, .iOr I p => .iOr I (fun i => translate boxObj η (p i))

variable (boxObj : D (RTy.t ⇒ RTy.t)) (η : ∀ {σ : Ty}, Param σ → D σ)

theorem lastVar_eq (Γ : Ctx) (σ : Ty) :
    InfinitaryComprehension.lastVar Γ σ = HLanguage.lastVar Γ σ := by
  induction Γ with
  | nil => rfl
  | cons τ Γ ih => exact congrArg Var.succ ih

theorem embed_eq (Γ Δ : Ctx) :
    @Eq (HLanguage.Ren Γ (Γ ++ Δ))
      (InfinitaryComprehension.Ren.embed Γ Δ) (HLanguage.Ren.embed Γ Δ) := by
  funext σ v
  induction v with
  | zero => rfl
  | succ v ih => exact congrArg Var.succ ih

theorem translate_rename {Γ σ} (p : InfinitaryComprehension.Term Param Γ σ) :
    ∀ {Δ} (r : InfinitaryComprehension.Ren Γ Δ),
      translate boxObj η (p.rename r) = (translate boxObj η p).rename r := by
  induction p with
  | var | param | top | bot | boxOp => intros; rfl
  | app p q ihp ihq => intro Δ r; exact HLanguage.congrArg2 HLanguage.Term.app (ihp r) (ihq r)
  | neg p ih => intro Δ r; exact congrArg HLanguage.Term.neg (ih r)
  | conj p q ihp ihq => intro Δ r; exact HLanguage.congrArg2 HLanguage.Term.conj (ihp r) (ihq r)
  | disj p q ihp ihq => intro Δ r; exact HLanguage.congrArg2 HLanguage.Term.disj (ihp r) (ihq r)
  | imp p q ihp ihq => intro Δ r; exact HLanguage.congrArg2 HLanguage.Term.imp (ihp r) (ihq r)
  | iff p q ihp ihq => intro Δ r; exact HLanguage.congrArg2 HLanguage.Term.iff (ihp r) (ihq r)
  | eq p q ihp ihq => intro Δ r; exact HLanguage.congrArg2 HLanguage.Term.eq (ihp r) (ihq r)
  | all p ih => intro Δ r; exact congrArg HLanguage.Term.all (ih (InfinitaryComprehension.Ren.lift r))
  | ex p ih => intro Δ r; exact congrArg HLanguage.Term.ex (ih (InfinitaryComprehension.Ren.lift r))
  | iAnd I p ih => intro Δ r; exact congrArg (HLanguage.Term.iAnd I) (funext (fun i => ih i r))
  | iOr I p ih => intro Δ r; exact congrArg (HLanguage.Term.iOr I) (funext (fun i => ih i r))

theorem translate_applyVars {Δ : Ctx} :
    ∀ (Γ : Ctx) (R : InfinitaryComprehension.Term Param Δ (RTy.ofArgs Γ))
      (xs : ∀ {σ}, Var Γ σ → InfinitaryComprehension.Term Param Δ σ),
      translate boxObj η (InfinitaryComprehension.Term.applyVars Γ R xs) =
        HLanguage.Term.applyVars Γ (translate boxObj η R)
          (fun v => translate boxObj η (xs v)) := by
  intro Γ
  induction Γ with
  | nil => intros; rfl
  | cons σ Γ ih =>
      intro R xs
      exact ih (.app R (xs .zero)) (fun v => xs (.succ v))

theorem translate_closeAll {Δ : Ctx} :
    ∀ (Γ : Ctx) (p : InfinitaryComprehension.Formula Param (Γ ++ Δ)),
      translate boxObj η (InfinitaryComprehension.Term.closeAll Γ p) =
        HLanguage.Term.closeAll Γ (translate boxObj η p) := by
  intro Γ
  induction Γ with
  | nil => intros; rfl
  | cons σ Γ ih => intro p; exact ih (.all p)

theorem translate_compBody {Γ : Ctx} (p : InfinitaryComprehension.Formula Param Γ) :
    translate boxObj η p.compBody = (translate boxObj η p).compBody := by
  change HLanguage.Term.iff
    (translate boxObj η
      (InfinitaryComprehension.Term.applyVars Γ
        (.var (InfinitaryComprehension.lastVar Γ _))
        (fun v => .var (InfinitaryComprehension.Ren.embed Γ _ v))))
    (translate boxObj η (p.rename (InfinitaryComprehension.Ren.embed Γ _))) = _
  rw [translate_applyVars, translate_rename]
  simp only [translate, lastVar_eq, embed_eq, HLanguage.Term.compBody]

/-- This is application of the represented operator. Native-box agreement
is deliberately left to the semantic theorem using its finite IC witness. -/
theorem translate_box {Γ : Ctx} (p : InfinitaryComprehension.Formula Param Γ) :
    translate boxObj η p.box =
      .app (.param boxObj) (translate boxObj η p) := rfl

/-- Exact syntax of the translated expanded comprehension formula. -/
theorem translate_comprehension {Γ : Ctx} (p : InfinitaryComprehension.Formula Param Γ) :
    translate boxObj η p.comprehension =
      .ex (.app (.param boxObj)
        (HLanguage.Term.closeAll Γ (translate boxObj η p).compBody)) := by
  change HLanguage.Term.ex (.app (.param boxObj)
    (translate boxObj η (InfinitaryComprehension.Term.closeAll Γ p.compBody))) = _
  rw [translate_closeAll, translate_compBody]

#print axioms translate_compBody
#print axioms translate_comprehension

end Classicism.Research.InfinitaryComprehension.HExpandedSyntax
