import Classicism.Results.Research.InfinitaryComprehensionHOriginalSchemas

/-!
# Transport original native comprehension through actual type grounding

Original research, misc, 26 October 2026. The casts below express proved
identities between grounded finite context and relation-type expressions.
They add no model assumption or comprehension instance.
-/

namespace Classicism.Research.InfinitaryComprehension.HOriginalICGrounding

open Classicism.Meta Grounding HOriginalTypes HOriginalSchemas
open EndpointOriginalTypes (OriginalTypedOps)

universe u v

variable {Param : Ty → Type u}

namespace Transport

/-- Retype only the result relation sort using a proved equality. -/
def castRel {P : Ty → Type u} {Γ : Ctx} {ρ τ : RTy}
    (h : ρ = τ) (p : HLanguage.Term P Γ ρ) : HLanguage.Term P Γ τ := h ▸ p

theorem castRel_app {P : Ty → Type u} {Γ : Ctx} {σ : Ty} {ρ τ : RTy}
    (h : ρ = τ) (f : HLanguage.Term P Γ (σ ⇒ ρ)) (a : HLanguage.Term P Γ σ) :
    castRel h (.app f a) = .app (castRel (congrArg (RTy.arr σ) h) f) a := by
  cases h
  rfl

def castCtx {P : Ty → Type u} {Γ Δ : Ctx} {σ : Ty}
    (h : Γ = Δ) (p : HLanguage.Term P Γ σ) : HLanguage.Term P Δ σ := h ▸ p

def castVar {Γ Δ : Ctx} {σ : Ty} (h : Γ = Δ) (v : Var Γ σ) : Var Δ σ := h ▸ v

theorem castVar_cons {Γ Δ : Ctx} {σ τ : Ty} (h : Γ = Δ) (v : Var Γ σ) :
    castVar (congrArg (List.cons τ) h) (.succ v) = .succ (castVar h v) := by
  cases h
  rfl

theorem castVar_zero {Γ Δ : Ctx} (σ : Ty) (h : Γ = Δ) :
    castVar (congrArg (List.cons σ) h) (.zero : Var (σ :: Γ) σ) = .zero := by
  cases h
  rfl

theorem castCtx_var {P : Ty → Type u} {Γ Δ : Ctx} {σ : Ty}
    (h : Γ = Δ) (v : Var Γ σ) :
    castCtx h (.var v : HLanguage.Term P Γ σ) = .var (castVar h v) := by
  cases h
  rfl

theorem castCtx_all {P : Ty → Type u} {Γ Δ : Ctx} {σ : Ty}
    (h : Γ = Δ) (p : HLanguage.Formula P (σ :: Γ)) :
    castCtx h (.all p) = .all (castCtx (congrArg (List.cons σ) h) p) := by
  cases h
  rfl

theorem castCtx_applyVars {P : Ty → Type u} {Δ Θ : Ctx} (h : Δ = Θ)
    (Γ : Ctx) (R : HLanguage.Term P Δ (RTy.ofArgs Γ))
    (xs : ∀ {σ}, Var Γ σ → HLanguage.Term P Δ σ) :
    castCtx h (HLanguage.Term.applyVars Γ R xs) =
      HLanguage.Term.applyVars Γ (castCtx h R) (fun v => castCtx h (xs v)) := by
  cases h
  rfl

theorem castCtx_castRel {P : Ty → Type u} {Γ Δ : Ctx} {ρ τ : RTy}
    (hΓ : Γ = Δ) (hρ : ρ = τ) (p : HLanguage.Term P Γ ρ) :
    castCtx hΓ (castRel hρ p) = castRel hρ (castCtx hΓ p) := by
  cases hΓ
  cases hρ
  rfl

end Transport

open Transport

/-- Application along a finite spine commutes with grounding, with the
single explicit arity cast required by the relational type datatype. -/
theorem groundTerm_applyVars {Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ)) {Δ : Ctx} :
    ∀ (Γ : Ctx) (R : HLanguage.Term Param Δ (RTy.ofArgs Γ))
      (xs : ∀ {σ}, Var Γ σ → HLanguage.Term Param Δ σ)
      (ys : ∀ {σ}, Var (groundCtx Γ) σ → HLanguage.Term Param' (groundCtx Δ) σ),
      (∀ {σ} (v : Var Γ σ), groundTerm mapParam (xs v) = ys (groundVar v)) →
      groundTerm mapParam (HLanguage.Term.applyVars Γ R xs) =
        HLanguage.Term.applyVars (groundCtx Γ)
          (castRel (groundRTy_ofArgs Γ) (groundTerm mapParam R)) ys := by
  intro Γ
  induction Γ with
  | nil => intros; rfl
  | cons σ Γ ih =>
      intro R xs ys h
      change groundTerm mapParam
        (HLanguage.Term.applyVars Γ (.app R (xs .zero)) (fun v => xs (.succ v))) =
          HLanguage.Term.applyVars (groundCtx Γ)
            (.app (castRel (groundRTy_ofArgs (σ :: Γ)) (groundTerm mapParam R)) (ys .zero))
            (fun v => ys (.succ v))
      rw [ih (.app R (xs .zero)) (fun v => xs (.succ v))
        (fun v => ys (.succ v)) (fun v => h (.succ v))]
      have he : castRel (groundRTy_ofArgs Γ) (groundTerm mapParam (.app R (xs .zero))) =
          .app (castRel (groundRTy_ofArgs (σ :: Γ)) (groundTerm mapParam R)) (ys .zero) := by
        change castRel (groundRTy_ofArgs Γ)
          (.app (groundTerm mapParam R) (groundTerm mapParam (xs .zero))) = _
        exact (castRel_app (groundRTy_ofArgs Γ)
          (groundTerm mapParam R) (groundTerm mapParam (xs .zero))).trans
          (congrArg (fun a => HLanguage.Term.app
            (castRel (groundRTy_ofArgs (σ :: Γ)) (groundTerm mapParam R)) a) (h .zero))
      rw [he]

/-- Grounding distributes over an appended finite context. -/
theorem groundCtx_append (Γ Δ : Ctx) :
    groundCtx (Γ ++ Δ) = groundCtx Γ ++ groundCtx Δ := List.map_append

theorem groundVar_embed {Γ Δ : Ctx} {σ : Ty} (v : Var Γ σ) :
    castVar (groundCtx_append Γ Δ) (groundVar (HLanguage.Ren.embed Γ Δ v)) =
      HLanguage.Ren.embed (groundCtx Γ) (groundCtx Δ) (groundVar v) := by
  induction v with
  | zero => exact castVar_zero _ (groundCtx_append _ Δ)
  | succ v ih =>
      exact (castVar_cons (groundCtx_append _ Δ)
        (groundVar (HLanguage.Ren.embed _ Δ v))).trans (congrArg Var.succ ih)

theorem groundVar_last (Γ : Ctx) (σ : Ty) :
    castVar (groundCtx_append Γ [σ]) (groundVar (HLanguage.lastVar Γ σ)) =
      HLanguage.lastVar (groundCtx Γ) (groundTy σ) := by
  induction Γ with
  | nil => rfl
  | cons τ Γ ih =>
      exact (castVar_cons (groundCtx_append Γ [σ])
        (groundVar (HLanguage.lastVar Γ σ))).trans (congrArg Var.succ ih)

/-- Every finite primitive binder is preserved by the syntax translation. -/
theorem groundTerm_closeAll {Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ)) {Δ : Ctx} :
    ∀ (Γ : Ctx) (p : HLanguage.Formula Param (Γ ++ Δ)),
      groundTerm mapParam (HLanguage.Term.closeAll Γ p) =
        HLanguage.Term.closeAll (groundCtx Γ)
          (castCtx (groundCtx_append Γ Δ) (groundTerm mapParam p)) := by
  intro Γ
  induction Γ with
  | nil => intro p; rfl
  | cons σ Γ ih =>
      intro p
      change groundTerm mapParam (HLanguage.Term.closeAll Γ (.all p)) = _
      rw [ih]
      exact congrArg (HLanguage.Term.closeAll (groundCtx Γ))
        (castCtx_all (groundCtx_append Γ Δ) (groundTerm mapParam p))


/-- Grounding preserves every variable position, even when it identifies types. -/
theorem groundVar_ext {D : Ty → Sort v} : ∀ {Γ : Ctx}
    (f g : ∀ {σ}, Var (groundCtx Γ) σ → D σ),
    (∀ {σ} (v : Var Γ σ), f (groundVar v) = g (groundVar v)) →
    @Eq (∀ {σ}, Var (groundCtx Γ) σ → D σ) f g := by
  intro Γ
  induction Γ with
  | nil => intro f g h; funext σ v; cases v
  | cons τ Γ ih =>
      intro f g h
      funext σ v
      cases v with
      | zero => exact h .zero
      | succ v =>
          exact congrArg (fun k : ∀ {σ}, Var (groundCtx Γ) σ → D σ => k v)
            (ih (fun v => f (.succ v)) (fun v => g (.succ v))
              (fun v => h (.succ v)))

namespace Transport

theorem castCtx_iff {P : Ty → Type u} {Γ Δ : Ctx} (h : Γ = Δ)
    (p q : HLanguage.Formula P Γ) :
    castCtx h (.iff p q) = .iff (castCtx h p) (castCtx h q) := by
  cases h
  rfl

/-- Comprehension with an explicitly equal relation-type annotation. -/
def compBodyAt {P : Ty → Type u} (Γ : Ctx) {ρ : RTy}
    (h : ρ = RTy.ofArgs Γ) (A : HLanguage.Formula P Γ) :
    HLanguage.Formula P (Γ ++ [Ty.rel ρ]) :=
  .iff (HLanguage.Term.applyVars Γ (castRel h (.var (HLanguage.lastVar Γ _)))
    (fun v => .var (HLanguage.Ren.embed Γ _ v)))
    (A.rename (HLanguage.Ren.embed Γ _))

theorem comprehensionAt_eq {P : Ty → Type u} (Γ : Ctx) {ρ : RTy}
    (h : ρ = RTy.ofArgs Γ) (A : HLanguage.Formula P Γ) :
    HLanguage.Term.ex (.box (HLanguage.Term.closeAll Γ (compBodyAt Γ h A))) =
      A.comprehension := by
  subst ρ
  rfl

theorem sameAt_eq {P : Ty → Type u} (Γ : Ctx) {ρ : RTy}
    (h : ρ = RTy.ofArgs Γ) (A B : HLanguage.Formula P Γ) :
    HLanguage.Term.ex
      (.conj (.box (HLanguage.Term.closeAll Γ (compBodyAt Γ h A)))
        (.box (HLanguage.Term.closeAll Γ (compBodyAt Γ h B)))) =
      HLanguage.Term.sameFormula A B := by
  subst ρ
  rfl

end Transport

/-- Renaming naturality with a proved target-context identification. -/
theorem groundTerm_rename_cast {Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ)) {Γ Δ Θ σ}
    (p : HLanguage.Term Param Γ σ) (r : HLanguage.Ren Γ Δ)
    (hΔ : groundCtx Δ = Θ) (s : HLanguage.Ren (groundCtx Γ) Θ)
    (h : ∀ {τ} (v : Var Γ τ), castVar hΔ (groundVar (r v)) = s (groundVar v)) :
    castCtx hΔ (groundTerm mapParam (p.rename r)) =
      (groundTerm mapParam p).rename s := by
  subst Θ
  exact groundTerm_rename mapParam p r s (fun v => (h v).symm)

/-- The translated argument-variable substitution is precisely the target
argument-variable substitution after the proved append-context identity. -/
theorem cast_groundSubst_embed {Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ)) (Γ Δ : Ctx) :
    @Eq (HLanguage.Subst Param' (groundCtx Γ) (groundCtx Γ ++ groundCtx Δ))
      (fun v => castCtx (groundCtx_append Γ Δ)
        (groundSubst mapParam (fun v => .var (HLanguage.Ren.embed Γ Δ v)) v))
      (fun v => .var (HLanguage.Ren.embed (groundCtx Γ) (groundCtx Δ) v)) := by
  apply groundVar_ext
  intro σ v
  have hg := congrArg (fun p : HLanguage.Term Param' (groundCtx (Γ ++ Δ)) (groundTy σ) =>
    castCtx (groundCtx_append Γ Δ) p)
    (groundSubst_get mapParam (fun v => .var (HLanguage.Ren.embed Γ Δ v)) v)
  exact hg.trans ((castCtx_var (groundCtx_append Γ Δ)
    (groundVar (HLanguage.Ren.embed Γ Δ v))).trans
      (congrArg HLanguage.Term.var (groundVar_embed v)))

/-- Exact matrix transport, retaining the explicit harmless arity cast. -/
theorem groundTerm_compBody {Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ))
    {Γ : Ctx} (A : HLanguage.Formula Param Γ) :
    castCtx (groundCtx_append Γ [Ty.rel (RTy.ofArgs Γ)])
      (groundTerm mapParam A.compBody) =
        compBodyAt (groundCtx Γ) (groundRTy_ofArgs Γ) (groundTerm mapParam A) := by
  let ρ := RTy.ofArgs Γ
  let hctx := groundCtx_append Γ [Ty.rel ρ]
  let xs : HLanguage.Subst Param Γ (Γ ++ [Ty.rel ρ]) :=
    fun v => .var (HLanguage.Ren.embed Γ _ v)
  let ys : HLanguage.Subst Param' (groundCtx Γ) (groundCtx (Γ ++ [Ty.rel ρ])) :=
    groundSubst mapParam xs
  have hg := groundTerm_applyVars mapParam Γ (.var (HLanguage.lastVar Γ (Ty.rel ρ)))
    xs ys (fun v => (groundSubst_get mapParam xs v).symm)
  have hr0 : castCtx hctx
      (groundTerm mapParam (.var (HLanguage.lastVar Γ (Ty.rel ρ)))) =
        HLanguage.Term.var (HLanguage.lastVar (groundCtx Γ) (groundTy (Ty.rel ρ))) :=
    (castCtx_var hctx (groundVar (HLanguage.lastVar Γ (Ty.rel ρ)))).trans
      (congrArg HLanguage.Term.var (groundVar_last Γ (Ty.rel ρ)))
  have hr := (castCtx_castRel hctx (groundRTy_ofArgs Γ)
    (groundTerm mapParam (.var (HLanguage.lastVar Γ (Ty.rel ρ))))).trans
      (congrArg (castRel (groundRTy_ofArgs Γ)) hr0)
  have hxs := cast_groundSubst_embed mapParam Γ [Ty.rel ρ]
  have happ := (congrArg
    (fun p : HLanguage.Formula Param' (groundCtx (Γ ++ [Ty.rel ρ])) => castCtx hctx p)
    hg).trans
    ((castCtx_applyVars hctx (groundCtx Γ)
      (castRel (groundRTy_ofArgs Γ)
        (groundTerm mapParam (.var (HLanguage.lastVar Γ (Ty.rel ρ))))) ys).trans
      (HLanguage.congrArg2
        (fun (R : HLanguage.Term Param' (groundCtx Γ ++ [groundTy (Ty.rel ρ)])
              (RTy.ofArgs (groundCtx Γ)))
          (args : HLanguage.Subst Param' (groundCtx Γ)
            (groundCtx Γ ++ [groundTy (Ty.rel ρ)])) =>
          HLanguage.Term.applyVars (groundCtx Γ) R args) hr hxs))
  have hren := groundTerm_rename_cast mapParam A (HLanguage.Ren.embed Γ [Ty.rel ρ])
    hctx (HLanguage.Ren.embed (groundCtx Γ) [groundTy (Ty.rel ρ)])
    (fun v => groundVar_embed v)
  exact (castCtx_iff hctx
    (groundTerm mapParam (HLanguage.Term.applyVars Γ
      (.var (HLanguage.lastVar Γ (Ty.rel ρ))) xs))
    (groundTerm mapParam (A.rename (HLanguage.Ren.embed Γ [Ty.rel ρ])))).trans
      (HLanguage.congrArg2 HLanguage.Term.iff happ hren)

/-- The translated closed comprehension formula is the ordinary original
comprehension instance of the translated matrix, without an extra premise. -/
theorem groundTerm_comprehension {Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ))
    {Γ : Ctx} (A : HLanguage.Formula Param Γ) :
    groundTerm mapParam A.comprehension = (groundTerm mapParam A).comprehension := by
  have hb := (groundTerm_closeAll mapParam Γ A.compBody).trans
    (congrArg (HLanguage.Term.closeAll (groundCtx Γ)) (groundTerm_compBody mapParam A))
  exact (congrArg (fun p : HLanguage.Formula Param' [Ty.rel (groundRTy (RTy.ofArgs Γ))] =>
    HLanguage.Term.ex p.box) hb).trans
      (comprehensionAt_eq (groundCtx Γ) (groundRTy_ofArgs Γ) (groundTerm mapParam A))

/-- Whole-operation sameness has the same original-type transport. -/
theorem groundTerm_same {Param' : Ty → Type u}
    (mapParam : ∀ {σ : Ty}, Param σ → Param' (groundTy σ))
    {Γ : Ctx} (A B : HLanguage.Formula Param Γ) :
    groundTerm mapParam (HLanguage.Term.sameFormula A B) =
      HLanguage.Term.sameFormula (groundTerm mapParam A) (groundTerm mapParam B) := by
  have ha := (groundTerm_closeAll mapParam Γ A.compBody).trans
    (congrArg (HLanguage.Term.closeAll (groundCtx Γ)) (groundTerm_compBody mapParam A))
  have hb := (groundTerm_closeAll mapParam Γ B.compBody).trans
    (congrArg (HLanguage.Term.closeAll (groundCtx Γ)) (groundTerm_compBody mapParam B))
  exact (HLanguage.congrArg2
    (fun p q : HLanguage.Formula Param' [Ty.rel (groundRTy (RTy.ofArgs Γ))] =>
      HLanguage.Term.ex (.conj p.box q.box)) ha hb).trans
      (sameAt_eq (groundCtx Γ) (groundRTy_ofArgs Γ)
        (groundTerm mapParam A) (groundTerm mapParam B))

/-- Only source IC at original formed matrices is used by the lifted model. -/
theorem comprehension_lift {S : OriginalTypedOps.{u}}
    (M : HOriginalModel.Model S) (hIC : HOriginalSchemas.Comprehension M) :
    M.toModel.Comprehension := by
  intro Γ A
  have h := hIC (Formation.ground_context_closed Γ)
    (groundTerm (OriginalCarrier.groundParam S) A)
    (groundTerm_formed (OriginalCarrier.groundParam S) A)
  change S.truth (M.eval _
    (groundTerm (OriginalCarrier.groundParam S) A.comprehension)
    _ (S.groundEnv HLanguage.Env.nil))
  have he := M.eval_congr Formation.context_nil
    (groundTerm_comprehension (OriginalCarrier.groundParam S) A)
    (groundTerm_formed (OriginalCarrier.groundParam S) A.comprehension)
    (formed_comprehension (Formation.ground_context_closed Γ)
      (groundTerm (OriginalCarrier.groundParam S) A)
      (groundTerm_formed (OriginalCarrier.groundParam S) A))
    (HOriginalModel.envNil S)
  exact Eq.mpr (congrArg S.truth he) h

#print axioms groundTerm_applyVars
#print axioms groundTerm_comprehension
#print axioms groundTerm_same
#print axioms comprehension_lift
#print axioms groundTerm_closeAll

end Classicism.Research.InfinitaryComprehension.HOriginalICGrounding
