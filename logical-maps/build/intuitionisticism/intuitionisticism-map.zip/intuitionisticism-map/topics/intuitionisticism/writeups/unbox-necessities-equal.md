# □(□ = □₂) ⇒ □ = □₂

<p class='cert'>Result — Source: Misc.; produced by Codex (GPT-6), prompted by Zachary Goodsell, connecting proof; recorded by Codex (GPT-6), prompted by Zachary Goodsell.</p>

## Premises

- **□(□ = □₂).** $\Box ((\lambda p:t. \Box p) = \Box _{2})$

## Conclusion

- **□ = □₂.** $(\lambda p:t. \Box p) = \Box _{2}$

## Proof

Apply the standing theorem $\Box A\to A$ to the entire displayed sentence, with all of its quantifiers inside A.

## Notes

Informal proof; no independent checker or Lean verification. Formula assumptions are not eligible for unrestricted necessitation.

## Sources

- **Codex connecting proofs, 13 Sep 2026** — Codex (GPT-6), connecting proof unbox-necessities-equal, 2026-09-13.
- **Possibility in Intuitionistic Higher-Order Logic** — Zachary Goodsell, Possibility in Intuitionistic Higher-Order Logic (21 August 2026), §3.2, Theorem 1, p. 9 (definitions/background).

<p class='cert'>Record: <code>topics/intuitionisticism/results/unbox-necessities-equal.yaml</code></p>
