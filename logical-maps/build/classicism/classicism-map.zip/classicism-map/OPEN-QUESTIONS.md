# Open questions — Classicism

Conjectures, their current answers, and remaining gaps where a new result or model would contribute to the map.

**"Open" means not settled by the records in this bundle.** It does not mean unsolved in the literature, and it does not mean hard. Many entries below are routine and simply have not been added yet. Check the sources before assuming a question is new.

## 1. Conjectures and their answers

Answers below are recomputed from proved records under the fixed topic background. A conjectured record supplies no evidence for its own answer. Records marked was_conjectured remain in this history after promotion to proved; their proved status, rather than the historical marker, determines whether they supply evidence. Original sources and notes are retained below each answer.

### 1.1 Unresolved (1)

#### Relational Choice ⇒ Transversal Choice — `relational-choice-r-implies-transversal-choice-r`

**Answer: Open.**

Original record notes:

Does Relational Choice alone give a transversal for every equivalence relation? Christopher Sun observed that the literature claims this without proof. The converse is recorded. The quotient argument chooses from each cell $\lambda z\, .\,(Rx)z$ and needs the cells of two members of one class to be the same property; in C that is necessary coextension, and the hypothesis gives actual coextension only. No definable substitute for the cell helps, since an operation definable from $R$ identifies $x$ with $x'$ only when they are necessarily indiscernible with respect to $R$. A Zermelo-style well-ordering argument breaks at the same point: coextensive but distinct stages receive different chosen elements. The expectation is that the implication fails. What would settle it: a proof that uses the chosen relation to break the symmetry between coextensive cells, or a model of C with Relational Choice that is not extensionally full at its evaluation point. Every recorded model of Relational Choice is extensionally full there, in that every set of tuples from the domains is the extension of a rigid element, and that fullness verifies Transversal Choice by the same metatheoretic choice, so none separates the two. Symmetric Henkin models in the Fraenkel–Mostowski style cannot separate them either; see the write-up.
Update of 28 September 2026: Christopher Sun showed on 26 September that Transversal Choice is equivalent to Relational Choice together with Transversal (transversal-and-relational-choice-imply-transversal-choice), so this question is equivalent to whether Relational Choice implies Transversal. Anything that implies Transversal, such as Actuality, closes the gap.
Update of 28 October 2026: Vicinity also closes the gap ([[vicinity-and-relational-choice-imply-transversal-choice]], from GPT-6 Astra, prompted by Daniel Kodsi). So a model separating Relational Choice from Transversal Choice must falsify Vicinity, and hence ND at type $t$ and Actuality.

- **Sun via Goodsell 25 Sep** — Christopher Sun, observation communicated by Zachary Goodsell on 25 September 2026, that the transversal formulation of choice is claimed in the literature without a proof from Relational Choice.

Record: `topics/classicism/results/relational-choice-r-implies-transversal-choice-r.yaml`.

### 1.2 Resolved (84)

#### Actuality ∧ BF ⇒ Inextensible Comprehension — `actuality-and-bf-imply-inextensible-comprehension`

**Answer: Proved.**

Supporting result ids: `actuality-and-bf-imply-inextensible-comprehension`.

Original record notes:

BF is used only at the actual world, at the type $\bar\sigma t$ of $X$ and at the argument types $\bar\sigma$, to bring the quantifiers in the negated leading box of inextensibility out to the actual world, where Actuality can be applied to the chosen instances. This strengthens the earlier result from □BF and Actuality, which now follows from it. The identifier was first used on 26 September 2026 for this claim as a conjecture, which was withdrawn the same day because the recorded argument then needed □BF.

- **Sun, 26 Sep** — Christopher Sun, argument communicated to Cian Dorr on 26 September 2026 and reported by him on 27 September 2026; see the write-up.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, pp. 28–30 (inextensibility); Proposition 2.1, pp. 20–21 (BF).

Record: `topics/classicism/results/actuality-and-bf-imply-inextensible-comprehension.yaml`.

#### □ND ∧ Atomicity ⇒ No Pure Contingency — `c5-and-atomicity-imply-no-pure-contingency`

**Answer: Proved.**

Supporting result ids: `c5-and-atomicity-imply-no-pure-contingency`.

Original record notes:

Reported by the source as a theorem of Goodsell and Yli-Vakkuri, without a proof; recorded as conjectured on 17 September 2026 pending verification, and promoted on 23 September 2026 with an independent proof, sketched by Cian Dorr with permission from Zachary Goodsell. Only the type-t instance of Atomicity is used; the record c5-and-atomicity-t-imply-no-pure-contingency states that sharper form and this record is derivable from it. □ND is used through ND (rigidity of identity propositions at each type) and BF (commutation of the atom-exchanging automorphism with the quantifiers, and rigidity of the hypothesis that the two atoms are distinct).

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 27.
- **Dorr 23 Sep** — Cian Dorr, proof sketch of 23 September 2026, with permission from Zachary Goodsell; written out in the write-up.

Record: `topics/classicism/results/c5-and-atomicity-imply-no-pure-contingency.yaml`.

#### Maximalism (pure) ∧ Rigid Comprehension ⇒ ⊥ — `maximalist-distinctness-incompatible-with-rigid-comprehension`

**Answer: Proved.**

Supporting result ids: `maximalist-distinctness-incompatible-with-rigid-comprehension`.

Original record notes:

Recorded on 17 September 2026 as a reported theorem awaiting a supplied proof. The proof is now Goodsell's own, imported from Arithmetic is Necessary, and the record is derivable from the recorded chain through Boolean Completeness, Countable Boolean Completeness and the Necessity of Arithmetic.

- **Arithmetic is Necessary** — Zachary Goodsell, Arithmetic is Necessary, draft of 5 June 2024, §6, Theorem 11 and the remark following it, p. 25.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41.

Record: `topics/classicism/results/maximalist-distinctness-incompatible-with-rigid-comprehension.yaml`.

#### □Atomicity ∧ Boolean Completeness ∧ BF ⇒ Rigid Comprehension — `necessary-atomicity-completeness-bf-imply-rigid-comprehension`

**Answer: Refuted.**

Supporting result ids: `necessary-boolean-completeness-r-implies-boolean-completeness-r`, `necessary-barcan-r-implies-barcan-r`.

Model witness ids: `ultralimit-fork`.

Original record notes:

Downgraded from proved to conjectured on 28 September 2026, at Cian Dorr's request. The source's proof (Proposition 2.11, note 42) has two gaps, found that day by an agent working in the Lean-Classicism formalization project; the write-up sets out the paper's argument with the gaps marked. (a) Part (iv) of note 42 boxes a claim that holds pointwise in the object variables by BF, where □BF would be needed. Cian Dorr agreed. (b) The same part's "without loss of generality" step replaces the atom $w'$ by $w''$, the greatest lower bound of the propositions $p$ with $w\le(p=w')$. The proof then needs $w\le(w''=w')$, so that $w''$ is still possible and below $X^*z\land\neg Yz$ where $w$ holds; nothing in the premises gives this, and □BF does not help. A propositional structure in which that step fails is sketched in the project's VERIFICATION.md; it has not been extended to a model of C with all the premises, so it shows that the step needs an argument, not that the proposition is false. What is proved there: Actuality, Boolean Completeness and BF (at the relevant types), together with a restriction principle, give Rigid Comprehension with the paper's witness $X^*$. The restriction principle says that for all $p,q$ there is an $r$ with $p\le(r=q)$ such that $r\le s$ whenever $p\le(q\le s)$. It holds in C5, with $r:=q\land\Diamond p$. Restructured this way, gap (a) disappears, and gap (b) becomes the question whether the premises here give the restriction principle. What would settle the conjecture: a derivation of the restriction principle, or another argument, from boxed Atomicity, Boolean Completeness and BF; or a model of C with those three principles that fails Rigid Comprehension. The source's first cross-reference to Proposition 2.6 was replaced in the earlier transcription by Proposition 2.7; the statement and premises are unchanged.

Refuted, 1 October 2026: the model ultralimit-fork, from Branden Fitelson (with Claude and GPT-6 Astra), satisfies Classicism, □Atomicity, □Boolean Completeness, □BF and □Actuality, and fails Rigid Comprehension at type $t\to t$. It extends the propositional structure mentioned above to a model of C with all the premises, so gap (b) is a genuine gap. The record stays conjectured, as the map's convention requires; the model is the refuting evidence. Gap-free in the end is part (ii), which gets Actuality: Atomicity (type $t$) and Weak Inextensible Comprehension imply Actuality (atomicity-t-and-weakly-inextensible-comprehension-imply-actuality), and Boolean Completeness implies Weak Inextensible Comprehension.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.11, p. 30 and n. 42.

Record: `topics/classicism/results/necessary-atomicity-completeness-bf-imply-rigid-comprehension.yaml`.

#### □Rigid Comprehension ∧ Intensional Choice ∧ Forcing Possibilism ∧ Non-contingency of the Continuum Hypothesis ⇒ ⊥ — `necessary-rigid-comprehension-intensional-choice-and-forcing-possibilism-incompatible-with-non-contingency-of-ch`

**Answer: Refuted.**

Supporting result ids: `necessary-intensional-choice-r-implies-intensional-choice-r`, `necessity-of-second-order-analysis-implies-non-contingency-of-ch`.

Model witness ids: `full-double-retraction-glued-constants`, `full-free-monoid-glued-constants-singleton`, `full-free-monoid-glued-constants`, `full-free-product-glued-constants`, `ultraproduct-countable-full-s5-finite-individuals`.

Original record notes:

Stated by Bacon as a theorem, with the proof deferred to another venue; his handout of 19 October 2026 on the lottery-algebra model and the draft Modalized Domains on Possibility Frames do not reproduce it (the lottery record notes a transfer argument not given there). The expected proof: Forcing Possibilism supplies a proposition whose entailment algebra is a complete Boolean algebra forcing CH, and one forcing its negation; under □Rigid Comprehension and Intensional Choice the real number structures at the worlds below each are those of the corresponding generic extensions. Recorded as conjectured until a proof is supplied; a written proof, or a model of the three premises deciding CH one way necessarily, would settle it.

As encoded, with the map's strict reading of smallness (finite, or with strictly fewer elements than there are propositions), the conjecture is refuted: [[full-free-monoid-glued-constants]], [[full-free-monoid-glued-constants-singleton]], [[full-free-product-glued-constants]], [[full-double-retraction-glued-constants]] and [[ultraproduct-countable-full-s5-finite-individuals]] satisfy □Rigid Comprehension, Intensional Choice, Forcing Possibilism and Non-contingency of CH. Each has exactly $2^{\aleph_0}$ propositions, and an infinite complete Boolean algebra has at least $2^{\aleph_0}$ elements, so only finite algebras are small there, and Forcing Possibilism never asks for an algebra that changes CH. (For the ultraproduct, this holds in every factor.) The expected proof needs a CH-changing algebra to be small: an algebra forcing $\neg$CH has at least $\aleph_2$ elements, and one forcing CH over a model of $\neg$CH may have $2^{2^{\aleph_0}}$, so a premise saying that there are more than $2^{2^{\aleph_0}}$ propositions would suffice for that step, while one saying only that there are more than $2^{\aleph_0}$ might not. In the lottery cloud of Modalized Domains (Bacon and Claude Opus 5.5, Remark 6.12), which the source cites, every complete Boolean algebra of size below a strong limit $\mu$ is small and realized; Bacon's Theorem 6.1 is cited there as showing that CH is contingent in it.

Suggested repair (Cian Dorr, 25 October 2026): add the premise that there are more than $2^{2^{\aleph_0}}$ propositions, i.e. that no injective relation runs from the properties of the reals of some real number structure into the propositions. All five models above falsify it. It is not recorded as a principle until the repaired implication is proved, since by itself it would only call for large variants of many models.

- **Could mathematics have been different?** — Andrew Bacon, Could the truths of mathematics have been different?, draft of 9 October 2025, §6, Theorem 6.1, p. 27.

Record: `topics/classicism/results/necessary-rigid-comprehension-intensional-choice-and-forcing-possibilism-incompatible-with-non-contingency-of-ch.yaml`.

#### □Strong Atomicity ∧ Rigid Comprehension ⇒ □BF (relational types) — `necessary-strong-atomicity-and-rigid-comprehension-imply-necessary-bf-relational`

**Answer: Proved.**

Supporting result ids: `necessary-strong-atomicity-r-implies-strong-atomicity-r`, `strong-atomicity-and-rigid-comprehension-imply-necessary-rigid-comprehension`, `necessary-strong-atomicity-and-necessary-rigid-comprehension-imply-necessary-bf-relational`.

Original record notes:

Downgraded from proved to conjectured on 11 October 2026, at Cian Dorr's request. The proof of Theorem 8.2 in the book has a gap, found while formalizing it in Lean and confirmed by Cian Dorr; the write-up sets out the book's argument with the gap marked. The argument proves $\forall p\,.\,Wp\to p=r$ at the evaluation point and then boxes it as following "from necessary assumptions". But step (i), that a $W$-proposition $p$ falls under some member of $H$ at every world, uses the claim that the world property $U=\lambda q\,.\,v\land q=p$ is $H$ because it is a world property accessible to $W$; that holds at the evaluation point, where $H$ is coextensive with the accessible world properties, but at another world $H$ is known only to be rigid, and need not contain the world properties built there from that world's $v$ and $p$. The step is needed exactly at such worlds, since $W$ may have no actual instance. Boxing Rigid Comprehension does not obviously help, since $r$ must be defined from a single actual $H$. What would settle the conjecture: a repair of step (i), or a model of C with □Strong Atomicity and Rigid Comprehension in which BF fails at some relational type. No recorded model refutes it, and without this record the map does not derive it. With □Rigid Comprehension and Rigid Power in place of Rigid Comprehension the conclusion holds (strong-atomicity-necessary-rigid-comprehension-and-rigid-power-imply-bf-relational, Cian Dorr), so a countermodel must fail one of those. The converse half of Theorem 8.2, atomicity-and-bf-relational-imply-strong-atomicity and its boxed form, is unaffected.

- **Philosophical Introduction to HOL** — Andrew Bacon, A Philosophical Introduction to Higher-Order Logics, Routledge, 2024, §8.2, Theorem 8.2, pp. 169–171.

Record: `topics/classicism/results/necessary-strong-atomicity-and-rigid-comprehension-imply-necessary-bf-relational.yaml`.

#### Possible Infinity (type e) ⇒ Axiom of Infinity (type e) — `possible-infinity-e-implies-axiom-of-infinity-e`

**Answer: Refuted.**

Supporting result ids: `possibility-schema-r-implies-possible-infinity-e`, `axiom-of-infinity-e-implies-infinity-e`.

Model witness ids: `coalesced-definable-root`, `coalesced-single-individual-root`, `finite-support-two-object-all-maps-at-singleton`.

Original record notes:

Equivalent to the claim that a finite count of individuals is necessary whenever it is true. It holds with No Pure Contingency and with BF, by the recorded results. A countermodel would need a world with finitely many individuals that can see one with more, and must violate both BF at type $e$ and No Pure Contingency; the coalesced sums on the map do not supply one, since their roots have infinitely many individuals.

- **Dorr 20 Sep** — Cian Dorr, question of 20 September 2026.

Record: `topics/classicism/results/possible-infinity-e-implies-axiom-of-infinity-e.yaml`.

#### Possible Infinity (type t) ⇒ Axiom of Infinity (type t) — `possible-infinity-t-implies-axiom-of-infinity-t`

**Answer: Refuted.**

Supporting result ids: `axiom-of-infinity-t-implies-infinity-t`.

Model witness ids: `absorbing-entrance-swappable-pairs`, `full-two-object-chain-free-loop`, `full-two-object-chain-free-loop-sigma-true-atom`, `full-two-object-chain-free-loop-individuals-fixed-infinite`, `full-two-object-chain-free-loop-individuals-fixed-infinite-metatheory-socks`, `full-two-object-chain-free-loop-individuals-fixed-infinite-sigma-true-atom`, `full-two-object-chain-free-loop-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`, `symmetric-entrance-qualitative-links`, `symmetric-entrance-qualitative-links-sigma-true-atom`.

Original record notes:

Equivalent to the claim that a finite count of propositions is necessary whenever it is true. It holds with No Pure Contingency and with BF (type $t$), by the recorded results. If some finite $Z$ holds of $\lambda p\, .\,\top$ then every proposition is one of finitely many, and NI carries each identity across, but collecting them under a box is an instance of BF at type $t$, which C does not prove. A proof would need to bypass that; a countermodel would need a world with finitely many propositions that can see one with more, and must violate both BF (type $t$) and No Pure Contingency.

- **Dorr 20 Sep** — Cian Dorr, question of 20 September 2026.

Record: `topics/classicism/results/possible-infinity-t-implies-axiom-of-infinity-t.yaml`.

#### Relational Choice ∧ Boolean Completeness ⇒ Transversal Choice — `relational-choice-and-boolean-completeness-imply-transversal-choice`

**Answer: Proved.**

Supporting result ids: `relational-choice-and-boolean-completeness-imply-actuality`, `completeness-and-actuality-imply-weak-rigid-comprehension`, `relational-choice-and-weak-rigid-comprehension-imply-transversal-choice`.

Original record notes:

Does adding Boolean Completeness to Relational Choice suffice for Transversal Choice in C? The question without Boolean Completeness is recorded separately. No proof was supplied. A proof of this implication, or a model of C satisfying both premises and failing Transversal Choice, would settle this conjecture.

- **Goodsell 27 Sep** — Zachary Goodsell, conjecture communicated on 27 September 2026: Relational Choice + Boolean Completeness ⊢ Transversal Choice.

Record: `topics/classicism/results/relational-choice-and-boolean-completeness-imply-transversal-choice.yaml`.

#### Rigid Rigidity ⇒ Rigid Power — `rigid-rigidity-implies-rigid-power`

**Answer: Refuted.**

Model witness ids: `coalesced-two-extensional-arithmetics-root`, `supported-product-free-monoids-glued-constants`, `supported-product-surjections-glued-constants`.

Original record notes:

Cian Dorr proposed it on 10 October 2026, with an argument that assumed rigidity is closed under conjunction. It is not, in C: if $x\ne y$ but possibly $x=y$, the conjunction of their haecceities is persistent but not weakly inextensible, since weak inextensibility would require $\Box\,x\ne y$. Under □ND conjunctions of rigid relations are rigid and the argument goes through, but C5 already gives □Rigid Power. A countermodel must therefore have contingent identity at some accessible world: a rigid $Y$ not below a rigid $X$ that comes below it at an accessible world by identifications, without becoming identical there to any rigid subrelation of $X$ at the evaluation point. With the recorded results, the conjecture would make Rigid Rigidity equivalent to □BF + Rigid Power, and Weakly Rigid Weak Rigidity equivalent to BF + Weakly Rigid Power. Since Rigid Rigidity implies its necessitation, the conjecture is equivalent to Rigid Rigidity ⇒ □Rigid Power. It is refuted: coalesced-two-extensional-arithmetics-root (20 October 2026) satisfies Rigid Rigidity but not Rigid Power, as do the two supported-product models.

- **Dorr 10 Oct** — Cian Dorr, conjecture of 10 October 2026.

Record: `topics/classicism/results/rigid-rigidity-implies-rigid-power.yaml`.

#### Tame Rigidity ∧ Rigid Power ⇒ Weakly Rigid Power — `tame-rigidity-and-rigid-power-imply-weakly-rigid-power`

**Answer: Refuted.**

Supporting result ids: `rigid-comprehension-implies-tame-rigidity`, `necessary-rigid-power-r-implies-rigid-power-r`, `barcan-and-weakly-rigid-power-imply-necessary-tame-rigidity`.

Model witness ids: `symmetric-boolean-prefix-recurrent-colours`, `symmetric-finite-compression-entrance`, `symmetric-recurrent-colours`.

Original record notes:

The converse of weakly-rigid-power-implies-tame-rigidity and weakly-rigid-power-implies-rigid-power. With □Tame Rigidity in place of Tame Rigidity it is proved (necessary-tame-rigidity-and-rigid-power-imply-weakly-rigid-power). The unboxed argument fails at weak inextensibility: for weakly rigid $F$, $P_F:=\lambda X\, .\,\operatorname{WeaklyRigid}(X)\land X\le F$ is weakly persistent, but $Z:=\lambda X\, .\,\operatorname{Rigid}(X)\land X\le F$ satisfies $\forall X\, .\,P_FX\to\Box ZX$, so the weak inextensibility of $P_F$ requires $P_F\le Z$, which is Tame Rigidity below $F$ at every accessible world. Weakly Rigid Power implies □Tame Rigidity at type $t$ (and, with BF, at every type: barcan-and-weakly-rigid-power-imply-necessary-tame-rigidity), so the conjecture would follow from Tame Rigidity + Rigid Power ⇒ □Tame Rigidity, and a countermodel must satisfy Tame Rigidity and Rigid Power while failing □Tame Rigidity at type $t$. No recorded model yet separates Tame Rigidity from □Tame Rigidity.

Refuted (25 October 2026): [[symmetric-finite-compression-entrance]], GPT-6 Astra's construction (prompted by Daniel Kodsi, 23 October 2026), satisfies Tame Rigidity and Rigid Power at every type and fails Weakly Rigid Power at type $et$, through a weakly rigid but not rigid relation below the transport of a rigid bound, at a world where □Tame Rigidity fails at type $et$. Since then [[symmetric-entrance-qualitative-links]] and this model both separate Tame Rigidity from □Tame Rigidity.

- **Dorr 10 Oct** — Cian Dorr, question of 10 October 2026.

Record: `topics/classicism/results/tame-rigidity-and-rigid-power-imply-weakly-rigid-power.yaml`.

#### Vicinity ⇒ 5-necessities are two-hat necessary — `vicinity-implies-five-implies-two-hat`

**Answer: Proved.**

Supporting result ids: `vicinity-implies-five-implies-two-hat`.

Original record notes:

Proved by Christopher Sun, 19 October 2026, through Theorem D9 rather than an atom. The notes recorded with the conjecture follow. Conjectured by Cian Dorr, 14 October 2026. Actuality suffices (see the proved result), and so does Vicinity with BF at type $t$. Without BF, the two places where the Actuality proof uses the atom resist the Vicinity substitution: the characterization $\hat{\hat\Box}p\leftrightarrow\Box(\hat\Diamond w\to p)$ needs $\Box(\hat\Diamond w\to\hat\Diamond q)$ for an arbitrary true $q$, which is B for $\Box_{\ne}$ at $q$; and step 1 of Proposition D19 applies the atom to the truth $\forall z\,\Box(\hat\Diamond w\to Yz)$, which is ND-necessary only if $\Box_{\ne}$ already commutes with $\forall z$. A countermodel would need Vicinity without Actuality at a world where the two-hat cluster is non-principal; the paired-individuals and star-graph models fail Vicinity.

- **Dorr–Claude 14 Oct** — Cian Dorr and Claude Fable 5.1 (Anthropic), conversation of 14 October 2026 (transcript in the private notes).
- **Sun 19 Oct** — Christopher Sun, handwritten argument sent to Cian Dorr on 19 October 2026 (Proposition: Principal □5 implies ∀p(□5p → two-hat necessity of p)).
- **Bounds of Possibility** — Cian Dorr, John Hawthorne, and Juhani Yli-Vakkuri, The Bounds of Possibility, Appendix D, Theorem D9, p. 405.

Record: `topics/classicism/results/vicinity-implies-five-implies-two-hat.yaml`.

#### Coalesced sum: maximalist root — `coalesced-maximalist-root`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-two-hat-implies-nd-necessity`, `maximalist-distinctness-incompatible-with-necessary-five-implies-two-hat-necessity`, `maximalist-distinctness-incompatible-with-necessary-truth-implies-five-necessity`, `maximalism-incompatible-with-intensional-choice`, `maximalist-distinctness-incompatible-with-atomicity-t`, `maximalist-distinctness-incompatible-with-necessary-vicinity`, `maximalist-distinctness-incompatible-with-necessary-weakly-inextensible-comprehension-r`, `maximalist-distinctness-incompatible-with-necessary-transversal-r`, `maximalism-incompatible-with-necessity-of-analysis`, `maximalism-incompatible-with-self-atoms-are-atoms-t`, `self-atoms-are-strong-atoms-t-implies-self-atoms-are-atoms-t`, `self-atomicity-t-implies-necessary-actuality`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `coalesced-maximalist-root`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Theorem 3.26, §§3.6, pp. 62–64; Appendix E, pp. 80–83; §2.6, p. 41.

Record: `topics/classicism/models/coalesced-maximalist-root.yaml`.

#### Coalesced sum: singleton individual root — `coalesced-single-individual-root`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `possibility-plus-r-implies-possibility-schema-r`, `necessary-two-hat-implies-nd-implies-necessary-five-implies-two-hat`, `maximalist-distinctness-incompatible-with-necessary-five-implies-two-hat-necessity`, `maximalist-distinctness-incompatible-with-necessary-truth-implies-five-necessity`, `maximalism-incompatible-with-intensional-choice`, `maximalist-distinctness-incompatible-with-atomicity-t`, `necessary-vicinity-implies-necessary-five-implies-two-hat`, `maximalist-distinctness-incompatible-with-necessary-weakly-inextensible-comprehension-r`, `maximalist-distinctness-incompatible-with-necessary-transversal-r`, `maximalism-incompatible-with-necessity-of-analysis`, `maximalism-incompatible-with-self-atoms-are-atoms-t`, `self-atoms-are-strong-atoms-t-implies-self-atoms-are-atoms-t`, `self-atomicity-t-implies-necessary-actuality`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `coalesced-single-individual-root`.

Original record notes:

Promoted on 22 September 2026 for the pure package, which the source establishes; the earlier conjectured status concerned an expansion to the map’s signature Σ. That expansion exists exactly when Σ has at most one individual constant: with two, the unique root individual would have to be carried to two different interpretations in a component where they differ, which no arrow can do. So the signature principles are not listed; for a signature with individual constants see the constant-indexed root.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, pp. 41–42 and n. 61; Appendix E, p. 83.

Record: `topics/classicism/models/coalesced-single-individual-root.yaml`.

#### Finite-support action model: dyadic roundings of N — `finite-support-dyadic-roundings`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `barcan-r-implies-barcan-t`, `atomicity-and-bf-imply-necessary-actuality`, `barcan-t-and-necessary-actuality-imply-self-atomicity-t`, `strong-atomicity-t-implies-self-atomicity-t`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-atomicity-t`.

Model witness ids: `finite-support-dyadic-roundings`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 7, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-dyadic-roundings.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-atoms-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_atoms.py.

Record: `topics/classicism/models/finite-support-dyadic-roundings.yaml`.

#### Finite-support action model: dyadic roundings of N [Σ true atom] — `finite-support-dyadic-roundings-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `barcan-r-implies-barcan-t`, `atomicity-and-bf-imply-necessary-actuality`, `barcan-t-and-necessary-actuality-imply-self-atomicity-t`, `strong-atomicity-t-implies-self-atomicity-t`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-atomicity-t`.

Model witness ids: `finite-support-dyadic-roundings-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 7, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-dyadic-roundings.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-atoms-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_atoms.py.

Record: `topics/classicism/models/finite-support-dyadic-roundings.yaml`.

#### Finite-support action model: dyadic roundings of N [one individual] — `finite-support-dyadic-roundings-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `strong-atomicity-t-implies-self-atomicity-t`, `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-atomicity-t`.

Model witness ids: `finite-support-dyadic-roundings-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 7, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-dyadic-roundings.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-atoms-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_atoms.py.

Record: `topics/classicism/models/finite-support-dyadic-roundings.yaml`.

#### Finite-support action model: dyadic roundings of N [one individual; Σ true atom] — `finite-support-dyadic-roundings-individuals-singleton-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `strong-atomicity-t-implies-self-atomicity-t`, `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-atomicity-t`.

Model witness ids: `finite-support-dyadic-roundings-individuals-singleton-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 7, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-dyadic-roundings.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-atoms-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_atoms.py.

Record: `topics/classicism/models/finite-support-dyadic-roundings.yaml`.

#### Finite-support action model: identity-or-collapse monotone surjections — `finite-support-identity-or-collapse-surjections`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `self-atoms-are-strong-atoms-t-implies-self-atoms-are-atoms-t`, `atomicity-t-and-bf-imply-atomicity`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `necessary-self-atomicity-t-implies-necessary-atoms-are-self-atoms-t`, `possibility-and-necessary-atoms-are-self-atoms-t-incompatible`.

Model witness ids: `finite-support-identity-or-collapse-surjections`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 5, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse-surjections.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse-surjections.yaml`.

#### Finite-support action model: identity-or-collapse monotone surjections [Σ true atom] — `finite-support-identity-or-collapse-surjections-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `self-atoms-are-strong-atoms-t-implies-self-atoms-are-atoms-t`, `atomicity-t-and-bf-imply-atomicity`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `necessary-self-atomicity-t-implies-necessary-atoms-are-self-atoms-t`, `possibility-and-necessary-atoms-are-self-atoms-t-incompatible`.

Model witness ids: `finite-support-identity-or-collapse-surjections-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 5, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse-surjections.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse-surjections.yaml`.

#### Finite-support action model: identity-or-collapse monotone surjections [one individual] — `finite-support-identity-or-collapse-surjections-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `self-atoms-are-strong-atoms-t-implies-self-atoms-are-atoms-t`, `atomicity-t-and-bf-imply-atomicity`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `necessary-self-atomicity-t-implies-necessary-atoms-are-self-atoms-t`, `possibility-and-necessary-atoms-are-self-atoms-t-incompatible`.

Model witness ids: `finite-support-identity-or-collapse-surjections-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 5, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse-surjections.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse-surjections.yaml`.

#### Finite-support action model: identity-or-collapse monotone surjections [one individual; Σ true atom] — `finite-support-identity-or-collapse-surjections-individuals-singleton-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `self-atoms-are-strong-atoms-t-implies-self-atoms-are-atoms-t`, `atomicity-t-and-bf-imply-atomicity`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `necessary-self-atomicity-t-implies-necessary-atoms-are-self-atoms-t`, `possibility-and-necessary-atoms-are-self-atoms-t-incompatible`.

Model witness ids: `finite-support-identity-or-collapse-surjections-individuals-singleton-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 5, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse-surjections.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse-surjections.yaml`.

#### Finite-support action model: identity-or-collapse monotone maps — `finite-support-identity-or-collapse`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `necessary-atoms-are-self-atoms-r-implies-necessary-atoms-are-self-atoms-t`, `necessary-atoms-are-self-atoms-t-implies-atoms-are-self-atoms-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `barcan-r-implies-barcan-t`, `no-pure-contingency-and-actuality-imply-necessary-actuality`, `barcan-t-and-necessary-actuality-imply-self-atomicity-t`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-necessary-atoms-are-self-atoms-t-incompatible`.

Model witness ids: `finite-support-identity-or-collapse`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 4, pp. 74, 78 and n. 97; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse.yaml`.

#### Finite-support action model: identity-or-collapse monotone maps [Σ true atom] — `finite-support-identity-or-collapse-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `necessary-atoms-are-self-atoms-r-implies-necessary-atoms-are-self-atoms-t`, `necessary-atoms-are-self-atoms-t-implies-atoms-are-self-atoms-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `barcan-r-implies-barcan-t`, `no-pure-contingency-and-actuality-imply-necessary-actuality`, `barcan-t-and-necessary-actuality-imply-self-atomicity-t`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-necessary-atoms-are-self-atoms-t-incompatible`.

Model witness ids: `finite-support-identity-or-collapse-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 4, pp. 74, 78 and n. 97; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse.yaml`.

#### Finite-support action model: identity-or-collapse monotone maps [one individual] — `finite-support-identity-or-collapse-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `necessary-atoms-are-self-atoms-r-implies-necessary-atoms-are-self-atoms-t`, `necessary-atoms-are-self-atoms-t-implies-atoms-are-self-atoms-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `no-pure-contingency-and-actuality-imply-necessary-actuality`, `barcan-t-and-necessary-actuality-imply-self-atomicity-t`, `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-necessary-atoms-are-self-atoms-t-incompatible`.

Model witness ids: `finite-support-identity-or-collapse-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 4, pp. 74, 78 and n. 97; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse.yaml`.

#### Finite-support action model: identity-or-collapse monotone maps [one individual; Σ true atom] — `finite-support-identity-or-collapse-individuals-singleton-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `necessary-atoms-are-self-atoms-r-implies-necessary-atoms-are-self-atoms-t`, `necessary-atoms-are-self-atoms-t-implies-atoms-are-self-atoms-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `no-pure-contingency-and-actuality-imply-necessary-actuality`, `barcan-t-and-necessary-actuality-imply-self-atomicity-t`, `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-necessary-atoms-are-self-atoms-t-incompatible`.

Model witness ids: `finite-support-identity-or-collapse-individuals-singleton-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 4, pp. 74, 78 and n. 97; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse.yaml`.

#### Finite-support action model: monotone maps of N — `finite-support-monotone-maps`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `truth-implies-two-hat-implies-truth-implies-five`, `vicinity-and-truth-implies-five-necessity-imply-actuality`, `actuality-incompatible-with-atomlessness`, `necessary-relational-choice-r-implies-relational-choice-r`, `relational-choice-and-boolean-completeness-imply-actuality`, `necessary-self-atoms-are-atoms-r-implies-necessary-self-atoms-are-atoms-t`, `necessary-self-atoms-are-atoms-t-implies-self-atoms-are-atoms-t`, `self-atomicity-t-and-self-atoms-are-atoms-t-imply-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`.

Model witness ids: `finite-support-monotone-maps`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. The source notes that with all maps BF would still hold, since every map agrees on any finite set with a surjection; monotonicity is what makes it fail.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 3, pp. 74, 77; n. 96; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-monotone-maps.yaml`.

#### Finite-support action model: monotone maps of N [Σ top] — `finite-support-monotone-maps-sigma-top`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `truth-implies-two-hat-implies-truth-implies-five`, `vicinity-and-truth-implies-five-necessity-imply-actuality`, `actuality-incompatible-with-atomlessness`, `necessary-relational-choice-r-implies-relational-choice-r`, `relational-choice-and-boolean-completeness-imply-actuality`, `necessary-self-atoms-are-atoms-r-implies-necessary-self-atoms-are-atoms-t`, `necessary-self-atoms-are-atoms-t-implies-self-atoms-are-atoms-t`, `self-atomicity-t-and-self-atoms-are-atoms-t-imply-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomlessness`.

Model witness ids: `finite-support-monotone-maps-sigma-top`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. The source notes that with all maps BF would still hold, since every map agrees on any finite set with a surjection; monotonicity is what makes it fail.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 3, pp. 74, 77; n. 96; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-monotone-maps.yaml`.

#### Finite-support action model: monotone maps of N [one individual] — `finite-support-monotone-maps-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `truth-implies-two-hat-implies-truth-implies-five`, `vicinity-and-truth-implies-five-necessity-imply-actuality`, `actuality-incompatible-with-atomlessness`, `necessary-self-atoms-are-atoms-r-implies-necessary-self-atoms-are-atoms-t`, `necessary-self-atoms-are-atoms-t-implies-self-atoms-are-atoms-t`, `self-atomicity-t-and-self-atoms-are-atoms-t-imply-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`.

Model witness ids: `finite-support-monotone-maps-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. The source notes that with all maps BF would still hold, since every map agrees on any finite set with a surjection; monotonicity is what makes it fail.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 3, pp. 74, 77; n. 96; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-monotone-maps.yaml`.

#### Finite-support action model: monotone maps of N [one individual; Σ top] — `finite-support-monotone-maps-individuals-singleton-sigma-top`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `truth-implies-two-hat-implies-truth-implies-five`, `vicinity-and-truth-implies-five-necessity-imply-actuality`, `actuality-incompatible-with-atomlessness`, `necessary-self-atoms-are-atoms-r-implies-necessary-self-atoms-are-atoms-t`, `necessary-self-atoms-are-atoms-t-implies-self-atoms-are-atoms-t`, `self-atomicity-t-and-self-atoms-are-atoms-t-imply-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomlessness`.

Model witness ids: `finite-support-monotone-maps-individuals-singleton-sigma-top`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. The source notes that with all maps BF would still hold, since every map agrees on any finite set with a surjection; monotonicity is what makes it fail.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 3, pp. 74, 77; n. 96; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-monotone-maps.yaml`.

#### Finite-support action model: monotone surjections of N — `finite-support-monotone-surjections`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `fregean-incompatible-with-infinity-t`, `necessary-relational-choice-r-implies-relational-choice-r`, `relational-choice-and-boolean-completeness-imply-actuality`, `actuality-incompatible-with-atomlessness`, `necessary-self-atoms-are-atoms-r-implies-necessary-self-atoms-are-atoms-t`, `necessary-self-atoms-are-atoms-t-implies-self-atoms-are-atoms-t`, `self-atomicity-t-and-self-atoms-are-atoms-t-imply-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `atomlessness-implies-atoms-are-strong-atoms-r`, `atoms-are-strong-atoms-r-implies-atoms-are-strong-atoms-t`, `atoms-are-strong-atoms-t-implies-atoms-are-self-atoms-t`, `no-pure-contingency-and-atoms-are-self-atoms-t-imply-necessary-atoms-are-self-atoms-t`, `possibility-and-necessary-atoms-are-self-atoms-t-incompatible`.

Model witness ids: `finite-support-monotone-surjections`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 2, pp. 74, 76–77; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-monotone-surjections.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-monotone-surjections.yaml`.

#### Finite-support action model: monotone surjections of N [one individual] — `finite-support-monotone-surjections-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-self-atoms-are-atoms-r-implies-necessary-self-atoms-are-atoms-t`, `necessary-self-atoms-are-atoms-t-implies-self-atoms-are-atoms-t`, `self-atomicity-t-and-self-atoms-are-atoms-t-imply-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `atomlessness-implies-atoms-are-strong-atoms-r`, `atoms-are-strong-atoms-r-implies-atoms-are-strong-atoms-t`, `atoms-are-strong-atoms-t-implies-atoms-are-self-atoms-t`, `no-pure-contingency-and-atoms-are-self-atoms-t-imply-necessary-atoms-are-self-atoms-t`, `possibility-and-necessary-atoms-are-self-atoms-t-incompatible`.

Model witness ids: `finite-support-monotone-surjections-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 2, pp. 74, 76–77; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-monotone-surjections.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-monotone-surjections.yaml`.

#### Finite-support action model: permutations of N — `finite-support-permutations`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-vicinity`, `vicinity-and-weakly-inextensible-comprehension-imply-actuality`, `actuality-incompatible-with-atomlessness`, `necessary-relational-choice-r-implies-relational-choice-r`, `relational-choice-and-boolean-completeness-imply-actuality`, `vicinity-boolean-completeness-t-and-relational-choice-imply-actuality`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `finite-support-permutations`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. The source derives the failure of Boolean Completeness through C5 and the failure of Actuality (Propositions 2.5–2.6), which gives nothing about countable families.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 1, pp. 74–76; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-permutations.yaml`.

#### Finite-support action model: permutations of N [one individual] — `finite-support-permutations-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-vicinity`, `vicinity-and-weakly-inextensible-comprehension-imply-actuality`, `actuality-incompatible-with-atomlessness`, `necessary-relational-choice-r-implies-relational-choice-r`, `vicinity-boolean-completeness-t-and-relational-choice-imply-actuality`, `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `finite-support-permutations-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. The source derives the failure of Boolean Completeness through C5 and the failure of Actuality (Propositions 2.5–2.6), which gives nothing about countable families.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 1, pp. 74–76; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-permutations.yaml`.

#### Finite-support action model: truncated shifts of N — `finite-support-truncated-shifts`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `atomicity-r-implies-atomicity-t`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-atomicity-t`.

Model witness ids: `finite-support-truncated-shifts`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 8, pp. 74, 78–79; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-truncated-shifts.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-truncated-shifts.yaml`.

#### Finite-support action model: truncated shifts of N [Σ true atom] — `finite-support-truncated-shifts-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `atomicity-r-implies-atomicity-t`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-atomicity-t`.

Model witness ids: `finite-support-truncated-shifts-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 8, pp. 74, 78–79; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-truncated-shifts.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-truncated-shifts.yaml`.

#### Finite-support action model: truncated shifts of N [one individual] — `finite-support-truncated-shifts-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `atomicity-r-implies-atomicity-t`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-atomicity-t`.

Model witness ids: `finite-support-truncated-shifts-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 8, pp. 74, 78–79; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-truncated-shifts.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-truncated-shifts.yaml`.

#### Finite-support action model: truncated shifts of N [one individual; Σ true atom] — `finite-support-truncated-shifts-individuals-singleton-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `atomicity-r-implies-atomicity-t`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-atomicity-t`.

Model witness ids: `finite-support-truncated-shifts-individuals-singleton-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 8, pp. 74, 78–79; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-truncated-shifts.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-truncated-shifts.yaml`.

#### Finite-support action model: truncations of N — `finite-support-truncations`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-relational-choice-r-implies-relational-choice-r`, `relational-choice-and-boolean-completeness-imply-actuality`, `atomicity-r-implies-atomicity-t`, `atomicity-t-and-weakly-inextensible-comprehension-imply-actuality`, `self-atomicity-t-implies-necessary-actuality`, `necessary-actuality-implies-actuality`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-atomicity-t`.

Model witness ids: `finite-support-truncations`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them. Even the universal property has no inextensible coextension, since $\operatorname{Inextensible}(\top_{et})$ unfolds to $\Box$BF at type $e$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 6, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-atoms-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_atoms.py.

Record: `topics/classicism/models/finite-support-truncations.yaml`.

#### Finite-support action model: truncations of N [one individual] — `finite-support-truncations-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `self-atomicity-t-implies-necessary-actuality`, `necessary-actuality-implies-actuality`, `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `atomicity-r-implies-atomicity-t`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-atomicity-t`.

Model witness ids: `finite-support-truncations-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them. Even the universal property has no inextensible coextension, since $\operatorname{Inextensible}(\top_{et})$ unfolds to $\Box$BF at type $e$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 6, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-atoms-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_atoms.py.

Record: `topics/classicism/models/finite-support-truncations.yaml`.

#### Finite-support action model: N and singleton, all maps — `finite-support-two-object-all-maps`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atoms-are-strong-atoms-t-implies-necessary-atoms-are-self-atoms-t`, `necessary-barcan-r-implies-necessary-barcan-t`, `necessary-barcan-t-implies-necessary-atoms-are-strong-atoms-t`, `signature-b-and-witnessed-possibility-incompatible`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-five-implies-two-hat-necessity`.

Model witness ids: `finite-support-two-object-all-maps`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, paragraph beginning “One particularly interesting result”.

Record: `topics/classicism/models/finite-support-two-object-all-maps.yaml`.

#### Full action model: free monoid on countably many generators, glued constants, thread individuals — `full-free-monoid-glued-constants`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `barcan-r-implies-barcan-t`, `nd-t-and-bf-t-imply-necessary-nd-t`, `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `atomicity-and-bf-imply-necessary-actuality`, `necessary-actuality-implies-necessary-persistent-comprehension`, `necessary-persistent-comprehension-r-implies-persistent-comprehension-r`, `c5-and-persistent-comprehension-imply-gallin`, `gallin-comprehension-implies-nd`, `logical-necessity-r-implies-separated-structure-r`, `separated-structure-incompatible-with-nd`.

Model witness ids: `full-free-monoid-glued-constants`.

Original record notes:

Promoted from conjectured on 22 September 2026. The gap in the source was its Theorem A.8, stated without proof, and the deferred type-e case; the write-up closes both by choosing a self-similar individual domain and applying the book’s coalesced sums. The signature is assumed countable; for a larger signature use a tree with as many branches. Distinct constants of one type denote distinct entities at the root, since every domain, including the individuals, has more than one element; they are also possibly identical. Everything else follows from the listed principles by the map’s results. Bacon’s interpretation of his predicates Pure and Fun in this model, and the principles stated with them, are not recorded, following Zachary Goodsell’s decision to keep the map to the logical vocabulary and the constants of Σ.

- **Logical Combinatorialism** — Andrew Bacon, Logical Combinatorialism, Philosophical Review 129 (2020), Appendix A.2–A.3, pp. 580–587; §2, n. 15, p. 547; §4, n. 48, p. 566.
- **Philosophical Introduction to HOL** — Andrew Bacon, A Philosophical Introduction to Higher-Order Logics, Routledge, 2024, §18.1, Definition 18.1, pp. 391–392; §18.3, Definition 18.6, p. 395; §18.6, Definitions 18.14–18.15, Proposition 18.7, Theorem 18.5 and Exercise 18.23, pp. 405–410.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.4–3.5, pp. 55–61 (full action models and the principles they validate); Appendix E, pp. 80–83 (truncations).
- **Fable 22 Sep** — Claude Fable 5.1 (Anthropic), prompted by Cian Dorr, verification of 22 September 2026 (see the write-up).

Record: `topics/classicism/models/full-free-monoid-glued-constants.yaml`.

#### Full action model: idempotent two-arrow monoid — `full-idempotent-monoid`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `necessary-atomicity-r-implies-necessary-atomicity-t`, `necessary-atomicity-t-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `strong-atomicity-t-implies-self-atomicity-t`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t`, `necessary-rigid-comprehension-r-implies-necessary-actuality`, `barcan-t-and-necessary-actuality-imply-self-atomicity-t`, `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `analytic-necessitism-implies-necessity-of-analysis`, `maximalism-incompatible-with-necessity-of-analysis`, `truth-implies-nd-implies-five-implies-nd`, `nd-t-and-five-to-nd-collapse-imply-necessary-nd`.

Model witness ids: `full-idempotent-monoid`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-atoms-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_atoms.py.

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: idempotent two-arrow monoid [Σ true atom] — `full-idempotent-monoid-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `necessary-atomicity-r-implies-necessary-atomicity-t`, `necessary-atomicity-t-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `strong-atomicity-t-implies-self-atomicity-t`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t`, `necessary-rigid-comprehension-r-implies-necessary-actuality`, `barcan-t-and-necessary-actuality-imply-self-atomicity-t`, `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `analytic-necessitism-implies-necessity-of-analysis`, `maximalism-incompatible-with-necessity-of-analysis`, `truth-implies-nd-implies-five-implies-nd`, `nd-t-and-five-to-nd-collapse-imply-necessary-nd`.

Model witness ids: `full-idempotent-monoid-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-atoms-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_atoms.py.

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals] — `full-idempotent-monoid-individuals-fixed-infinite`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `necessary-atomicity-r-implies-necessary-atomicity-t`, `necessary-atomicity-t-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `strong-atomicity-t-implies-self-atomicity-t`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t`, `necessary-rigid-comprehension-r-implies-necessary-actuality`, `barcan-t-and-necessary-actuality-imply-self-atomicity-t`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `truth-implies-nd-implies-five-implies-nd`, `nd-t-and-five-to-nd-collapse-imply-necessary-nd`.

Model witness ids: `full-idempotent-monoid-individuals-fixed-infinite`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-atoms-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_atoms.py.

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals; ZF + socks] — `full-idempotent-monoid-individuals-fixed-infinite-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `necessary-atomicity-r-implies-necessary-atomicity-t`, `necessary-atomicity-t-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `strong-atomicity-t-implies-self-atomicity-t`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t`, `necessary-rigid-comprehension-r-implies-necessary-actuality`, `barcan-t-and-necessary-actuality-imply-self-atomicity-t`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `truth-implies-nd-implies-five-implies-nd`, `nd-t-and-five-to-nd-collapse-imply-necessary-nd`.

Model witness ids: `full-idempotent-monoid-individuals-fixed-infinite-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-atoms-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_atoms.py.

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals; Σ true atom] — `full-idempotent-monoid-individuals-fixed-infinite-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `necessary-atomicity-r-implies-necessary-atomicity-t`, `necessary-atomicity-t-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `strong-atomicity-t-implies-self-atomicity-t`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t`, `necessary-rigid-comprehension-r-implies-necessary-actuality`, `barcan-t-and-necessary-actuality-imply-self-atomicity-t`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `truth-implies-nd-implies-five-implies-nd`, `nd-t-and-five-to-nd-collapse-imply-necessary-nd`.

Model witness ids: `full-idempotent-monoid-individuals-fixed-infinite-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-atoms-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_atoms.py.

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-idempotent-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `necessary-atomicity-r-implies-necessary-atomicity-t`, `necessary-atomicity-t-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `strong-atomicity-t-implies-self-atomicity-t`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t`, `necessary-rigid-comprehension-r-implies-necessary-actuality`, `barcan-t-and-necessary-actuality-imply-self-atomicity-t`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `truth-implies-nd-implies-five-implies-nd`, `nd-t-and-five-to-nd-collapse-imply-necessary-nd`.

Model witness ids: `full-idempotent-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-atoms-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_atoms.py.

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: two-element group — `full-involution-group`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `gallin-comprehension-implies-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-involution-group`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: two-element group [Σ true atom] — `full-involution-group-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `gallin-comprehension-implies-nd`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-involution-group-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: two-element group [infinitely many fixed individuals] — `full-involution-group-individuals-fixed-infinite`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `gallin-comprehension-implies-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-involution-group-individuals-fixed-infinite`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: two-element group [infinitely many fixed individuals; ZF + socks] — `full-involution-group-individuals-fixed-infinite-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `gallin-comprehension-implies-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-involution-group-individuals-fixed-infinite-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: two-element group [infinitely many fixed individuals; Σ true atom] — `full-involution-group-individuals-fixed-infinite-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `gallin-comprehension-implies-nd`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-involution-group-individuals-fixed-infinite-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: two-element group [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-involution-group-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `gallin-comprehension-implies-nd`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-involution-group-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: surjections of an infinite set — `full-surjection-monoid`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `fregean-incompatible-with-infinity-t`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-self-atoms-are-atoms-r`, `self-atoms-are-atoms-r-implies-self-atoms-are-atoms-t`.

Model witness ids: `full-surjection-monoid`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-metatheory-no-countable-choice-reals`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-and-necessary-bf-imply-necessary-strong-atomicity`, `necessary-strong-atomicity-r-implies-strong-atomicity-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `strong-atomicity-weak-rigid-comprehension-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-self-atoms-are-atoms-r`, `self-atoms-are-atoms-r-implies-self-atoms-are-atoms-t`.

Model witness ids: `full-surjection-monoid-metatheory-no-countable-choice-reals`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [ZF + socks] — `full-surjection-monoid-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-and-necessary-bf-imply-necessary-strong-atomicity`, `necessary-strong-atomicity-r-implies-strong-atomicity-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `strong-atomicity-weak-rigid-comprehension-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-self-atoms-are-atoms-r`, `self-atoms-are-atoms-r-implies-self-atoms-are-atoms-t`.

Model witness ids: `full-surjection-monoid-metatheory-no-countable-choice-reals`, `full-surjection-monoid-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [Σ true atom] — `full-surjection-monoid-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `fregean-incompatible-with-infinity-t`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-self-atoms-are-atoms-r`, `self-atoms-are-atoms-r-implies-self-atoms-are-atoms-t`.

Model witness ids: `full-surjection-monoid-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-sigma-true-atom-metatheory-no-countable-choice-reals`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-and-necessary-bf-imply-necessary-strong-atomicity`, `necessary-strong-atomicity-r-implies-strong-atomicity-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `strong-atomicity-weak-rigid-comprehension-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-self-atoms-are-atoms-r`, `self-atoms-are-atoms-r-implies-self-atoms-are-atoms-t`.

Model witness ids: `full-surjection-monoid-sigma-true-atom-metatheory-no-countable-choice-reals`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [Σ true atom; ZF + socks] — `full-surjection-monoid-sigma-true-atom-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-and-necessary-bf-imply-necessary-strong-atomicity`, `necessary-strong-atomicity-r-implies-strong-atomicity-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `strong-atomicity-weak-rigid-comprehension-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-self-atoms-are-atoms-r`, `self-atoms-are-atoms-r-implies-self-atoms-are-atoms-t`.

Model witness ids: `full-surjection-monoid-sigma-true-atom-metatheory-no-countable-choice-reals`, `full-surjection-monoid-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [infinitely many fixed individuals] — `full-surjection-monoid-individuals-fixed-infinite`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `fregean-incompatible-with-infinity-t`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-self-atoms-are-atoms-r`, `self-atoms-are-atoms-r-implies-self-atoms-are-atoms-t`.

Model witness ids: `full-surjection-monoid-individuals-fixed-infinite`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [infinitely many fixed individuals; ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-individuals-fixed-infinite-metatheory-no-countable-choice-reals`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-and-necessary-bf-imply-necessary-strong-atomicity`, `necessary-strong-atomicity-r-implies-strong-atomicity-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `strong-atomicity-weak-rigid-comprehension-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-self-atoms-are-atoms-r`, `self-atoms-are-atoms-r-implies-self-atoms-are-atoms-t`.

Model witness ids: `full-surjection-monoid-individuals-fixed-infinite-metatheory-no-countable-choice-reals`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [infinitely many fixed individuals; ZF + socks] — `full-surjection-monoid-individuals-fixed-infinite-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-and-necessary-bf-imply-necessary-strong-atomicity`, `necessary-strong-atomicity-r-implies-strong-atomicity-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `strong-atomicity-weak-rigid-comprehension-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-self-atoms-are-atoms-r`, `self-atoms-are-atoms-r-implies-self-atoms-are-atoms-t`.

Model witness ids: `full-surjection-monoid-individuals-fixed-infinite-metatheory-no-countable-choice-reals`, `full-surjection-monoid-individuals-fixed-infinite-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [infinitely many fixed individuals; Σ true atom] — `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `fregean-incompatible-with-infinity-t`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-self-atoms-are-atoms-r`, `self-atoms-are-atoms-r-implies-self-atoms-are-atoms-t`.

Model witness ids: `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [infinitely many fixed individuals; Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-no-countable-choice-reals`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-and-necessary-bf-imply-necessary-strong-atomicity`, `necessary-strong-atomicity-r-implies-strong-atomicity-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `strong-atomicity-weak-rigid-comprehension-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-self-atoms-are-atoms-r`, `self-atoms-are-atoms-r-implies-self-atoms-are-atoms-t`.

Model witness ids: `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-no-countable-choice-reals`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-and-necessary-bf-imply-necessary-strong-atomicity`, `necessary-strong-atomicity-r-implies-strong-atomicity-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `strong-atomicity-weak-rigid-comprehension-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-self-atoms-are-atoms-r`, `self-atoms-are-atoms-r-implies-self-atoms-are-atoms-t`.

Model witness ids: `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-no-countable-choice-reals`, `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: two-object chain — `full-two-object-chain`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `analytic-necessitism-implies-necessity-of-analysis`, `maximalism-incompatible-with-necessity-of-analysis`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r`.

Model witness ids: `full-two-object-chain`, `full-two-object-chain-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object chain [Σ true atom] — `full-two-object-chain-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-no-pure-contingency-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `analytic-necessitism-implies-necessity-of-analysis`, `maximalism-incompatible-with-necessity-of-analysis`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r`.

Model witness ids: `full-two-object-chain`, `full-two-object-chain-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object chain [infinitely many fixed individuals] — `full-two-object-chain-individuals-fixed-infinite`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r`.

Model witness ids: `full-two-object-chain-individuals-fixed-infinite`, `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object chain [infinitely many fixed individuals; ZF + socks] — `full-two-object-chain-individuals-fixed-infinite-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r`.

Model witness ids: `full-two-object-chain-individuals-fixed-infinite-metatheory-socks`, `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object chain [infinitely many fixed individuals; Σ true atom] — `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r`, `no-contingency-signature-r-implies-no-pure-contingency-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r`.

Model witness ids: `full-two-object-chain-individuals-fixed-infinite`, `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object chain [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r`, `no-contingency-signature-r-implies-no-pure-contingency-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r`.

Model witness ids: `full-two-object-chain-individuals-fixed-infinite-metatheory-socks`, `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object retract — `full-two-object-retract`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `necessary-self-atoms-are-strong-atoms-r-implies-necessary-self-atoms-are-strong-atoms-t`, `necessary-self-atoms-are-strong-atoms-t-implies-self-atoms-are-strong-atoms-t`, `self-atomicity-t-and-self-atoms-are-strong-atoms-t-imply-strong-atomicity-t`, `strong-atomicity-t-necessary-rigid-comprehension-and-rigid-power-imply-bf-t`, `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-vicinity`, `vicinity-and-barcan-t-imply-five-implies-two-hat`, `self-atomicity-t-implies-two-hat-implies-nd`, `two-hat-implies-nd-and-five-implies-two-hat-imply-five-implies-nd`, `necessary-truth-implies-five-necessity-implies-truth-implies-five-necessity`, `five-implies-nd-and-truth-implies-five-imply-truth-implies-nd`, `vicinity-implies-five-implies-two-hat`, `necessary-atomicity-r-implies-necessary-atomicity-t`, `necessary-atomicity-t-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `strong-atomicity-t-implies-two-hat-implies-nd`, `fregean-axiom-implies-distinctness-preserving-collapse`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `analytic-necessitism-implies-necessity-of-analysis`, `maximalism-incompatible-with-necessity-of-analysis`.

Model witness ids: `full-two-object-retract`, `full-two-object-retract-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Only the type-t ND assertion is recorded. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Full action model: two-object retract [Σ true atom] — `full-two-object-retract-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `necessary-self-atoms-are-strong-atoms-r-implies-necessary-self-atoms-are-strong-atoms-t`, `necessary-self-atoms-are-strong-atoms-t-implies-self-atoms-are-strong-atoms-t`, `self-atomicity-t-and-self-atoms-are-strong-atoms-t-imply-strong-atomicity-t`, `strong-atomicity-t-necessary-rigid-comprehension-and-rigid-power-imply-bf-t`, `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-vicinity`, `vicinity-and-barcan-t-imply-five-implies-two-hat`, `self-atomicity-t-implies-two-hat-implies-nd`, `two-hat-implies-nd-and-five-implies-two-hat-imply-five-implies-nd`, `necessary-truth-implies-five-necessity-implies-truth-implies-five-necessity`, `five-implies-nd-and-truth-implies-five-imply-truth-implies-nd`, `vicinity-implies-five-implies-two-hat`, `necessary-atomicity-r-implies-necessary-atomicity-t`, `necessary-atomicity-t-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `strong-atomicity-t-implies-two-hat-implies-nd`, `fregean-axiom-implies-distinctness-preserving-collapse`, `no-contingency-signature-r-implies-no-pure-contingency-r`, `no-pure-contingency-and-nd-t-imply-necessary-nd-t`, `necessary-distinctness-necessary-t-implies-necessary-two-hat-implies-nd`, `necessary-two-hat-implies-nd-necessity-implies-two-hat-implies-nd-necessity`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `analytic-necessitism-implies-necessity-of-analysis`, `maximalism-incompatible-with-necessity-of-analysis`.

Model witness ids: `full-two-object-retract`, `full-two-object-retract-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Only the type-t ND assertion is recorded. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Full action model: two-object retract [infinitely many fixed individuals] — `full-two-object-retract-individuals-fixed-infinite`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `necessary-self-atoms-are-strong-atoms-r-implies-necessary-self-atoms-are-strong-atoms-t`, `necessary-self-atoms-are-strong-atoms-t-implies-self-atoms-are-strong-atoms-t`, `self-atomicity-t-and-self-atoms-are-strong-atoms-t-imply-strong-atomicity-t`, `strong-atomicity-t-necessary-rigid-comprehension-and-rigid-power-imply-bf-t`, `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-vicinity`, `vicinity-and-barcan-t-imply-five-implies-two-hat`, `self-atomicity-t-implies-two-hat-implies-nd`, `two-hat-implies-nd-and-five-implies-two-hat-imply-five-implies-nd`, `necessary-truth-implies-five-necessity-implies-truth-implies-five-necessity`, `five-implies-nd-and-truth-implies-five-imply-truth-implies-nd`, `vicinity-implies-five-implies-two-hat`, `necessary-atomicity-r-implies-necessary-atomicity-t`, `necessary-atomicity-t-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `strong-atomicity-t-implies-two-hat-implies-nd`, `fregean-axiom-implies-distinctness-preserving-collapse`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-two-object-retract-individuals-fixed-infinite`, `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Only the type-t ND assertion is recorded. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Full action model: two-object retract [infinitely many fixed individuals; ZF + socks] — `full-two-object-retract-individuals-fixed-infinite-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `necessary-atomicity-r-implies-necessary-atomicity-t`, `necessary-atomicity-t-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `strong-atomicity-t-implies-self-atomicity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-two-object-retract-individuals-fixed-infinite-metatheory-socks`, `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Only the type-t ND assertion is recorded. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Full action model: two-object retract [infinitely many fixed individuals; Σ true atom] — `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `necessary-self-atoms-are-strong-atoms-r-implies-necessary-self-atoms-are-strong-atoms-t`, `necessary-self-atoms-are-strong-atoms-t-implies-self-atoms-are-strong-atoms-t`, `self-atomicity-t-and-self-atoms-are-strong-atoms-t-imply-strong-atomicity-t`, `strong-atomicity-t-necessary-rigid-comprehension-and-rigid-power-imply-bf-t`, `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-vicinity`, `vicinity-and-barcan-t-imply-five-implies-two-hat`, `self-atomicity-t-implies-two-hat-implies-nd`, `two-hat-implies-nd-and-five-implies-two-hat-imply-five-implies-nd`, `necessary-truth-implies-five-necessity-implies-truth-implies-five-necessity`, `five-implies-nd-and-truth-implies-five-imply-truth-implies-nd`, `vicinity-implies-five-implies-two-hat`, `necessary-atomicity-r-implies-necessary-atomicity-t`, `necessary-atomicity-t-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `strong-atomicity-t-implies-two-hat-implies-nd`, `fregean-axiom-implies-distinctness-preserving-collapse`, `no-contingency-signature-r-implies-no-pure-contingency-r`, `no-pure-contingency-and-nd-t-imply-necessary-nd-t`, `necessary-distinctness-necessary-t-implies-necessary-two-hat-implies-nd`, `necessary-two-hat-implies-nd-necessity-implies-two-hat-implies-nd-necessity`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-two-object-retract-individuals-fixed-infinite`, `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Only the type-t ND assertion is recorded. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Full action model: two-object retract [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `necessary-atomicity-r-implies-necessary-atomicity-t`, `necessary-atomicity-t-implies-atomicity-t`, `atomicity-t-and-atoms-are-self-atoms-t-imply-self-atomicity-t`, `strong-atomicity-t-implies-self-atomicity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `no-contingency-signature-r-implies-no-pure-contingency-r`, `no-pure-contingency-and-nd-imply-necessary-nd`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t`, `necessary-rigid-comprehension-r-implies-necessary-actuality`, `barcan-t-and-necessary-actuality-imply-self-atomicity-t`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-two-object-retract-individuals-fixed-infinite-metatheory-socks`, `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Only the type-t ND assertion is recorded. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Henkin model: base without a choice function — `henkin-without-relational-choice`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-no-contingency-signature-r`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-distinctness-necessary-r`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `extensionality-r-implies-intensional-choice-r`, `maximalism-incompatible-with-intensional-choice`.

Model witness ids: `henkin-without-relational-choice`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 46, p. 32.

Record: `topics/classicism/models/henkin-without-relational-choice.yaml`.

#### Henkin model: base without a choice function [Σ independent] — `henkin-without-relational-choice-sigma-independent`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Model witness ids: `henkin-without-relational-choice-sigma-independent`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 46, p. 32.

Record: `topics/classicism/models/henkin-without-relational-choice.yaml`.

#### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) — `symmetric-qualitative-contrast`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `actuality-implies-persistent-comprehension-r`, `c5-and-persistent-comprehension-imply-gallin`, `gallin-comprehension-implies-nd`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `symmetric-qualitative-contrast`, `symmetric-qualitative-contrast-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them. Plenitude still holds by C5 plus Actuality and Propositions 2.5 and 2.14, so this model separates it from Functional Choice even under C5, Rigid Comprehension and Boolean Completeness. This does not settle whether C5 plus Functional Choice implies Atomicity: the model fails the proposed premise.

- **Singleton choice verdicts (22 Oct 2026)** — OpenAI Codex, prompted by Daniel Kodsi, Singleton-individual variants: direct choice verdicts from the stabilizer theorem, 22 October 2026, §§1–4, unpaginated; Relational Choice forces Transversal Choice in symmetric ideally-full map categories, §§1–2, same date, unpaginated.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, final construction (two copies of N).
- **GPT-6 proof 24 Sep** — OpenAI Codex (GPT-6), prompted by Zachary Goodsell, 24 September 2026. Finite-support transposition proof that Relational Choice and Functional Choice fail at W0, following the user’s suggestion to transfer Plenitude countermodels to Functional Choice; see the accompanying write-up.

Record: `topics/classicism/models/symmetric-qualitative-contrast.yaml`.

#### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) [Σ true atom] — `symmetric-qualitative-contrast-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-contingency-signature-r-implies-no-pure-contingency-r`, `no-pure-contingency-and-actuality-imply-necessary-actuality`, `c5-and-necessary-actuality-imply-atomicity`, `actuality-implies-persistent-comprehension-r`, `c5-and-persistent-comprehension-imply-gallin`, `gallin-comprehension-implies-nd`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `symmetric-qualitative-contrast`, `symmetric-qualitative-contrast-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them. Plenitude still holds by C5 plus Actuality and Propositions 2.5 and 2.14, so this model separates it from Functional Choice even under C5, Rigid Comprehension and Boolean Completeness. This does not settle whether C5 plus Functional Choice implies Atomicity: the model fails the proposed premise.

- **Singleton choice verdicts (22 Oct 2026)** — OpenAI Codex, prompted by Daniel Kodsi, Singleton-individual variants: direct choice verdicts from the stabilizer theorem, 22 October 2026, §§1–4, unpaginated; Relational Choice forces Transversal Choice in symmetric ideally-full map categories, §§1–2, same date, unpaginated.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, final construction (two copies of N).
- **GPT-6 proof 24 Sep** — OpenAI Codex (GPT-6), prompted by Zachary Goodsell, 24 September 2026. Finite-support transposition proof that Relational Choice and Functional Choice fail at W0, following the user’s suggestion to transfer Plenitude countermodels to Functional Choice; see the accompanying write-up.

Record: `topics/classicism/models/symmetric-qualitative-contrast.yaml`.

#### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) [one individual] — `symmetric-qualitative-contrast-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-nd-implies-bf`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `actuality-implies-persistent-comprehension-r`, `c5-and-persistent-comprehension-imply-gallin`, `gallin-comprehension-implies-nd`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `symmetric-qualitative-contrast-individuals-singleton`, `symmetric-qualitative-contrast-individuals-singleton-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them. Plenitude still holds by C5 plus Actuality and Propositions 2.5 and 2.14, so this model separates it from Functional Choice even under C5, Rigid Comprehension and Boolean Completeness. This does not settle whether C5 plus Functional Choice implies Atomicity: the model fails the proposed premise.

- **Singleton choice verdicts (22 Oct 2026)** — OpenAI Codex, prompted by Daniel Kodsi, Singleton-individual variants: direct choice verdicts from the stabilizer theorem, 22 October 2026, §§1–4, unpaginated; Relational Choice forces Transversal Choice in symmetric ideally-full map categories, §§1–2, same date, unpaginated.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, final construction (two copies of N).
- **GPT-6 proof 24 Sep** — OpenAI Codex (GPT-6), prompted by Zachary Goodsell, 24 September 2026. Finite-support transposition proof that Relational Choice and Functional Choice fail at W0, following the user’s suggestion to transfer Plenitude countermodels to Functional Choice; see the accompanying write-up.

Record: `topics/classicism/models/symmetric-qualitative-contrast.yaml`.

#### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) [one individual; Σ true atom] — `symmetric-qualitative-contrast-individuals-singleton-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-nd-implies-bf`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-no-pure-contingency-r`, `no-pure-contingency-and-actuality-imply-necessary-actuality`, `c5-and-necessary-actuality-imply-atomicity`, `actuality-implies-persistent-comprehension-r`, `c5-and-persistent-comprehension-imply-gallin`, `gallin-comprehension-implies-nd`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `symmetric-qualitative-contrast-individuals-singleton`, `symmetric-qualitative-contrast-individuals-singleton-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them. Plenitude still holds by C5 plus Actuality and Propositions 2.5 and 2.14, so this model separates it from Functional Choice even under C5, Rigid Comprehension and Boolean Completeness. This does not settle whether C5 plus Functional Choice implies Atomicity: the model fails the proposed premise.

- **Singleton choice verdicts (22 Oct 2026)** — OpenAI Codex, prompted by Daniel Kodsi, Singleton-individual variants: direct choice verdicts from the stabilizer theorem, 22 October 2026, §§1–4, unpaginated; Relational Choice forces Transversal Choice in symmetric ideally-full map categories, §§1–2, same date, unpaginated.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, final construction (two copies of N).
- **GPT-6 proof 24 Sep** — OpenAI Codex (GPT-6), prompted by Zachary Goodsell, 24 September 2026. Finite-support transposition proof that Relational Choice and Functional Choice fail at W0, following the user’s suggestion to transfer Plenitude countermodels to Functional Choice; see the accompanying write-up.

Record: `topics/classicism/models/symmetric-qualitative-contrast.yaml`.

### 1.3 Incompatible with background (0)

None.

## 2. Central questions

Answering a central question settles many other open questions. A question is S ⊢ c, whether S entails c, for S at most two principle classes (True, with none) and c a class or False, asked only where no smaller premise set already proves or excludes c; S ⊢ False asks whether S is inconsistent. "No" denies the entailment, not the conditional. A question is settled alike by a proof, by an exclusion (S ∧ c ⇒ False) or by a recorded model that holds S and fails c. Each row scores an open question by the number of *other* open questions that stop being open once the answer joins the proved records. Both answers are scored, because proving a strong conjecture settles everything below it while refuting a weak one settles everything above it; a question with two high scores is worth answering either way. A refutation is scored by its least informative countermodel, so an actual model settles at least as much. A model check (model: principle) scores deciding an unknown verdict inside a recorded model, which settles questions exactly as a proof does. Under a background, only models of that background count and the class of its theorems is named after it (True, with no preset). Recompute with `python3 scripts/pmap.py lynchpins classicism`.

### Under no extra assumptions

125 classes and 247 fitting models; 63110 open questions. 90% of questions with up to two premises settled (589831 of 652941).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | supported-product-free-monoids-glued-constants: Finite-Type Necessitism | 2966 | 717 |
| 2 | supported-product-free-monoids-glued-constants: Finite-Type Analytic Necessitism | 1763 | 847 |
| 3 | symmetric-surjections-free-words-glued-individuals-moving: Finite-Type Necessitism | 1787 | 817 |
| 4 | symmetric-surjections-free-words-glued: Finite-Type Necessitism | 1772 | 778 |
| 5 | symmetric-surjections-free-words-glued-individuals-moving: Finite-Type Analytic Necessitism | 1082 | 1054 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| 45826 | Relational Choice ⊢ Transversal Choice ★ bronze | 557 | 1 | `relational-choice-r-implies-transversal-choice-r` |
| — | Forcing Possibilism ∧ Intensional Choice ∧ □Rigid Comprehension ∧ Non-contingency of the Continuum Hypothesis ⊢ ⊥ ★ bronze  [refuted] | — | — | `necessary-rigid-comprehension-intensional-choice-and-forcing-possibilism-incompatible-with-non-contingency-of-ch` |
| — | Boolean Completeness ∧ Relational Choice ⊢ Transversal Choice ★ bronze  [proved] | — | — | `relational-choice-and-boolean-completeness-imply-transversal-choice` |
| — | □Strong Atomicity ∧ Rigid Comprehension ⊢ □BF (relational types) ★ bronze  [proved] | — | — | `necessary-strong-atomicity-and-rigid-comprehension-imply-necessary-bf-relational` |
| — | BF ∧ Boolean Completeness ∧ □Atomicity ⊢ Rigid Comprehension ★ bronze  [refuted] | — | — | `necessary-atomicity-completeness-bf-imply-rigid-comprehension` |
| — | □Rigid Rigidity ⊢ Rigid Power ★ bronze  [refuted] | — | — | `rigid-rigidity-implies-rigid-power` |
| — | Possible Infinity (type e) ⊢ Axiom of Infinity (type e) ★ bronze  [refuted] | — | — | `possible-infinity-e-implies-axiom-of-infinity-e` |
| — | Possible Infinity (type t) ⊢ Axiom of Infinity (type t) ★ bronze  [refuted] | — | — | `possible-infinity-t-implies-axiom-of-infinity-t` |
| — | Rigid Power ∧ Tame Rigidity ⊢ Weakly Rigid Power ★ bronze  [refuted] | — | — | `tame-rigidity-and-rigid-power-imply-weakly-rigid-power` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | No Collapse ⊬ Strong Possibility (pure) | 0 | 8641 |
| 2 | No Collapse ⊬ Strong Possibility (signature Σ) | 0 | 8066 |
| 3 | No Collapse ⊬ Possibility+ (signature Σ) | 0 | 7968 |
| 4 | No Collapse ⊬ Maximalism (signature Σ) | 2 | 7856 |
| 5 | No Collapse ⊬ Possibility+ (pure) | 1 | 7660 |

### Under C5

44 classes and 53 fitting models; 3192 open questions. 70% of questions with up to two premises settled (7554 of 10746).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | finite-support-permutations: Finite-Type Necessitism | 228 | 135 |
| 2 | finite-support-permutations: Finite-Type Analytic Necessitism | 96 | 226 |
| 3 | finite-support-permutations-individuals-singleton: Finite-Type Necessitism | 208 | 99 |
| 4 | symmetric-permutations-infinite-classes: Finite-Type Necessitism | 136 | 123 |
| 5 | finite-support-permutations-individuals-singleton: Finite-Type Analytic Necessitism | 86 | 174 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| — | Atomicity ∧ Forcing Possibilism ∧ Intensional Choice ⊢ ⊥ ★ bronze  [refuted] | — | — | `necessary-rigid-comprehension-intensional-choice-and-forcing-possibilism-incompatible-with-non-contingency-of-ch` |
| — | Atomicity ⊢ Actuality ★ bronze  [proved] | — | — | `necessary-atomicity-completeness-bf-imply-rigid-comprehension` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Finite-Type Necessitism ⊬ Atomicity | 0 | 624 |
| 2 | Finite-Type Analytic Necessitism ⊬ Atomicity | 0 | 589 |
| 3 | Infinity Schema (type t) ⊬ Finite-Type Necessitism | 0 | 579 |
| 4 | Independence (signature Σ) ⊬ Truths are ND-necessary | 0 | 568 |
| 5 | Axiom of Infinity (type t) ⊬ Finite-Type Necessitism | 1 | 549 |

### Under C5 + Atomicity

25 classes and 37 fitting models; 100 open questions. 80% of questions with up to two premises settled (400 of 500).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | Forcing Possibilism ∧ Independence (signature Σ) ⊢ ⊥ | 9 | 3 |
| 2 | Forcing Possibilism ⊢ Modal Freedom (signature Σ) | 5 | 4 |
| 3 | Independence (signature Σ) ⊢ Modal Freedom (signature Σ) | 7 | 3 |
| 4 | Axiom of Infinity (type t) ∧ Independence (signature Σ) ⊢ No Contingency (signature Σ) | 3 | 5 |
| 5 | Axiom of Infinity (type t) ∧ Infinity Schema (type e) ⊢ Modal Freedom (signature Σ) | 3 | 5 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| — | Forcing Possibilism ∧ Intensional Choice ⊢ ⊥ ★ bronze  [refuted] | — | — | `necessary-rigid-comprehension-intensional-choice-and-forcing-possibilism-incompatible-with-non-contingency-of-ch` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Independence (signature Σ) ⊬ Truths are ND-necessary | 0 | 47 |
| 2 | ⊤ ⊬ Modal Freedom (signature Σ) | 0 | 31 |
| 3 | Independence (signature Σ) ∧ Infinity Schema (type t) ⊬ ⊥ | 1 | 24 |
| 4 | full-infinite-s5-individuals-fixed-infinite-sigma-true-atom: Modal Freedom (signature Σ) | 0 | 19 |
| 5 | Axiom of Infinity (type t) ∧ Independence (signature Σ) ⊬ ⊥ | 2 | 17 |

### Under Extensionalism

22 classes and 7 fitting models; 3 open questions. 95% of questions with up to two premises settled (64 of 67).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | Infinity Schema (type e) ⊢ Axiom of Infinity (type e) | 2 | 0 |
| 2 | Functional Choice ∧ Infinity Schema (type e) ⊢ Axiom of Infinity (type e) | 0 | 1 |
| 3 | Independence (signature Σ) ∧ Infinity Schema (type e) ⊢ Axiom of Infinity (type e) | 0 | 1 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| — | Forcing Possibilism ⊢ ⊥ ★ bronze  [proved] | — | — | `necessary-rigid-comprehension-intensional-choice-and-forcing-possibilism-incompatible-with-non-contingency-of-ch` |
| — | Possible Infinity (type t) ⊢ Axiom of Infinity (type t) ★ bronze  [proved] | — | — | `possible-infinity-t-implies-axiom-of-infinity-t` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Infinity Schema (type e) ⊬ Axiom of Infinity (type e) | 0 | 2 |
| 2 | Functional Choice ∧ Infinity Schema (type e) ⊢ Axiom of Infinity (type e) | 0 | 1 |
| 3 | Independence (signature Σ) ∧ Infinity Schema (type e) ⊢ Axiom of Infinity (type e) | 0 | 1 |

### Under Pure Maximalist Classicism

139 classes and 10 fitting models; 12918 open questions. 40% of questions with up to two premises settled (8806 of 21724).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | coalesced-pinned-interpretations-root: No Collapse | 220 | 386 |
| 2 | coalesced-constant-indexed-root: No Collapse | 334 | 224 |
| 3 | coalesced-pinned-substitutions-root: No Collapse | 327 | 218 |
| 4 | interpretation-cover-named-permutations: No Collapse | 281 | 217 |
| 5 | coalesced-maximalist-root: No Collapse | 347 | 185 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| 7608 | Relational Choice ⊢ Transversal Choice ★ bronze | 65 | 3 | `relational-choice-r-implies-transversal-choice-r` |
| 12080 | Rigid Power ∧ Tame Rigidity ⊢ Weakly Rigid Power ★ bronze | 0 | 8 | `tame-rigidity-and-rigid-power-imply-weakly-rigid-power` |
| — | Rigid Rigidity ⊢ Rigid Power ★ bronze  [refuted] | — | — | `rigid-rigidity-implies-rigid-power` |
| — | BF ∧ Boolean Completeness ∧ □Atomicity ⊢ Rigid Comprehension ★ bronze  [incompatible] | — | — | `necessary-atomicity-completeness-bf-imply-rigid-comprehension` |
| — | Boolean Completeness ∧ Relational Choice ⊢ Transversal Choice ★ bronze  [incompatible] | — | — | `relational-choice-and-boolean-completeness-imply-transversal-choice` |
| — | Forcing Possibilism ∧ Intensional Choice ∧ □Rigid Comprehension ∧ Non-contingency of the Continuum Hypothesis ⊢ ⊥ ★ bronze  [proved] | — | — | `necessary-rigid-comprehension-intensional-choice-and-forcing-possibilism-incompatible-with-non-contingency-of-ch` |
| — | □Strong Atomicity ∧ Rigid Comprehension ⊢ □BF (relational types) ★ bronze  [incompatible] | — | — | `necessary-strong-atomicity-and-rigid-comprehension-imply-necessary-bf-relational` |
| — | ⊤ ⊢ Axiom of Infinity (type e) ★ bronze  [refuted] | — | — | `possible-infinity-e-implies-axiom-of-infinity-e` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Rigid Power ⊬ ⊥ | 0 | 2781 |
| 2 | Tame Rigidity ⊬ ⊥ | 0 | 2385 |
| 3 | No Collapse ⊬ ⊥ | 0 | 1926 |
| 4 | Rigid Power ⊬ BF | 1 | 1737 |
| 5 | ⊤ ⊬ Transversal Choice | 0 | 1735 |

### Under □Rigid Comprehension

85 classes and 129 fitting models; 27358 open questions. 82% of questions with up to two premises settled (125527 of 152885).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | full-free-product-glued-constants: Analytic Necessitism | 666 | 471 |
| 2 | full-free-product-glued-constants: Finite-Type Analytic Necessitism | 666 | 471 |
| 3 | full-free-product-glued-constants: Second-Order Analytic Necessitism | 666 | 471 |
| 4 | (Atomicity ∧ Atoms are strong atoms) or (Atomicity ∧ BF (relational types)) or (Atomicity ∧ □Atoms are strong atoms) or (Atoms are strong atoms ∧ □Atomicity) or (BF (relational types) ∧ □Atomicity) or (□Atomicity ∧ □Atoms are strong atoms) or □Strong Atomicity ⊢ Analytic Necessitism or Finite-Type Analytic Necessitism or Second-Order Analytic Necessitism | 449 | 403 |
| 5 | symmetric-range-gap: Second-Order Analytic Necessitism | 426 | 390 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| 9748 | □Rigid Rigidity ⊢ Rigid Power ★ bronze | 102 | 8 | `rigid-rigidity-implies-rigid-power` |
| 21377 | Possible Infinity (type e) ⊢ Axiom of Infinity (type e) ★ bronze | 128 | 0 | `possible-infinity-e-implies-axiom-of-infinity-e` |
| — | Forcing Possibilism ∧ Intensional Choice ∧ Non-contingency of the Continuum Hypothesis ⊢ ⊥ ★ bronze  [refuted] | — | — | `necessary-rigid-comprehension-intensional-choice-and-forcing-possibilism-incompatible-with-non-contingency-of-ch` |
| — | □Strong Atomicity ⊢ BF (relational types) ★ bronze  [proved] | — | — | `necessary-strong-atomicity-and-rigid-comprehension-imply-necessary-bf-relational` |
| — | Possible Infinity (type t) ⊢ Axiom of Infinity (type t) ★ bronze  [refuted] | — | — | `possible-infinity-t-implies-axiom-of-infinity-t` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Finite-Type Necessitism ⊬ □Atomicity | 0 | 4037 |
| 2 | B for pure sentences ⊬ Finite-Type Analytic Necessitism | 0 | 3612 |
| 3 | Finite-Type Necessitism ⊬ Atomicity | 1 | 3106 |
| 4 | B for pure sentences ⊬ Second-Order Analytic Necessitism | 1 | 2980 |
| 5 | Rigid Power ⊬ □Atomicity | 1 | 2858 |

## 3. Open questions under each recorded package

The most useful place to work: these are open *given* assumptions the sources already make.

### C5 + Atomicity

Assuming `necessary-distinctness-necessary-r`, `atomicity-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Pure Maximalist Classicism

Assuming `distinctness-schema-r`, these remain open:

- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- No Collapse (`no-collapse`)
- Relational Choice (`relational-choice-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### BF + Weak Rigid Comprehension + Atomicity + Relational Choice

Assuming `barcan-r`, `weak-rigid-comprehension-r`, `atomicity-r`, `relational-choice-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Functionality (`necessary-functionality-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Self-Atomicity (type t) (`necessary-self-atomicity-t`)
- □Strong Atomicity (`necessary-strong-atomicity-r`)
- □Strong Atomicity (type t) (`necessary-strong-atomicity-t`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Weak Rigid Comprehension (`necessary-weak-rigid-comprehension-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)

### Self-Atomicity + Atomicity (type t) + Weak Rigid Comprehension + Relational Choice

Assuming `self-atomicity-r`, `atomicity-t`, `weak-rigid-comprehension-r`, `relational-choice-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Atomicity (`atomicity-r`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Self-Atomicity (type t) (`necessary-self-atomicity-t`)
- □Strong Actuality (`necessary-strong-actuality`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Weak Rigid Comprehension (`necessary-weak-rigid-comprehension-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Rigid Power (`rigid-power-r`)

### Well-Ordering + Weak Rigid Comprehension + BF

Assuming `well-ordering-r`, `weak-rigid-comprehension-r`, `barcan-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Vicinity (`necessary-vicinity`)

### Strong Atomicity (type t) + Rigid Comprehension + BF (relational types)

Assuming `strong-atomicity-t`, `rigid-comprehension-r`, `barcan-relational`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Atomicity (`atomicity-r`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Strong Atomicity (`necessary-strong-atomicity-r`)
- □Strong Atomicity (type t) (`necessary-strong-atomicity-t`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Rigid Power (`rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Self-Atomicity (`self-atomicity-r`)
- Strong Atomicity (`strong-atomicity-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### Vicinity + Boolean Completeness (type t) + Relational Choice

Assuming `vicinity`, `boolean-completeness-t`, `relational-choice-r`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Transversal (`necessary-transversal-r`)

### □BF + □Atomicity + □Rigid Comprehension

Assuming `necessary-barcan-r`, `necessary-atomicity-r`, `necessary-rigid-comprehension-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### □Vicinity + □Boolean Completeness (type t) + □Relational Choice

Assuming `necessary-vicinity`, `necessary-boolean-completeness-t`, `necessary-relational-choice-r`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)

### Strong Atomicity + □Rigid Comprehension + Rigid Power

Assuming `strong-atomicity-r`, `necessary-rigid-comprehension-r`, `rigid-power-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Strong Atomicity (type t) + □Rigid Comprehension + Rigid Power

Assuming `strong-atomicity-t`, `necessary-rigid-comprehension-r`, `rigid-power-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Atomicity (`atomicity-r`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Strong Atomicity (type t) (`necessary-strong-atomicity-t`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Strong Atomicity + Weak Rigid Comprehension + Relational Choice

Assuming `strong-atomicity-r`, `weak-rigid-comprehension-r`, `relational-choice-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- BF (relational types) (`barcan-relational`)
- BF (type t) (`barcan-t`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Self-Atomicity (type t) (`necessary-self-atomicity-t`)
- □Strong Atomicity (`necessary-strong-atomicity-r`)
- □Strong Atomicity (type t) (`necessary-strong-atomicity-t`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Weak Rigid Comprehension (`necessary-weak-rigid-comprehension-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Rigid Power (`rigid-power-r`)

### Boolean Completeness + Actuality

Assuming `boolean-completeness-r`, `actuality`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- □Transversal (`necessary-transversal-r`)

### □BF + Actuality

Assuming `necessary-barcan-r`, `actuality`, these remain open:

- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Transversal (`necessary-transversal-r`)

### □ND + Actuality

Assuming `necessary-distinctness-necessary-r`, `actuality`, these remain open:

- Finite-Type Necessitism (`finite-type-necessitism`)
- □Transversal (`necessary-transversal-r`)

### No Pure Contingency + Actuality

Assuming `no-pure-contingency-r`, `actuality`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Strong Actuality (`strong-actuality`)

### Actuality + Self-atoms are strong atoms (type t)

Assuming `actuality`, `self-atoms-are-strong-atoms-t`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Transversal (`necessary-transversal-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)

### Finite-Type Necessitism + Analytic Necessitism

Assuming `finite-type-necessitism`, `analytic-necessitism`, these remain open:

- Actuality (`actuality`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Persistent Comprehension (`necessary-persistent-comprehension-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- □Weak Rigid Comprehension (`necessary-weak-rigid-comprehension-r`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Rigid Power (`rigid-power-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal (`transversal-r`)
- Vicinity (`vicinity`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### Analytic Necessitism + Transversal

Assuming `analytic-necessitism`, `transversal-r`, these remain open:

- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal (`necessary-transversal-r`)
- Tame Rigidity (`tame-rigidity-r`)

### Atomicity + BF

Assuming `atomicity-r`, `barcan-r`, these remain open:

- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)

### Atomicity + BF (relational types)

Assuming `atomicity-r`, `barcan-relational`, these remain open:

- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)

### Atomicity + □Rigid Comprehension

Assuming `atomicity-r`, `necessary-rigid-comprehension-r`, these remain open:

- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)

### No Pure Contingency + Atomicity

Assuming `no-pure-contingency-r`, `atomicity-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal (`necessary-transversal-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Rigid Power (`rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal (`transversal-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### Atomicity + Rigid Comprehension

Assuming `atomicity-r`, `rigid-comprehension-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Transversal (`necessary-transversal-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)

### Atomicity (type t) + BF

Assuming `atomicity-t`, `barcan-r`, these remain open:

- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)

### Atomicity (type t) + BF (type t)

Assuming `atomicity-t`, `barcan-t`, these remain open:

- □Atomicity (type t) (`necessary-atomicity-t`)

### □ND + Atomicity (type t)

Assuming `necessary-distinctness-necessary-r`, `atomicity-t`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Atomicity (type t)

Assuming `no-pure-contingency-r`, `atomicity-t`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Atomicity (`atomicity-r`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Atomicity (`necessary-atomicity-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal (`necessary-transversal-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Rigid Power (`rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal (`transversal-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### Vicinity + Atomicity (type t)

Assuming `vicinity`, `atomicity-t`, these remain open:

- □Transversal (`necessary-transversal-r`)

### Atomicity (type t) + Weakly Inextensible Comprehension

Assuming `atomicity-t`, `weakly-inextensible-comprehension-r`, these remain open:

- □Transversal (`necessary-transversal-r`)

### □ND + Atomlessness

Assuming `necessary-distinctness-necessary-r`, `atomlessness`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- No Contingency (signature Σ) (`no-contingency-signature-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### No Pure Contingency + Atomlessness

Assuming `no-pure-contingency-r`, `atomlessness`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- Tame Rigidity (`tame-rigidity-r`)

### No Pure Contingency + Atoms are self-atoms

Assuming `no-pure-contingency-r`, `atoms-are-self-atoms-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)

### Atoms are self-atoms + Self-atoms are strong atoms

Assuming `atoms-are-self-atoms-r`, `self-atoms-are-strong-atoms-r`, these remain open:

- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)

### No Pure Contingency + Atoms are self-atoms (type t)

Assuming `no-pure-contingency-r`, `atoms-are-self-atoms-t`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Atoms are self-atoms (`atoms-are-self-atoms-r`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)

### Atoms are self-atoms (type t) + Self-atoms are strong atoms (type t)

Assuming `atoms-are-self-atoms-t`, `self-atoms-are-strong-atoms-t`, these remain open:

- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)

### No Pure Contingency + Atoms are strong atoms

Assuming `no-pure-contingency-r`, `atoms-are-strong-atoms-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)

### Atoms are strong atoms + Self-atoms are atoms

Assuming `atoms-are-strong-atoms-r`, `self-atoms-are-atoms-r`, these remain open:

- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)

### No Pure Contingency + Atoms are strong atoms (type t)

Assuming `no-pure-contingency-r`, `atoms-are-strong-atoms-t`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Atoms are self-atoms (`atoms-are-self-atoms-r`)
- Atoms are strong atoms (`atoms-are-strong-atoms-r`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)

### Atoms are strong atoms (type t) + Self-atoms are atoms (type t)

Assuming `atoms-are-strong-atoms-t`, `self-atoms-are-atoms-t`, these remain open:

- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)

### Gallin Extensional Comprehension + BF

Assuming `gallin-extensional-comprehension-r`, `barcan-r`, these remain open:

- Finite-Type Necessitism (`finite-type-necessitism`)
- □Transversal (`necessary-transversal-r`)

### BF + Intensional Choice

Assuming `barcan-r`, `intensional-choice-r`, these remain open:

- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### No Pure Contingency + BF

Assuming `no-pure-contingency-r`, `barcan-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are ND-necessary (`five-implies-nd-necessity`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- Two-hat necessities are ND-necessary (`two-hat-implies-nd-necessity`)

### Rigid Comprehension + BF

Assuming `rigid-comprehension-r`, `barcan-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Transversal (`necessary-transversal-r`)

### Self-Atomicity (type t) + BF

Assuming `self-atomicity-t`, `barcan-r`, these remain open:

- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)

### Self-atoms are atoms (type t) + BF

Assuming `self-atoms-are-atoms-t`, `barcan-r`, these remain open:

- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)

### Self-atoms are strong atoms (type t) + BF

Assuming `self-atoms-are-strong-atoms-t`, `barcan-r`, these remain open:

- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)

### BF + Weakly Rigid Power

Assuming `barcan-r`, `weakly-rigid-power-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### No Pure Contingency + BF (relational types)

Assuming `no-pure-contingency-r`, `barcan-relational`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- BF (`barcan-r`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are ND-necessary (`five-implies-nd-necessity`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Functionality (`functionality-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □BF (`necessary-barcan-r`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- Tractarianism (`tractarianism-r`)
- Two-hat necessities are ND-necessary (`two-hat-implies-nd-necessity`)

### BF (type t) + □Actuality

Assuming `barcan-t`, `necessary-actuality`, these remain open:

- □Strong Actuality (`necessary-strong-actuality`)

### No Pure Contingency + BF (type t)

Assuming `no-pure-contingency-r`, `barcan-t`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Atoms are self-atoms (`atoms-are-self-atoms-r`)
- Atoms are strong atoms (`atoms-are-strong-atoms-r`)
- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are ND-necessary (`five-implies-nd-necessity`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Functionality (`functionality-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- Tractarianism (`tractarianism-r`)
- Two-hat necessities are ND-necessary (`two-hat-implies-nd-necessity`)

### Possible Infinity (type t) + BF (type t)

Assuming `possible-infinity-t`, `barcan-t`, these remain open:

- Atoms are self-atoms (`atoms-are-self-atoms-r`)
- Atoms are strong atoms (`atoms-are-strong-atoms-r`)
- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- Functionality (`functionality-r`)
- Tractarianism (`tractarianism-r`)

### Rigid Comprehension + BF (type t)

Assuming `rigid-comprehension-r`, `barcan-t`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Transversal (`necessary-transversal-r`)

### Boolean Completeness + Modalized Relational Choice

Assuming `boolean-completeness-r`, `modalized-relational-choice-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)

### □ND + Boolean Completeness

Assuming `necessary-distinctness-necessary-r`, `boolean-completeness-r`, these remain open:

- Finite-Type Necessitism (`finite-type-necessitism`)
- □Transversal (`necessary-transversal-r`)

### No Pure Contingency + Boolean Completeness

Assuming `no-pure-contingency-r`, `boolean-completeness-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Relational Choice + Boolean Completeness

Assuming `relational-choice-r`, `boolean-completeness-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)

### No Pure Contingency + Boolean Completeness (type t)

Assuming `no-pure-contingency-r`, `boolean-completeness-t`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### No Pure Contingency + Countable Boolean Completeness

Assuming `no-pure-contingency-r`, `countable-boolean-completeness-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)

### No Pure Contingency + ND

Assuming `no-pure-contingency-r`, `distinctness-necessary-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### ND + Strong Actuality

Assuming `distinctness-necessary-r`, `strong-actuality`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Transversal (`necessary-transversal-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Power (`rigid-power-r`)

### Weak Rigid Comprehension + ND

Assuming `weak-rigid-comprehension-r`, `distinctness-necessary-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Transversal (`necessary-transversal-r`)
- Rigid Power (`rigid-power-r`)

### ND (type t) + Inextensible Comprehension

Assuming `distinctness-necessary-t`, `inextensible-comprehension-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Transversal (`necessary-transversal-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Plenitude (`plenitude-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)

### No Pure Contingency + ND (type t)

Assuming `no-pure-contingency-r`, `distinctness-necessary-t`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Maximalism (pure) + Separated Structure

Assuming `distinctness-schema-r`, `separated-structure-r`, these remain open:

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Infinity Schema (type e) (`infinity-e`)
- No Collapse (`no-collapse`)
- Relational Choice (`relational-choice-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### No Pure Contingency + 5-necessities are ND-necessary

Assuming `no-pure-contingency-r`, `five-implies-nd-necessity`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + 5-necessities are two-hat necessary

Assuming `no-pure-contingency-r`, `five-implies-two-hat-necessity`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Functional Choice

Assuming `no-pure-contingency-r`, `functional-choice-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Functionality

Assuming `no-pure-contingency-r`, `functionality-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are ND-necessary (`five-implies-nd-necessity`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- Two-hat necessities are ND-necessary (`two-hat-implies-nd-necessity`)

### No Pure Contingency + Gallin Extensional Comprehension

Assuming `no-pure-contingency-r`, `gallin-extensional-comprehension-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Inextensible Comprehension

Assuming `no-pure-contingency-r`, `inextensible-comprehension-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### □Relational Choice + Intensional Choice

Assuming `necessary-relational-choice-r`, `intensional-choice-r`, these remain open:

- Modal Well-Ordering (`modal-well-ordering-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### No Pure Contingency + Intensional Choice

Assuming `no-pure-contingency-r`, `intensional-choice-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal (`necessary-transversal-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal (`transversal-r`)

### No Pure Contingency + B

Assuming `no-pure-contingency-r`, `modal-b`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### No Pure Contingency + 5

Assuming `no-pure-contingency-r`, `modal-five`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### 5 + Self-Atomicity (type t)

Assuming `modal-five`, `self-atomicity-t`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### 5 + Strong Atomicity (type t)

Assuming `modal-five`, `strong-atomicity-t`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Modalized Relational Choice

Assuming `no-pure-contingency-r`, `modalized-relational-choice-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### □Boolean Completeness + □Actuality

Assuming `necessary-boolean-completeness-r`, `necessary-actuality`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)

### □ND + □Actuality

Assuming `necessary-distinctness-necessary-r`, `necessary-actuality`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □Actuality + □Self-atoms are strong atoms (type t)

Assuming `necessary-actuality`, `necessary-self-atoms-are-strong-atoms-t`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)

### □Atomicity + □BF

Assuming `necessary-atomicity-r`, `necessary-barcan-r`, these remain open:

- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- Rigid Rigidity (`rigid-rigidity-r`)

### □Atomicity (type t) + □BF

Assuming `necessary-atomicity-t`, `necessary-barcan-r`, these remain open:

- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- Rigid Rigidity (`rigid-rigidity-r`)

### □Atoms are self-atoms (type t) + □Self-atoms are strong atoms (type t)

Assuming `necessary-atoms-are-self-atoms-t`, `necessary-self-atoms-are-strong-atoms-t`, these remain open:

- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)

### □Atoms are strong atoms (type t) + □Self-atoms are atoms (type t)

Assuming `necessary-atoms-are-strong-atoms-t`, `necessary-self-atoms-are-atoms-t`, these remain open:

- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)

### □Self-atoms are atoms (type t) + □BF

Assuming `necessary-self-atoms-are-atoms-t`, `necessary-barcan-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Tame Rigidity (`tame-rigidity-r`)

### □Self-atoms are strong atoms (type t) + □BF

Assuming `necessary-self-atoms-are-strong-atoms-t`, `necessary-barcan-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Tame Rigidity (`tame-rigidity-r`)

### □Strong Atomicity (type t) + □BF

Assuming `necessary-strong-atomicity-t`, `necessary-barcan-r`, these remain open:

- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- Rigid Rigidity (`rigid-rigidity-r`)

### □BF + Rigid Power

Assuming `necessary-barcan-r`, `rigid-power-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### □ND + □Boolean Completeness

Assuming `necessary-distinctness-necessary-r`, `necessary-boolean-completeness-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □ND + □Persistent Comprehension

Assuming `necessary-distinctness-necessary-r`, `necessary-persistent-comprehension-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □ND + □Rigid Comprehension

Assuming `necessary-distinctness-necessary-r`, `necessary-rigid-comprehension-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □ND + □Strong Actuality

Assuming `necessary-distinctness-necessary-r`, `necessary-strong-actuality`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □ND + Persistent Comprehension

Assuming `necessary-distinctness-necessary-r`, `persistent-comprehension-r`, these remain open:

- Finite-Type Necessitism (`finite-type-necessitism`)
- □Transversal (`necessary-transversal-r`)

### □Relational Choice + □Intensional Choice

Assuming `necessary-relational-choice-r`, `necessary-intensional-choice-r`, these remain open:

- Modal Well-Ordering (`modal-well-ordering-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### □Relational Choice + □Plenitude

Assuming `necessary-relational-choice-r`, `necessary-plenitude-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □Strong Atomicity + □Rigid Comprehension

Assuming `necessary-strong-atomicity-r`, `necessary-rigid-comprehension-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### □Rigid Comprehension + Rigid Power

Assuming `necessary-rigid-comprehension-r`, `rigid-power-r`, these remain open:

- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)

### □Tame Rigidity + □Rigid Power

Assuming `necessary-tame-rigidity-r`, `necessary-rigid-power-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### □Self-Atomicity + □Self-atoms are atoms

Assuming `necessary-self-atomicity-r`, `necessary-self-atoms-are-atoms-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Atoms are strong atoms (`atoms-are-strong-atoms-r`)
- Atoms are strong atoms (type t) (`atoms-are-strong-atoms-t`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Strong Atomicity (`necessary-strong-atomicity-r`)
- □Strong Atomicity (type t) (`necessary-strong-atomicity-t`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Self-atoms are strong atoms (type t) (`self-atoms-are-strong-atoms-t`)
- Strong Atomicity (`strong-atomicity-r`)
- Strong Atomicity (type t) (`strong-atomicity-t`)
- Tame Rigidity (`tame-rigidity-r`)

### □Self-Atomicity + □Self-atoms are strong atoms

Assuming `necessary-self-atomicity-r`, `necessary-self-atoms-are-strong-atoms-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Tame Rigidity (`tame-rigidity-r`)

### □Self-Atomicity (type t) + □Self-atoms are atoms (type t)

Assuming `necessary-self-atomicity-t`, `necessary-self-atoms-are-atoms-t`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Atoms are strong atoms (type t) (`atoms-are-strong-atoms-t`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Strong Atomicity (type t) (`necessary-strong-atomicity-t`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Self-atoms are strong atoms (type t) (`self-atoms-are-strong-atoms-t`)
- Strong Atomicity (type t) (`strong-atomicity-t`)
- Tame Rigidity (`tame-rigidity-r`)

### □Self-Atomicity (type t) + □Self-atoms are strong atoms (type t)

Assuming `necessary-self-atomicity-t`, `necessary-self-atoms-are-strong-atoms-t`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Tame Rigidity (`tame-rigidity-r`)

### □Tame Rigidity + Rigid Power

Assuming `necessary-tame-rigidity-r`, `rigid-power-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### No Pure Contingency + Persistent Comprehension

Assuming `no-pure-contingency-r`, `persistent-comprehension-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Strong Actuality (`strong-actuality`)

### No Pure Contingency + Plenitude

Assuming `no-pure-contingency-r`, `plenitude-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Possible Infinity (type e) + No Pure Contingency

Assuming `possible-infinity-e`, `no-pure-contingency-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)

### Possible Infinity (type t) + No Pure Contingency

Assuming `possible-infinity-t`, `no-pure-contingency-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)

### No Pure Contingency + Relational Choice

Assuming `no-pure-contingency-r`, `relational-choice-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### No Pure Contingency + Rigid Comprehension

Assuming `no-pure-contingency-r`, `rigid-comprehension-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Strong Actuality (`strong-actuality`)

### No Pure Contingency + Rigid Power

Assuming `no-pure-contingency-r`, `rigid-power-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Tame Rigidity (`tame-rigidity-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### No Pure Contingency + Self-Atomicity

Assuming `no-pure-contingency-r`, `self-atomicity-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### No Pure Contingency + Self-Atomicity (type t)

Assuming `no-pure-contingency-r`, `self-atomicity-t`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Atoms are self-atoms (`atoms-are-self-atoms-r`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Self-Atomicity (`self-atomicity-r`)

### No Pure Contingency + Self-atoms are atoms

Assuming `no-pure-contingency-r`, `self-atoms-are-atoms-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Self-atoms are strong atoms (type t) (`self-atoms-are-strong-atoms-t`)
- Tame Rigidity (`tame-rigidity-r`)

### No Pure Contingency + Self-atoms are atoms (type t)

Assuming `no-pure-contingency-r`, `self-atoms-are-atoms-t`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Self-atoms are strong atoms (type t) (`self-atoms-are-strong-atoms-t`)
- Tame Rigidity (`tame-rigidity-r`)

### No Pure Contingency + Self-atoms are strong atoms

Assuming `no-pure-contingency-r`, `self-atoms-are-strong-atoms-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- Tame Rigidity (`tame-rigidity-r`)

### No Pure Contingency + Self-atoms are strong atoms (type t)

Assuming `no-pure-contingency-r`, `self-atoms-are-strong-atoms-t`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Tame Rigidity (`tame-rigidity-r`)

### No Pure Contingency + Strong Actuality

Assuming `no-pure-contingency-r`, `strong-actuality`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### No Pure Contingency + Strong Atomicity

Assuming `no-pure-contingency-r`, `strong-atomicity-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- BF (type t) (`barcan-t`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Functionality (`functionality-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Tame Rigidity (`tame-rigidity-r`)
- Tractarianism (`tractarianism-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### No Pure Contingency + Strong Atomicity (type t)

Assuming `no-pure-contingency-r`, `strong-atomicity-t`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Atomicity (`atomicity-r`)
- Atoms are self-atoms (`atoms-are-self-atoms-r`)
- Atoms are strong atoms (`atoms-are-strong-atoms-r`)
- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- BF (type t) (`barcan-t`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Functionality (`functionality-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Strong Atomicity (`necessary-strong-atomicity-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Self-Atomicity (`self-atomicity-r`)
- Strong Atomicity (`strong-atomicity-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Tractarianism (`tractarianism-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### No Pure Contingency + Tame Rigidity

Assuming `no-pure-contingency-r`, `tame-rigidity-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)

### No Pure Contingency + Tractarianism

Assuming `no-pure-contingency-r`, `tractarianism-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are ND-necessary (`five-implies-nd-necessity`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- Two-hat necessities are ND-necessary (`two-hat-implies-nd-necessity`)

### No Pure Contingency + Transversal Choice

Assuming `no-pure-contingency-r`, `transversal-choice-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- Tame Rigidity (`tame-rigidity-r`)

### No Pure Contingency + Transversal

Assuming `no-pure-contingency-r`, `transversal-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)

### No Pure Contingency + Truths are 5-necessary

Assuming `no-pure-contingency-r`, `truth-implies-five-necessity`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)

### No Pure Contingency + Truths are two-hat necessary

Assuming `no-pure-contingency-r`, `truth-implies-two-hat-necessity`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### No Pure Contingency + Two-hat necessities are ND-necessary

Assuming `no-pure-contingency-r`, `two-hat-implies-nd-necessity`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Vicinity

Assuming `no-pure-contingency-r`, `vicinity`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### No Pure Contingency + Weak Rigid Comprehension

Assuming `no-pure-contingency-r`, `weak-rigid-comprehension-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Strong Actuality (`strong-actuality`)

### No Pure Contingency + Weakly Inextensible Comprehension

Assuming `no-pure-contingency-r`, `weakly-inextensible-comprehension-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### No Pure Contingency + Weakly Rigid Power

Assuming `no-pure-contingency-r`, `weakly-rigid-power-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### No Pure Contingency + Well-Ordering

Assuming `no-pure-contingency-r`, `well-ordering-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- Tame Rigidity (`tame-rigidity-r`)

### Witnessed Possibility + No Pure Contingency

Assuming `witnessed-possibility-r`, `no-pure-contingency-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Infinity Schema (type t) (`infinity-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal (`necessary-transversal-r`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal (`transversal-r`)

### Relational Choice + Plenitude

Assuming `relational-choice-r`, `plenitude-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Rigid Power (`rigid-power-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### Relational Choice + Weak Rigid Comprehension

Assuming `relational-choice-r`, `weak-rigid-comprehension-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)

### Strong Atomicity + Rigid Comprehension

Assuming `strong-atomicity-r`, `rigid-comprehension-r`, these remain open:

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Rigid Rigidity + Rigid Power

Assuming `rigid-rigidity-r`, `rigid-power-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### Self-Atomicity + Self-atoms are atoms

Assuming `self-atomicity-r`, `self-atoms-are-atoms-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Self-Atomicity (type t) (`necessary-self-atomicity-t`)
- □Strong Actuality (`necessary-strong-actuality`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Tame Rigidity (`tame-rigidity-r`)

### Self-Atomicity + Self-atoms are strong atoms

Assuming `self-atomicity-r`, `self-atoms-are-strong-atoms-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Self-Atomicity (type t) (`necessary-self-atomicity-t`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Strong Atomicity (`necessary-strong-atomicity-r`)
- □Strong Atomicity (type t) (`necessary-strong-atomicity-t`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Tame Rigidity (`tame-rigidity-r`)

### Self-Atomicity (type t) + Self-atoms are atoms (type t)

Assuming `self-atomicity-t`, `self-atoms-are-atoms-t`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Self-Atomicity (type t) (`necessary-self-atomicity-t`)
- □Strong Actuality (`necessary-strong-actuality`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Tame Rigidity (`tame-rigidity-r`)

### Self-Atomicity (type t) + Self-atoms are strong atoms (type t)

Assuming `self-atomicity-t`, `self-atoms-are-strong-atoms-t`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Self-Atomicity (type t) (`necessary-self-atomicity-t`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Strong Atomicity (type t) (`necessary-strong-atomicity-t`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Tame Rigidity (`tame-rigidity-r`)

### Tame Rigidity + Weak Rigid Comprehension

Assuming `tame-rigidity-r`, `weak-rigid-comprehension-r`, these remain open:

- Arithmetic Necessitism (`arithmetic-necessitism`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Transversal (`necessary-transversal-r`)

## 4. Unknown verdicts inside each model

For these principles the model has not been checked either way. Deciding one is a self-contained calculation in a construction that is already written down.

### Absorbing entrance to an integer action, with finitely supported swappable pairs — `absorbing-entrance-swappable-pairs`

Fully determined; nothing unknown.

### Coalesced sum: root over all finite individual domains — `coalesced-all-finite-individual-domains`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Coalesced sum: free root over the all-maps model and countable full S5 — `coalesced-all-maps-and-countable-s5-root`

Fully determined; nothing unknown.

### Coalesced sum: root individuals indexed by infinitely many individual constants — `coalesced-constant-indexed-root`

- Forcing Possibilism (`forcing-possibilism`)
- No Collapse (`no-collapse`)

### Coalesced sum: interpretation arrows into every component object, definable root — `coalesced-definable-root`

- Atoms are self-atoms (`atoms-are-self-atoms-r`)
- Atoms are self-atoms (type t) (`atoms-are-self-atoms-t`)
- Atoms are strong atoms (`atoms-are-strong-atoms-r`)
- Atoms are strong atoms (type t) (`atoms-are-strong-atoms-t`)
- No Collapse (`no-collapse`)
- Rigid Power (`rigid-power-r`)

### Coalesced sum: maximalist root — `coalesced-maximalist-root`

- Forcing Possibilism (`forcing-possibilism`)
- No Collapse (`no-collapse`)

### Coalesced sum: interpretation arrows into every component object, finitely pinned root — `coalesced-pinned-interpretations-root`

- No Collapse (`no-collapse`)
- Rigid Power (`rigid-power-r`)

### Coalesced sum: substitution arrows over two atomless components disagreeing about CH — `coalesced-pinned-substitutions-ch-root`

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- ND (`distinctness-necessary-r`)
- ND (type t) (`distinctness-necessary-t`)
- Truths are ND-necessary (`distinctness-preserving-collapse`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are ND-necessary (`five-implies-nd-necessity`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Functionality (`functionality-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Intensional Choice (`intensional-choice-r`)
- B (`modal-b`)
- 5 (`modal-five`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □ND (`necessary-distinctness-necessary-r`)
- □ND (type t) (`necessary-distinctness-necessary-t`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Functionality (`necessary-functionality-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □B (`necessary-modal-b`)
- □5 (`necessary-modal-five`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Vicinity (`necessary-vicinity`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- No Collapse (`no-collapse`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Separated Structure (`separated-structure-r`)
- B for sentences of Σ (`signature-b-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Tractarianism (`tractarianism-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)
- Two-hat necessities are ND-necessary (`two-hat-implies-nd-necessity`)
- Vicinity (`vicinity`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)
- Well-Ordering (`well-ordering-r`)
- Witnessed Possibility (`witnessed-possibility-r`)
- Zorn's Lemma (`zorn-r`)

### Coalesced sum: substitution arrows over an atomless component with nonstandard arithmetic — `coalesced-pinned-substitutions-nonstandard-root`

- Independence (signature Σ) (`independence-signature-r`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Well-Ordering (`necessary-well-ordering-r`)
- No Collapse (`no-collapse`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- B for pure sentences (`pure-b-r`)
- Rigid Power (`rigid-power-r`)
- Separated Structure (`separated-structure-r`)
- B for sentences of Σ (`signature-b-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Coalesced sum: substitution arrows over a one-world component — `coalesced-pinned-substitutions-one-world-root`

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Truths are ND-necessary (`distinctness-preserving-collapse`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are ND-necessary (`five-implies-nd-necessity`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Functionality (`functionality-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Functionality (`necessary-functionality-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Vicinity (`necessary-vicinity`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- No Collapse (`no-collapse`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Separated Structure (`separated-structure-r`)
- B for sentences of Σ (`signature-b-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Tractarianism (`tractarianism-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)
- Two-hat necessities are ND-necessary (`two-hat-implies-nd-necessity`)
- Vicinity (`vicinity`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)
- Well-Ordering (`well-ordering-r`)
- Witnessed Possibility (`witnessed-possibility-r`)
- Zorn's Lemma (`zorn-r`)

### Coalesced sum: interpretation and substitution arrows, finitely pinned root — `coalesced-pinned-substitutions-root`

- No Collapse (`no-collapse`)
- Rigid Power (`rigid-power-r`)

### Coalesced sum: substitution arrows over the truncations model — `coalesced-pinned-substitutions-truncations-root`

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- ND (`distinctness-necessary-r`)
- ND (type t) (`distinctness-necessary-t`)
- Truths are ND-necessary (`distinctness-preserving-collapse`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are ND-necessary (`five-implies-nd-necessity`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Functionality (`functionality-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Intensional Choice (`intensional-choice-r`)
- B (`modal-b`)
- 5 (`modal-five`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Functionality (`necessary-functionality-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Vicinity (`necessary-vicinity`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- No Collapse (`no-collapse`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Separated Structure (`separated-structure-r`)
- B for sentences of Σ (`signature-b-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Tractarianism (`tractarianism-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)
- Two-hat necessities are ND-necessary (`two-hat-implies-nd-necessity`)
- Vicinity (`vicinity`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)
- Well-Ordering (`well-ordering-r`)
- Witnessed Possibility (`witnessed-possibility-r`)
- Zorn's Lemma (`zorn-r`)

### Coalesced sum: singleton individual root — `coalesced-single-individual-root`

- Maximalism (signature Σ) (`distinctness-signature-r`)
- Forcing Possibilism (`forcing-possibilism`)
- Independence (signature Σ) (`independence-signature-r`)
- No Collapse (`no-collapse`)
- Possibility+ (signature Σ) (`possibility-plus-signature-r`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Coalesced sum: interpretation and substitution arrows, fullest root — `coalesced-substitutions-fullest-root`

- Atoms are self-atoms (`atoms-are-self-atoms-r`)
- Atoms are self-atoms (type t) (`atoms-are-self-atoms-t`)
- Atoms are strong atoms (`atoms-are-strong-atoms-r`)
- Atoms are strong atoms (type t) (`atoms-are-strong-atoms-t`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Forcing Possibilism (`forcing-possibilism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- No Collapse (`no-collapse`)
- Rigid Power (`rigid-power-r`)
- Strong Actuality (`strong-actuality`)
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### Coalesced sum: free root over a Henkin model with independently swappable pairs — `coalesced-swappable-pairs-root`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Coalesced sum of two extensional models disagreeing about arithmetic — `coalesced-two-extensional-arithmetics-root`

- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)

### Coalesced sum of two extensional models disagreeing about CH — `coalesced-two-extensional-ch-models-root`

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Power (`rigid-power-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### Cofinite entrance to the full idempotent action — `cofinite-entrance-idempotent`

- Finite-Type Necessitism (`finite-type-necessitism`)

### Finite-pin fanout: nested-equivalence components — `finite-pin-fanout-nested-equivalence-components`

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Atoms are self-atoms (`atoms-are-self-atoms-r`)
- Atoms are self-atoms (type t) (`atoms-are-self-atoms-t`)
- Atoms are strong atoms (`atoms-are-strong-atoms-r`)
- Atoms are strong atoms (type t) (`atoms-are-strong-atoms-t`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- ND (`distinctness-necessary-r`)
- ND (type t) (`distinctness-necessary-t`)
- Truths are ND-necessary (`distinctness-preserving-collapse`)
- Maximalism (pure) (`distinctness-schema-r`)
- Maximalism (signature Σ) (`distinctness-signature-r`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are ND-necessary (`five-implies-nd-necessity`)
- Forcing Possibilism (`forcing-possibilism`)
- Functional Choice (`functional-choice-r`)
- Functionality (`functionality-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- Intensional Choice (`intensional-choice-r`)
- B (`modal-b`)
- 5 (`modal-five`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Functionality (`necessary-functionality-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Plenitude (`plenitude-r`)
- Possibility+ (pure) (`possibility-plus-r`)
- Possibility+ (signature Σ) (`possibility-plus-signature-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are atoms (type t) (`self-atoms-are-atoms-t`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Self-atoms are strong atoms (type t) (`self-atoms-are-strong-atoms-t`)
- Separated Structure (`separated-structure-r`)
- B for sentences of Σ (`signature-b-r`)
- Strong Actuality (`strong-actuality`)
- Strong Possibility (pure) (`strong-possibility-r`)
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Tractarianism (`tractarianism-r`)
- Transversal Choice (`transversal-choice-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)
- Two-hat necessities are ND-necessary (`two-hat-implies-nd-necessity`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)
- Well-Ordering (`well-ordering-r`)
- Witnessed Possibility (`witnessed-possibility-r`)
- Zorn's Lemma (`zorn-r`)

### Paired-individuals model with a singleton-source prefix — `finite-source-prefix-paired-individuals`

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- ND (`distinctness-necessary-r`)
- ND (type t) (`distinctness-necessary-t`)
- Truths are ND-necessary (`distinctness-preserving-collapse`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are ND-necessary (`five-implies-nd-necessity`)
- Forcing Possibilism (`forcing-possibilism`)
- Functional Choice (`functional-choice-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- Intensional Choice (`intensional-choice-r`)
- B (`modal-b`)
- 5 (`modal-five`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- No Collapse (`no-collapse`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Plenitude (`plenitude-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- B for pure sentences (`pure-b-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Rigid Power (`rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are atoms (type t) (`self-atoms-are-atoms-t`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Self-atoms are strong atoms (type t) (`self-atoms-are-strong-atoms-t`)
- Separated Structure (`separated-structure-r`)
- B for sentences of Σ (`signature-b-r`)
- Strong Actuality (`strong-actuality`)
- Tame Rigidity (`tame-rigidity-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)
- Two-hat necessities are ND-necessary (`two-hat-implies-nd-necessity`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finitely pinned action model: Cantor fan of terminal worlds — `finite-support-cantor-fan`

- Analytic Necessitism (`analytic-necessitism`)
- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Functionality (`functionality-r`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □Functionality (`necessary-functionality-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Tame Rigidity (`tame-rigidity-r`)
- Tractarianism (`tractarianism-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Finite-support action model: dyadic roundings of N — `finite-support-dyadic-roundings`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: dyadic roundings of N [Σ true atom] — `finite-support-dyadic-roundings-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: dyadic roundings of N [one individual] — `finite-support-dyadic-roundings-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: dyadic roundings of N [one individual; Σ true atom] — `finite-support-dyadic-roundings-individuals-singleton-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: identity-or-collapse monotone surjections — `finite-support-identity-or-collapse-surjections`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Finite-support action model: identity-or-collapse monotone surjections [Σ true atom] — `finite-support-identity-or-collapse-surjections-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Finite-support action model: identity-or-collapse monotone surjections [one individual] — `finite-support-identity-or-collapse-surjections-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Finite-support action model: identity-or-collapse monotone surjections [one individual; Σ true atom] — `finite-support-identity-or-collapse-surjections-individuals-singleton-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Finite-support action model: identity-or-collapse monotone maps — `finite-support-identity-or-collapse`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: identity-or-collapse monotone maps [Σ true atom] — `finite-support-identity-or-collapse-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: identity-or-collapse monotone maps [one individual] — `finite-support-identity-or-collapse-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: identity-or-collapse monotone maps [one individual; Σ true atom] — `finite-support-identity-or-collapse-individuals-singleton-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: monotone maps of N — `finite-support-monotone-maps`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Independence (signature Σ) (`independence-signature-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- B for sentences of Σ (`signature-b-r`)

### Finite-support action model: monotone maps of N [Σ top] — `finite-support-monotone-maps-sigma-top`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: monotone maps of N [one individual] — `finite-support-monotone-maps-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- B for sentences of Σ (`signature-b-r`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)

### Finite-support action model: monotone maps of N [one individual; Σ top] — `finite-support-monotone-maps-individuals-singleton-sigma-top`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)

### Finite-support action model: monotone surjections of N — `finite-support-monotone-surjections`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Finite-support action model: monotone surjections of N [one individual] — `finite-support-monotone-surjections-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Finite-support action model: pair-preserving injections and pair collapses of N — `finite-support-pair-injections-or-collapses`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: pair-preserving injections and pair collapses of N [one individual] — `finite-support-pair-injections-or-collapses-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: permutations of N, with each point doubled at a second object — `finite-support-permutations-and-doubled-points`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Independence (signature Σ) (`independence-signature-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: permutations of N — `finite-support-permutations`

- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)

### Finite-support action model: permutations of N [one individual] — `finite-support-permutations-individuals-singleton`

- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)

### Finite-support action model: N and N×2, sections and projection — `finite-support-sections-and-projection`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Independence (signature Σ) (`independence-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: single-flip sections and projection — `finite-support-single-flip-sections`

- Analytic Necessitism (`analytic-necessitism`)
- Atomicity (`atomicity-r`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Functional Choice (`functional-choice-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Plenitude (`plenitude-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)

### Finite-support action model: truncated shifts of N — `finite-support-truncated-shifts`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: truncated shifts of N [Σ true atom] — `finite-support-truncated-shifts-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: truncated shifts of N [one individual] — `finite-support-truncated-shifts-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: truncated shifts of N [one individual; Σ true atom] — `finite-support-truncated-shifts-individuals-singleton-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: truncations of N — `finite-support-truncations`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: truncations of N [one individual] — `finite-support-truncations-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: N and singleton, all maps, evaluated at the singleton — `finite-support-two-object-all-maps-at-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Finite-support action model: N and singleton, all maps — `finite-support-two-object-all-maps`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full Boolean-valued model: one atom and an atomless component — `full-boolean-valued-atom-and-atomless`

- Finite-Type Necessitism (`finite-type-necessitism`)
- Necessity of Analysis (`necessity-of-analysis`)

### Full Boolean-valued model: one atom and an atomless component [built in L] — `full-boolean-valued-atom-and-atomless-universe-constructible`

- Finite-Type Necessitism (`finite-type-necessitism`)

### Full Boolean-valued model: one atom and the Cohen algebra, with infinitely many individuals — `full-boolean-valued-atom-and-cohen-real`

- Finite-Type Necessitism (`finite-type-necessitism`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)

### Full Boolean-valued model: one atom and the Cohen algebra, with infinitely many individuals [built in L] — `full-boolean-valued-atom-and-cohen-real-universe-constructible`

- Finite-Type Necessitism (`finite-type-necessitism`)

### Full Boolean-valued model with countably closed subset forcing — `full-boolean-valued-countably-closed-subset`

- Actuality (`actuality`)
- Atomlessness (`atomlessness`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Forcing Possibilism (`forcing-possibilism`)
- Functional Choice (`functional-choice-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- Intensional Choice (`intensional-choice-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Atomlessness (`necessary-atomlessness`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- No Contingency (signature Σ) (`no-contingency-signature-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Plenitude (`plenitude-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Strong Actuality (`strong-actuality`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)

### Full Boolean-valued model with a no-new-reals collapse — `full-boolean-valued-no-new-reals-collapse`

- Actuality (`actuality`)
- Atomlessness (`atomlessness`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Forcing Possibilism (`forcing-possibilism`)
- Functional Choice (`functional-choice-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Atomlessness (`necessary-atomlessness`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Plenitude (`plenitude-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Strong Actuality (`strong-actuality`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)

### Full action model: double retraction with free sites, glued constants — `full-double-retraction-glued-constants`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: free monoid on countably many generators, glued constants, singleton individuals — `full-free-monoid-glued-constants-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: free monoid on countably many generators, glued constants, thread individuals — `full-free-monoid-glued-constants`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: free product of a free monoid with an idempotent, the bicyclic monoid and an involution, glued constants — `full-free-product-glued-constants`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full Henkin model: finite individual domain — `full-henkin-finite-base`

Fully determined; nothing unknown.

### Full Henkin model: finite individual domain [Σ independent] — `full-henkin-finite-base-sigma-independent`

Fully determined; nothing unknown.

### Full Henkin model: countably infinite individual domain — `full-henkin-infinite-base`

Fully determined; nothing unknown.

### Full Henkin model: countably infinite individual domain [Σ independent] — `full-henkin-infinite-base-sigma-independent`

Fully determined; nothing unknown.

### Full Henkin model: singleton individual domain — `full-henkin-singleton-base`

Fully determined; nothing unknown.

### Full action model: idempotent two-arrow monoid — `full-idempotent-monoid`

Fully determined; nothing unknown.

### Full action model: idempotent two-arrow monoid [Σ true atom] — `full-idempotent-monoid-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals] — `full-idempotent-monoid-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals; ZF + socks] — `full-idempotent-monoid-individuals-fixed-infinite-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals; Σ true atom] — `full-idempotent-monoid-individuals-fixed-infinite-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-idempotent-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: infinite S5 — `full-infinite-s5`

- Forcing Possibilism (`forcing-possibilism`)

### Full action model: infinite S5 [ZF + ¬AC_ω(ℝ)] — `full-infinite-s5-metatheory-no-countable-choice-reals`

- Forcing Possibilism (`forcing-possibilism`)

### Full action model: infinite S5 [ZF + socks] — `full-infinite-s5-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: infinite S5 [Σ true atom] — `full-infinite-s5-sigma-true-atom`

- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: infinite S5 [Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-infinite-s5-sigma-true-atom-metatheory-no-countable-choice-reals`

- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: infinite S5 [Σ true atom; ZF + socks] — `full-infinite-s5-sigma-true-atom-metatheory-socks`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: infinite S5 [infinitely many fixed individuals] — `full-infinite-s5-individuals-fixed-infinite`

- Forcing Possibilism (`forcing-possibilism`)

### Full action model: infinite S5 [infinitely many fixed individuals; ZF + ¬AC_ω(ℝ)] — `full-infinite-s5-individuals-fixed-infinite-metatheory-no-countable-choice-reals`

- Forcing Possibilism (`forcing-possibilism`)

### Full action model: infinite S5 [infinitely many fixed individuals; ZF + socks] — `full-infinite-s5-individuals-fixed-infinite-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: infinite S5 [infinitely many fixed individuals; Σ true atom] — `full-infinite-s5-individuals-fixed-infinite-sigma-true-atom`

- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: infinite S5 [infinitely many fixed individuals; Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-infinite-s5-individuals-fixed-infinite-sigma-true-atom-metatheory-no-countable-choice-reals`

- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: infinite S5 [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-infinite-s5-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: two-element group — `full-involution-group`

Fully determined; nothing unknown.

### Full action model: two-element group [Σ true atom] — `full-involution-group-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: two-element group [infinitely many fixed individuals] — `full-involution-group-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: two-element group [infinitely many fixed individuals; ZF + socks] — `full-involution-group-individuals-fixed-infinite-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: two-element group [infinitely many fixed individuals; Σ true atom] — `full-involution-group-individuals-fixed-infinite-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: two-element group [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-involution-group-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: the monoid with ac = bc — `full-monoid-ac-equals-bc`

- Forcing Possibilism (`forcing-possibilism`)

### Full action model: the monoid with ac = bc [Σ true atom] — `full-monoid-ac-equals-bc-sigma-true-atom`

- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: the monoid with ac = bc [infinitely many fixed individuals] — `full-monoid-ac-equals-bc-individuals-fixed-infinite`

- Forcing Possibilism (`forcing-possibilism`)

### Full action model: the monoid with ac = bc [infinitely many fixed individuals; ZF + socks] — `full-monoid-ac-equals-bc-individuals-fixed-infinite-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Intensional Choice (`intensional-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: the monoid with ac = bc [infinitely many fixed individuals; Σ true atom] — `full-monoid-ac-equals-bc-individuals-fixed-infinite-sigma-true-atom`

- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: the monoid with ac = bc [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-monoid-ac-equals-bc-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Intensional Choice (`intensional-choice-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: permutations of an infinite set — `full-permutation-group-infinite-set`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [ZF + ¬AC_ω(ℝ)] — `full-permutation-group-infinite-set-metatheory-no-countable-choice-reals`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [Σ true atom] — `full-permutation-group-infinite-set-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-permutation-group-infinite-set-sigma-true-atom-metatheory-no-countable-choice-reals`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [infinitely many fixed individuals] — `full-permutation-group-infinite-set-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [infinitely many fixed individuals; ZF + ¬AC_ω(ℝ)] — `full-permutation-group-infinite-set-individuals-fixed-infinite-metatheory-no-countable-choice-reals`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [infinitely many fixed individuals; ZF + socks] — `full-permutation-group-infinite-set-individuals-fixed-infinite-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [infinitely many fixed individuals; Σ true atom] — `full-permutation-group-infinite-set-individuals-fixed-infinite-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [infinitely many fixed individuals; Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-permutation-group-infinite-set-individuals-fixed-infinite-sigma-true-atom-metatheory-no-countable-choice-reals`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-permutation-group-infinite-set-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: surjections of an infinite set — `full-surjection-monoid`

Fully determined; nothing unknown.

### Full action model: surjections of an infinite set [ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-metatheory-no-countable-choice-reals`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: surjections of an infinite set [ZF + socks] — `full-surjection-monoid-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: surjections of an infinite set [Σ true atom] — `full-surjection-monoid-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: surjections of an infinite set [Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-sigma-true-atom-metatheory-no-countable-choice-reals`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: surjections of an infinite set [Σ true atom; ZF + socks] — `full-surjection-monoid-sigma-true-atom-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: surjections of an infinite set [infinitely many fixed individuals] — `full-surjection-monoid-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: surjections of an infinite set [infinitely many fixed individuals; ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-individuals-fixed-infinite-metatheory-no-countable-choice-reals`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: surjections of an infinite set [infinitely many fixed individuals; ZF + socks] — `full-surjection-monoid-individuals-fixed-infinite-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: surjections of an infinite set [infinitely many fixed individuals; Σ true atom] — `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: surjections of an infinite set [infinitely many fixed individuals; Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-no-countable-choice-reals`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: surjections of an infinite set [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: three-object fork with a merged composite — `full-three-object-fork`

- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- B for pure sentences (`pure-b-r`)
- B for sentences of Σ (`signature-b-r`)

### Full action model: three-object fork with a merged composite [Σ true atom] — `full-three-object-fork-sigma-true-atom`

- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- B for pure sentences (`pure-b-r`)

### Full action model: three-object fork with a merged composite [infinitely many fixed individuals] — `full-three-object-fork-individuals-fixed-infinite`

- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- B for pure sentences (`pure-b-r`)
- B for sentences of Σ (`signature-b-r`)

### Full action model: three-object fork with a merged composite [infinitely many fixed individuals; ZF + socks] — `full-three-object-fork-individuals-fixed-infinite-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- B for pure sentences (`pure-b-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- B for sentences of Σ (`signature-b-r`)

### Full action model: three-object fork with a merged composite [infinitely many fixed individuals; Σ true atom] — `full-three-object-fork-individuals-fixed-infinite-sigma-true-atom`

- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- B for pure sentences (`pure-b-r`)

### Full action model: three-object fork with a merged composite [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-three-object-fork-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- B for pure sentences (`pure-b-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: two-object chain with a free loop at the second object — `full-two-object-chain-free-loop`

Fully determined; nothing unknown.

### Full action model: two-object chain with a free loop at the second object [Σ true atom] — `full-two-object-chain-free-loop-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: two-object chain with a free loop at the second object [infinitely many fixed individuals] — `full-two-object-chain-free-loop-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: two-object chain with a free loop at the second object [infinitely many fixed individuals; ZF + socks] — `full-two-object-chain-free-loop-individuals-fixed-infinite-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Intensional Choice (`intensional-choice-r`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: two-object chain with a free loop at the second object [infinitely many fixed individuals; Σ true atom] — `full-two-object-chain-free-loop-individuals-fixed-infinite-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: two-object chain with a free loop at the second object [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-two-object-chain-free-loop-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Intensional Choice (`intensional-choice-r`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: two-object chain, one individual becoming two — `full-two-object-chain-new-individual`

Fully determined; nothing unknown.

### Full action model: two-object chain — `full-two-object-chain`

Fully determined; nothing unknown.

### Full action model: two-object chain [Σ true atom] — `full-two-object-chain-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: two-object chain [infinitely many fixed individuals] — `full-two-object-chain-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: two-object chain [infinitely many fixed individuals; ZF + socks] — `full-two-object-chain-individuals-fixed-infinite-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: two-object chain [infinitely many fixed individuals; Σ true atom] — `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: two-object chain [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Full action model: two-object retract with two retractions — `full-two-object-double-retraction`

Fully determined; nothing unknown.

### Full action model: two-object retract with two retractions [Σ true atom] — `full-two-object-double-retraction-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: two-object retract with two retractions [infinitely many fixed individuals] — `full-two-object-double-retraction-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: two-object retract with two retractions [infinitely many fixed individuals; ZF + socks] — `full-two-object-double-retraction-individuals-fixed-infinite-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)

### Full action model: two-object retract with two retractions [infinitely many fixed individuals; Σ true atom] — `full-two-object-double-retraction-individuals-fixed-infinite-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: two-object retract with two retractions [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-two-object-double-retraction-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)

### Full action model: two-object retract — `full-two-object-retract`

Fully determined; nothing unknown.

### Full action model: two-object retract [Σ true atom] — `full-two-object-retract-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: two-object retract [infinitely many fixed individuals] — `full-two-object-retract-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: two-object retract [infinitely many fixed individuals; ZF + socks] — `full-two-object-retract-individuals-fixed-infinite-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)

### Full action model: two-object retract [infinitely many fixed individuals; Σ true atom] — `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: two-object retract [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)

### Henkin model: base without a choice function — `henkin-without-relational-choice`

Fully determined; nothing unknown.

### Henkin model: base without a choice function [Σ independent] — `henkin-without-relational-choice-sigma-independent`

Fully determined; nothing unknown.

### Interpretation cover: named permutations — `interpretation-cover-named-permutations`

- Finite-Type Necessitism (`finite-type-necessitism`)
- No Collapse (`no-collapse`)
- Rigid Power (`rigid-power-r`)
- Strong Possibility (signature Σ) (`strong-possibility-signature-r`)

### Interpretation cover: progressive substitutions — `interpretation-cover-progressive-substitutions`

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- No Collapse (`no-collapse`)
- Rigid Power (`rigid-power-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### Interpretation cover: identity-only over the stitched Cohen middle — `interpretation-cover-stitched-cohen-middle`

- Actuality (`actuality`)
- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Atomlessness (`atomlessness`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Truths are ND-necessary (`distinctness-preserving-collapse`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are ND-necessary (`five-implies-nd-necessity`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Forcing Possibilism (`forcing-possibilism`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Atomlessness (`necessary-atomlessness`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Persistent Comprehension (`necessary-persistent-comprehension-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Self-Atomicity (type t) (`necessary-self-atomicity-t`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Strong Actuality (`necessary-strong-actuality`)
- □Strong Atomicity (`necessary-strong-atomicity-r`)
- □Strong Atomicity (type t) (`necessary-strong-atomicity-t`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Vicinity (`necessary-vicinity`)
- □Weak Rigid Comprehension (`necessary-weak-rigid-comprehension-r`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- No Collapse (`no-collapse`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Power (`rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Self-Atomicity (`self-atomicity-r`)
- Self-Atomicity (type t) (`self-atomicity-t`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are atoms (type t) (`self-atoms-are-atoms-t`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Self-atoms are strong atoms (type t) (`self-atoms-are-strong-atoms-t`)
- Separated Structure (`separated-structure-r`)
- B for sentences of Σ (`signature-b-r`)
- Strong Actuality (`strong-actuality`)
- Strong Atomicity (`strong-atomicity-r`)
- Strong Atomicity (type t) (`strong-atomicity-t`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)
- Two-hat necessities are ND-necessary (`two-hat-implies-nd-necessity`)
- Vicinity (`vicinity`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)
- Well-Ordering (`well-ordering-r`)
- Witnessed Possibility (`witnessed-possibility-r`)
- Zorn's Lemma (`zorn-r`)

### Interpretation cover: surjective chain names — `interpretation-cover-surjective-chain-names`

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- No Collapse (`no-collapse`)
- Possibility+ (pure) (`possibility-plus-r`)
- Possibility+ (signature Σ) (`possibility-plus-signature-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Power (`rigid-power-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Modalized domains: Cohen cloud — `modalized-cohen-cloud`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Independence (signature Σ) (`independence-signature-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Modalized domains: Cohen–idempotent rooted sum — `modalized-cohen-idempotent-sum`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Independence (signature Σ) (`independence-signature-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Modalized domains: lottery cloud — `modalized-lottery-cloud`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Independence (signature Σ) (`independence-signature-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Nominal cofinite entrance: double-retraction tail — `nominal-cofinite-double-retraction-entrance`

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- Truths are ND-necessary (`distinctness-preserving-collapse`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Independence (signature Σ) (`independence-signature-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Rigid Power (`rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are atoms (type t) (`self-atoms-are-atoms-t`)
- Separated Structure (`separated-structure-r`)
- B for sentences of Σ (`signature-b-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal Choice (`transversal-choice-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Well-Ordering (`well-ordering-r`)
- Witnessed Possibility (`witnessed-possibility-r`)
- Zorn's Lemma (`zorn-r`)

### Nominal cofinite entrance over sections and projection — `nominal-cofinite-sections-entrance`

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- Truths are ND-necessary (`distinctness-preserving-collapse`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Independence (signature Σ) (`independence-signature-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Weak Rigid Comprehension (`necessary-weak-rigid-comprehension-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Power (`rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are atoms (type t) (`self-atoms-are-atoms-t`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Self-atoms are strong atoms (type t) (`self-atoms-are-strong-atoms-t`)
- Separated Structure (`separated-structure-r`)
- B for sentences of Σ (`signature-b-r`)
- Transversal Choice (`transversal-choice-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)
- Well-Ordering (`well-ordering-r`)
- Witnessed Possibility (`witnessed-possibility-r`)
- Zorn's Lemma (`zorn-r`)

### Paired-individuals two-object model: surjective block-respecting maps, evaluated at the second object — `paired-individuals-two-object-surjective-at-v`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- No Collapse (`no-collapse`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Paired-individuals two-object model: surjective block-respecting maps — `paired-individuals-two-object-surjective`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- No Collapse (`no-collapse`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Paired-individuals two-object model: block-respecting maps — `paired-individuals-two-object`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- No Collapse (`no-collapse`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Eventually stationary entrance to the full successor action — `stationary-entrance-successor`

- Finite-Type Necessitism (`finite-type-necessitism`)

### Stitched forcing model: ground-model root with a CH-reversing extension at its one other world — `stitched-ch-reversing`

- Necessity of Analysis (`necessity-of-analysis`)

### Stitched forcing model: ground-model root with a CH-reversing extension at its one other world [over L] — `stitched-ch-reversing-universe-constructible`

Fully determined; nothing unknown.

### Stitched Cohen model with a coalesced middle world — `stitched-cohen-coalesced-middle`

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Atoms are self-atoms (`atoms-are-self-atoms-r`)
- Atoms are strong atoms (`atoms-are-strong-atoms-r`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- Truths are ND-necessary (`distinctness-preserving-collapse`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- B for pure sentences (`pure-b-r`)
- Rigid Power (`rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Self-Atomicity (`self-atomicity-r`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are atoms (type t) (`self-atoms-are-atoms-t`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Self-atoms are strong atoms (type t) (`self-atoms-are-strong-atoms-t`)
- B for sentences of Σ (`signature-b-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### Stitched forcing model: ground-model root with a Cohen extension at its one other world — `stitched-cohen-extension`

- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)

### Stitched forcing model: ground-model root with a Cohen extension at its one other world [over L] — `stitched-cohen-extension-universe-constructible`

Fully determined; nothing unknown.

### Stitched forcing model: countably closed subset forcing — `stitched-countably-closed-subset`

- BF (relational types) (`barcan-relational`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Stitched forcing model: countably closed subset forcing [over L] — `stitched-countably-closed-subset-universe-constructible`

- BF (relational types) (`barcan-relational`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Supported model over the ultrafilters of a complete homogeneous algebra, with a free root — `supported-boolean-complete-predecessor`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- □Transversal (`necessary-transversal-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Supported-product action model: κ⁺ free-monoid coordinates, glued constants — `supported-product-free-monoids-glued-constants`

- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)

### Supported-product action model: free-monoid coordinates and surjections of the individuals, glued constants — `supported-product-surjections-glued-constants`

- Finite-Type Necessitism (`finite-type-necessitism`)

### Symmetric ideally-full model: all surjections of N (Base 1) — `symmetric-all-surjections`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: all surjections of N (Base 1) [one individual] — `symmetric-all-surjections-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: atomless Boolean prefix with recurrent colour subalgebras — `symmetric-boolean-prefix-recurrent-colours`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Transversal (`necessary-transversal-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- No Collapse (`no-collapse`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: atomless Boolean prefix with recurrent colour subalgebras [one individual] — `symmetric-boolean-prefix-recurrent-colours-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- No Collapse (`no-collapse`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Relational Choice (`relational-choice-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal Choice (`transversal-choice-r`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: class-reflecting surjections of infinitely many infinite classes — `symmetric-class-reflecting-surjections`

- Analytic Necessitism (`analytic-necessitism`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Tame Rigidity (`tame-rigidity-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Symmetric ideally-full model: class-reflecting surjections of infinitely many infinite classes [one individual] — `symmetric-class-reflecting-surjections-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Intensional Choice (`intensional-choice-r`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal (`necessary-transversal-r`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal (`transversal-r`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Symmetric Cohen model: arithmetic growth — `symmetric-cohen-arithmetic-growth`

- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Atomlessness (`atomlessness`)
- Atoms are self-atoms (`atoms-are-self-atoms-r`)
- Atoms are self-atoms (type t) (`atoms-are-self-atoms-t`)
- Atoms are strong atoms (`atoms-are-strong-atoms-r`)
- Atoms are strong atoms (type t) (`atoms-are-strong-atoms-t`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- ND (`distinctness-necessary-r`)
- ND (type t) (`distinctness-necessary-t`)
- Truths are ND-necessary (`distinctness-preserving-collapse`)
- 5-necessities are ND-necessary (`five-implies-nd-necessity`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Forcing Possibilism (`forcing-possibilism`)
- Functionality (`functionality-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- Intensional Choice (`intensional-choice-r`)
- Logical Necessity (`logical-necessity-r`)
- B (`modal-b`)
- 5 (`modal-five`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Atomlessness (`necessary-atomlessness`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Functionality (`necessary-functionality-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Vicinity (`necessary-vicinity`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- No Collapse (`no-collapse`)
- No Contingency (signature Σ) (`no-contingency-signature-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are atoms (type t) (`self-atoms-are-atoms-t`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Self-atoms are strong atoms (type t) (`self-atoms-are-strong-atoms-t`)
- Separated Structure (`separated-structure-r`)
- B for sentences of Σ (`signature-b-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Tractarianism (`tractarianism-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)
- Two-hat necessities are ND-necessary (`two-hat-implies-nd-necessity`)
- Vicinity (`vicinity`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Symmetric ideally-full model: collapsers of a fixed pair, and a point — `symmetric-collapse-pair-and-point`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Self-Atomicity (type t) (`necessary-self-atomicity-t`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Weak Rigid Comprehension (`necessary-weak-rigid-comprehension-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- B for pure sentences (`pure-b-r`)
- Rigid Power (`rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- B for sentences of Σ (`signature-b-r`)

### Symmetric ideally-full model: collapsers of a fixed pair, and a point [Σ true atom] — `symmetric-collapse-pair-and-point-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Self-Atomicity (type t) (`necessary-self-atomicity-t`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Weak Rigid Comprehension (`necessary-weak-rigid-comprehension-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- B for pure sentences (`pure-b-r`)
- Rigid Power (`rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: collapsers of a fixed pair, and a point [one individual] — `symmetric-collapse-pair-and-point-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Self-Atomicity (type t) (`necessary-self-atomicity-t`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Weak Rigid Comprehension (`necessary-weak-rigid-comprehension-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Power (`rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- B for sentences of Σ (`signature-b-r`)
- Transversal Choice (`transversal-choice-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: collapsers of a fixed pair, and a point [one individual; Σ true atom] — `symmetric-collapse-pair-and-point-individuals-singleton-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Self-Atomicity (type t) (`necessary-self-atomicity-t`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Weak Rigid Comprehension (`necessary-weak-rigid-comprehension-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Power (`rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Transversal Choice (`transversal-choice-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: permutations and collapsers of a fixed pair (Base 2) — `symmetric-collapse-pair`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: permutations and collapsers of a fixed pair (Base 2) [Σ true atom] — `symmetric-collapse-pair-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: permutations and collapsers of a fixed pair (Base 2) [one individual] — `symmetric-collapse-pair-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Intensional Choice (`intensional-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: permutations and collapsers of a fixed pair (Base 2) [one individual; Σ true atom] — `symmetric-collapse-pair-individuals-singleton-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Intensional Choice (`intensional-choice-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: a one-point entrance to the qualitative-links tail — `symmetric-entrance-qualitative-links`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: a one-point entrance to the qualitative-links tail [Σ true atom] — `symmetric-entrance-qualitative-links-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: finite-compression labels at an entrance — `symmetric-finite-compression-entrance`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Transversal (`necessary-transversal-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- No Collapse (`no-collapse`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Transversal (`transversal-r`)

### Symmetric ideally-full model: finite-compression labels at an entrance [one individual] — `symmetric-finite-compression-entrance-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Intensional Choice (`intensional-choice-r`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal (`necessary-transversal-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- No Collapse (`no-collapse`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Rigid Power (`rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal (`transversal-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### Symmetric ideally-full model: automorphisms of infinitely many infinite classes — `symmetric-infinite-classes`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: automorphisms of infinitely many infinite classes [one individual] — `symmetric-infinite-classes-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Intensional Choice (`intensional-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Transversal (`necessary-transversal-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Transversal (`transversal-r`)

### Symmetric ideally-full model: old and new individuals — `symmetric-old-new-individuals`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Intensional Choice (`intensional-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: old and new individuals [one individual] — `symmetric-old-new-individuals-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: permutations, with the automorphisms of infinitely many infinite classes as symmetries — `symmetric-permutations-infinite-classes`

- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)

### Symmetric ideally-full model: permutations, with the automorphisms of infinitely many infinite classes as symmetries [one individual] — `symmetric-permutations-infinite-classes-individuals-singleton`

- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### Symmetric ideally-full model: qualitative contrast, evaluated at W1 — `symmetric-qualitative-contrast-at-w1`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: qualitative contrast, evaluated at W1 [one individual] — `symmetric-qualitative-contrast-at-w1-individuals-singleton`

- Actuality (`actuality`)
- Analytic Necessitism (`analytic-necessitism`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Functional Choice (`functional-choice-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Intensional Choice (`intensional-choice-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Functional Choice (`necessary-functional-choice-r`)
- □Gallin Extensional Comprehension (`necessary-gallin-extensional-comprehension-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Persistent Comprehension (`necessary-persistent-comprehension-r`)
- □Plenitude (`necessary-plenitude-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Self-Atomicity (type t) (`necessary-self-atomicity-t`)
- □Strong Actuality (`necessary-strong-actuality`)
- □Strong Atomicity (`necessary-strong-atomicity-r`)
- □Strong Atomicity (type t) (`necessary-strong-atomicity-t`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Weak Rigid Comprehension (`necessary-weak-rigid-comprehension-r`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Atomicity by necessarily-world propositions (`necessary-world-atomicity`)
- No Contingency (signature Σ) (`no-contingency-signature-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Plenitude (`plenitude-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Self-Atomicity (`self-atomicity-r`)
- Self-Atomicity (type t) (`self-atomicity-t`)
- Strong Actuality (`strong-actuality`)
- Strong Atomicity (`strong-atomicity-r`)
- Strong Atomicity (type t) (`strong-atomicity-t`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)

### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) — `symmetric-qualitative-contrast`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- □Transversal (`necessary-transversal-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) [Σ true atom] — `symmetric-qualitative-contrast-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- □Transversal (`necessary-transversal-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) [one individual] — `symmetric-qualitative-contrast-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- □Transversal (`necessary-transversal-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) [one individual; Σ true atom] — `symmetric-qualitative-contrast-individuals-singleton-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- □Transversal (`necessary-transversal-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Qualitative-link model with a translation clock — `symmetric-qualitative-links-clock`

- Actuality (`actuality`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Atomlessness (`atomlessness`)
- Atoms are self-atoms (`atoms-are-self-atoms-r`)
- Atoms are self-atoms (type t) (`atoms-are-self-atoms-t`)
- Atoms are strong atoms (`atoms-are-strong-atoms-r`)
- Atoms are strong atoms (type t) (`atoms-are-strong-atoms-t`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- ND (`distinctness-necessary-r`)
- ND (type t) (`distinctness-necessary-t`)
- Truths are ND-necessary (`distinctness-preserving-collapse`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are ND-necessary (`five-implies-nd-necessity`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Forcing Possibilism (`forcing-possibilism`)
- Functional Choice (`functional-choice-r`)
- Functionality (`functionality-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- Intensional Choice (`intensional-choice-r`)
- Logical Necessity (`logical-necessity-r`)
- B (`modal-b`)
- 5 (`modal-five`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Atomlessness (`necessary-atomlessness`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Functionality (`necessary-functionality-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Persistent Comprehension (`necessary-persistent-comprehension-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Self-Atomicity (type t) (`necessary-self-atomicity-t`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Strong Actuality (`necessary-strong-actuality`)
- □Strong Atomicity (`necessary-strong-atomicity-r`)
- □Strong Atomicity (type t) (`necessary-strong-atomicity-t`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Vicinity (`necessary-vicinity`)
- □Weak Rigid Comprehension (`necessary-weak-rigid-comprehension-r`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- No Collapse (`no-collapse`)
- No Contingency (signature Σ) (`no-contingency-signature-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Plenitude (`plenitude-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Self-Atomicity (`self-atomicity-r`)
- Self-Atomicity (type t) (`self-atomicity-t`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are atoms (type t) (`self-atoms-are-atoms-t`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Self-atoms are strong atoms (type t) (`self-atoms-are-strong-atoms-t`)
- Separated Structure (`separated-structure-r`)
- B for sentences of Σ (`signature-b-r`)
- Strong Actuality (`strong-actuality`)
- Strong Atomicity (`strong-atomicity-r`)
- Strong Atomicity (type t) (`strong-atomicity-t`)
- Tractarianism (`tractarianism-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)
- Two-hat necessities are ND-necessary (`two-hat-implies-nd-necessity`)
- Vicinity (`vicinity`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)
- Well-Ordering (`well-ordering-r`)
- Witnessed Possibility (`witnessed-possibility-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: qualitative link structure (Base 3) — `symmetric-qualitative-links`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: qualitative link structure (Base 3) [Σ true atom] — `symmetric-qualitative-links-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: qualitative link structure (Base 3) [one individual] — `symmetric-qualitative-links-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Intensional Choice (`intensional-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: qualitative link structure (Base 3) [one individual; Σ true atom] — `symmetric-qualitative-links-individuals-singleton-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Intensional Choice (`intensional-choice-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: arrows omitting or reserving a fixed individual — `symmetric-range-gap-without-actuality`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Transversal (`necessary-transversal-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Transversal (`transversal-r`)

### Symmetric ideally-full model: arrows omitting or reserving a fixed individual [one individual] — `symmetric-range-gap-without-actuality-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Intensional Choice (`intensional-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Transversal (`necessary-transversal-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Transversal (`transversal-r`)

### Symmetric ideally-full model: arrows omitting a fixed individual — `symmetric-range-gap`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: arrows omitting a fixed individual [Σ true atom] — `symmetric-range-gap-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: arrows omitting a fixed individual [one individual] — `symmetric-range-gap-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Intensional Choice (`intensional-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: arrows omitting a fixed individual [one individual; Σ true atom] — `symmetric-range-gap-individuals-singleton-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Intensional Choice (`intensional-choice-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: recurrent finite colour approximations — `symmetric-recurrent-colours`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Intensional Choice (`intensional-choice-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- No Collapse (`no-collapse`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Transversal (`transversal-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)

### Symmetric ideally-full model: recurrent finite colour approximations [one individual] — `symmetric-recurrent-colours-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Intensional Choice (`intensional-choice-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal (`necessary-transversal-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- No Collapse (`no-collapse`)
- No Contingency (signature Σ) (`no-contingency-signature-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal (`transversal-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Symmetric surjection product: κ-pinned surjections and free words, glued constants — `symmetric-surjections-free-words-glued`

- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### Symmetric surjection product: κ-pinned surjections and free words, glued constants [individuals $U$] — `symmetric-surjections-free-words-glued-individuals-moving`

- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### Symmetric surjection product: κ-pinned surjections and free words, glued constants [free words × idempotent] — `symmetric-surjections-free-words-glued-monoid-words-idempotent`

- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### Symmetric surjection product: κ-pinned surjections and free words, glued constants [free words × idempotent; individuals $U$] — `symmetric-surjections-free-words-glued-monoid-words-idempotent-individuals-moving`

- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### Symmetric ideally-full model: N and a point, all maps — `symmetric-two-object-all-maps`

- Analytic Necessitism (`analytic-necessitism`)
- Atomlessness (`atomlessness`)
- Truths are ND-necessary (`distinctness-preserving-collapse`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are ND-necessary (`five-implies-nd-necessity`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Forcing Possibilism (`forcing-possibilism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Intensional Choice (`intensional-choice-r`)
- □Atomlessness (`necessary-atomlessness`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Transversal (`necessary-transversal-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- No Collapse (`no-collapse`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- B for pure sentences (`pure-b-r`)
- Rigid Power (`rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are atoms (type t) (`self-atoms-are-atoms-t`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Self-atoms are strong atoms (type t) (`self-atoms-are-strong-atoms-t`)
- B for sentences of Σ (`signature-b-r`)
- Transversal (`transversal-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)
- Two-hat necessities are ND-necessary (`two-hat-implies-nd-necessity`)

### Symmetric ideally-full model: N and a point, all maps [one individual] — `symmetric-two-object-all-maps-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Atomlessness (`atomlessness`)
- Truths are ND-necessary (`distinctness-preserving-collapse`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- 5-necessities are ND-necessary (`five-implies-nd-necessity`)
- 5-necessities are two-hat necessary (`five-implies-two-hat-necessity`)
- Forcing Possibilism (`forcing-possibilism`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Intensional Choice (`intensional-choice-r`)
- □Atomlessness (`necessary-atomlessness`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are self-atoms (type t) (`necessary-atoms-are-self-atoms-t`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □Atoms are strong atoms (type t) (`necessary-atoms-are-strong-atoms-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Truths are ND-necessary (`necessary-distinctness-preserving-collapse`)
- □5-necessities are ND-necessary (`necessary-five-implies-nd-necessity`)
- □5-necessities are two-hat necessary (`necessary-five-implies-two-hat-necessity`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Transversal (`necessary-transversal-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Two-hat necessities are ND-necessary (`necessary-two-hat-implies-nd-necessity`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- No Collapse (`no-collapse`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- B for pure sentences (`pure-b-r`)
- Rigid Power (`rigid-power-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are atoms (type t) (`self-atoms-are-atoms-t`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Self-atoms are strong atoms (type t) (`self-atoms-are-strong-atoms-t`)
- B for sentences of Σ (`signature-b-r`)
- Transversal (`transversal-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)
- Two-hat necessities are ND-necessary (`two-hat-implies-nd-necessity`)

### Symmetric ideally-full model: two objects, the second unpinned — `symmetric-two-object-unpinned`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: two objects, the second unpinned [Σ true atom] — `symmetric-two-object-unpinned-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetric ideally-full model: two objects, the second unpinned [one individual] — `symmetric-two-object-unpinned-individuals-singleton`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Intensional Choice (`intensional-choice-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- B for pure sentences (`pure-b-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- B for sentences of Σ (`signature-b-r`)

### Symmetric ideally-full model: two objects, the second unpinned [one individual; Σ true atom] — `symmetric-two-object-unpinned-individuals-singleton-sigma-true-atom`

- Analytic Necessitism (`analytic-necessitism`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Intensional Choice (`intensional-choice-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- B for pure sentences (`pure-b-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)

### Symmetry-constrained full model: all maps on three individuals — `symmetry-constrained-full-all-maps`

Fully determined; nothing unknown.

### Symmetry-constrained full model: all maps on three individuals [Σ true atom] — `symmetry-constrained-full-all-maps-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Symmetry-constrained full model: all maps on three individuals [one individual] — `symmetry-constrained-full-all-maps-individuals-singleton`

Fully determined; nothing unknown.

### Symmetry-constrained full model: all maps on three individuals [one individual; Σ true atom] — `symmetry-constrained-full-all-maps-individuals-singleton-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Symmetry-constrained full model: permutations and collapses on three individuals — `symmetry-constrained-full-collapse`

Fully determined; nothing unknown.

### Symmetry-constrained full model: permutations and collapses on three individuals [Σ true atom] — `symmetry-constrained-full-collapse-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Symmetry-constrained full model: permutations and collapses on three individuals [one individual] — `symmetry-constrained-full-collapse-individuals-singleton`

- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)

### Symmetry-constrained full model: permutations and collapses on three individuals [one individual; Σ true atom] — `symmetry-constrained-full-collapse-individuals-singleton-sigma-true-atom`

- Intensional Choice (`intensional-choice-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)

### Symmetry-constrained full model: a one-point object, its maps into three individuals, and their permutations — `symmetry-constrained-full-point-and-three-forward`

Fully determined; nothing unknown.

### Symmetry-constrained full model: a one-point object, its maps into three individuals, and their permutations [one individual] — `symmetry-constrained-full-point-and-three-forward-individuals-singleton`

- Atoms are self-atoms (`atoms-are-self-atoms-r`)
- Atoms are strong atoms (`atoms-are-strong-atoms-r`)
- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- Functionality (`functionality-r`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Atoms are self-atoms (`necessary-atoms-are-self-atoms-r`)
- □Atoms are strong atoms (`necessary-atoms-are-strong-atoms-r`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □Functionality (`necessary-functionality-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Self-Atomicity (`necessary-self-atomicity-r`)
- □Strong Atomicity (`necessary-strong-atomicity-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Self-Atomicity (`self-atomicity-r`)
- Strong Atomicity (`strong-atomicity-r`)
- Tractarianism (`tractarianism-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Symmetry-constrained full model: a one-point object and all maps to three individuals — `symmetry-constrained-full-point-and-three`

Fully determined; nothing unknown.

### Symmetry-constrained full model: a one-point object and all maps to three individuals [one individual] — `symmetry-constrained-full-point-and-three-individuals-singleton`

- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)

### Action model: a fork with an ultralimit world — `ultralimit-fork`

- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)

### Henkin ultraproduct: countable full S5 models with n individuals — `ultraproduct-countable-full-s5-finite-individuals`

Fully determined; nothing unknown.

### Henkin ultraproduct: finite full S5 models, n worlds and n individuals — `ultraproduct-finite-full-s5`

Fully determined; nothing unknown.

### Wreath-supported cofinite entrance over old and new individuals — `wreath-cofinite-old-new-entrance`

- Analytic Necessitism (`analytic-necessitism`)
- Arithmetic Necessitism (`arithmetic-necessitism`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- Truths are ND-necessary (`distinctness-preserving-collapse`)
- Finite-Type Analytic Necessitism (`finite-type-analytic-necessitism`)
- Finite-Type Necessitism (`finite-type-necessitism`)
- Forcing Possibilism (`forcing-possibilism`)
- Independence (signature Σ) (`independence-signature-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Self-atoms are atoms (`necessary-self-atoms-are-atoms-r`)
- □Self-atoms are atoms (type t) (`necessary-self-atoms-are-atoms-t`)
- □Self-atoms are strong atoms (`necessary-self-atoms-are-strong-atoms-r`)
- □Self-atoms are strong atoms (type t) (`necessary-self-atoms-are-strong-atoms-t`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Truths are 5-necessary (`necessary-truth-implies-five-necessity`)
- □Truths are two-hat necessary (`necessary-truth-implies-two-hat-necessity`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Analysis (`necessity-of-analysis`)
- Necessity of Second-Order Analysis (`necessity-of-second-order-analysis`)
- Non-contingency of the Continuum Hypothesis (`non-contingency-of-ch`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Second-Order Analytic Necessitism (`second-order-analytic-necessitism`)
- Self-atoms are atoms (`self-atoms-are-atoms-r`)
- Self-atoms are atoms (type t) (`self-atoms-are-atoms-t`)
- Self-atoms are strong atoms (`self-atoms-are-strong-atoms-r`)
- Self-atoms are strong atoms (type t) (`self-atoms-are-strong-atoms-t`)
- Separated Structure (`separated-structure-r`)
- B for sentences of Σ (`signature-b-r`)
- Transversal Choice (`transversal-choice-r`)
- Truths are 5-necessary (`truth-implies-five-necessity`)
- Truths are two-hat necessary (`truth-implies-two-hat-necessity`)
- Well-Ordering (`well-ordering-r`)
- Witnessed Possibility (`witnessed-possibility-r`)
- Zorn's Lemma (`zorn-r`)

## 5. Open single-premise pairs (492)

*A ⇒ B ?* means neither implication nor incompatibility nor a countermodel is currently recorded. Grouped by antecedent. Most are open only because the obvious model has not been added.

- **5** (`modal-five`) ⇒ □5-necessities are two-hat necessary, Arithmetic Necessitism, Necessity of Arithmetic, Rigid Power, □Rigid Power
- **Analytic Necessitism** (`analytic-necessitism`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary, Necessity of Arithmetic
- **Atomicity** (`atomicity-r`) ⇒ 5-necessities are two-hat necessary, Transversal, □Transversal
- **□Atomicity** (`necessary-atomicity-r`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary, Transversal, □Transversal
- **Atomicity (type t)** (`atomicity-t`) ⇒ 5-necessities are two-hat necessary, Transversal, □Transversal
- **□Atomicity (type t)** (`necessary-atomicity-t`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary, Transversal, □Transversal
- **Atomicity by necessarily-world propositions** (`necessary-world-atomicity`) ⇒ Modal Freedom (signature Σ)
- **B** (`modal-b`) ⇒ □5-necessities are two-hat necessary, Arithmetic Necessitism, Necessity of Arithmetic, Rigid Power, □Rigid Power
- **B for pure sentences** (`pure-b-r`) ⇒ Arithmetic Necessitism, Necessity of Arithmetic
- **B for sentences of Σ** (`signature-b-r`) ⇒ Arithmetic Necessitism, Necessity of Arithmetic
- **Boolean Completeness** (`boolean-completeness-r`) ⇒ 5-necessities are two-hat necessary, Arithmetic Necessitism
- **□Boolean Completeness** (`necessary-boolean-completeness-r`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary, Arithmetic Necessitism, Inextensible Comprehension, □Inextensible Comprehension
- **Boolean Completeness (type t)** (`boolean-completeness-t`) ⇒ 5-necessities are two-hat necessary
- **□Boolean Completeness (type t)** (`necessary-boolean-completeness-t`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary
- **Converse Witnessed Possibility** (`converse-witnessed-possibility-r`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary, Arithmetic Necessitism, Finite-Type Necessitism, Modal Freedom (signature Σ)
- **Countable Boolean Completeness** (`countable-boolean-completeness-r`) ⇒ 5-necessities are two-hat necessary, Arithmetic Necessitism
- **□Countable Boolean Completeness** (`necessary-countable-boolean-completeness-r`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary, Arithmetic Necessitism
- **Finite-Type Analytic Necessitism** (`finite-type-analytic-necessitism`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary, Atomicity, □Atomicity, Atomicity (type t), □Atomicity (type t), Boolean Completeness, □Boolean Completeness, Boolean Completeness (type t), □Boolean Completeness (type t), Countable Boolean Completeness, □Countable Boolean Completeness, Inextensible Comprehension, □Inextensible Comprehension, Necessity of Arithmetic, Rigid Power, □Rigid Power, Tame Rigidity, □Tame Rigidity, Vicinity, □Vicinity, Weakly Inextensible Comprehension, □Weakly Inextensible Comprehension, Weakly Rigid Power, □Weakly Rigid Power
- **Finite-Type Necessitism** (`finite-type-necessitism`) ⇒ 5-necessities are two-hat necessary, Transversal
- **Forcing Possibilism** (`forcing-possibilism`) ⇒ 5-necessities are two-hat necessary, Actuality, Arithmetic Necessitism, Finite-Type Necessitism, Inextensible Comprehension, Persistent Comprehension, Relational Choice, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Well-Ordering, Zorn's Lemma
- **Functional Choice** (`functional-choice-r`) ⇒ □5-necessities are two-hat necessary, Arithmetic Necessitism, Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Finite-Type Necessitism, Inextensible Comprehension, Necessity of Arithmetic, □Relational Choice, Rigid Comprehension, Rigid Power, □Rigid Power, Tame Rigidity, □Transversal, □Transversal Choice, Weak Rigid Comprehension, Weakly Rigid Power, □Well-Ordering
- **□Functional Choice** (`necessary-functional-choice-r`) ⇒ Modal Freedom (signature Σ)
- **Gallin Extensional Comprehension** (`gallin-extensional-comprehension-r`) ⇒ □5-necessities are two-hat necessary, Arithmetic Necessitism, Finite-Type Necessitism, Necessity of Arithmetic, Rigid Power, □Rigid Power, □Self-atoms are atoms, □Self-atoms are atoms (type t), □Self-atoms are strong atoms, □Self-atoms are strong atoms (type t), □Transversal
- **□Gallin Extensional Comprehension** (`necessary-gallin-extensional-comprehension-r`) ⇒ Modal Freedom (signature Σ)
- **Independence (signature Σ)** (`independence-signature-r`) ⇒ 5-necessities are two-hat necessary, Arithmetic Necessitism, Finite-Type Necessitism, Transversal
- **Inextensible Comprehension** (`inextensible-comprehension-r`) ⇒ 5-necessities are two-hat necessary
- **□Inextensible Comprehension** (`necessary-inextensible-comprehension-r`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary
- **Intensional Choice** (`intensional-choice-r`) ⇒ Transversal, □Transversal
- **□Intensional Choice** (`necessary-intensional-choice-r`) ⇒ Transversal, □Transversal
- **Logical Necessity** (`logical-necessity-r`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary, Arithmetic Necessitism, Axiom of Infinity (type t), Countable Boolean Completeness, □Countable Boolean Completeness, Finite-Type Necessitism, Infinity Schema (type t), Possible Infinity (type t), Tame Rigidity, □Tame Rigidity, Transversal, □Transversal
- **Maximalism (pure)** (`distinctness-schema-r`) ⇒ 5-necessities are two-hat necessary, Finite-Type Necessitism, No Collapse, Relational Choice, Transversal, Transversal Choice, Well-Ordering, Zorn's Lemma
- **Maximalism (signature Σ)** (`distinctness-signature-r`) ⇒ 5-necessities are two-hat necessary, Axiom of Infinity (type e), Finite-Type Necessitism, Infinity Schema (type e), No Collapse, Relational Choice, Transversal, Transversal Choice, Well-Ordering, Zorn's Lemma
- **Modal Freedom (signature Σ)** (`modal-freedom-signature-r`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary, Arithmetic Necessitism, Finite-Type Necessitism
- **Modalized Relational Choice** (`modalized-relational-choice-r`) ⇒ Modal Well-Ordering, Transversal, □Transversal, Transversal Choice, □Transversal Choice, Well-Ordering, □Well-Ordering, Zorn's Lemma
- **□Modalized Relational Choice** (`necessary-modalized-relational-choice-r`) ⇒ Modal Well-Ordering, Transversal, □Transversal, Transversal Choice, □Transversal Choice, Well-Ordering, □Well-Ordering, Zorn's Lemma
- **ND** (`distinctness-necessary-r`) ⇒ □5-necessities are two-hat necessary, Arithmetic Necessitism, Necessity of Arithmetic, Rigid Power, □Rigid Power
- **ND (type t)** (`distinctness-necessary-t`) ⇒ □5-necessities are two-hat necessary, Arithmetic Necessitism, Necessity of Arithmetic, Rigid Power, □Rigid Power
- **Necessity of Analysis** (`necessity-of-analysis`) ⇒ Necessity of Arithmetic
- **Necessity of Arithmetic** (`necessity-of-arithmetic`) ⇒ Arithmetic Necessitism
- **Necessity of Second-Order Analysis** (`necessity-of-second-order-analysis`) ⇒ Necessity of Arithmetic
- **No Collapse** (`no-collapse`) ⇒ 5, 5-necessities are ND-necessary, 5-necessities are two-hat necessary, Actuality, Analytic Necessitism, Arithmetic Necessitism, Atomicity, □Atomicity, Atomicity (type t), □Atomicity (type t), Atoms are self-atoms, □Atoms are self-atoms, Atoms are self-atoms (type t), □Atoms are self-atoms (type t), Atoms are strong atoms, □Atoms are strong atoms, Atoms are strong atoms (type t), □Atoms are strong atoms (type t), Axiom of Infinity (type e), Axiom of Infinity (type t), B, B for pure sentences, B for sentences of Σ, BF, □BF, BF (relational types), □BF (relational types), BF (type t), □BF (type t), Boolean Completeness, □Boolean Completeness, Boolean Completeness (type t), □Boolean Completeness (type t), Countable Boolean Completeness, □Countable Boolean Completeness, Finite-Type Analytic Necessitism, Finite-Type Necessitism, Forcing Possibilism, Functional Choice, Functionality, □Functionality, Gallin Extensional Comprehension, Independence (signature Σ), Inextensible Comprehension, □Inextensible Comprehension, Infinity Schema (type e), Infinity Schema (type t), Intensional Choice, □Intensional Choice, Maximalism (pure), Maximalism (signature Σ), Modal Well-Ordering, Modalized Relational Choice, □Modalized Relational Choice, ND, ND (type t), Necessity of Analysis, Necessity of Arithmetic, Necessity of Second-Order Analysis, Non-contingency of the Continuum Hypothesis, Persistent Comprehension, Plenitude, Possibility+ (pure), Possibility+ (signature Σ), Possible Infinity (type e), Possible Infinity (type t), Possibly Witnessed Possibility, Relational Choice, □Relational Choice, Rigid Comprehension, Rigid Power, □Rigid Power, Rigid Rigidity, □Rigid Rigidity, Second-Order Analytic Necessitism, Self-atoms are atoms, □Self-atoms are atoms, Self-atoms are atoms (type t), □Self-atoms are atoms (type t), Self-atoms are strong atoms, □Self-atoms are strong atoms, Self-atoms are strong atoms (type t), □Self-atoms are strong atoms (type t), Separated Structure, Strong Actuality, Strong Possibility (pure), Strong Possibility (signature Σ), Tame Rigidity, □Tame Rigidity, Tractarianism, □Tractarianism, Transversal, □Transversal, Transversal Choice, □Transversal Choice, Truths are 5-necessary, □Truths are 5-necessary, Truths are ND-necessary, Truths are two-hat necessary, Two-hat necessities are ND-necessary, Vicinity, Weak Rigid Comprehension, Weakly Inextensible Comprehension, □Weakly Inextensible Comprehension, Weakly Rigid Power, □Weakly Rigid Power, Weakly Rigid Weak Rigidity, □Weakly Rigid Weak Rigidity, Well-Ordering, □Well-Ordering, Witnessed Possibility, Zorn's Lemma
- **No Contingency (signature Σ)** (`no-contingency-signature-r`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary, Analytic Necessitism, Arithmetic Necessitism, Finite-Type Analytic Necessitism, Finite-Type Necessitism, Second-Order Analytic Necessitism
- **No Pure Contingency** (`no-pure-contingency-r`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary, Arithmetic Necessitism, Finite-Type Necessitism, Modal Freedom (signature Σ)
- **Non-contingency of the Continuum Hypothesis** (`non-contingency-of-ch`) ⇒ Necessity of Arithmetic
- **Plenitude** (`plenitude-r`) ⇒ □5-necessities are two-hat necessary, Arithmetic Necessitism, Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Finite-Type Necessitism, Necessity of Arithmetic, Rigid Power, □Rigid Power, □Transversal, Weak Rigid Comprehension
- **□Plenitude** (`necessary-plenitude-r`) ⇒ Modal Freedom (signature Σ)
- **Possibility+ (pure)** (`possibility-plus-r`) ⇒ 5-necessities are two-hat necessary, Finite-Type Necessitism, No Collapse, Relational Choice, Transversal, Transversal Choice, Well-Ordering, Zorn's Lemma
- **Possibility+ (signature Σ)** (`possibility-plus-signature-r`) ⇒ 5-necessities are two-hat necessary, Axiom of Infinity (type e), Finite-Type Necessitism, Infinity Schema (type e), No Collapse, Relational Choice, Transversal, Transversal Choice, Well-Ordering, Zorn's Lemma
- **Possibly Witnessed Possibility** (`possibly-witnessed-possibility-r`) ⇒ 5-necessities are two-hat necessary, Arithmetic Necessitism, Axiom of Infinity (type t), Finite-Type Necessitism, Infinity Schema (type t), Possible Infinity (type t), Transversal
- **Relational Choice** (`relational-choice-r`) ⇒ Transversal, Transversal Choice, Well-Ordering, Zorn's Lemma
- **□Relational Choice** (`necessary-relational-choice-r`) ⇒ Transversal, □Transversal, Transversal Choice, □Transversal Choice, Well-Ordering, □Well-Ordering, Zorn's Lemma
- **Rigid Comprehension** (`rigid-comprehension-r`) ⇒ □5-necessities are two-hat necessary, Arithmetic Necessitism, □Transversal
- **Rigid Power** (`rigid-power-r`) ⇒ Arithmetic Necessitism, Necessity of Arithmetic
- **□Rigid Power** (`necessary-rigid-power-r`) ⇒ Arithmetic Necessitism, Necessity of Arithmetic
- **Second-Order Analytic Necessitism** (`second-order-analytic-necessitism`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary, Finite-Type Analytic Necessitism, Necessity of Arithmetic
- **□Self-atoms are atoms** (`necessary-self-atoms-are-atoms-r`) ⇒ Self-atoms are strong atoms, Self-atoms are strong atoms (type t)
- **Self-atoms are atoms (type t)** (`self-atoms-are-atoms-t`) ⇒ Self-atoms are atoms
- **□Self-atoms are atoms (type t)** (`necessary-self-atoms-are-atoms-t`) ⇒ Self-atoms are atoms, □Self-atoms are atoms, Self-atoms are strong atoms, Self-atoms are strong atoms (type t)
- **Self-atoms are strong atoms (type t)** (`self-atoms-are-strong-atoms-t`) ⇒ Self-atoms are atoms, Self-atoms are strong atoms
- **□Self-atoms are strong atoms (type t)** (`necessary-self-atoms-are-strong-atoms-t`) ⇒ Self-atoms are atoms, □Self-atoms are atoms, Self-atoms are strong atoms, □Self-atoms are strong atoms
- **Separated Structure** (`separated-structure-r`) ⇒ 5-necessities are two-hat necessary, Arithmetic Necessitism, Axiom of Infinity (type t), Finite-Type Necessitism, Infinity Schema (type t), Possible Infinity (type t), Transversal
- **Strong Possibility (pure)** (`strong-possibility-r`) ⇒ 5-necessities are two-hat necessary, Actuality, Atomlessness, Atoms are self-atoms, Atoms are self-atoms (type t), Atoms are strong atoms, Atoms are strong atoms (type t), Boolean Completeness (type t), Finite-Type Necessitism, Forcing Possibilism, Independence (signature Σ), Inextensible Comprehension, No Collapse, Persistent Comprehension, Possibility+ (pure), Relational Choice, Rigid Power, Tame Rigidity, Transversal, Transversal Choice, Truths are 5-necessary, Truths are two-hat necessary, Vicinity, Weakly Inextensible Comprehension, Weakly Rigid Power, Well-Ordering, Witnessed Possibility, Zorn's Lemma
- **Strong Possibility (signature Σ)** (`strong-possibility-signature-r`) ⇒ 5-necessities are ND-necessary, 5-necessities are two-hat necessary, Actuality, Atomlessness, Atoms are self-atoms, Atoms are self-atoms (type t), Atoms are strong atoms, Atoms are strong atoms (type t), Axiom of Infinity (type e), BF, BF (relational types), BF (type t), Boolean Completeness (type t), Finite-Type Necessitism, Forcing Possibilism, Functionality, Inextensible Comprehension, Infinity Schema (type e), No Collapse, Persistent Comprehension, Possibility+ (pure), Possibility+ (signature Σ), Relational Choice, Rigid Power, Strong Actuality, Tame Rigidity, Tractarianism, Transversal, Transversal Choice, Truths are 5-necessary, Truths are two-hat necessary, Two-hat necessities are ND-necessary, Vicinity, Weakly Inextensible Comprehension, Weakly Rigid Power, Well-Ordering, Zorn's Lemma
- **Truths are 5-necessary** (`truth-implies-five-necessity`) ⇒ 5-necessities are two-hat necessary, Truths are two-hat necessary
- **□Truths are 5-necessary** (`necessary-truth-implies-five-necessity`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary, Truths are two-hat necessary, □Truths are two-hat necessary
- **Weak Rigid Comprehension** (`weak-rigid-comprehension-r`) ⇒ Arithmetic Necessitism, □Transversal
- **□Weak Rigid Comprehension** (`necessary-weak-rigid-comprehension-r`) ⇒ Arithmetic Necessitism, Inextensible Comprehension, □Inextensible Comprehension
- **Weakly Inextensible Comprehension** (`weakly-inextensible-comprehension-r`) ⇒ 5-necessities are two-hat necessary
- **□Weakly Inextensible Comprehension** (`necessary-weakly-inextensible-comprehension-r`) ⇒ 5-necessities are two-hat necessary, □5-necessities are two-hat necessary
- **Weakly Rigid Power** (`weakly-rigid-power-r`) ⇒ Arithmetic Necessitism, Necessity of Arithmetic
- **□Weakly Rigid Power** (`necessary-weakly-rigid-power-r`) ⇒ Arithmetic Necessitism, Necessity of Arithmetic
- **Witnessed Possibility** (`witnessed-possibility-r`) ⇒ 5-necessities are two-hat necessary, Arithmetic Necessitism, Axiom of Infinity (type t), Finite-Type Necessitism, Infinity Schema (type t), Possible Infinity (type t), Transversal

## 6. Deliberately deferred

`topics/classicism/extraction.md` has a section listing claims that were **not** recorded because they need a further reading of the sources. Those are marked deferred rather than open: the answer is likely in the literature and needs transcribing, not discovering. Read that section before starting work.

## 7. How to record an answer

- Proved an implication? Add `topics/classicism/results/<id>.yaml` with the full premise list and the proof.
- Refuted one? Add `topics/classicism/models/<id>.yaml` listing what you verified in `satisfies` and `violates`.
- Settling an existing conjecture? For a proof of the same statement, keep its ID, set `was_conjectured: true`, and change its status to `proved`. If the statement changes substantially, retain the original and add a separate record. Refuted proposals stay `status: conjectured`, with proved refuting evidence recorded separately. Answers under extra exploration assumptions are contextual, not global record statuses.
- Worked on a question without settling it? Put what you tried and what would settle it in the conjecture's `notes`; that alone earns it a bronze lynchpin star. Say in the notes whether you think it deserves silver or gold, by importance and difficulty, and why. Only a human sets `tier: silver` or `tier: gold`; an agent never does.
- Not sure? Add it with `status: conjectured`, an empty proof, and say in `notes` what would settle it.
- Then run `python3 scripts/pmap.py validate` and `status`. Never hand-edit the derived counts.

`README.md` has the exact record shapes and the sourcing rules. Follow them; an unsourced or misattributed record is worse than an absent one.
